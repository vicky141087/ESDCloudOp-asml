import os
import pandas as pd
import numpy as np
import unittest
from copy import deepcopy

from pyeuv.Collector.Radon import radon_io, radd
from pyeuv.Collector.Radon.shared import get_normalized_intensity, get_radius, get_phi, phi_to_hour
from pyeuv.Collector.Radon.radon_image_processing import create_delta_image
from pyeuv.Collector.Radon.radon_scaling import get_scaling
from pyeuv.Collector.Radon.radd import detect_rois, link_to_existing_rois, update_rois_with_roi_as_key


class TestRadd(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # image 1: whole row 3, except the outside 2 keys, to 0 --> new roi
        # image 2: add row 2 and 4, except the outside 2 keys, to 0 --> 1 bigger roi
        # image 3: row 3, except the outside 2 keys, back to 100 --> 2 rois, 2 new nrs
        # image 4: row 3, except the outside 2 keys, back to 0 --> 1 roi, new nr

        # load the generic reference
        filename = 'generic_reference_median_per_mirror_and_pupil_3400.dat'
        ref_dict = dict()
        ref_dir = radon_io.get_reference_directory()
        ref_dict['data'] = radon_io.load_dots(os.path.join(ref_dir, filename))
        ref_dict['data']['reflectivity'] = 100
        ref_dict['timestamp'] = pd.Timestamp(0).tz_localize('UTC')
        ref_dict['pc'] = 0

        luers_dict = {}
        target_image = deepcopy(ref_dict)
        for i in range(2, 13):
            target_image['data']['reflectivity'].loc['3_' + str(i)] = 0
        target_image['timestamp'] = target_image['timestamp'] + pd.to_timedelta('1d')
        target_image['pc'] = target_image['pc'] + 1
        luers_dict[1] = target_image

        target_image = deepcopy(target_image)
        for i in range(2, 13):
            target_image['data']['reflectivity'].loc['2_' + str(i)] = 0
            target_image['data']['reflectivity'].loc['4_' + str(i)] = 0
        target_image['timestamp'] = target_image['timestamp'] + pd.to_timedelta('1d')
        target_image['pc'] = target_image['pc'] + 1
        luers_dict[2] = target_image

        target_image = deepcopy(target_image)
        for i in range(2, 13):
            target_image['data']['reflectivity'].loc['3_' + str(i)] = 100
        target_image['timestamp'] = target_image['timestamp'] + pd.to_timedelta('1d')
        target_image['pc'] = target_image['pc'] + 1
        luers_dict[3] = target_image

        target_image = deepcopy(target_image)
        for i in range(2, 13):
            target_image['data']['reflectivity'].loc['3_' + str(i)] = 0
        target_image['timestamp'] = target_image['timestamp'] + pd.to_timedelta('1d')
        target_image['pc'] = target_image['pc'] + 1
        luers_dict[4] = target_image

        image_data = {}
        rois_image_as_key = {}
        rois_roi_as_key = {}

        # RADD detection and linking
        for key, luer_dict in luers_dict.items():
            # perform detection of ROIs
            luer_dict = detect_rois(luers_dict, key)
            # tornado: link to ROIs in previous luer
            luer_dict = link_to_existing_rois(luers_dict, key)
            # collect data
            image_data[key] = luer_dict
            rois_image_as_key[key] = luer_dict['rois']
            rois_roi_as_key = update_rois_with_roi_as_key(rois_roi_as_key, luer_dict, key)

        cls.image_data = image_data
        cls.rois_image_as_key = rois_image_as_key
        cls.rois_roi_as_key = rois_roi_as_key

    def test_amount_of_images(self):
        # check if all images in dict
        self.assertEqual(4, len(self.rois_image_as_key))

    def test_amount_of_rois(self):
        # check if correct amount of rois are detected
        self.assertEqual(1, len(self.rois_image_as_key[1]))
        self.assertEqual(1, len(self.rois_image_as_key[2]))
        # TODO: fix, output is just 1 roi
        self.assertEqual(2, len(self.rois_image_as_key[3]))
        self.assertEqual(1, len(self.rois_image_as_key[4]))

        # check that there are a total of 4 rois
        # TODO: fix, image 3 should introduce 2 new rois (because it's a split)
        #  and image 4 should introduce another new roi so in total 4
        self.assertEqual(4, len(self.rois_roi_as_key))

    def test_content_dicts(self):
        # metrics from roi 0 in image 1 should be equal to metrics from image 1 in roi 0
        self.assertTrue(self.rois_image_as_key[1][0] == self.rois_roi_as_key[0][1])
        # the same for roi 1 in image 3
        self.assertTrue(self.rois_image_as_key[3][1] == self.rois_roi_as_key[1][3])

    def test_parents(self):
        self.assertEqual([0], self.rois_image_as_key[3][1]['parents'])
        self.assertEqual([0], self.rois_image_as_key[3][2]['parents'])

        self.assertEqual([1, 2], self.rois_image_as_key[4][3]['parents'])

    def test_ancestors(self):
        np.testing.assert_array_equal([0, 1, 2],  self.rois_image_as_key[4][3]['ancestors'])

    def test_main_ancestors(self):
        self.assertEqual(0, self.rois_image_as_key[4][3]['main_ancestor'])
