import pandas as pd
import numpy as np
import unittest

from pyeuv.EUVDashboard.clients import UserLANClient, get_euvdb_test_credentials
from influxdb.exceptions import InfluxDBClientError


class TestEUVDashboard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        username, password = get_euvdb_test_credentials()
        cls.client = UserLANClient(
            username, password, cache_dir='./test_data/cache')

    def test_get_signals_1h_last(self):
        """ Check if we can get aggreated data """
        data = self.client.get_signals(
            ['s38441.RT05.BDenergyAvgOn.1h.last'],
            pd.Timestamp('2018-01-01'),
            pd.Timestamp('2018-01-20')
        )

        if data.empty:
            assert False

    def test_get_signals(self):
        """ Check if we can get unaggregated data"""
        data = self.client.get_signals(
            ['s38441.RT05.BDenergyAvgOn'],
            pd.Timestamp('2018-01-15'),
            pd.Timestamp('2018-01-26')
        )

        if data.empty:
            assert False

    def test_get_signals_str(self):
        """ Check if get_signals works with string signals """
        data = self.client.get_signals(
            's38441.RT05.BDenergyAvgOn',
            pd.Timestamp('2018-01-15'),
            pd.Timestamp('2018-01-26')
        )

        if data.empty:
            assert False

    def test_get_multiple_signals(self):
        """ Check if we can get two signals out simultaneously"""
        data = self.client.get_signals(
            [
                's38441.RT05.BDenergyAvgOn.1h.last',
                's38441.RT05.BDenergyStdOn.1h.last'
            ],
            pd.Timestamp('2018-01-15'),
            pd.Timestamp('2018-01-20')
        )

        if data.empty:
            assert False
        if len(data.columns) != 2:
            assert False

    def test_chunk_size(self):
        """ Check if the chunksize limit works """
        signal = 's38441.RT05.BDenergyAvgOn.1h.mean'

        chunk_generator = self.client.chunk_signal(
            signal,
            from_time=pd.Timestamp('2018-01-15'),
            to_time=pd.Timestamp('2018-01-20'),
            chunksize=10
        )

        for chunk in chunk_generator:
            if len(chunk) > 10:
                assert False

    def test_get_empty_data(self):
        """ Check if we get the right response if there is no data"""
        data = self.client.get_signals(
            [
                's38441.RT05.BDenergyAvgOn.1h.last',
                's38441.RT05.BDenergyStdOn.1h.last'
            ],
            # This range will definetly not return any data
            pd.Timestamp('2018-01-15'),
            pd.Timestamp('2017-01-20')
        )

        if not isinstance(data, pd.DataFrame):
            assert False
        if not data.empty:
            assert False

    def test_perform_bad_query(self):
        """ Check if we get the right response for a bad query """
        try:
            data = self.client.get_signals(
                ['Harr.Jar.Fiddle.Li.Dee'],
                # This range will definetly not return any data
                pd.Timestamp('2018-01-15'),
                pd.Timestamp('2018-01-20')
            )

        # Expect this error
        except InfluxDBClientError as e:
            assert True
        else:
            assert False

    def test_get_machine_list(self):
        """ Check if we can get the machine list """
        machine_list = self.client.get_machine_list()

        # Should return a list by default
        if type(machine_list) != list:
            assert False

        if len(machine_list) == 0:
            assert False

        machine_list = self.client.get_machine_list(return_type='dataframe')
        if not isinstance(machine_list, pd.DataFrame) and len(machine_list) > 0:
            assert False

    def test_last_value_before(self):
        """ Check if this function runs without error and returns 1 value """
        data_rt = self.client.get_last_value_before(
            's38441.RT05.BDenergyAvgOn',
            pd.Timestamp('2018-09-04')
        )

        if len(data_rt) != 1:
            assert False

        if data_rt.index > pd.Timestamp('2018-09-04', tz='utc'):
            assert False

        data_pvp = self.client.get_last_value_before(
            's38441.Source_PVP.POWER_LIMIT_MMDC',
            pd.Timestamp('2018-09-04')
        )

        if len(data_pvp) != 1:
            assert False

    def test_last_value_before_aggregate(self):
        """ Checks if the functions works when the signal contains an aggregate """
        data = self.client.get_last_value_before(
            's44481.Scanner.DW_SS_cf_anchor.1d.last',
            pd.Timestamp('2018-01-01')
        )

        if len(data) != 1:
            assert False

    def test_first_value_after_aggregate(self):
        """ Checks if the functions works when the signal contains an aggregate """
        data = self.client.get_first_value_after(
            's44481.Scanner.DW_SS_cf_anchor.1d.last',
            pd.Timestamp('2018-01-01')
        )

        if len(data) != 1:
            assert False

        if data.index < pd.Timestamp('2018-01-01', tz='utc'):
            assert False

    def test_tag_filter(self):
        """ Checks if the tag filter runs """
        data_raw = self.client.get_signals(
            ['s62265.RT23.TFMmajorAxis'],
            pd.Timestamp('2018-08-23 14:00:00'),
            pd.Timestamp('2018-08-23 15:00:00')
        )

        data_single_malt = self.client.get_signals(
            ['s62265.RT23.TFMmajorAxis{subroutine=MP}'],
            pd.Timestamp('2018-08-23 14:00:00'),
            pd.Timestamp('2018-08-23 15:00:00')
        )

        data_double_malt = self.client.get_signals(
            ['s62265.RT23.TFMmajorAxis{subroutine=MP}{in_spec=True}'],
            pd.Timestamp('2018-08-23 14:00:00'),
            pd.Timestamp('2018-08-23 15:00:00')
        )

        if data_raw.empty or data_single_malt.empty or data_double_malt.empty:
            assert False

        # Verify that the filter had effect
        if len(data_single_malt) >= len(data_raw):
            assert False
        if len(data_double_malt) >= len(data_single_malt):
            assert False

        assert True

    def test_tag_filter2(self):
        """ Checks if the tag filter works with the name keyword (reserved)"""
        data_raw = self.client.get_signals(
            ['s39811.Context.Source.System.CPD_operation'],
            pd.Timestamp('2019-01-01 14:00:00'),
            pd.Timestamp('2019-04-08 15:00:00')
        )

        data_single_malt = self.client.get_signals(
            ['s39811.Context.Source.System.CPD_operation{name=CPDFFAPCM}'],
            pd.Timestamp('2019-01-01 14:00:00'),
            pd.Timestamp('2019-04-08 15:00:00')
        )

        if data_raw.empty or data_single_malt.empty:
            assert False

        # Verify that the filter had effect
        if len(data_single_malt) >= len(data_raw):
            assert False

        assert True

    def test_tag_filter_field(self):
        """ Checks if the tag filter works nicely with fields """
        data_default = self.client.get_signals(
            ['s62265.RT23.TFMmajorAxis{subroutine=MP}{in_spec=True}'],
            pd.Timestamp('2018-08-23 14:00:00'),
            pd.Timestamp('2018-08-23 15:00:00')
        )

        data_field = self.client.get_signals(
            ['s62265.RT23.TFMmajorAxis[value]{subroutine=MP}{in_spec=True}'],
            pd.Timestamp('2018-08-23 14:00:00'),
            pd.Timestamp('2018-08-23 15:00:00')
        )

        if data_default is None or data_field is None:
            assert False
        elif len(data_default) != len(data_field):
            assert False
        else:
            assert True

    def test_tag_filter_field_nodata(self):
        """ Check if an empty tag filter gets ignored """
        data_default = self.client.get_signals(
            ['s62269.SourceLog.OSD-0200[max_dose_error]{}'],
            pd.Timestamp('2018-12-01 12:00:00'),
            pd.Timestamp('2018-12-10 15:00:00')
        )
        data_empty_tags = self.client.get_signals(
            ['s62269.SourceLog.OSD-0200[max_dose_error]{}'],
            pd.Timestamp('2018-12-01 12:00:00'),
            pd.Timestamp('2018-12-10 15:00:00')
        )

        # The empty tag filter should make no difference.
        if len(data_default) != len(data_empty_tags):
            assert False

    def test_tag_filter_missing_key(self):
        """ Check if a KeyError is thrown when a key is missing """
        try:
            data = self.client.get_signals(
                ['s62265.RT23.TFMmajorAxis{waffles=MP}'],
                pd.Timestamp('2018-08-23 14:00:00'),
                pd.Timestamp('2018-08-23 15:00:00')
            )
        except KeyError:
            assert True
        else:
            assert False

    def test_tag_filter_missing_value(self):
        """ Check if a ValueError is thrown when a missing tag value is requested """
        try:
            data = self.client.get_signals(
                ['s62265.RT23.TFMmajorAxis{subroutine=DanceParty}'],
                pd.Timestamp('2018-08-23 14:00:00'),
                pd.Timestamp('2018-08-23 15:00:00')
            )
        except ValueError:
            assert True
        else:
            assert False

    def test_get_wildcard_field(self):
        """ Checks if we get multiple columns when using the wildcard field """
        tstart = pd.Timestamp('2018-09-01 00:00:00')
        tstop = pd.Timestamp('2018-09-05 00:00:00')

        signals = [
            "s62269.SourceLog.OSD-0200[*]"
        ]

        df = self.client.get_signals(signals, tstart, tstop)

        if df is None or len(df) == 0:
            assert False
        elif len(df.columns) > 1:
            assert True
        else:
            assert False

    def test_authorization_error(self):
        """ Makes sure that an authorization error is handled correctly """
        try:
            bad_client = UserLANClient(username='donald', password='trump')
        except InfluxDBClientError:
            assert True
        else:
            assert False

    def test_get_signal_list(self):
        """ Checks if we can get a signal list """

        machine = {
            'name': 'Proto 7',
            'source_nr': '38441',
            'machine_nr': '6224'
        }

        machine_list = None
        machine_list = self.client.get_signal_list('s38441')
        if len(machine_list) <= 0:
            assert False

        machine_list = None
        machine_list = self.client.get_signal_list('m6224')
        if len(machine_list) <= 0:
            assert False

        machine_list = None
        machine_list = self.client.get_signal_list(machine)
        if len(machine_list) <= 0:
            assert False

    def test_last_value_mode(self):
        """ Checks if this mode runs w/o errors"""
        data = self.client.get_signals(
            ['s38441.RT05.BDenergyAvgOn'],
            pd.Timestamp('2018-01-15 13:30:00'),
            pd.Timestamp('2018-01-15 13:35:00'),
            last_value=True
        )

        if len(data) != 1:
            assert False

    def test_defaults(self):
        """ Checks if defaults are returned in this mode """
        defaults = {
            's38441.RT05.BDenergyAvgOn': 3.42
        }

        data = self.client.get_signals(
            ['s38441.RT05.BDenergyAvgOn'],
            # This time range will not return data
            pd.Timestamp('2018-01-16 13:30:00'),
            pd.Timestamp('2018-01-15 13:35:00'),
            defaults=defaults
        )

        # Expect the default
        if np.abs((data.iloc[0, 0] - 3.42)) > 0.001:
            assert False

    def test_last_value_with_defaults_mode(self):
        """ Checks if this mode works w/o erors """

        defaults = {
            's38441.RT05.BDenergyAvgOn': 3.42
        }

        data = self.client.get_signals(
            ['s38441.RT05.BDenergyAvgOn'],
            # This time range will not return data
            pd.Timestamp('2018-01-16 13:30:00'),
            pd.Timestamp('2018-01-15 13:35:00'),
            last_value=True,
            defaults=defaults
        )

        # Expect last value, not the default
        if np.abs((data.iloc[0, 0] - 3.42)) < 0.001:
            assert False

        data = self.client.get_signals(
            ['s38441.RT05.BDenergyAvgOn'],
            # This time range will not return data, not even a last value.
            pd.Timestamp('2000-01-16 13:30:00'),
            pd.Timestamp('2000-01-15 13:35:00'),
            last_value=True,
            defaults=defaults
        )

        # Expect the default
        if np.abs((data.iloc[0, 0] - 3.42)) > 0.001:
            assert False

    def test_groupby_chunk_behavior(self):
        """
        Chunking must not affect the returned data. Chunks must be adjusted to
        avoid interrupting groups.

        Example:

        group size: 3
        agg method: last
        t :  0  1  2  3  4  5  6  7  8  9  10
        x :  0  1  2  3  4  5  6  7  8  9  10
        tg:  0        3        6        9
        xg:  2        5        8        10
                                        ^
                                        group is based on only 2 points i.s.o 3
                                        adjust tstop for this chunk and tstart
                                        for the next chunk to 9.
        """
        tstart = pd.Timestamp('2018-01-04 07:00:01')
        tstop = pd.Timestamp('2018-01-04 07:00:32')
        signals = ['s38441.RT05.BDenergyAvgOn.10s.mean']

        df = self.client.get_signals(signals, tstart, tstop, chunksize=2)

        # Test for expected value
        if np.abs((df.iloc[-1, 0] - 3.00868)) > 0.00001:
            assert False

    def test_groupby_chunk_behaviour_small_chunks(self):
        """
        Chunking signals with different aggregation periods and small chunks.
        """
        tstart = pd.Timestamp('2018-01-04 07:00:01')
        tstop = pd.Timestamp('2018-01-04 07:01:00')
        signals = ['s38441.RT05.BDenergyAvgOn.3s.mean',
                   's38441.RT05.BDenergyAvgOn.10s.mean',
                   's38441.RT05.BDenergyAvgOn']

        df = self.client.get_signals(signals, tstart, tstop, chunksize=2)
        if len(df['s38441.RT05.BDenergyAvgOn.3s.mean'].dropna()) != 19:
            assert False

        if len(df['s38441.RT05.BDenergyAvgOn.10s.mean'].dropna()) != 6:
            assert False

        if len(df['s38441.RT05.BDenergyAvgOn'].dropna()) != 61:
            assert False

    def test_groupby_chunk_behaviour_small_chunk_large_window(self):
        """
        Using small chunks and a large time windows may cause that the time window exceeds
        CHUNK_SIZE * aggregation_time. This will test if the chunking loop can handle this
        correctly.
        """

        df = self.client.get_signals(
            signals=['s62265.RT05.BDenergyTargetAvg.1m.mean'],
            from_time=pd.Timestamp('2017-01-01'),
            to_time=pd.Timestamp('2017-05-01')
        )
        if len(df) >= 5253:
            assert True
        else:
            assert False  # Data was skipped

    def test_get_tag_keys(self):
        """ Checks if we get the expected tags for RT23.TFMdebrisArea """
        signal_name = 's38441.RT23.TFMdebrisArea'
        signal_tags = self.client.get_tag_keys(signal_name)

        if type(signal_tags) != list:
            assert False
        if len(signal_tags) == 0:
            assert False
        if 'subroutine' not in signal_tags:
            assert False

    def test_get_tag_values(self):
        """ Checks that we get the 'MP' subroutine tag value for
        the RT23.TFMdebrisArea signal """
        signal_name = 's38441.RT23.TFMdebrisArea'
        tag_name = 'subroutine'

        tag_values = self.client.get_tag_values(signal_name, tag_name)

        if type(tag_values) != list:
            assert False
        if len(tag_values) == 0:
            assert False
        if 'Debris' not in tag_values:
            assert False

    def test_get_cached(self):
        """ Check if we can get unaggregated data using the cached version of get_signals"""
        data = self.client.get_signals_cached(
            ['s38441.RT05.BDenergyAvgOn'],
            pd.Timestamp('2018-01-15'),
            pd.Timestamp('2018-01-26')
        )
        if 's38441.RT05.BDenergyAvgOn' not in self.client.cache.list_signals():
            assert False

        if data.empty:
            assert False

        # Test if the cached version of get_signals returns the same result
        data_live = self.client.get_signals(
            ['s38441.RT05.BDenergyAvgOn'],
            pd.Timestamp('2018-01-15'),
            pd.Timestamp('2018-01-26')
        )

        assert data.equals(data_live)
