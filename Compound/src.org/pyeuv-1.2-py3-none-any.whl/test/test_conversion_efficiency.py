import unittest
import pandas as pd
from pyeuv.SourcePerformance.conversion_efficiency import ConversionEfficiency as CE


class CETests(unittest.TestCase):

    def test_processing_ce_machine_version_s3_missing_rt26(self):
        """
        Tests for S3 systems that the CE metric returns an empty dataframe when rt26 input data is missing
        """

        rt05 = pd.read_csv('test_data/staging_csv/RT05/66224_DB-RT_5-20181009-215959-20181009-221500.csv',
                           index_col='Timestamp')
        rt05.index = pd.to_datetime(rt05.index)
        rt05 = rt05[['BDenergyAvgOn', 'BDfcem1MpEnergyMeanOn']]
        rt26 = pd.DataFrame()
        dict_pdf = {
            'RT05': rt05,
            'RT26': rt26
        }

        ce = CE().process_signals(dict_pdf, machine_version='S3')

        self.assertTrue(ce.empty)

    def test_processing_ce_machine_version_s2_missing_rt26(self):
        """
            Tests for S2 systems that the CE metric returns data and that it has the correct value
        """

        rt05 = pd.read_csv('test_data/calculated_csv/RT05/62252_DB-RT_5-20190210-235959-20190211-001500.csv',
                           index_col='Timestamp')
        rt05.index = pd.to_datetime(rt05.index)
        rt05 = rt05[['BDenergyAvgOn', 'BDfcem1MpEnergyMeanOn']]
        rt26 = pd.DataFrame()
        dict_pdf = {
            'RT05': rt05,
            'RT26': rt26
        }

        ce = CE().process_signals(dict_pdf, machine_version='S2')

        expected = [1.118942565, 1.157068643, 2.571405180, 1.561208725, 1.696754444, 1.788386583, 1.824674296,
                    1.783193263, 1.782335399, 1.859295650, 1.866654655, 1.788675591, 1.875960730, 1.814986440,
                    1.833830510, 1.856818312, 1.894776934, 1.893844081, 1.850312671, 1.828151153]
        result = [round(elem, 9) if elem is not None else elem for elem in list(ce._CE)]
        self.assertListEqual(result, expected)

    def test_processing_ce_machine_version_s3(self):
        """
        tests that when the input data is available, it yields the correct result
        """

        rt05 = pd.read_csv('test_data/calculated_csv/RT05/62297_DB-RT_5-20190515-211459-20190515-213000.csv',
                           index_col='Timestamp')
        rt05.index = pd.to_datetime(rt05.index)
        rt05 = rt05[['BDenergyAvgOn', 'BDfcem1MpEnergyMeanOn']]
        rt26 = pd.read_csv('test_data/calculated_csv/RT26/62297_DB-RT_26-20190515-211459-20190515-213000.csv',
                           index_col='Timestamp')
        rt26.index = pd.to_datetime(rt26.index)
        rt26 = rt26[['BDfcem1MpEnergyMeanOn']]
        dict_pdf = {
            'RT05': rt05,
            'RT26': rt26
        }
        ce = CE().process_signals(dict_pdf, machine_version='S3')

        expected = [3.089663139, 1.407553536, 2.40771337, 4.737192473, 4.628187024, 4.635360896, 3.966665524,
                    3.982814556, 4.507752187, 4.50648471, 4.377395949, 4.38239566, 4.330867902, 4.283767119,
                    4.222424512, 4.298476287, 4.298820544, 4.304908664]
        result = [round(elem, 9) if elem is not None else elem for elem in list(ce._CE)]
        self.assertListEqual(result, expected)


if __name__ == '__main__':
    unittest.main()
