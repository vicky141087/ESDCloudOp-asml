from pyeuv.RT_Processing import rt_common
from pyeuv.Parsers import dat_parser
import unittest


class TestParsers(unittest.TestCase):
    def test_on_drop_mask(self):
        rt2_files = ['test_data/datv1/set2/2018-08-09T030549+0800_RT02_000_.dat']
        signal_list = dat_parser.ls_dat(rt2_files[0])
        datv1_metadatfile = 'test_data/datv1/set2/MetaData.csv'

        df_rt2 = dat_parser.parse_dat(
            rt2_files,
            signal_list,
            datv1_metadatfile=datv1_metadatfile,
            verbose=True
        )

        result = rt_common.on_drop_mask(df_rt2, gate_lag=2)

        assert True