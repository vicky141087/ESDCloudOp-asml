import unittest

from pyeuv.Parsers import adel_parser, dat_parser

class TestParsers(unittest.TestCase):
    def test_adel_scanner(self):
        test_file = 'test_data/adel/DW_SLIE.xml.gz'
        data_adel = adel_parser.parse_adel(test_file, verbose=True)

        if len(list(data_adel.keys())) == 0:
            assert False

    def test_adel_source_kpi(self):
        test_files = [
            'test_data/adel/KPI_H2_Flows.xml.gz',
            'test_data/adel/KPI_Vanes.xml.xz'
        ]

        for test_file in test_files:
            data_adel = adel_parser.parse_adel(test_file, verbose=True)
            if len(list(data_adel.keys())) == 0:
                assert False

    @unittest.SkipTest
    def test_rt_datv0(self):
        pass

    def test_ls_dat_v1(self):
        filenames = ['test_data/datv1/set2/2018-08-09T030549+0800_RT02_000_.dat']
        signal_list = dat_parser.ls_dat(filenames[0])

        if len(signal_list) > 0:
            assert True
        else:
            assert False


    def test_rt_datv1_xz(self):
        filenames = ['test_data/datv1/set1/RT02_test.dat.xz']
        signal_list = ['ECeuvValue']
        df_rt = dat_parser.parse_dat(
            filenames,
            signal_list,
            datv1_metadatfile='test_data/datv1/set1/StreamingMetaData.txt',
            verbose=True
        )

        if df_rt.empty:
            assert False

    def test_rt_datv1_dat(self):
        filenames = ['test_data/datv1/set2/2018-08-09T030549+0800_RT02_000_.dat']
        signal_list = dat_parser.ls_dat(filenames[0])

        df_rt = dat_parser.parse_dat(
            filenames,
            signal_list,
            verbose=True,
            datv1_metadatfile='test_data/datv1/set2/MetaData.csv'
        )
        if df_rt.empty:
            assert False


    def test_rt_datv2_RT05(self):
        filenames = ['test_data/datv2/RT5_test.xz']
        signal_list = [
            'Sequence', 'BDenergyAvg', 'BDenergyAvgOn', 'BDenergyStdOn', 'BDbeginTime', 'BDbeginNSecs',
            'BDburstLength', 'BDexposureId', 'BDfcem1MpEnergyMeanOn', 'BDfcem1MpEnergyStdOn',
            'BDfcem1PpEnergyMeanOn', 'BDfcem1PpEnergyStdOn', 'BDtFireActualMeanOn', 'BDtFireActualStdOn'
        ]

        df_rt = dat_parser.parse_dat(filenames, signal_list, verbose=True)
        if df_rt.empty:
            assert False

    def test_rt_datv2_RT23(self):
        filenames = ['test_data/datv2/RT23_test.dat']
        signal_list = ['TFMpositionX', 'TFMpositionY']

        df_rt = dat_parser.parse_dat(filenames, signal_list, verbose=True)

        if df_rt.empty:
            assert False

    
    def test_rt_datv2_RT02(self):
        filenames = ["test_data/datv2/RT02_etdc_test.dat"]
        signal_list = [
            'ECburstIndex',
            'ECeuvValue',
            'ECshotID'
        ]

        df_rt = dat_parser.parse_dat(filenames, signal_list, verbose=True)
        if df_rt.empty:
            assert False



    def test_parse_dat_directory(self):
        """
        Try to parse the RT02 in test data directory 
        """
        df_rt = dat_parser.parse_dat_directory('test_data/datv2', 'RT02')
        if df_rt.empty:
            assert False
