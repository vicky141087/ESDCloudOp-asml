import unittest
import numpy as np

from pyeuv.SourcePerformance.ctxt_filter_tool import ContextFilterObject


class TestSum(unittest.TestCase):
    def test_cfo_creation(self):
        """
        Testcase for Context Filter Object creation.

        Check that the shape of cfo times and edges are equal \
            and all elements of these objects are equal.
        """
        dt_vector = np.array([np.datetime64('2020-08-11T17:11:11') + np.timedelta64(i, 'm') for i in np.arange(12,52,2)])
        boolean = np.array([0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0])
        cfo = ContextFilterObject(dt_vector, boolean)
        np.testing.assert_array_equal(cfo.times,
                                      np.array(['2020-08-11T17:27:11', '2020-08-11T17:35:11',
                                                '2020-08-11T17:41:11', '2020-08-11T17:45:11',
                                                '2020-08-11T17:51:11', '2020-08-11T17:59:11'],
                                               dtype='datetime64[s]'), 'Time arrays are not equal')
        np.testing.assert_array_equal(cfo.edges, np.array([ 1, -1,  1, -1,  1, -1]),
                                      'Edge arrays are not equal')


    def test_deglitch_inter_gate(self):
        """
        Testcase for deglitching (modification).

        Check that the shape of cfo times and edges are equal \
            and all elements of these objects are equal.
        """
        dt_vector = np.array([np.datetime64('2020-08-11T17:11:11') + np.timedelta64(i, 'm') for i in np.arange(12,52,2)])
        boolean = np.array([0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0])
        cfo = ContextFilterObject(dt_vector, boolean)
        cfo.deglitch_inter_gates(timedelta_diff=5, inter=False, unit='m')
        np.testing.assert_array_equal(cfo.times,
                                      np.array(['2020-08-11T17:27:11', '2020-08-11T17:35:11',
                                                '2020-08-11T17:51:11', '2020-08-11T17:59:11'],
                                               dtype='datetime64[s]'), 'Time arrays are not equal')
        np.testing.assert_array_equal(cfo.edges, np.array([ 1, -1,  1, -1]),
                                      'Edge arrays are not equal')


    def test_shift_edge_points(self):
        """
        Testcase for edge shifting (modification).

        Check that the shape of cfo times and edges are equal \
            and all elements of these objects are equal.
        """
        dt_vector = np.array([np.datetime64('2020-08-11T17:11:11') + np.timedelta64(i, 'm') for i in [5, 10, 15, 18, 20, 30, 35, 37, 45, 55]])
        boolean = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1, 0])
        cfo = ContextFilterObject(dt_vector, boolean)
        cfo.shift_edge_points(timedelta_assert=-2, timedelta_deassert=1, unit='m')
        np.testing.assert_array_equal(cfo.times,
                                      np.array(['2020-08-11T17:14:11', '2020-08-11T17:22:11',
                                                '2020-08-11T17:24:11', '2020-08-11T17:29:11',
                                                '2020-08-11T17:30:11', '2020-08-11T17:42:11',
                                                '2020-08-11T17:44:11', '2020-08-11T17:49:11',
                                                '2020-08-11T17:54:11', '2020-08-11T18:07:11'],
                                               dtype='datetime64[s]'), 'Time arrays are not equal')
        np.testing.assert_array_equal(cfo.edges, np.array([ 1, -1,  1, -1,  1, -1,  1, -1,  1, -1]),
                                      'Edge arrays are not equal')


    def test_not_ctxt_filters(self):
        """
        Testcase for logical NOT (modification).

        Check that the shape of cfo times and edges are equal \
            and all elements of these objects are equal.
        """
        dt_vector = np.array([np.datetime64('2020-08-11T17:11:11') + np.timedelta64(i, 'm') for i in [5, 10, 15, 18, 20, 30, 35, 37, 45, 55]])
        boolean = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1, 0])
        cfo = ContextFilterObject(dt_vector, boolean)
        cfo = cfo.not_ctxt_filters()
        np.testing.assert_array_equal(cfo.times,
                                      np.array(['0001-01-01T00:00:00.000000', '2020-08-11T17:16:11.000000',
                                                '2020-08-11T17:21:11.000000', '2020-08-11T17:26:11.000000',
                                                '2020-08-11T17:29:11.000000', '2020-08-11T17:31:11.000000',
                                                '2020-08-11T17:41:11.000000', '2020-08-11T17:46:11.000000',
                                                '2020-08-11T17:48:11.000000', '2020-08-11T17:56:11.000000',
                                                '2020-08-11T18:06:11.000000', '9999-12-31T23:59:59.999999'],
                                               dtype='datetime64[us]'), 'Time arrays are not equal')
        np.testing.assert_array_equal(cfo.edges, np.array([ 1, -1,  1, -1,  1, -1,  1, -1,  1, -1,  1, -1]),
                                      'Edge arrays are not equal')


    def test_limit_gate_freq(self):
        """
        Testcase for limit of gates frequency (modification).

        Check that the shape of cfo times and edges are equal \
            and all elements of these objects are equal.
        """
        dt_vector = np.array([np.datetime64('2020-08-11T17:11:11') + np.timedelta64(i, 'm') for i in np.arange(3,63,3)])
        boolean = np.array([0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0])
        cfo = ContextFilterObject(dt_vector, boolean)
        cfo.limit_gate_freq(timedelta_diff=30, unit='m', from_end=False)
        np.testing.assert_array_equal(cfo.times,
                                      np.array(['2020-08-11T17:20:11', '2020-08-11T17:32:11',
                                                '2020-08-11T17:56:11', '2020-08-11T18:08:11'],
                                               dtype='datetime64[s]'), 'Time arrays are not equal')
        np.testing.assert_array_equal(cfo.edges, np.array([ 1, -1,  1, -1]),
                                      'Edge arrays are not equal')


    def test_combine_ctxt_filters(self):
        """
        Testcase for combination of Context Filter Objects (and,or,xor).

        Check that the shape of cfo times and edges are equal \
            and all elements of these objects are equal.
        """
        dt_vector_A = np.array([np.datetime64('2020-08-11T17:11:11') + np.timedelta64(i, 'm') for i in np.arange(3,63,3)])
        boolean_A = np.array([0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0])
        dt_vector_B = np.array([np.datetime64('2020-08-11T17:11:11') + np.timedelta64(i, 'm') for i in [5, 10, 15, 18, 20, 30, 35, 37, 45, 55]])
        boolean_B = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1, 0])
        cfo_A = ContextFilterObject(dt_vector_A, boolean_A)
        cfo_B = ContextFilterObject(dt_vector_B, boolean_B)
        cfo_and = cfo_A.combine_ctxt_filters(cfo2=cfo_B, logic='and')
        np.testing.assert_array_equal(cfo_and.times,
                                      np.array(['2020-08-11T17:20:11.000000000', '2020-08-11T17:21:11.000000000',
                                                '2020-08-11T17:26:11.000000000', '2020-08-11T17:29:11.000000000',
                                                '2020-08-11T17:31:11.000000000', '2020-08-11T17:32:11.000000000',
                                                '2020-08-11T17:46:11.000000000', '2020-08-11T17:47:11.000000000',
                                                '2020-08-11T17:56:11.000000000', '2020-08-11T18:06:11.000000000'],
                                               dtype='datetime64[ns]'), 'AND: Time arrays are not equal')
        np.testing.assert_array_equal(cfo_and.edges, np.array([ 1, -1,  1, -1,  1, -1,  1, -1,  1, -1]),
                                      'AND: Edge arrays are not equal')

        cfo_or = cfo_A.combine_ctxt_filters(cfo2=cfo_B, logic='or')
        np.testing.assert_array_equal(cfo_or.times,
                                      np.array(['2020-08-11T17:16:11.000000000', '2020-08-11T17:48:11.000000000',
                                                '2020-08-11T17:56:11.000000000', '2020-08-11T18:08:11.000000000'],
                                               dtype='datetime64[ns]'), 'OR: Time arrays are not equal')
        np.testing.assert_array_equal(cfo_or.edges, np.array([ 1, -1,  1, -1]),
                                      'OR: Edge arrays are not equal')

        cfo_xor = cfo_A.combine_ctxt_filters(cfo2=cfo_B, logic='xor')
        np.testing.assert_array_equal(cfo_xor.times,
                                      np.array(['2020-08-11T17:16:11.000000000', '2020-08-11T17:20:11.000000000',
                                                '2020-08-11T17:21:11.000000000', '2020-08-11T17:26:11.000000000',
                                                '2020-08-11T17:29:11.000000000', '2020-08-11T17:31:11.000000000',
                                                '2020-08-11T17:32:11.000000000', '2020-08-11T17:46:11.000000000',
                                                '2020-08-11T17:47:11.000000000', '2020-08-11T17:48:11.000000000',
                                                '2020-08-11T18:06:11.000000000', '2020-08-11T18:08:11.000000000'],
                                               dtype='datetime64[ns]'), 'XOR: Time arrays are not equal')
        np.testing.assert_array_equal(cfo_xor.edges, np.array([ 1, -1,  1, -1,  1, -1,  1, -1,  1, -1,  1, -1]),
                                      'XOR: Edge arrays are not equal')


    def test_apply_ctxt_filter(self):
        """
        Testcase for Context Filter filtering (application).

        Check that the shape of filtering indices are equal \
            and all elements of these objects are equal.
        """
        date_time = np.datetime64('2020-08-11T17:11:11')
        dt_vector = np.array([date_time + np.timedelta64(i, 'm') for i in np.arange(12,52,2)])
        boolean = np.array([0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0])
        cfo = ContextFilterObject(dt_vector, boolean)
        filter_dt_vector = np.array([date_time + np.timedelta64(i, 'm') for i in np.arange(0,63,3)])
        ramp_signal = np.array([i for i in range(1, len(filter_dt_vector) + 1)])
        idx = cfo.apply_ctxt_filter(filter_dt_vector)
        np.testing.assert_array_equal(idx, np.array([0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0]),
                                      'Index arrays are not equal')


    def test_agg_ctxt_filter(self):
        """
        Testcase for Context Filter aggregation (standard, user function).

        Check that the shape of aggregated times and data are equal \
            and all elements of these objects are equal.
        """
        date_time = np.datetime64('2020-08-11T17:11:11')
        dt_vector = np.array([date_time + np.timedelta64(i, 'm') for i in [5, 10, 15, 18, 20, 30, 35, 37, 45, 55]])
        boolean = np.array([1, 0, 1, 0, 1, 0, 1, 0, 1, 0])
        cfo = ContextFilterObject(dt_vector, boolean)
        filter_dt_vector = np.array([date_time + np.timedelta64(i, 'm') for i in np.arange(0,63,3)])
        all_one = np.ones(len(filter_dt_vector))
        time_aggr_sum, data_aggr_sum = cfo.agg_ctxt_filter(filter_dt_vector, all_one, lambda x: np.sum(x))
        np.testing.assert_array_equal(time_aggr_sum,
                                      np.array(['2020-08-11T17:29:11', '2020-08-11T18:06:11'],
                                               dtype='datetime64[s]'),
                                      'Sum: Time arrays are not equal')
        np.testing.assert_array_equal(data_aggr_sum, np.array([1, 1]),
                                      'Sum: Data arrays are not equal')

        ramp_signal = np.array([i for i in range(1, len(filter_dt_vector) + 1)])
        time_aggr_maxmin, data_aggr_maxmin = cfo.agg_ctxt_filter(filter_dt_vector, ramp_signal, lambda x: np.max(x) - np.min(x))
        np.testing.assert_array_equal(time_aggr_maxmin,
                                      np.array(['2020-08-11T17:29:11', '2020-08-11T18:06:11'],
                                               dtype='datetime64[s]'),
                                      'Maxmin: Time arrays are not equal')
        np.testing.assert_array_equal(data_aggr_maxmin, np.array([6, 16]),
                                      'Maxmin: Data arrays are not equal')
