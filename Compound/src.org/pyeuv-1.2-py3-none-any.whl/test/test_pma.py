import os
import configparser
import unittest
import pandas as pd
from unittest import SkipTest

from pyeuv.PMA.clients import PMAClient

credential_file = "~/.pyeuv/test_credentials.conf"


def get_pma_credentials():
    """
    Read the credential file and return username, password and api_key. The credential file is pointed to by
    the credential_file variable of this module. The text file must contain at least the following config section:

    ::

    [PMA]
    username=<username>
    password=<password>
    api_key=<api_key>

    Also, see the Unit testing section of the Pyeuv Manual.

    :returns: username, password, api_key
    :rtype: tuple<str>
    """
    if os.path.exists(os.path.expanduser(credential_file)):
        config = configparser.ConfigParser()
        with open(os.path.expanduser(credential_file), 'r') as f:
            config.read_file(f)

        username = config['PMA']['username']
        password = config['PMA']['password']
        api_key = config['PMA']['api_key']
    else:
        raise FileNotFoundError("Missing credential file: {0}\n"
                                "Please refer to the testing section of the manual."
                                "".format(os.path.expanduser(credential_file)))

    return username, password, api_key


@SkipTest  # PMA NG performance too unstable to include by default.
class TestPMAClient(unittest.TestCase):
    """
    In this test case we create an instance of the PMA Client class and use it to try to download some parameter,
    cpd report and MC data.
    """
    @classmethod
    def setUpClass(cls):
        cls.pma_client = PMAClient(*get_pma_credentials())

    @classmethod
    def reconnect(cls):
        cls.pma_client.close()
        cls.setUpClass()

    def test_01_download_dw_slie(self):
        """ Check if we can download DW_SLIE for a fixed time window and machine. """
        machine = {
            'machine_nr': 9445,
            'name': 'TSMC 7'
        }

        df_slie = self.pma_client.get_parameters(['DW_SLIE'], machine, pd.Timestamp('2019-04-01'),
                                                 pd.Timestamp('2019-05-01'), verbose=True)
        if len(df_slie['DW_SLIE']) > 0:
            assert True
        else:
            assert False

    def test_02_list_parameters(self):
        params = self.pma_client.list_parameters()
        if len(params) > 1:
            assert True
        else:
            assert False

    def test_03_download_lues(self):
        """ Check if we can download LUES reports for a given machine and time window. """
        # For some reason we need to reconnect when switching away from the performance tables. Perhaps this has
        # something to do with the implementation where performance data requests are routed to CDL?
        self.reconnect()
        machines = [
            {
                'machine_nr': 9445,
                'name': 'TSMC 7'
            }
        ]
        df_lues = self.pma_client.get_cpd_results('LUES', machines, pd.Timestamp('2019-04-20'),
                                                  pd.Timestamp('2019-05-28'), verbose=True)

        if len(df_lues) > 0:
            assert True
        else:
            assert False

    def test_04_download_mc(self):
        """ Test if we can download the mirror state MC using the get_machine_constants method """
        machines = [
            {
                'machine_nr': '3981',
                'name': 'TSMC-5'
            },
            {
                'machine_nr': 'BJ14',
                'name': 'TSMC-10'
            }
        ]

        df_mc = self.pma_client.get_machine_constants('MCULTF_FFMPeriph_MIRROR_STATE_MIRROR_STATE_TAG',
                                                      machines, pd.Timestamp('2017-01-01'),
                                                      pd.Timestamp('2019-07-30'), verbose=True)

        if len(df_mc) > 0:
            assert True

    def test_05_equipment_info(self):
        """ Test if we can get equipment information from PMA"""
        machines = [
            {
                'machine_nr': '3981',
                'name': 'TSMC-5'
            },
            {
                'machine_nr': 'BJ14',
                'name': 'TSMC-10'
            }
        ]

        df_qr = self.pma_client.get_machine_equipment_info(machines, verbose=True)

        if df_qr.empty:
            assert False

        # Make sure that data for both requested machines is returned
        for m in machines:
            if m['machine_nr'] not in df_qr['UK_MACHINE_EQUIPMENT_NR'].unique():
                assert False

        # Make sure that no data is returned for machines that are not in the list
        for machine_nr in df_qr['UK_MACHINE_EQUIPMENT_NR'].unique():
            if machine_nr not in [m['machine_nr'] for m in machines]:
                assert False

    def test_06_pvp_config(self):
        """ Test if we can get the DGL_CONFIG parameter history for two machines """
        machines = [
            {
                'machine_nr': '3981',
                'name': 'TSMC-5'
            },
            {
                'machine_nr': 'BJ14',
                'name': 'TSMC-10'
            }
        ]

        df_pvp = self.pma_client.get_pvp_config(machines, ['DGL_CONFIG'], pd.Timestamp('2018-01-01'),
                                                pd.Timestamp('now'), verbose=True)

        if len(df_pvp) == 0:
            assert False

        if 'UK_CONFIG_OPTION_NAME' not in df_pvp.columns or 'UK_MACHINE_EQUIPMENT_NR' not in df_pvp.columns:
            assert False

        if not (df_pvp['UK_CONFIG_OPTION_NAME'] == 'DGL_CONFIG').any():
            assert False

        if set((df_pvp['UK_MACHINE_EQUIPMENT_NR']).unique()) != {'3981', 'BJ14'}:
            assert False

