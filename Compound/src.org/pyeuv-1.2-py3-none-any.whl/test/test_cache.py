import os
import unittest
import pandas as pd
from pyeuv.Shared.cache import SignalCache


class TestSignalCache(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not os.path.exists('./test_data'):
            os.mkdir('./test_data/cache')

        cls.cache = SignalCache('./test_data/cache')
        cls.cache.clear()

        # Add a test signal to the cache
        df = pd.DataFrame(
            pd.np.random.randn(100),
            index=pd.date_range('2019-10-30 00:00:00', '2019-10-30 12:00:00', periods=100),
            columns=['test']
        )

        cls.cache.cache_signal('test', df)

    def test_store_signal(self):
        """ Generates a random signal and store it."""
        df = pd.DataFrame(
            pd.np.random.randn(100),
            index=pd.date_range('2019-10-30 00:00:00', '2019-10-30 12:00:00', periods=100),
            columns=['test']
        )

        self.cache.cache_signal('test', df)

        if 'test' not in self.cache.list_signals():
            assert False

    def test_get_signal(self):
        """ Performs various requests on the cache and checks the response"""

        # No overshoot left and right windows must be None
        df0, wl, wr = self.cache.get_signal('test', pd.Timestamp('2019-10-30 00:00:00'),
                                            pd.Timestamp('2019-10-30 12:00:00'))
        if df0.empty or wl is not None or wr is not None:
            assert False

        # Left and right overshoot
        df1, wl, wr = self.cache.get_signal('test', pd.Timestamp('2019-10-29 00:00:00'),
                                            pd.Timestamp('2019-10-31 00:00:00'))
        if df1.empty or wl is None or wr is None:
            assert False

        # Left overshoot
        df2, wl, wr = self.cache.get_signal('test', pd.Timestamp('2019-10-29 00:00:00'),
                                            pd.Timestamp('2019-10-30 12:00:00'))
        if df2.empty or wl is None or wr is not None:
            assert False

        # Right overshoot
        df3, wl, wr = self.cache.get_signal('test', pd.Timestamp('2019-10-30 00:00:00'),
                                            pd.Timestamp('2019-10-30 13:00:00'))
        if df3.empty:
            assert False
        if wl is not None or wr is None:
            assert False

        # Requested data newer than cached
        df4, wl, wr = self.cache.get_signal('test', pd.Timestamp('2019-10-31 00:00:00'),
                                            pd.Timestamp('2019-11-01 00:00:00'))
        if not df4.empty or wl is not None or wr is None:
            assert False

        # Requested data older than cached
        df5, wl, wr = self.cache.get_signal('test', pd.Timestamp('2019-10-29 00:00:00'),
                                            pd.Timestamp('2019-10-29 23:00:00'))
        if not df5.empty or wl is None or wr is not None:
            assert False

    def test_update_signal(self):
        """ Update a cached signal with new data """
        df_new = pd.DataFrame(
            pd.np.random.randn(100),
            index=pd.date_range('2019-10-30 9:00:00', '2019-10-30 15:00:00', periods=100),
            columns=['test']
        )
        df_new.iloc[0, 0] = 42  # Well check if this values is in the cache

        self.cache.cache_signal('test', df_new)
        df, wl, wr = self.cache.get_signal('test', df_new.index[0], df_new.index[-1])

        # Check if new values are appended
        if df.index[-1] != df_new.index[-1]:
            assert False

        # Check if existing values are updated
        if df.loc[df.index[0], 'test'] != 42:
            assert False

    @classmethod
    def tearDownClass(cls):
        cls.cache.clear()
