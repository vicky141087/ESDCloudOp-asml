# This Python file uses encoding: utf-8

"""
POB TMONI - Projection Optics Box Transmission Monitoring tool

See class POB_TMONI docstring for more information.

Copyright 2020, ASML HOLDING N.V. (INCLUDING AFFILIATES). ALL RIGHTS RESERVED.
"""

import itertools
import logging
import numpy as np
import pandas as pd

from inspect import currentframe  # logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from ruptures import Pelt  # For jump detection
from scipy.optimize import curve_fit
from scipy.signal import find_peaks
import traceback

# ASML libraries
from pyeuv.Do_It import do_it_library as do_it
import pyeuv.STC.general.shared as shared

TIMEZERO = pd.Timestamp(year=2013, month=1, day=1).tz_localize('UTC')


def identify_peak_indices(y: np.array, verbose: bool = False, **kwargs):
    """
    Find peaks in the signal using scipy.stats.find_peaks, then invert the signal to find also negative peaks.
    Any additional kwargs are transferred to find_peaks

    Some other algoriths are compared here: https://github.com/MonsieurV/py-findpeaks

    :param y: A signal with peaks
    :param verbose: to switch internal debug info, defaults to False
    :param kwargs: Keyword arguments for scipy.signal.find_peaks
    :return: Peak indices based on y
    :rtype: numpy array
    """
    do_it.do_it_verbose(currentframe(), verbose)

    peaks, properties = find_peaks(y, **kwargs)
    yinv = y.mean() + (-1 * (y - y.mean()))
    peaksinv, propertiesinv = find_peaks(yinv, **kwargs)
    peaks = np.append(peaks, peaksinv)
    return peaks


def identify_changepoints(y: np.array,
                          min_jump_ratio: float=0.01, min_size: int=3,
                          penalty: int=25):
    """
    Use the Pelt algorithm to find changepoints. Jumps too close to the edges are discarded based on min_size.

    Reference: "The Power of the Pruned Exact Linear Time(PELT) Test in Multiple Changepoint Detection"
    dx.doi.org/10.11648/j.ajtas.20150406.30

    :param y: Array of data values
    :param direction: 'up' or 'down', define jump direction
    :param min_jump_ratio: Ratio of minimum jump required, 0.01 would be 1%
    :param min_size: Minimum # of datapoints required for analysis (segment length for changepoint detection algorithm)
    :param penalty: Penalty parameter for changepoint algorithm
    :return: Dictionary with keys 'up' and 'down' containing each a list of indices for the changepoints
    :rtype: dictionary
    """
    if len(y) <= min_size + 1:
        out = {'up': np.array([]), 'down': np.array([])}
    else:
        result = np.array(Pelt(model='l1', min_size=min_size, jump=1).fit_predict(y, pen=penalty))

        # Filter out jumps near the edges, just to be sure
        result = result[np.logical_and(result > min_size, result < len(y) - min_size)]

        # Determine direction of jump, and filter on min_jump_ratio
        out = {'up': [res for res in result if np.mean(y[res:res + min_size]) /
                      np.mean(y[res - min_size:res]) - 1 >= min_jump_ratio],
               'down': [res for res in result if np.mean(y[res:res + min_size]) /
                        np.mean(y[res - min_size:res]) - 1 <= -1 * min_jump_ratio]
               }
    return out


def add_doe_id_name(df: pd.DataFrame, pupinfo: pd.DataFrame, verbose: bool=False):
    """
    Use a csv file to add DOE name info to input DataFrame.
    For unknown and flexray pupils, unknownX or flexrayX is used as DOE name.

    Pupilshape modes:
    ILL -> 0 = conventional;  1 = annular;       2 = quasar;     4 = custom pupils
    DC  -> 0 = custom pupils; 1 = conventional;  2 = annular;    3 = quasar

    :param df: dataframe containing columns sigma_inner, sigma_outer, mode_DC
    :param pupinfo: dataframe with extensive pupil information
    :param verbose: to switch internal debug info, defaults to False
    :return: dataframe with column doe_name added
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), verbose)

    df_unique = df.copy()[[x for x in df.columns if x in
                           ['sigma_inner', 'sigma_outer', 'mode_DC']]].drop_duplicates()
    df_unique = df_unique.merge(pupinfo, how='left')

    iflex = iter(np.arange(1, df.shape[0], 1))
    iunknown = iter(np.arange(1, df.shape[0], 1))
    for i, ituple in enumerate(df_unique.itertuples()):
        idict = ituple._asdict()
        name = idict['doe_name'] if str(idict['doe_name']).lower() != 'nan' else (
            f'flexray_{next(iflex)}' if idict['mode_DC'] == 0 else f'unknown{next(iunknown)}')
        df_unique.loc[idict['Index'], 'doe_name'] = name
    df = shared.merge_ts_index(df, df_unique, how='left')
    return df


def piecewise_linear(x: np.array, x0: float, y0: float, k1: float, k2: float):
    """
    Piecewise linear function with two pieces.

    Source: https://stackoverflow.com/questions/29382903/how-to-apply-piecewise-linear-fit-in-python

    :param x: Input array
    :param x0: Location of switch between first to second linear fit
    :param y0: Offset of both fits, defined at x==x0
    :param k1: Slope for fit left of x0
    :param k2: Slope for fit right of x0
    """
    return np.piecewise(x, [x < x0], [lambda x:y0 + k1 * (x - x0), lambda x: y0 + k2 * (x - x0)])


def sigma_filter(x: np.array, n_sigma: float = 3):
    """
    Given an array, will return an array of booleans, where True means the point
    is outside the mean+-n_sigma*sigma limits.

    :param x: Input array
    :param n_sigma: Number of sigmas used to filter, defaults to 3
    :return: Array with mask, True means point outside sigma limits
    :rtype: numpy array
    """
    mean = np.nanmean(x)
    std = np.sqrt(np.nanvar(x, ddof=1))
    output = np.logical_or(x < (mean - n_sigma * std), x > (mean + n_sigma * std))
    return output


def column_sorter(columns: list):
    """
    To make the final result more human readable, sort columns

    :param columns: List of columns to be sorted
    :return: Sorted list of columns, sorted by custom logic, not alphabetically
    :rtype: List
    """
    # Sort columns for csv readability
    sorter = lambda x: sorted(x, key=lambda L: (L.lower(), L))

    # Remove these columns
    del_cnames = ['counter', 'UR', 'FSLIE_count']

    cnames1 = [x for x in ['hardware', 'customer', 'customer_nr', 'displayname',
                           'machine_id', 'source_nr', 'col_clean_period', 'doe_name', '_ts_index_', ] if x in columns]
    cnames2 = [x for x in columns if 'dose' in x and x not in cnames1]
    cnames3 = [x for x in columns if 'FSLIE' in x and x not in cnames1 + cnames2]
    cnames4 = [x for x in columns if x not in cnames1 + cnames2 + cnames3 + del_cnames]
    sorted_columns = cnames1 + sorter(cnames2) + sorter(cnames3) + sorter(cnames4)
    return sorted_columns


def weighted_average(df: pd.DataFrame, cname: str, cname_weights: str):
    """
    Wrapper function to calculate the weighted average for dataframe columns.

    :param df: Dataframe
    :param cname: Column to calculate average of
    :param cname_weights: Column to use as weights
    :return: Average number
    :rtype: float
    """
    return np.average(df[cname].to_numpy(), weights=df[cname_weights].to_numpy())


class POB_TMONI(object):
    """
    POB TMONI is the Projection Optics Box Transmission MONItoring tool of the System Transmission Control team.
    The goal is to report the transmission losses in the POB. The available sensors in the NXE scanner are the Spot
    Sensor (SS) and Slit Sensor (SLS), both (SSLS) at wafer level, and the Energy Sensor (ES) at reticle level.
    The KPI is FSLIE, which is the ratio of ES/SLS. The loss of FSLIE versus cumulative dose gives the (total)
    transmission loss of the POB.

    Where the SSLS measure the complete intensity profile, the ES measures only (outside) the sides of the slit.
    This means that while the SSLS is sensitive to transmission losses in the POB, the ES is susceptible to changes
    in the ratio of energy inside and outside the slit. Therefore collector contamination, beam misalignment or other
    effects that impact this ratio should also be corrected for to get accurate results. Next to that other mechanisms
    also account for loss in the optical path, such as fiducial degrdation, DGLm membranes, Unicom fingers, gasses,
    etcetera. These other mechanisms should be subtracted from the reported FSLIE loss value to get the actual POB
    transmission loss.

    This code is described in D000872316 - EDS POB TMONI Automation

    :param data_dict: Contains all signals necessary for analysis as well as some meta tags such as to_time /
    from_time / source_nr. Dictionary keys with expected signals can be inferred from the POB_IO.py code.
    :type data_dict: dictionary
    :param local: Toggle if local file storage is allowed, defaults to False
    :type local: boolean, optional
    :param verbose: To switch internal debug info, defaults to False
    :type verbose: boolean, optional
    :return: POB_TMONI class instance
    :rtype: class
    """

    def __init__(self, data_dict: dict, local: bool=False, verbose: bool=False):
        """
        Constructor of POB_TMONI class.
        Will create some local folders for logging/result saving if parameter local==True.
        """
        do_it.do_it_verbose(currentframe(), verbose)

        # Set mandatory parameters
        self.data_dict = data_dict
        self.source_nr = int(self.data_dict['source_nr'])
        self.machine_id = self.data_dict['machine_id']
        self.local = local  # Determine whether to save data locally or not
        self.verbose = verbose

        if self.local:  # If not run locally do not attempt to write to disk
            # Make sure all directories are created (for new users)
            self.main_dir = Path(r'~/.tmoni').expanduser()
            if not self.main_dir.exists():
                self.main_dir.mkdir()

            self.cache_fname = self.main_dir.joinpath(
                f'cache/pob_m{self.machine_id}_s{self.source_nr}.zip')
            if not self.cache_fname.parent.exists():
                self.cache_fname.parent.mkdir()

            self.log_fname = self.main_dir.joinpath(
                f'log/log_{self.__class__.__name__}.log')
            if not self.log_fname.parent.exists():
                self.log_fname.parent.mkdir()

            self.log = self._init_logging(
                self.__class__.__name__, self.log_fname, local=self.local)

            np.set_printoptions(precision=3)  # For prettier logging
        else:
            self.log = self._init_logging(
                self.__class__.__name__, local=self.local)

        self.log.info('#' * 80)
        self.log.info(
            f'Class {self.__class__.__name__} initiated for m{self.machine_id} / s{self.source_nr}')

        # # FSLIE Simulated values filtering
        # Values above the normal FSLIE by this much are filtered
        self.FSLIE_SIM_cutoff = 75
        # How many identical FSLIE values allowed per collector period
        self.FSLIE_SIM_maxpoints = 50
        # Maximum expected FSLIE value, values above this are filtered.
        self.FSLIE_maxvalue = 300

        # Identify UR2 measurements if value is within this time of previous measurement
        self.UR_timedelta = pd.Timedelta(5, unit='s')
        # How many pulses are taken into account after a collector swap to determine 'clean collector' FSLIE
        # Collectors with less than this amount of pulses are discarded, except if it is the last collector
        self.pulses_after_swap = 10e9
        # If pressure below value (in Pascal), vacuum present, else not
        self.vacuum_pressure_min = 20  # Pascal

        # Pressure variables
        self.pressure_maxdelta = 0.1,  # Pa, only take values if delta with previous lower than this value
        self.pressure_upperlimit = 15,  # Pa, only take pressure values between upper- and lowerlimit
        self.pressure_lowerlimit = 2,
        self.pressure_impact_POB = 0.0061  # % POB T-loss per Pa of pressure increase

        # Ratio is below toggle value: pellicle present, else not
        self.fiducial_reticle_ratio_toggle = 0.85
        # Assume if transmission is below toggle value: DGLmembrane present, else not
        self.DGLmembrane_toggle = 95
        # Convert DGLm value to actual transmission loss
        self.DGLmembrane_transmissiondict = {85: 0.854, 90: 0.879, 100: 1.0}
        # Values higher are likely simulated, should be removed
        self.SS_SL_cutoff = 10000
        # If both the SS and SL leading or non-leading have an upwards jump of
        # this ratio or more, ignore as it is likely a HW swap
        self.SS_SL_hwjump = 1.75

        # Timeinterval to average FSLIE per pupil
        self.pupil_combination_timeinterval = '24H'
        # List of pupils to use for combining, the first one will be the reference
        self.pupil_combination_list = ['Large Conventional', 'Quasi conventional', 'Small Annular', ]

        self.FAT_to_SAT_mintime = 40  # Days
        # If in the "clean collector period" more than this amount of measurements is done,
        # only take 70-90% of highest values
        self.min_measurements_after_colswap = 50
        # If less dose accumulated than this value, remove colswap from final table
        self.reject_after_colswap_on_mindose = 0.1
        # If less time than this between collector swaps, remove colswap from final table
        self.reject_after_colswap_on_maxtime = pd.Timedelta(90, unit='d')
        # If more than this amount of FSLIE counts for Combined pupil, ignore mindose/maxtime requirement
        self.FSLIE_mincount = 1000

        # # Jump detection settings
        self.min_jump_ratio = 0.05
        self.jump_smoothing_timeinterval = '6h'
        self.jump_peak_smooth_kwargs = {'prominence': 3, 'width': (0, 5), 'wlen': 15}

        # Variables to determine representative FSLIE value
        # How many times the self.pulses_after_swap criterion is used to look at FSLIE
        self.pulses_after_swap_multiplier = 3
        # Determine interval for FSLIE resampling
        self.rep_FSLIE_resample_timeinterval = '6h'

        # Variables to judge relative transmission loss values
        self.upper_limit = 0.01
        # Lower limit is only used to display a warning, not to filter FSLIE loss values
        self.lower_limit_slope = 3 * -0.05  # ratio per GJ
        self.lower_limit_offset = -0.15  # ratio loss
        return None

    @staticmethod
    def _init_logging(name: str, fname: str='', local: bool=False):
        """
        Initialize logging, with a RotatingFileHandler that will log all messages to fname, and a StreamHandler that
        will give output to the console.

        :param name: Name of logging instance
        :param fname: Filename of log (including path), defaults to ''
        :param local: Toggle if log is saved locally, defaults to False
        :return: Instance of logger
        :rtype: logging logger
        """
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)

        formatter = logging.Formatter(
            # '%(asctime)s - '
            '%(levelname)-8.8s - '
            '%(message)s')

        existing_handlers = [h.name for h in logger.handlers]
        if False:  # local and f'{name}_file' not in existing_handlers:
            handler = RotatingFileHandler(fname,
                                          mode='a',
                                          maxBytes=1e6,
                                          backupCount=3)
            handler.set_name(f'{name}_file')
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        # Also add StreamHandler to print to stderr (console)
        if f'{name}_stream' not in existing_handlers:
            streamhandler = logging.StreamHandler()
            streamhandler.set_name(f'{name}_stream')
            streamhandler.setFormatter(formatter)
            logger.addHandler(streamhandler)
        return logger

    def extract_start_stop_time_from_discrete_parameters(self, df: pd.DataFrame, cname: str,
                                                         method: (None, str)=None, maxgroups: int=100000,
                                                         dt_margin: (bool, pd.Timestamp)=False):
        """
        Extract the first and last timestamp of consecutive values in column cname from df.
        Only works for discrete parameters that can be grouped. If gaps in the data exist,
        then 'dt_margin' gives the allowed gap before a new group is defined.
        For example, determine the periods in which the scanner vacuum was on or off.

        :param df: Input data
        :param cname: Column to work on
        :param method: Choose to fill gaps (in time) between datapoints, None, 'ffill', or 'bfill', defaults to None
        :param maxgroups: Function is aborted if more than this number of groups is found, defaults to 100000
        :param dt_margin: Used to determine if values are within same group. If False will simply compare consecutive
            values, if a pandas.Timedelta is given will use a new group if a subsequent similar value is further
            in time than said Timedelta. Defaults to False
        :return: dataframe with column doe_name added
        :rtype: pandas dataframe
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        df = df.loc[:, [cname]].dropna().sort_index()  # Cleanup of input df
        if df.empty:
            self.log.debug(
                f'Empty DataFrame given, cannot execute "extract_start_stop_time_from_discrete_parameters"')
            df_out = pd.DataFrame({'tmax': [], cname: [], }, index=pd.to_datetime(np.array([]), utc=True))
            df_out.index.name = '_ts_index_'
            return df_out
        df['index_shifted'] = df.index
        df['index_shifted'] = df['index_shifted'].shift(-1)
        df['deltatime'] = df['index_shifted'] - df.index
        if isinstance(dt_margin, bool) and dt_margin:
            raise NotImplementedError(
                f'Input for "dt_margin" can only be False or pandas.Timedelta, not True')

        counter = 0
        grouper = [counter]

        # If no dt_margin, use (way faster) pandas operations to drop consecutive values before iterating per row
        if isinstance(dt_margin, bool) and not dt_margin:
            df = shared.drop_consecutive_duplicates(df, cname)

        # Check if previous value is similar, if so append current counter value, else up counter and append new value.
        # More robust than df.shift method
        # If dt_margin, also append new value when deltatime (dt) larger than dt_margin
        for (i, j, dt) in zip(df[cname].tolist()[:-1], df[cname].tolist()[1:], df['deltatime']):
            if i != j or (dt_margin and dt > dt_margin):
                counter += 1
            grouper.append(counter)
        df['grouper'] = grouper
        dfg = df.groupby('grouper')

        if dfg.ngroups > maxgroups:
            raise ValueError(self.log.exception(
                f'Number of groups discovered (column "{cname}", {dfg.ngroups}) is larger than allowed maximum' +
                f'({maxgroups}, set by kwarg maxgroups). Function stopped to prevent excessive delays'))

        df_out = pd.DataFrame()
        for segment, group in dfg:
            df_out = df_out.append(pd.DataFrame({'tmax': group.index.max(), cname: group[
                                   cname].values[0], }, index=[group.index.min()]))

        # Fill all gaps that might exist in original timestamps, not
        # recommended except for plottng
        if method == 'ffill':
            df_out = self._ffill(df_out)
        elif method == 'bfill':
            df_out = self._bfill(df_out)
        elif method:
            raise NotImplementedError(
                f'Input for "method" not accepted: {shared.to_string(method)}')
        return df_out

    def _ffill(self, df: pd.DataFrame):
        """
        Forward fill function. Take the (timeseries) index, subtract 1 seconds, shift it one back, and add it to 
        column 'tmax'. The last value in that column will be self.data_dict['to_time'].

        :param df: Dataframe to work on
        :return: Dataframe with 'tmax' column
        :rtype: pandas Dataframe
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        df['tmax'] = [x - pd.Timedelta(1, unit='s')
                      for x in df.index.tolist()[1:] + [self.data_dict['to_time']]]
        return df

    def _bfill(self, df: pd.DataFrame):
        """
        Backward fill function. Take the (timeseries) index, subtract 1 seconds, shift it one further, and add it to 
        column 'tmax'. The first value in that column will be self.data_dict['from_time'].

        :param df: Dataframe to work on
        :return: Dataframe with 'tmax' column
        :rtype: pandas Dataframe
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        df.index = [x - pd.Timedelta(1, unit='s')
                    for x in [self.data_dict['from_time']] + df['tmax'].tolist()[:-1]]
        return df

    def get(self, target: str):
        """
        Get a class item.

        :param target: Name of target
        :return: Requested item
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        return self.__getattribute__(target)

    def set(self, *args):
        """
        Set a class item.

        :param args: Arguments for self.__setattr__
        :return: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        return self.__setattr__(*args)

    def todict(self):
        """
        Get class contents in dictionary form.

        :return: Class contents
        :rtype: dictionary
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        return self.__dict__

    def classify_UR_state(self, df: pd.DataFrame):
        """
        Add a column "UR" to the dataframe to classify if it is UR1 or UR2. Works on a timeseries index, everything is
        UR1 unless the index is within self.UR_timedelta seconds of the previous index, then it is assumed to be UR2.

        :param df: DataFrame to determine UR state based on index
        :return: DataFrame with column 'UR' added
        :rtype: pandas dataframe
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        timedeltas = [self.UR_timedelta * 2] + \
            np.diff(df.index.to_numpy()).tolist()
        df['UR'] = [1 if x > self.UR_timedelta else 2 for x in timedeltas]
        return df

    def run(self):
        """
        Run whole POB TMONI flow.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        cnames = ['source_nr', 'doe_name', 'FSLIE_cumprod',
                  'FSLIE', 'cumulative_dose_cumsum']

        self.valid_dataset = True
        if self.valid_dataset:
            if self.data_dict['FSLIE'].dropna().shape[0] < 10 or \
                    self.data_dict['colswaps'].shape[0] < 1:
                self.valid_dataset = False
                self.log.warning('No FSLIE data found, aborted')
                return None

            self.log.info('Cleaning up and prepping data...')
            try:
                self.prep_ALL()
            except Exception as e:
                self.log.warning(f'Function "prep_ALL" failed, probably an invalid dataset. ' +
                                 f'Error:\n{traceback.format_exc()}: {e}')
                self.valid_dataset = False

        if self.valid_dataset:
            self.correct_ALL()

        if self.valid_dataset:
            self.calculate_ALL()

        self.sanitize_output()

        return self.output_dict

    def sanitize_input(self):
        """
        Strip all leading underscores of the column names in the input data, except for _ts_index_.
        This is done as all columns inside the class do not use leading underscores, at the end they are added to the
        relevant output dataframes.
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "sanitize_input"')

        for key in [key for key in self.data_dict.keys() if isinstance(self.data_dict[key], pd.DataFrame)]:
            self.data_dict[key].columns = [x.lstrip('_') for x in self.data_dict[key].columns if x != '_ts_index_']
        return None

    def prep_ALL(self):
        """
        Execute all "prep_*" functions, to obtain all data necessary for analysis.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        self.prep_clean_collector_timeperiods()

        if not self.valid_dataset:
            return None

        self.prep_FSLIE_and_UR_state()

        if not self.valid_dataset:
            return None

        self.prep_vacuum_states()

        self.prep_pressure()

        self.prep_DGLmembrane_presence()

        self.prep_pellicle_presence()

        self.df_SSCFl = self.prep_SS_SL_values('SSCFl')
        self.df_SLCFl = self.prep_SS_SL_values('SLCFl')
        self.df_SSCFl = self.prep_SS_SL_jump_removal(target='l')

        # Troubleshooting
        if self.local:
            self.df_SSCFa = self.prep_SS_SL_values('SSCFa')

            self.df_SSCFnl = self.prep_SS_SL_values('SSCFnl')
            self.df_SLCFnl = self.prep_SS_SL_values('SLCFnl')
            self.df_SSCFnl = self.prep_SS_SL_jump_removal(target='nl')

        self.prep_Unicom_values()

        self.prep_FAT_period()

        if self.local:
            self.prep_plasma_source_position()

        return None

    def prep_clean_collector_timeperiods(self):
        """
        Determine time interval (index to tmax) of 'clean collector'

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_clean_collector_timeperiods"')

        self.df_colswaps = self.data_dict['colswaps'].copy(deep=True)
        self.df_pulsecount = self.data_dict['pulsecount'].copy(deep=True)  # Unit: #
        self.df_pulsecount['pulsedelta'] = [0, ] + np.diff(self.df_pulsecount['pulsecount']).tolist()
        self.df_dose = self.data_dict['cumdose'].copy(deep=True)  # Unit: J
        self.df_dose['cumulative_dose'] = self.df_dose['cumulative_dose'] * 1e-9  # Unit: MJ

        self.df_colswaps['machine_id'] = self.machine_id

        if self.df_pulsecount.shape[0] <= 1:
            self.valid_dataset = False
            self.log.warning('No values present in self.df_pulsecount, cannot process this system')
            return None

        swap = self.df_colswaps.index.to_list() + [self.data_dict['to_time']]
        for i, ituple in enumerate(self.df_colswaps.itertuples()):
            idict = ituple._asdict()

            pulsecount = self.df_pulsecount.loc[swap[i]: swap[i + 1], 'pulsecount']
            if pulsecount.empty:  # If no pulses fired at all
                pulsecount = 0
            else:
                # If the pulsecounter was not reset at the proper time, and is still above the cutoff
                timestart = np.datetime64('NaT')  # Init with dummy value
                if self.df_pulsecount.loc[swap[i]: swap[i + 1], 'pulsecount'][0] > self.pulses_after_swap:
                    timestart = self.df_pulsecount.loc[swap[i]: swap[i + 1]].query(
                        f'pulsecount<={self.pulses_after_swap}').index.min()
                if pd.isnull(timestart):  # If no pulses found or pulsecounter starts at zero (as it should)
                    timestart = swap[i]

                pulsecount = self.df_pulsecount.loc[timestart: swap[i + 1], 'pulsecount'].max()
                tmax = self.df_pulsecount.loc[timestart: swap[i + 1]].query(
                    f'pulsecount>={self.pulses_after_swap}').index.min()
                # Also determine the time for 3x the limit to be used to determine representative FSLIE later on
                tmax_x3 = self.df_pulsecount.loc[timestart: swap[i + 1]].query(
                    f'pulsecount>={self.pulses_after_swap_multiplier*self.pulses_after_swap}').index.min()

            if pulsecount == 0 or pd.isnull(tmax):  # If pulsecount criteria not met, use next colswap timestamp
                tmax = swap[i + 1] - pd.Timedelta(1, unit='s')
            self.df_colswaps.loc[idict['Index'], 'tmax'] = tmax

            if pulsecount == 0 or pd.isnull(tmax_x3):  # If pulsecount criteria not met, use next colswap timestamp
                tmax_x3 = swap[i + 1] - pd.Timedelta(1, unit='s')
            self.df_colswaps.loc[idict['Index'], 'tmax_x3'] = tmax_x3

            self.df_colswaps.loc[idict['Index'], 'pulsecount'] = pulsecount

            self.df_colswaps.loc[idict['Index'], 'cumulative_dose'] = self.df_dose.loc[
                idict['Index']: tmax, 'cumulative_dose'].min() if (self.df_dose.shape[0] > 0 and
                                                                   tmax > self.df_dose.index.min()) else 0
            # If the cumulative dose signal is not extended into the clean collector
            # period, take the last previous value
            if np.isnan(self.df_colswaps.loc[idict['Index'], 'cumulative_dose']):
                self.df_colswaps.loc[idict['Index'], 'cumulative_dose'] = \
                    self.df_dose.loc[: idict['Index'], 'cumulative_dose'].tolist()[-1]

        self.df_colswaps.sort_index(ascending=True)
        if 'df_FSLIE_avg' in self.data_dict and self.data_dict['df_FSLIE_avg'].shape[0] >= 1:
            self.df_colswaps['col_clean_period'] = self.data_dict['df_FSLIE_avg'].loc[
                :, 'col_clean_period'].max() + 1 + np.arange(self.df_colswaps.shape[0])
        else:
            self.df_colswaps['col_clean_period'] = np.arange(self.df_colswaps.shape[0])
        self.df_colswaps['col_period'] = self.df_colswaps['col_clean_period']

        if (self.df_colswaps.shape[0] <= 1 and
                ('df_FSLIE_avg' not in self.data_dict or self.data_dict['df_FSLIE_avg'].shape[0] < 1)):
            self.valid_dataset = False
            self.log.warning('Either one or no collectors present in self.df_colswaps, cannot process this system')
        if self.df_dose.shape[0] <= 1:
            self.valid_dataset = False
            self.log.warning('No values present in self.df_dose, cannot process this system')
        return None

    def prep_FSLIE_and_UR_state(self):
        """
        Get FSLIE data, as well as chuck_id and illumination information.
        Will determine columns "col_clean_period" and "UR". FSLIE values are copied to column "FSLIE_original".

        Prerequisite: run function prep_clean_collector_timeperiods first

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_FSLIE_and_UR_state"')

        self.df_FSLIE = self.data_dict['FSLIE'].copy(deep=True)

        self.df_FSLIE.dropna(inplace=True)

        # Add columns col_clean_period and col_period
        if self.df_colswaps.empty:
            self.log.error(
                'No collector swaps found in self.df_colswaps, was "prep_clean_collector_timeperiods" run earlier?')
        self.df_FSLIE['col_clean_period'] = -1  # Init column
        self.df_FSLIE['col_period'] = -1  # Init column
        for i, ituple in enumerate(self.df_colswaps.itertuples()):
            idict = ituple._asdict()
            self.df_FSLIE['col_clean_period'] = [idict['col_clean_period'] if
                                                 idict['Index'] < time < idict['tmax'] else
                                                 value for (time, value) in
                                                 zip(self.df_FSLIE.index.tolist(),
                                                     self.df_FSLIE['col_clean_period'].tolist())]
            self.df_FSLIE.loc[idict['Index']:, 'col_period'] = idict['col_clean_period']
        self.df_FSLIE = shared.merge_ts_index(self.df_FSLIE, self.df_colswaps[['col_period', 'colswap']], how='left')
        self.df_FSLIE['machine_id'] = self.machine_id
        self.df_FSLIE['source_nr'] = self.source_nr

        # Classify UR state and select only UR1
        self.df_FSLIE = self.classify_UR_state(self.df_FSLIE)
        self.df_FSLIE = self.df_FSLIE.query('UR==1')

        # Note: filtering does not take into account pupil dependency of FSLIE

        # Filter values that occur too often, likely simulated
        dfg = self.df_FSLIE.groupby(by=['col_period', 'FSLIE'], as_index=False).count().rename(
            columns={'source_nr': 'count'})
        self.df_FSLIE = shared.merge_ts_index(self.df_FSLIE, dfg[['col_period', 'FSLIE', 'count']], how='left')
        self.df_FSLIE = self.df_FSLIE.query(f'count<{self.FSLIE_SIM_maxpoints}')

        # Since col_period's with very few datapoints (or no measurements) can
        # give issues, also use a simple upper limit to filter those
        self.df_FSLIE = self.df_FSLIE.query(f'1<FSLIE<{self.FSLIE_maxvalue}')  # Also filter out FSLIE==0 values

        # Filter all values that are too far above the mean
        self.df_FSLIE = shared.merge_ts_index(self.df_FSLIE,
                                              self.df_FSLIE.groupby(by=['col_period'], as_index=False).mean(
                                              ).rename(columns={'FSLIE': 'FSLIE_mean'})[['col_period', 'FSLIE_mean']],
                                              how='left')
        self.df_FSLIE = self.df_FSLIE.loc[self.df_FSLIE['FSLIE'] < self.df_FSLIE['FSLIE_mean'] + self.FSLIE_SIM_cutoff]

        self.df_FSLIE = self.df_FSLIE.sort_index()
        # Make backup of FSLIE values to compare later to corrected values
        self.df_FSLIE['FSLIE_original'] = self.df_FSLIE['FSLIE']

        self.prep_pupil_usage()

        self.df_FSLIE_AllData = self.df_FSLIE.copy()

        # Filter data before the first known collector swap
        self.df_FSLIE = self.df_FSLIE.loc[self.df_colswaps.index[0]:]

        # Clean up
        del self.df_FSLIE['FSLIE_mean']
        del self.df_FSLIE['count']

        if self.df_FSLIE.shape[0] <= 10:
            self.valid_dataset = False
            self.log.warning('No FSLIE data found, aborted')

        return None

    def prep_pupil_usage(self):
        """
        Determine how often a pupil is used in self.df_FSLIE, based on columns 'mode_DC', 'sigma_inner', 'sigma_outer'.
        Only uses the 'clean' collector period. This information is added to self.df_FSLIE

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_pupil_usage"')

        # Determine pupil usage stats, group both chucks, assume exposures use dual chuck
        # Do NOT group on doe_id, as this can change (For example: Large
        # Conventional often has doe_id 0 and/or 15)
        segmentation = ['mode_DC', 'sigma_inner', 'sigma_outer']

        self.df_pupil_usage = self.df_FSLIE.query('col_clean_period!=-1').groupby(segmentation, as_index=False).agg(
            {'FSLIE': np.size}).sort_values(by='FSLIE', ascending=False).rename(columns={'FSLIE': 'FSLIE_counter'})
        self.df_pupil_usage = add_doe_id_name(self.df_pupil_usage, self.data_dict['pupinfo'])

        self.df_FSLIE = shared.merge_ts_index(self.df_FSLIE, self.df_pupil_usage, how='left')
        return None

    def prep_vacuum_states(self):
        """
        Determine the periods when the scanner was vented: i.e. the vacuum was off, based on the pressure inside the
        machine. Querying vacuum data can take a while.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_vacuum_states"')

        self.df_vacuum = self.data_dict['vacpress'].copy(deep=True)
        self.df_vacuum['vacenabled'] = self.df_vacuum[
            'vacpress'] < self.vacuum_pressure_min  # Based on Pa
        self.df_vacuum['vacpress'] = self.df_vacuum[
            'vacpress'] / 100000  # Pa to bar, 1bar = 100000 Pa
        self.df_vacuum = self.extract_start_stop_time_from_discrete_parameters(
            self.df_vacuum, 'vacenabled', dt_margin=pd.Timedelta(26, unit='h'))
        return None

    def prep_pressure(self):
        """
        Determine the periods when the scanner had stable pressure [Pa].

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_pressure"')

        dfp = self.data_dict['vacpress'].copy(deep=True)

        # Get overlap with FSLIE measurement dates
        sample_rate = dfp.index[1] - dfp.index[0]
        # Resampling breaks (ZeroDivisionError) if not enough points, no specific workaround deemed necessary
        dff = self.df_FSLIE[['FSLIE']].resample(sample_rate).mean().dropna().index.to_numpy()
        dfp['has_FSLIE'] = [x in dff for x in dfp.index]

        dfp['dvacpress'] = np.abs(dfp['vacpress'] - dfp['vacpress'].shift(-1))
        dfp['vacpress_stable'] = np.logical_and.reduce((dfp['dvacpress'] < self.pressure_maxdelta,  # Based on Pa,
                                                        dfp['vacpress'] < self.pressure_upperlimit,
                                                        dfp['vacpress'] > self.pressure_lowerlimit))
        self.df_pressure = dfp
        return None

    def prep_DGLmembrane_presence(self):
        """
        Determine if and at which times a DGL-Membrane was present, as this will decrease the transmission between ES
        and SS/SLS and therefore impact FSLIE.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_DGLmembrane_presence"')

        self.df_DGLmem_rawtrace = self.data_dict['DGLm'].copy(deep=True)
        self.df_DGLmem_rawtrace['DGLM_type'] = self.df_DGLmem_rawtrace[
            'DGLM_type'].astype(int)

        # Determine if the DGLmembrane is present or not. When measurement are
        # missing just assume last known state to still be correct
        self.df_DGLmem = self.extract_start_stop_time_from_discrete_parameters(
            self.df_DGLmem_rawtrace, 'DGLM_type', method='ffill')
        self.df_DGLmem['DGLmem'] = self.df_DGLmem[
            'DGLM_type'] < self.DGLmembrane_toggle

        if not set(self.df_DGLmem['DGLM_type'].tolist()) <= set(self.DGLmembrane_transmissiondict.keys()):
            raise Exception(
                f'Not all DGLm types are present in the DGLm type to transmission dictionary:' +
                f'{set(self.df_DGLmem["DGLM_type"].tolist())}')
        self.df_DGLmem['DGLM_trans'] = [self.DGLmembrane_transmissiondict[
            x] for x in self.df_DGLmem['DGLM_type']]
        return None

    def prep_pellicle_presence(self):
        """
        Determine if a pellicle was used. The SSLS fiducial versus reticle reflectivity ratio can be used for this.
        If a pellicle is present the reticle will reflect less, while the fiducial is not affected.
        Therefore this should not impact FSLIE which is measured with the fiducial, data is included for reference.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_pellicle_presence"')

        self.df_pellicle = self.data_dict['pellicle'].copy(deep=True)
        if not self.df_pellicle.empty:
            self.df_pellicle['pellicle'] = self.df_pellicle[
                'FidRetRatio'] < self.fiducial_reticle_ratio_toggle
            self.df_pellicle_rawtrace = self.df_pellicle.copy(deep=True)
            self.df_pellicle = self.extract_start_stop_time_from_discrete_parameters(
                self.df_pellicle, 'pellicle')
        return None

    def prep_SS_SL_values(self, target: str):
        """
        Prep SS CF values for the anchor for complete lifetime, optionally also the SS and SL CF values for anchor,
        leading, nonleading values.

        :param target: Key in data_dict with corresponding column in dataframe to work on
        :return: DataFrame with unique values, column tmax with ffill time and "{target}_rel_to_T0 column"
        :rtype: pandas dataframe
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info(f'Executing: "prep_SS_SL_values" for {target}')

        df = self.data_dict[target].copy(deep=True)
        df = df.query(f'{0}<{target}<{self.SS_SL_cutoff}')

        # Do not use the normal self.df_FSLIE as all FSLIE values before the first collector are removed
        df_FSLIE = self.df_FSLIE_AllData.copy()

        if not df.empty:
            df = self.extract_start_stop_time_from_discrete_parameters(df, target, method='ffill')

            df.index.name = '_ts_index_'

            # Filter any SS SL values where no FSLIE measurements where done
            df['group'] = np.arange(df.shape[0])
            df_tmp = df.join(df_FSLIE[['FSLIE']], how='outer')
            df_tmp = df_tmp.ffill().dropna()
            df_tmp = df_tmp.groupby('group').count().rename(columns={'FSLIE': 'FSLIE_counter'})
            df_del = df_tmp.query('1<FSLIE_counter<=10').reset_index()[['group', 'FSLIE_counter']]
            df_del = shared.merge_ts_index(df, df_del, how='right')
            for ituple in df_del.itertuples():
                idict = ituple._asdict()
                df_FSLIE = df_FSLIE.drop(df_FSLIE.loc[idict['Index']:idict['tmax']].index)

            df_tmp = df_tmp.query('FSLIE_counter>10').reset_index()[['group', 'FSLIE_counter']]
            self.df = df.copy()
            self.df_tmp = df_tmp.copy()
            df = shared.merge_ts_index(df, df_tmp, how='right')
            del df['group']

            if f'df_{target}' in self.data_dict and self.data_dict[f'df_{target}'].shape[0] >= 1:
                self.log.info('Previous SSCFl dataframe found, appending new SSCFl values')
                df_prev = self.data_dict[f'df_{target}'].copy()
                target_from_time = df_prev.index.max() + pd.Timedelta(1, unit='s')
                df = df.loc[target_from_time:, :]
                # Adjust the latest tmax value to reflect the new SSCFl data
                df_prev.loc[df_prev.index.max(), 'tmax'] = df.index.min() - pd.Timedelta(1, unit='s')
                df = df_prev.append(df)
            else:
                target_from_time = TIMEZERO

            init_value = df[target].tolist()[0]
            df.loc[:, f'{target}_delta_ratio'] = [1.0] + [(j / i) for (i, j) in zip(df[target].tolist()[:-1],
                                                                                    df[target].tolist()[1:])]
            df.loc[:, f'{target}_delta'] = [0] + [(j - i) / j for (i, j) in zip(df[target].tolist()[:-1],
                                                                                df[target].tolist()[1:])]
            df.loc[:, f'{target}_rel_to_T0'] = df.loc[:, target] / init_value

            df['tprev'] = [TIMEZERO] + df.index.tolist()[:-1]
            df['days_valid'] = df.index - df['tprev']
            df['days_valid'] = [x.total_seconds() / (24 * 60 * 60) for x in df['days_valid']]
        return df

    def prep_SS_SL_jump_removal(self, target='l'):
        """
        When the sensor module is swapped, and a low power version is replaced by a high power version,
        the photon sensitivity is 2-3 times lower, and thus the conversion factor is 2-3x higher. Since the module is
        per chuck, both the Spot and Slit Sensor CF of either the leading and/or non-leading should show a jump.

        Find these jumps, and remove them. All other SS/SL CF fluctuations should not be corrected.

        :param target: Define target to be leading 'l' or non-leading 'nl' sensors, defaults to 'l'
        :return: Dataframe with Spot Sensor data, corrected
        :rtype: pd.DataFrame
        """
        df_SS = self.get(f'df_SSCF{target}')
        df_SS.loc[:, f'SSCF{target}_delta_ratio_corrected'] = df_SS.loc[:, f'SSCF{target}_delta_ratio']
        df_SL = self.get(f'df_SLCF{target}')

        suspect_jumps = df_SS.loc[df_SS[f'SSCF{target}_delta_ratio'] > self.SS_SL_hwjump]

        for i, ituple in enumerate(suspect_jumps.itertuples()):
            idict = ituple._asdict()
            preSS = weighted_average(df_SS.loc[:idict['Index']], f'SSCF{target}', 'days_valid')
            preSL = weighted_average(df_SL.loc[:idict['Index']], f'SLCF{target}', 'days_valid')
            postSS = weighted_average(df_SS.loc[idict['Index']:], f'SSCF{target}', 'days_valid')
            postSL = weighted_average(df_SL.loc[idict['Index']:], f'SLCF{target}', 'days_valid')

            if postSS / preSS >= self.SS_SL_hwjump and postSL / preSL >= self.SS_SL_hwjump:
                self.log.info(f'Found a probable sensor-module swap from low to high power, ignored SS/SL CF ' +
                              f'{target} jump: {idict["Index"]}, jump ratio SS / SL: ' +
                              f'{postSS/preSS:.2f} / {postSL/preSL:.2f}')
                df_SS.loc[idict['Index'], f'SSCF{target}_delta_ratio_corrected'] = 1.0

        df_SS.loc[:, f'SSCF{target}_rel_to_T0_corrected'] = np.cumprod(
            df_SS.loc[:, f'SSCF{target}_delta_ratio_corrected'])
        return df_SS

    def prep_Unicom_values(self):
        """
        Get Unicom fingers absolute transmission values. Also determine the mean UnicomAbs value of the first collector
        swap with Unicom data, so that can be later used to correct earlier FSLIE with said value.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_Unicom_values"')

        self.df_Unicom = self.data_dict['UniCom'].copy(deep=True)
        if not self.df_Unicom.empty:
            self.df_Unicom = self.classify_UR_state(self.df_Unicom)
            self.df_Unicom = self.df_Unicom.query('UR==1')
            # As the Unicom values vary a lot, do not use the function
            # "extract_start_stop_time_from_discrete_parameters"
            self.df_Unicom['tmax'] = self.df_Unicom.index.tolist()[1:] + [self.data_dict['to_time']]
            self.df_Unicom['tmax'] = self.df_Unicom['tmax'] - pd.Timedelta(1e-3, unit='s')

            df = shared.custom_join(self.df_FSLIE, self.df_Unicom, 'UnicomAbs', np.nan)
            df = df.dropna().query(
                'col_clean_period!=-1')[['doe_name', 'colswap', 'col_clean_period', 'UnicomAbs']]
            df = df.groupby(['doe_name', 'col_clean_period']).mean()
            df = df.reset_index(drop=False)
            df = shared.merge_ts_index(self.df_colswaps['col_clean_period'], df, how='right')
        else:
            df = pd.DataFrame(columns=['doe_name', 'colswap', 'col_clean_period', 'UnicomAbs'],
                              index=pd.to_datetime(np.array([]), utc=True))
            df.index.name = '_ts_index_'
        df = df.reset_index(drop=False)

        if 'df_FSLIE_avg' in self.data_dict and self.data_dict['df_FSLIE_avg'].shape[0] >= 1:
            self.df_Unicom_avg = self.data_dict['df_FSLIE_avg'].copy()
            self.df_Unicom_avg = self.df_Unicom_avg.loc[self.df_Unicom_avg[
                'UnicomAbs'].notnull(), ['col_clean_period', 'doe_name', 'UnicomAbs']]
            if pd.api.types.is_datetime64_any_dtype(self.df_Unicom_avg.index):
                self.df_Unicom_avg = self.df_Unicom_avg.reset_index(drop=False)
            self.df_Unicom_avg = self.df_Unicom_avg.query(f'col_clean_period not in {df["col_clean_period"].tolist()}')
            self.df_Unicom_avg = self.df_Unicom_avg.append(df)
        else:
            self.df_Unicom_avg = df

        self.df_Unicom_avg = self.df_Unicom_avg.sort_values(by=['doe_name', 'col_clean_period'])
        self.df_Unicom_avg = self.df_Unicom_avg.set_index(['_ts_index_'])

        # Calculate the mean of the first colswap where Unicom values are present
        # Start from the first colswap in 2020 and then find the first colswap where Unicom values are present.
        self.Unicom_backfill_value = 1
        starttime_Unicom = pd.Timestamp(year=2020, month=1, day=1).tz_localize('UTC')
        if not self.df_Unicom.empty and not self.df_colswaps.loc[starttime_Unicom:].empty:
            for ituple in (self.df_colswaps.loc[starttime_Unicom:].itertuples()):
                idict = ituple._asdict()
                newvalue = self.df_Unicom.loc[idict['Index']:idict['tmax'], 'UnicomAbs'].mean()
                if not np.isnan(newvalue):
                    self.Unicom_backfill_value = newvalue
                    break

        self.log.info(f'Unicom backfill values calculated')  # : {self.Unicom_backfill_value:.3f}')

        return None

    def prep_FAT_period(self):
        """
        Add a column 'FAT' to self.df_colswaps identifying when machine was at Factory or (customer) Site.

        Use longest amount of consecutive days without vacuum between collector swaps as a benchmark whether the
        period after the collector swap was used for moving from Factory (ASML) to Site (customer).

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing: "prep_FAT_period"')

        df_novacuum = pd.DataFrame({'tmax': self.df_vacuum.index.tolist()[1:]}, index=self.df_vacuum['tmax'][:-1])
        df_novacuum.loc[:, 'timedelta'] = df_novacuum.loc[:, 'tmax'] - df_novacuum.index
        df_novacuum.loc[:, 'timedelta'] = df_novacuum.loc[:, 'timedelta'].astype('timedelta64[D]')

        if self.df_colswaps.empty:
            pass
        else:
            tmax_list = self.df_colswaps.index.tolist(
            )[1:] + [self.data_dict['to_time']]

            # Add number of novacuumdays
            for i, ituple in enumerate(self.df_colswaps.itertuples()):
                idict = ituple._asdict()
                metric = df_novacuum[idict['Index']:tmax_list[i]]['timedelta'].to_numpy()
                self.df_colswaps.loc[idict['Index'], 'novacuumdays'] = 0 if metric.size == 0 else metric.max()
            self.df_colswaps.loc[:, 'FAT'] = False

            last_FAT_period = self.df_colswaps[self.df_colswaps['novacuumdays'] >= self.FAT_to_SAT_mintime]
            if not last_FAT_period.empty:
                # All time before this was FAT, not SAT
                self.df_colswaps.loc[:last_FAT_period.index.tolist()[0], 'FAT'] = True
                self.log.info(
                    f'Found FAT period up to and including "col_clean_period":' +
                    f'{last_FAT_period["col_clean_period"].tolist()[0]}')

            # Add SAT column with counter of SAT period
            if 'df_FSLIE_avg' in self.data_dict and self.data_dict['df_FSLIE_avg'].shape[0] >= 1:
                # This probably does not go well if a system transfers from FAT to SAT if being analysed chunk by chunk
                SAT = self.data_dict['df_FSLIE_avg']['SAT'].max()
                self.df_colswaps.loc[:, 'SAT'] = np.linspace(SAT + 1, SAT + 1 + self.df_colswaps.shape[0] - 1,
                                                             num=self.df_colswaps.shape[0])
            else:
                n_fat = self.df_colswaps.query('FAT==True').shape[0]
                self.df_colswaps.loc[:, 'SAT'] = np.linspace(-n_fat, self.df_colswaps.shape[0] - n_fat - 1,
                                                             num=self.df_colswaps.shape[0])
        return None

    def prep_plasma_source_position(self):
        """
        Determine plasma/source position + delta modulus from x,y,z values. Simply use Pythagoras.

        :return: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        for target in ['pos_plasma', 'pos_source', ]:
            if target in self.data_dict and self.data_dict[target].shape[0] >= 1:
                self.log.info(f'Executing: "prep_plasma_source_position" for {target}')
                df = self.data_dict[target].copy(deep=True)
                df[target] = np.sqrt(np.power(df['x'], 2) + np.power(df['y'], 2) + np.power(df['z'], 2))

                df = self.extract_start_stop_time_from_discrete_parameters(
                    df, target, method='ffill')

                self.set(f'df_{target}', df)
        return None

    def prep_combined_pupil_data(self, target_df='df_FSLIE', target_cname='FSLIE'):
        """
        Combine FSLIE values of pupils to pad data and get more reliable analysis.

        :param target_df: Name of target Dataframe, changed inplace
        :param target_cname: Name of target column name
        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info(f'Executing: "prep_combined_pupil_data" for {target_df}, column "{target_cname}"')

        available_pupils = [x for x in self.pupil_combination_list if x in self.df_pupil_usage['doe_name'].tolist()]
        if len(available_pupils) <= 1:
            self.log.warning('Not enough of the pupil targets available for creating a combined pupil')
            return None

        pupil_combination_reference = available_pupils[0]
        pupil_combination_targets = available_pupils[1:]

        tmax_list = self.df_colswaps.index.tolist()[1:] + [self.data_dict['to_time']]

        pupil_ratios = pd.DataFrame(columns=['col_period', 'col_clean_period', 'doe_name', 'pupil_ratio'])

        for itarget, target in enumerate(pupil_combination_targets):
            for i, ituple in enumerate(self.df_colswaps.itertuples()):
                idict = ituple._asdict()

                # Select relevant data for clean pupil period
                df = self.get(target_df).loc[idict['Index']:idict['tmax']].query(f'doe_name in {available_pupils}')

                if df.empty:
                    pupil_ratios.loc[i, :] = [idict['col_clean_period'], idict['col_clean_period'], target, np.nan]
                else:
                    # Calculate mean FSLIE per pupil, and select only days where
                    # pupil_combination_reference is present
                    dfg = df.groupby(['doe_name', ]).resample(
                        self.pupil_combination_timeinterval).agg({f'{target_cname}': [np.mean, np.size]})
                    dfg = dfg.reset_index().set_index('_ts_index_')
                    dfg.columns = ["_".join(x).rstrip('_') for x in dfg.columns.ravel()]
                    dfg = dfg.query(f'{target_cname}_size>=2')
                    dfg = dfg.loc[dfg.query(f'doe_name=="{pupil_combination_reference}"').index]

                    # Select only those index values that have overlapping values
                    dfgtmp = dfg.groupby(['_ts_index_', ]).agg({'doe_name': [np.size]})
                    dfgtmp = dfgtmp.reset_index().set_index('_ts_index_')
                    dfgtmp.columns = ["_".join(x).rstrip('_') for x in dfgtmp.columns.ravel()]
                    dfgtmp = dfgtmp.query('doe_name_size>=2')
                    dfg = dfg.loc[dfgtmp.index]

                    # Save relevant value
                    pupil_ratio = dfg.query(f'doe_name=="{target}"')[f'{target_cname}_mean'].mean() / \
                        dfg.query(f'doe_name=="{pupil_combination_reference}"')[f'{target_cname}_mean'].mean()
                    # Assumed col_clean_period can also be used for col_period
                    pupil_ratios.loc[i, :] = [idict['col_clean_period'],
                                              idict['col_clean_period'], target, pupil_ratio]

            # For missing data, do a ffill then a bfill, then add to global dataframe
            pupil_ratios = pupil_ratios.fillna(method='ffill').fillna(method='bfill')

            for i, ituple in enumerate(pupil_ratios.itertuples()):
                idict = ituple._asdict()
                # Now correct the target, append both, and append to original df
                dfnew = self.get(target_df).query(f'col_period=={idict["col_period"]} and doe_name=="{target}"').copy()
                dfnew.loc[:, f'{target_cname}'] = dfnew.loc[:, f'{target_cname}'] / idict['pupil_ratio']
                if itarget == 0:  # Only append pupil_combination_reference once
                    dfnew = dfnew.append(self.get(target_df).query(f'col_period == {idict["col_period"]} and ' +
                                                                   f'doe_name == "{pupil_combination_reference}"'))
                dfnew.loc[:, 'doe_name_original'] = dfnew.loc[:, 'doe_name']
                dfnew.loc[:, 'doe_name'] = 'Combined Pupil'
                self.set(target_df, self.get(target_df).append(dfnew).sort_index())
        return None

    def correct_ALL(self):
        """
        Execute all 'correction'  functions of POB TMONI.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        self.correct_for_DGLmembrane()

        self.correct_SSCF_jumps(target='SSCFl')

        self.correct_Unicom_transmission()
        return None

    def correct_for_DGLmembrane(self, target_column: str='FSLIE'):
        """
        Adjust FSLIE values in self.df_FSLIE for presence (and subsequent transmission loss) of DGL membrane.

        FSLIE_corrected = FSLIE / DGLm_transmission

        :param target_column: Column to work on in self.df_FSLIE, defaults to 'FSLIE'
        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Correcting FSLIE signal for DGLmembrane impact')

        self.df_FSLIE = shared.custom_join(self.df_FSLIE, self.df_DGLmem, 'DGLM_trans', 1.0)
        self.df_FSLIE[target_column] /= self.df_FSLIE['DGLM_trans']
        return None

    def correct_SSCF_jumps(self, target: str='SSCFl', target_column: str='FSLIE'):
        """
        Multiply all FSLIE data with the relative SSCFx value with respect to the first value measured.
        The 'x' can be a, l, or nl for anchor, leading, or non-leading Spot Sensor Conversion Factor.

        FSLIE_corrected = FSLIE / SSCFx_relative_to_T0

        :param target: Name of sensor and dataframe to work on, SSCFa, SSCFl, SSCFnl, defaults to SSCFl
        :param target_column: Column to work on in self.df_FSLIE, defaults to 'FSLIE'
        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info(f'Correcting FSLIE signal for {target} jumps')

        self.df_FSLIE = shared.custom_join(self.df_FSLIE, self.get(f'df_{target}'), f'{target}_rel_to_T0_corrected', 1)
        self.df_FSLIE[target_column] /= self.df_FSLIE[f'{target}_rel_to_T0_corrected']
        return None

    def correct_Unicom_transmission(self, target_column: str='FSLIE'):
        """
        Unicom transmission correction. Only use UR1 values and correct all FSLIE values before UR data is available
        with the first UR measurement to prevent FSLIE jumps due to this correction.

        :param target_column: Column to work on in self.df_FSLIE, defaults to 'FSLIE'
        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Correcting FSLIE signal for Unicom transmission changes')

        if set(self.df_FSLIE['UR'].tolist()) != {1}:
            self.log.warning(
                'Function "correct_Unicom_transmission" should only be used for UR1 data, currently more UR data is' +
                'still present in the FSLIE dataframe.')

        # Set UnicomAbs value for all pupils with no Unicom data to 1
        UnicomPupils = set(self.df_Unicom_avg['doe_name'].tolist())
        # Create copies to prevent issues if index has duplicates
        df = self.df_FSLIE.loc[~self.df_FSLIE['doe_name'].isin(UnicomPupils), :].copy()
        df['UnicomAbs'] = 1  # Set value if no Unicom data present

        for pup in set(self.df_Unicom_avg['doe_name'].tolist()):
            Unicom_backfill_value = self.df_Unicom_avg.query(f'doe_name=="{pup}"').sort_values(
                by=['col_clean_period'], ascending=True)['UnicomAbs'].to_numpy()[0]
            self.log.info(f'Pupil {pup} has Unicom backfill value: {Unicom_backfill_value:.2f}')

            df_tmp = shared.custom_join(self.df_FSLIE.query(f'doe_name=="{pup}"'),
                                        self.df_Unicom,
                                        'UnicomAbs',
                                        Unicom_backfill_value)

            df = df.append(df_tmp)
        self.df_FSLIE = df.copy().sort_index()

        self.df_FSLIE.loc[:, target_column] /= self.df_FSLIE.loc[:, 'UnicomAbs']
        return None

    def calculate_ALL(self):
        """
        Execute all 'calculation' functions

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        # Only combine pupil data after corrections are done
        self.prep_combined_pupil_data()

        self.calculate_pressure_per_colswap()

        self.calculate_FSLIE_jumps()

        self.calculate_FSLIE_and_cumdose_after_colswap()

        self.df_FSLIE_avg = self.calculate_FSLIE_losses(self.df_FSLIE_avg)

        self.calculate_POB_loss()
        return None

    def calculate_FSLIE_jumps(self, cname: str='FSLIE'):
        """
        FSLIE jump detection still has to be finetuned. Currently a PELT algorithm is used to detect potential jumps,
        then some manual check are done to see if the jump is interesting. Basically there is a minimum amount of
        points needed on both sides of the jump, and a minimum amount of days with data from a certain range of days
        around the jump. The jump detection is done per collector time period, as with every new collector a jump is
        expected anyways.

        Sources:
        - https://techrando.com/2019/08/14/a-brief-introduction-to-change-point-detection-using-python/
        - http://ctruong.perso.math.cnrs.fr/ruptures-docs/build/html/detection/pelt.html

        :param cname: Column to work on in self.df_FSLIE, defaults to 'FSLIE'
        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Calculating potential FSLIE jumps')

        self.df_FSLIE_jumps = pd.DataFrame(columns=['_ts_index_', 'doe_name', 'source_nr', 'jump_direction'])
        self.df_FSLIE_jumps = self.df_FSLIE_jumps.set_index(['_ts_index_', 'doe_name'])
        colswaps = self.df_colswaps.index.tolist() + [self.data_dict['to_time']]

        # Look for potential jumps per collector
        for doe_name in ['Combined Pupil'] + self.pupil_combination_list:
            for idx in np.arange(len(colswaps) - 1):
                df = self.df_FSLIE.loc[colswaps[idx]:colswaps[idx + 1]]
                df = df.query(f'doe_name=="{doe_name}"')[[cname]]
                df = df.resample(self.jump_smoothing_timeinterval).mean().dropna()

                if df.shape[0] > 10:
                    time = df.index.to_numpy()
                    y = df[cname].to_numpy()

                    # Identify and remove peaks (limit false positives)
                    peaks = identify_peak_indices(y, **self.jump_peak_smooth_kwargs)
                    y_nopeaks = np.delete(y, peaks)
                    time_nopeaks = np.delete(time, peaks)

                    # Identify changepoints
                    for direction, jumps in identify_changepoints(y_nopeaks,
                                                                  min_jump_ratio=self.min_jump_ratio).items():
                        for jump in jumps:
                            self.df_FSLIE_jumps.loc[(time_nopeaks[jump], doe_name), :] = [self.source_nr, direction]
        self.df_FSLIE_jumps = self.df_FSLIE_jumps.reset_index(level='doe_name').sort_index()
        return None

    def calculate_pressure_per_colswap(self):
        """
        Calculate the pressure per clean collector period, for all pupils. This to prevent that pupils with fewer
        datapoints can get deviating pressure values.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Calculating pressure per clean collector period')

        for i, ituple in enumerate(self.df_colswaps.itertuples()):
            idict = ituple._asdict()
            pressure = self.df_pressure.loc[np.logical_and.reduce((
                self.df_pressure['has_FSLIE'],  # Filter only when FSLIE is measured
                self.df_pressure['vacpress_stable'],  # Filter only relevant pressure signal
                self.df_pressure.index > idict['Index'],
                self.df_pressure.index < idict['tmax_x3'])), 'vacpress'].mean()
            self.df_colswaps.loc[idict['Index'], 'pressure'] = pressure
        return None

    def _calculate_representative_FSLIE_value(self, df_input: pd.DataFrame, colswap_dict: dict, cname_y: str='FSLIE'):
        """
        Calculate the representative FSLIE value, within one collector period.

        Prep data:
        - Resample data per x hours (mean)
        - Filter data outside mean+-n*sigma
        - Filter peaks
        - Determine jumps more than x% within the clean collector period, then only analyse data after those jumps

        Determine representative FSLIE:
        - Use method 1, if criteria met to invalidate fit, use method 2
            - Method 1:
                Determine jumps, only take data after jumps within the clean collector period.
                Fit a piecewise linear function on scaled data, containing two pieces and appropriate bounds
                Take the y0 variable of the fit as the representative FSLIE value
            - Method 2:
                Take the mean of the top 3 post-filtering FSLIE datapoints

        :param df: Input dataframe, corresponding to one collector period
        :param colswap_dict: Dictionary containing the info of the collector swap being analysed
        :param cnamy_y: Column to work on, defaults to 'FSLIE'
        :return: DataFrame with resampled data, dataframe with result
        :rtype: pandas dataframe, pandas dataframe
        """
        do_it.do_it_verbose(currentframe(), self.verbose)

        doe_name = df_input['doe_name'].tolist()[0]

        self.log.info(f'Calculating {cname_y} metric per collector swap ({colswap_dict["col_period"]}): ' +
                       f'pupil is {doe_name}')

        valid = True
        # Resample data
        df = df_input.resample(self.rep_FSLIE_resample_timeinterval).mean()
        df = df.loc[df[cname_y].notnull(), :]
        df = df.reset_index(drop=False)

        df = df.loc[:, ['_ts_index_', cname_y, ]]
        tstart = df.loc[0, '_ts_index_']
        tmax_cleancol = (colswap_dict['tmax'] - tstart).total_seconds() / 3600
        tmax_cleancol_x3 = (colswap_dict['tmax_x3'] - tstart).total_seconds() / 3600

        df['_ts_index_hours'] = np.array([(x - tstart).total_seconds() / 3600 for x in df['_ts_index_']])

        # Start with filtering pre-jump data, use FSLIE jumps regardless of cname_y
        jumps = self.df_FSLIE_jumps.query(f'doe_name=="{doe_name}"').loc[df_input.index.min():df_input.index.max()]
        xdata_cutoff_for_jump = 0
        for jump in jumps.index.to_list():
            # Only look at jumps within tmax_x3 limit, and if there is FSLIE data between the jump and tmax_x3

            if jump < colswap_dict['tmax_x3'] and df.loc[np.logical_and(
                    df['_ts_index_'].to_numpy() > jump,
                    df['_ts_index_'].to_numpy() < colswap_dict['tmax_x3']), :].shape[0] >= 3:
                xdata_cutoff_for_jump = (jump - tstart).total_seconds() / 3600
        df['postjump'] = df['_ts_index_hours'] > xdata_cutoff_for_jump
        if df.loc[df['postjump']].shape[0] < 5:
            valid = False
            self.log.warning('Collector swap invalid: postjump datapoints less than 5')

        # Then use a 3 sigma filter
        df.loc[:, 'sigma_filtered'] = False
        if valid:
            df.loc[df['postjump'], 'sigma_filtered'] = sigma_filter(
                df[cname_y].loc[df['postjump']].to_numpy(), n_sigma=3)

        # Identify and remove peaks (limit false positives)
        # Also select data after jumps within clean collector period
        df.loc[:, 'peak'] = False
        if valid:
            peaks = identify_peak_indices(df.loc[np.logical_and(
                df['postjump'], ~df['sigma_filtered']), cname_y], **self.jump_peak_smooth_kwargs)
            df.loc[peaks, 'peak'] = True

        mask = np.logical_and.reduce((df['postjump'], ~df['sigma_filtered'], ~df['peak']))
        df['mask'] = mask

        if valid:
            # Determine FSLIE KPI for fallback: take mean of top 3 non-peak values within clean collector time period
            FSLIE_array = np.sort(df.loc[np.logical_and(
                df['_ts_index_hours'] < tmax_cleancol, mask), cname_y].drop_duplicates().to_numpy())
            FSLIE_array_x3 = np.sort(df.loc[np.logical_and(
                df['_ts_index_hours'] < tmax_cleancol_x3, mask), cname_y].drop_duplicates().to_numpy())
            if len(FSLIE_array) > 3:
                FSLIE_fallback = FSLIE_array[-3:].mean()
            elif len(FSLIE_array_x3) > 3:
                FSLIE_fallback = FSLIE_array_x3[-3:].mean()
                self.log.warning('Not enough points in clean collector period for fallback method, ' +
                                 'used tmax_cleancol_x3')
            else:
                FSLIE_fallback = np.nan
                self.log.warning('Not enough points in clean collector period for fallback method')

            # Now rescale the data to 0-1 for x and y
            xdata = df.loc[df['mask'], '_ts_index_hours'].to_numpy()
            ydata = df.loc[df['mask'], cname_y].to_numpy()
            if np.unique(ydata).size <= 4 or np.unique(ydata[xdata < tmax_cleancol_x3]).size <= 2:
                self.log.warning(f'Too few values to perform fit, aborted: ' +
                                 f'{xdata[xdata < tmax_cleancol_x3]} / {ydata[xdata < tmax_cleancol_x3]}')
                FSLIE_piecewise = np.nan
                fallback = True
            elif tmax_cleancol <= 0:
                self.log.warning(f'No {cname_y} values within clean collector period, aborted: ' +
                                 f'tmax_cleancol={tmax_cleancol}')
                FSLIE_piecewise = np.nan
                fallback = True
            else:
                xmax = xdata.max()
                xdata_scaled = xdata / xmax  # xdata already starts at zero, rescale is simpler

                ymin = ydata[xdata < tmax_cleancol_x3].min()
                ymax = ydata[xdata < tmax_cleancol_x3].max()
                ydata_scaled = (ydata - ymin) / (ymax - ymin)

                sigmas = np.array(
                    [1 if x < 2 * tmax_cleancol else (
                        2 if x < 3 * tmax_cleancol else
                        3 + 3 * x / tmax_cleancol)
                     for x in xdata])

                # x0, y0, k1, k2
                bounds = ([xdata.min() / xmax, 0., -np.inf, -np.inf],
                          [tmax_cleancol_x3 / xmax, 1, np.inf, 1])
                try:
                    popt, pcov = curve_fit(piecewise_linear, xdata_scaled, ydata_scaled,
                                           p0=[(xdata.min() + tmax_cleancol_x3) / xmax / 2, 1, 1, 0],
                                           maxfev=100000,
                                           sigma=sigmas,
                                           bounds=bounds
                                           )
                    self.log.info(f'Fit constants for piecewise linear fit (x0, y0, k1, k2): {popt}')

                    # Check validity of piecewise linear fit
                    fallback = self._check_piecewise_fit_validity(*popt, tmax_cleancol, tmax_cleancol_x3, xmax)
                except RuntimeError:  # No fit found
                    popt = [0, 0, 0, 0]
                    self.log.info(f'Fit failed as no optimal parameters found within maxfev, dummy values used: {popt}')

                    fallback = True

                self.get(f'representative_{cname_y}_fit')[doe_name][colswap_dict['SAT']] = {
                    'popt': popt, 'tstart': tstart, 'xmax': xmax, 'ymin': ymin, 'ymax': ymax, }

                x0, y0, k1, k2 = popt
                # Take y0 and scale back to actual FSLIE
                FSLIE_piecewise = y0 * (ymax - ymin) + ymin

        if 'Index' in colswap_dict:
            colswap_dict['_ts_index_'] = colswap_dict.pop('Index')

        df['doe_name'] = doe_name

        if not valid:
            FSLIE_piecewise, FSLIE_fallback, fallback = np.nan, np.nan, False

        result = pd.DataFrame(dict(**colswap_dict,
                                   **{f'{cname_y}_piecewise': FSLIE_piecewise,
                                      f'{cname_y}_fallback': FSLIE_fallback,
                                      cname_y: FSLIE_fallback if fallback else FSLIE_piecewise,
                                      'doe_name': doe_name,
                                      }), index=[0])
        return df, result

    def _check_piecewise_fit_validity(self, x0: float, y0: float, k1: float, k2: float,
                                      tmax_cleancol: float, tmax_cleancol_x3: float, xmax: float):
        """
        Check if the piecewise fit is valid or not.
        Put in a separate function to split the analysis and the validity check.

        See function "piecewise_linear" for fit coefficient definitions.

        :param x0: Fit parameter
        :param y0: Fit parameter
        :param k1: Fit parameter
        :param k2: Fit parameter
        :param tmax_cleancol: Time of end of clean collector period
        :param tmax_cleancol_x3: Time of end of 3x clean collector period
        :param xmax: Max time of collector period
        :return: Boolean whether the fit is invalid (True) and the fallback method should be used
        :rtype: boolean
        """
        if k1 <= 0:
            fallback = True
            self.log.info('Piecewise fit invalid: k1 <= 0')
        elif k2 >= 0:
            fallback = True
            self.log.info('Piecewise fit invalid: k2 >= 0')
        elif k2 <= -10:  # -10 FSLIE per hour is quite a wide margin
            fallback = True
            self.log.info('Piecewise fit invalid: k2 <= -10')
        elif y0 <= 0.50:
            fallback = True
            self.log.info('Piecewise fit invalid: y0 <= 0.50')
        elif x0 <= tmax_cleancol / xmax:
            fallback = True
            self.log.info('Piecewise fit unnecessary: x0 <= tmax_cleancol / xmax')
        elif x0 >= 0.999 * tmax_cleancol_x3 / xmax:
            fallback = True
            self.log.info('Piecewise fit invalid: x0 >= 0.999 * tmax_cleancol_x3 / xmax')
        else:
            fallback = False
            self.log.info('Succes with piecewise!')

        return fallback

    def calculate_FSLIE_and_cumdose_after_colswap(self):
        """
        Calculate a representative FSLIE value for every clean collector period, and also the cumulative dose.
        Representative FSLIE calculation itself is done in "_calculate_representative_FSLIE_value"

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Calculating FSLIE metric per collector swap')

        segmentation = ['doe_name', 'UR', 'col_clean_period']
        df = self.df_colswaps.copy()

        pupils = ['Combined Pupil'] + self.pupil_combination_list

        self.df_FSLIE_resamp = pd.DataFrame()
        if 'df_FSLIE_avg' in self.data_dict and self.data_dict['df_FSLIE_avg'].shape[0] >= 1:
            self.df_FSLIE_avg = self.data_dict['df_FSLIE_avg'].copy().reset_index()
        else:
            self.df_FSLIE_avg = pd.DataFrame(columns=['machine_id', 'source_nr', 'doe_name', 'colswap',
                                                      'cumulative_dose_cumsum',
                                                      'FSLIE', 'FSLIE_total_loss', 'FSLIE_pob_loss', 'FSLIE_weight', ],
                                             index=pd.to_datetime(np.array([]), utc=True))
            self.df_FSLIE_avg.index.name = '_ts_index_'

        self.representative_FSLIE_fit = {pup: {} for pup in pupils}  # dict of dicts

        for i, ituple in enumerate(df.itertuples()):
            idict = ituple._asdict()
            for pup in pupils:
                idf = self.df_FSLIE.query(f'col_period=={idict["col_period"]} and doe_name=="{pup}"')
                if idf[['doe_name', 'FSLIE']].dropna().shape[0] >= 5 and \
                        idf.index.max() - idf.index.min() > pd.Timedelta(self.rep_FSLIE_resample_timeinterval):
                    df_resamp, result = self._calculate_representative_FSLIE_value(idf, idict)

                    self.df_FSLIE_resamp = self.df_FSLIE_resamp.append(df_resamp)
                    self.df_FSLIE_avg = self.df_FSLIE_avg.append(result)

        self.df_FSLIE_avg = self.df_FSLIE_avg.reset_index(drop=True)
        if 'UnicomAbs' in self.df_FSLIE_avg.columns:  # If already present, replace with new values
            del self.df_FSLIE_avg['UnicomAbs']
        self.df_FSLIE_avg = shared.merge_ts_index(self.df_FSLIE_avg, self.df_Unicom_avg, how='left')

        return None

    def calculate_FSLIE_losses(self, df: pd.DataFrame,
                               cname_x: str='cumulative_dose', cname_y: str='FSLIE',
                               segmentation: list=['doe_name']):
        """
        Calculate the relative FSLIE loss per collector swap. Uses some basic logic to filter out FSLIE jumps that are
        likely artefacts and not actual transmission loss.

        First determine which collector swaps to use, exclude those too close to each other and with too little
        accumulated dose.
        Second determine per collector swap what the relative FSLIE change is, and give a weight (0 or 1) whether the
        value should be used in the cumulative product to calculate the total transmission loss.

        :param df: DataFrame
        :param cname_x: Column for time/dose axis, defaults to 'cumulative_dose'
        :param cname_y: Column for FSLIE values, defaults to 'FSLIE'
        :param segmentation: Segmentation to use for calculation, defaults to ['doe_name']
        :return: DataFrame with losses calculated
        :rtype: pandas dataframe
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info(f'Calculating {cname_y} losses')

        if df[segmentation].drop_duplicates().shape[0] > 1:
            self.log.warning(
                'Function "calculate_FSLIE_losses" called with more than one pupil, will execute function ' +
                f'recursively grouped by doe_name')
            out = pd.DataFrame()
            for segment, group in df.groupby(segmentation):
                out = out.append(self.calculate_FSLIE_losses(
                    group, cname_x=cname_x, cname_y=cname_y).reset_index())
            out = out.set_index('_ts_index_')
            return out

        # Ensure for this group the index is the time
        if '_ts_index_' in df.columns:
            df = df.set_index('_ts_index_')
        # Just to be sure everything is sorted on time
        df = df.sort_index(ascending=True)
        df.loc[:, f'{cname_y}_weight'] = np.nan

        # Create all columns that are expected later, to prevent issues if they
        # are not created (due to too little data)
        for cname in [x for x in [f'{cname_x}_period', f'{cname_x}_cumsum',
                                  f'col_period_days',
                                  f'{cname_y}_weight', f'{cname_y}_comment',  f'{cname_y}_reldelta',
                                  f'{cname_y}_cumprod', f'{cname_y}_total_loss'] if x not in df.columns]:
            df[cname] = np.nan

        if df.shape[0] <= 1:  # Cannot process as too few colswaps, add NaN values and return
            self.log.info(f'Total transmission loss: {np.nan*100:.2f}% for:' +
                          f'pupil "{df["doe_name"].tolist()[0]} (too few collector swaps)"')
            return df

        # Calculate FSLIE counts for Combined pupil per collector period
        # Do no use cname_y for this for now
        counter = self.df_FSLIE.query('doe_name=="Combined Pupil"')[['col_period', 'FSLIE']].groupby([
            'col_period'], as_index=False).count()
        counter = shared.merge_ts_index(self.df_colswaps[['col_period']], counter, how='left').rename(
            columns={'FSLIE': 'counter'}).fillna(0)

        # Merge is faster but in case the counter column already exists, only add new values
        for ituple in counter.loc[counter.index.isin(df.index)].itertuples():
            idict = ituple._asdict()
            df.loc[idict['Index'], 'counter'] = idict['counter']

        start_from_date = self.data_dict['manual_corrections'].query(
            f'source_nr=="{self.data_dict["source_nr"]}" and POB_reset==True').index.max()
        if isinstance(start_from_date, pd.Timestamp):
            start_from_date_reason = shared.to_string(self.data_dict['manual_corrections'].query(
                f'source_nr=="{self.data_dict["source_nr"]}" and POB_reset==True').loc[start_from_date, 'reason'])
            self.log.info(f'Ignoring all collector swaps before {start_from_date.strftime("%y-%m-%d")}, as specified in "manual_corrections.csv"')

        # Set (temporary) cumulative_dose for last collector up front
        df.loc[df.index[-1], f'{cname_x}_period'] = self.df_dose[cname_x].tolist()[-1] - df.loc[df.index[-1], cname_x]
        # First do a round to remove invalid values, only for new colswaps
        for idx, idx_p1 in zip(df.index[:-1], df.index[1:]):
            dose_accumulated = df.loc[idx_p1, cname_x] - df.loc[idx, cname_x]

            if isinstance(start_from_date, pd.Timestamp) and idx < start_from_date:
                weight = 0
                comment = f'Pre POB reset: {start_from_date_reason}'

            elif df.loc[idx, 'FAT']:
                weight = 0
                comment = 'FAT'

            # Note that the iteration is such that the last colswap is never excluded based on this criterium
            elif df.loc[idx, 'pulsecount'] < self.pulses_after_swap:
                weight = 0
                comment = f'Discarded as too few pulses (<{self.pulses_after_swap})'

            elif np.isnan(df.loc[idx, cname_y]):
                weight = 0
                comment = f'Discarded as no representative {cname_y} value determined'

            else:
                weight = comment = np.nan

            df.loc[idx, f'{cname_x}_period'] = dose_accumulated
            df.loc[idx, f'{cname_y}_weight'] = weight
            df.loc[idx, f'{cname_y}_comment'] = comment
            df.loc[idx, f'col_period_days'] = (idx_p1 - idx).days

        # Since the last colswap is not iterated over, do separate check for FSLIE value
        if np.isnan(df.loc[idx_p1, cname_y]):
            df.loc[idx_p1, f'{cname_y}_weight'] = 0
            df.loc[idx_p1, f'{cname_y}_comment'] = f'Discarded as no representative {cname_y} value determined'

        # Only iterate over accepted values to determine FSLIE losses
        indexes = df[df[f'{cname_y}_weight'] != 0].index.tolist()
        for i, idx in enumerate(indexes):
            idx_m1 = idx if idx == indexes[0] else indexes[i - 1]
            # Determine ratio of y wrt previous value, set to 0 for first value
            dy_ratio = df.loc[idx, cname_y] / df.loc[idx_m1, cname_y] - 1
            dx_delta = df.loc[idx, cname_x] - df.loc[idx_m1, cname_x]

            if idx == idx_m1 and 'Start' not in df.loc[:, f'{cname_y}_comment'].tolist():
                weight = 1
                comment = f'Start'
                idx_init_pressure = idx

            # Jump larger than x%, do not take into account
            elif dy_ratio > self.upper_limit:
                weight = 0
                comment = f'Jump over upper limit'

            else:
                weight = 1
                comment = f'OK'

            # Check if loss is more than the lower limits, but do not filter those
            # Jump smaller than -15%
            if dx_delta < (self.lower_limit_slope / self.lower_limit_offset) and dy_ratio < self.lower_limit_offset:
                self.log.warning(f'Jump lower than lower limit offset, {dy_ratio:5.2f} < {self.lower_limit_slope:5.2f}')

            # Jump smaller than THREE times the average loss of 5% per GJ
            elif (dx_delta > (self.lower_limit_slope / self.lower_limit_offset) and
                  dy_ratio < self.lower_limit_slope * dx_delta):
                self.log.warning(
                    f'Jump lower than lower limit slope, {dy_ratio:5.2f} < {self.lower_limit_slope*dx_delta:5.2f}')

            df.loc[idx, f'{cname_y}_reldelta'] = dy_ratio
            df.loc[idx, f'{cname_y}_weight'] = weight
            df.loc[idx, f'{cname_y}_comment'] = comment

        # Now determine relative pressure w.r.t. first valid collector and calculate T-loss impact
        if 'Start' in df.loc[:, f'{cname_y}_comment'].tolist():
            df.loc[:, f'pressure_relative'] = df.loc[:, f'pressure'] - df.loc[idx_init_pressure, f'pressure']
            df.loc[:, f'pressure_impact'] = df.loc[:, f'pressure_relative'] * self.pressure_impact_POB

        # Check if last colswap has too few pulses, if so make it a temporary datapoint
        if df.loc[df.index[-1], 'pulsecount'] < self.pulses_after_swap:
            df.loc[idx, f'{cname_y}_weight'] = weight * 0.5
            df.loc[df.index[-1], f'{cname_y}_comment'] = (f'Temporary datapoint as too few pulses' +
                                                          f'(<{self.pulses_after_swap}).' +
                                                          df.loc[df.index[-1], f'{cname_y}_comment'])

        # Remove cumulative dose of first accepted colswap
        df[f'{cname_x}_cumsum'] = df[cname_x] - df.loc[df[f'{cname_y}_weight'] != 0, cname_x].min()

        # Translate to relative transmission and use cumulative product, use ceil in case final index has weight 0.5
        df[f'{cname_y}_cumprod'] = (df.loc[:, f'{cname_y}_reldelta'] *
                                    np.ceil(df.loc[:, f'{cname_y}_weight']) + 1).cumprod()
        # Calculate total loss and also subtract pressure induced losses
        if 'pressure_impact' in df.columns:
            df[f'{cname_y}_total_loss'] = 1 - (df[f'{cname_y}_cumprod']) / (1 - df['pressure_impact'])
        else:  # If not at SAT, then pressure_impact column does not exist yet
            df[f'{cname_y}_total_loss'] = 1 - df[f'{cname_y}_cumprod']

        self.log.info(f'Total transmission loss: {df.loc[df.index.max(), f"{cname_y}_total_loss"]*100:.2f}% for:' +
                      f'pupil "{df["doe_name"].tolist()[0]}"')
        return df

    def calculate_POB_loss(self, cname_y: str='FSLIE'):
        """
        As the FSLIE value uses the Slit Sensor which uses the fiducial on the RS, any reflectivity loss of the
        fiducial will show as a FSLIE loss. To get just the POB transmission losses, the fiducial impact should
        be removed.

        This is currently done by reading a CSV for the fiducial values, as it is not yet possible to retrieve these
        automatically.

        Any manual corrections are also applied at this stage, to not interfer with the script itself.

        :param cname_y: Column for FSLIE values, defaults to 'FSLIE'
        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Calculating Fiducial losses')
        self.log.warning(
            'Fiducial losses are currently read from a .csv file which needs to be MANUALLY updated')

        self.df_FSLIE_avg['source_nr'] = self.source_nr

        df = self.data_dict['fiducial_losses'].copy(deep=True)
        self.df_FSLIE_avg = shared.merge_ts_index(self.df_FSLIE_avg, df, how='left')

        self.df_FSLIE_avg = self.df_FSLIE_avg.sort_index()
        # Only do manual corrections on the end result
        df = self.data_dict['manual_corrections'].query(
            f'source_nr=="{self.data_dict["source_nr"]}" and POB_reset==False')
        self.df_FSLIE_avg.loc[:, 'FSLIE_correction'] = 0
        for ituple in df.itertuples():
            idict = ituple._asdict()
            self.log.info(f'Manual correction found: {shared.to_string(idict)}')
            self.df_FSLIE_avg.loc[idict['Index']:, 'FSLIE_correction'] += idict['FSLIE_correction']
        self.df_FSLIE_avg[f'{cname_y}_total_loss'] += self.df_FSLIE_avg['FSLIE_correction']

        self.df_FSLIE_avg[f'{cname_y}_pob_loss'] = 1 - (1 - self.df_FSLIE_avg[f'{cname_y}_total_loss']) / \
            (1 - self.df_FSLIE_avg['fiducial_loss'] / 100)  # Assume fid. loss is in percentage
        return None

    def sanitize_output(self):
        """
        Clean up the output, both for csv export and Influx export.
        Limit the output dataframes in number of columns, and add leading underscores to column names that contain
        derived metrics (for Influx output only).

        A new dictionary is made at self.output_dict with keys 'POB' and 'SSCF'.

        :return: None
        :rtype: None
        """
        do_it.do_it_verbose(currentframe(), self.verbose)
        self.log.info('Executing "sanitize_output"')

        FSLIE_cnames = ['doe_name', 'colswap', 'cumulative_dose_cumsum',
                        'FSLIE', 'FSLIE_total_loss', 'FSLIE_pob_loss', 'FSLIE_weight', 'UnicomAbs', 'pressure']

        if self.valid_dataset:
            # Sort rows and columns
            self.df_FSLIE_avg = self.df_FSLIE_avg.sort_values(by=['doe_name', 'col_clean_period'])
            self.df_FSLIE_avg = self.df_FSLIE_avg[column_sorter(self.df_FSLIE_avg.columns)]
            self.df_FSLIE_avg_summary = self.df_FSLIE_avg[FSLIE_cnames]

            # Save local .csv files
            if self.local:
                fname = str(self.cache_fname.with_suffix('.csv')).replace('cache', 'result')
                self.log.info(f'Saving result to csv: {fname}')
                self.df_FSLIE_avg.to_csv(fname)
                self.df_FSLIE_avg_summary.to_csv(fname.replace('.csv', '_summary.csv'))

            self.log.info(f'Done for s{self.source_nr}!')
        else:
            self.df_FSLIE_avg_summary = pd.DataFrame(columns=FSLIE_cnames,
                                                     index=pd.to_datetime(np.array([]), utc=True))
            self.log.warning(f'Encountered an invalid dataset for s{self.source_nr}, ' +
                             f'likely due to not enough data returning an empty dataframe')

        # If for some reason this dataframe is not yet present, create  dummy values
        SSCF_cnames = ['SSCFl', 'SSCFl_delta_ratio_corrected']
        if 'df_SSCFl' not in dir(self) or self.df_SSCFl.shape[0] == 0:
            self.df_SSCFl = pd.DataFrame(columns=SSCF_cnames,
                                         index=pd.to_datetime(np.array([]), utc=True))
            self.df_SSCFl.index.name = '_ts_index_'

        # Create the output dictionary
        self.output_dict = {
            'POB': self.df_FSLIE_avg_summary.copy(),
            'SSCF': self.df_SSCFl[SSCF_cnames].copy(),
        }

        # Transform the column names so it is clear all except the direct_cnames are calculated values
        direct_cnames = ['_ts_index_', 'source_nr', 'doe_name', 'colswap']
        for key in self.output_dict.keys():
            self.output_dict[key].columns = [f'_{x}' if x not in direct_cnames else x
                                             for x in self.output_dict[key].columns]
            self.output_dict[key]['source_nr'] = self.source_nr

        return None

####
