# This Python file uses encoding: utf-8

"""
POB TMONI - Projection Optics Box Transmission Monitoring tool

This file contains all the data retrieval functions to support POB.py

Copyright 2020, ASML HOLDING N.V. (INCLUDING AFFILIATES). ALL RIGHTS RESERVED.
"""

import dill  # Used to save (serialize) the class/data
import glob
import numpy as np
import os
import pandas as pd
import re
import tempfile  # For pickling to temp file

from pathlib import Path
from inspect import currentframe
from zipfile import ZIP_DEFLATED
from zipfile import ZipFile

# ASML Libraries
from pyeuv.Do_It import do_it_library as do_it
HERE = Path(__file__).absolute().parent
import pyeuv.STC.general.shared as shared
import pyeuv.STC.POB.POB_calc as POB  # Do calculations

from pyeuv.EUVDashboard.clients import UserLANClient  # https://euv-dashboard.asml.com/service/tools.html

# Most signals will respect the from_time and to_time given to get_data
# However if no times are given, TIMEZERO and TIMENOW are used as defaults
# Some signals bypass the from_time kwarg and always use TIMEZERO
# These signals are all SS and SL CF signals
TIMEZERO = pd.Timestamp(year=2013, month=1, day=1).tz_localize('UTC')
TIMENOW = pd.Timestamp.now().tz_localize('UTC')


def get_data(client: UserLANClient, source_nr: int,
             from_time: pd.Timestamp=None, to_time: pd.Timestamp=None, verbose: bool=False):
    """
    Get all signals and return as a dictionary.

    :param client: Influx client
    :param source_nr: Source number of machine
    :param from_time: Start time of data request, defaults to 01-01-2013
    :param to_time: End time of data request, defaults to now
    :param verbose: to switch internal debug info, defaults to False
    :return: Dictionary with all data, in pandas dataframes, and some metatags as to_time and from_time
    :rtype: dictionary
    """
    do_it.do_it_verbose(currentframe(), verbose)

    if not isinstance(source_nr, int):
        source_nr = int(source_nr)

    data_dict = {}
    # Localize times to UTC and if not supplied use default values
    from_time = from_time if from_time else TIMEZERO
    to_time = to_time if to_time else TIMENOW
    kwargs = {'source_nr': source_nr, 'from_time': from_time, 'to_time': to_time, 'verbose': verbose}
    data_dict.update({'source_nr': source_nr, 'from_time': from_time, 'to_time': to_time})

    # Load data from client source
    data_dict['metadata'] = get_metadata(client, source_nr, verbose=verbose)
    data_dict['machine_id'] = data_dict['metadata']['machine_id'].values[0]

    data_dict['colswaps'] = get_colswaps(client, **kwargs)
    data_dict['pulsecount'] = get_pulsecount(client, **kwargs)
    data_dict['cumdose'] = get_cumdose(client, **kwargs)
    data_dict['FSLIE'] = get_FSLIE(client, **kwargs)
    data_dict['vacpress'] = get_vacpress(client, **kwargs)
    data_dict['DGLm'] = get_DGLm(client, **kwargs)
    data_dict['UniCom'] = get_UniCom(client, **kwargs)
    data_dict['SSCFl'] = get_SSCFl(client, **kwargs)  # From t0

    # Get previously analysed data (needed if script is run with partial data input)
    data_dict['df_FSLIE_avg'] = get_previous_FSLIE(client, **kwargs)
    data_dict['df_SSCFl'] = get_previous_SSCFl(client, **kwargs)

    # For troubleshooting, not strictly necessary!
    data_dict['pellicle'] = get_pellicle(client, **kwargs)

    # For troubleshooting, not strictly necessary!
    data_dict['SSCFa'] = get_SSCFa(client, **kwargs)  # From t0
    data_dict['SSCFnl'] = get_SSCFnl(client, **kwargs)  # From t0
    data_dict['SLCFl'] = get_SLCFl(client, **kwargs)  # From t0
    data_dict['SLCFnl'] = get_SLCFnl(client, **kwargs)  # From t0

    # For troubleshooting, not strictly necessary!
    data_dict['pos_plasma'] = get_plasma_source_position(client, target='PLASMA', **kwargs)
    data_dict['pos_source'] = get_plasma_source_position(client, target='SOURCE_RIGID', **kwargs)

    # Load data from csv files
    data_dict['pupinfo'] = load_pupinfo(HERE, verbose=verbose)
    data_dict['fiducial_losses'] = load_fiducial_losses(HERE, verbose=verbose)
    data_dict['manual_corrections'] = load_manual_corrections(HERE, verbose=verbose)

    return data_dict


def _get_signals(signal_dict: dict, client: UserLANClient, source_nr: int,
                 from_time: pd.Timestamp=None, to_time: pd.Timestamp=None, verbose: bool=False):
    """
    Helper function to actually query the data and clean up the retrieved data.

    :param signal_dict: Dictionary containing signal:new_column_name combinations
    :param client: Influx client
    :param source_nr: Source number of machine
    :param from_time: Start time of data request, defaults to 01-01-2013
    :param to_time: End time of data request, defaults to now
    :param verbose: to switch internal debug info, defaults to False
    :return: Dataframe with the signal column renamed to the signal_dict value
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), verbose)

    signal_dict = {f's{source_nr}.{signal}': value for (signal, value) in signal_dict.items()}
    df = client.get_signals_cached(
        signal_dict.keys(),
        from_time,
        to_time)

    df = _cleanup_signals(df, signal_dict, source_nr=source_nr, verbose=verbose)
    return df


def _cleanup_signals(df: pd.DataFrame, signal_dict: dict, source_nr: int, verbose: bool=False):
    """
    Clean up retrieved data, made it a separate function so it can be called from other scripts as well. 
    Will filter NA rows, rename all columns according to signal_dict, add source_nr column, add column names if 
    dataframe is empty, and pad with NaN columns if only certain columns are missing. 

    :param df: Dataframe with signals
    :param signal_dict: Dictionary containing signal:new_column_name combinations
    :param source_nr: Source number of machine
    :param verbose: to switch internal debug info, defaults to False
    :return: Dataframe which is cleaned
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), verbose)

    df = df.dropna()
    df = df.rename(columns=signal_dict)
    df['source_nr'] = source_nr

    if df.empty:
        df = pd.DataFrame(columns=signal_dict.values())
    elif df.shape[0] != len(signal_dict):  # If one or more columns are missing, add NaN's
        for value in set(signal_dict.values()).difference(set(df.columns)):
            df[value] = np.nan

    # Enforce all timestamp are Pandas Timestamp, otherwise Pandas code will slow down.
    df.index = pd.to_datetime(df.index)
    return df


def get_metadata(client: UserLANClient, source_nr: int =0, verbose: bool=False):
    """
    Get the metadata for all, or one specific machine if source_nr is specified

    :param client: Influx client
    :param source_nr: Source number of machine, defaults to 0
    :param verbose: to switch internal debug info, defaults to False
    :return: Dataframe with metadata
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), verbose)

    df = pd.DataFrame(client.get_machine_list()).rename(columns={'machine_nr': 'machine_id'})
    if source_nr and 'source_nr' in df.columns:
        df = df.query(f'source_nr=="{source_nr}"').reset_index()
    return df


def get_colswaps(client: UserLANClient, **kwargs):
    """
    Get signal for collector swaps, signal: column_name:
    r'Collector.Swap': 'colswap'

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Collector.Swap': 'colswap',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_pulsecount(client: UserLANClient, **kwargs):
    """
    Get signal for pulse counts (non cumulative), signal: column_name:
    r'Collector._PulseCount.1d.mean': 'pulsecount'

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Collector._PulseCount.1h.mean': 'pulsecount',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_cumdose(client: UserLANClient, **kwargs):
    """
    Get signal for cumulative dose, 1 day averaged, signal: column_name:
    r'OLT._CumulativeDose.1d.mean': 'cumulative_dose'

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'OLT._CumulativeDose.1d.mean': 'cumulative_dose',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_FSLIE(client: UserLANClient, **kwargs):
    """
    Get signal for FSLIE and pupil information, signal: column_name:
    r'Scanner.DW_FSLIE': 'FSLIE',  # Unit: J/m/bit
    r'Scanner.DW_FSLIE_used_chuck': 'chuck_id',
    r'Scanner.DW_SLIE_FSLIE_PS_doe_id': 'doe_id',
    r'Scanner.DW_SLIE_FSLIE_PS_im_mode': 'mode_DC',
    r'Scanner.DW_SLIE_FSLIE_PS_sigma_inner': 'sigma_inner',
    r'Scanner.DW_SLIE_FSLIE_PS_sigma_outer': 'sigma_outer',

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.DW_FSLIE': 'FSLIE',  # Unit: J/m/bit
        r'Scanner.DW_FSLIE_used_chuck': 'chuck_id',
        r'Scanner.DW_SLIE_FSLIE_PS_doe_id': 'doe_id',
        r'Scanner.DW_SLIE_FSLIE_PS_im_mode': 'mode_DC',
        r'Scanner.DW_SLIE_FSLIE_PS_sigma_inner': 'sigma_inner',
        r'Scanner.DW_SLIE_FSLIE_PS_sigma_outer': 'sigma_outer',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_vacpress(client: UserLANClient, **kwargs):
    """
    Get signal for vacuum pressure in the machine, signal: column_name:
    r'Scanner.VsPrsAbsMch.1d.mean': 'vacpress'

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.VsPrsAbsMch.1d.mean': 'vacpress',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_DGLm(client: UserLANClient, **kwargs):
    """
    Get signal for DGLm presence, signal: column_name:
    r'PXPBV2.MCPXPBV2_MEMBRANE_TRANSMISSION_TAG': 'DGLM_type'

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'PXPBV2.MCPXPBV2_MEMBRANE_TRANSMISSION_TAG': 'DGLM_type',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_pellicle(client: UserLANClient, **kwargs):
    """
    Get signal for ratio of fiducial and reticle reflectivity, giving pellicle presence, signal: column_name:
    r'Scanner.KEMI_PdrsRatioFidRetAvg': 'FidRetRatio'

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.KEMI_PdrsRatioFidRetAvg': 'FidRetRatio',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_SSCFa(client: UserLANClient, **kwargs):
    """
    Get signal for only the Slit Sensor Conversion Factor Anchor, signal: column_name:
    r'Scanner.DW_SS_cf_anchor': 'SSCFa'

    Get data from t0 to now as this is needed for analysis.

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.DW_SS_cf_anchor': 'SSCFa',
    }

    kwargs.update({'from_time': TIMEZERO, 'to_time': TIMENOW})
    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_SSCFl(client: UserLANClient, **kwargs):
    """
    Get signal for all Spot/Slit Sensor Conversion Factors: Anchor, Leading, Non-Leading, signal: column_name:
    r'Scanner.DW_SS_cf_leading': 'SSCFl',

    Get data from t0 to now as this is needed for analysis.

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.DW_SS_cf_leading': 'SSCFl',
    }

    kwargs.update({'from_time': TIMEZERO, 'to_time': TIMENOW})
    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_SSCFnl(client: UserLANClient, **kwargs):
    """
    Get signal for all Spot/Slit Sensor Conversion Factors: Anchor, Leading, Non-Leading, signal: column_name:
    r'Scanner.DW_SS_cf_non_leading': 'SSCFnl',

    Get data from t0 to now as this is needed for analysis.

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.DW_SS_cf_non_leading': 'SSCFnl',
    }

    kwargs.update({'from_time': TIMEZERO, 'to_time': TIMENOW})
    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_SLCFl(client: UserLANClient, **kwargs):
    """
    Get signal for all Spot/Slit Sensor Conversion Factors: Anchor, Leading, Non-Leading, signal: column_name:
    r'Scanner.DW_SL_cf_leading': 'SLCFl',

    Get data from t0 to now as this is needed for analysis.

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.DW_SL_cf_leading': 'SLCFl',
    }

    kwargs.update({'from_time': TIMEZERO, 'to_time': TIMENOW})
    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_SLCFnl(client: UserLANClient, **kwargs):
    """
    Get signal for all Spot/Slit Sensor Conversion Factors: Anchor, Leading, Non-Leading, signal: column_name:
    r'Scanner.DW_SL_cf_non_leading': 'SLCFnl',

    Get data from t0 to now as this is needed for analysis.

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.DW_SL_cf_non_leading': 'SLCFnl',
    }

    kwargs.update({'from_time': TIMEZERO, 'to_time': TIMENOW})
    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_UniCom(client: UserLANClient, **kwargs):
    """
    Get signal for absolute Unicom transmission, signal: column_name:
    r'Scanner.IlUnicomRefreshAbsTxAbsoluteTransmission': 'UnicomAbs'

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.IlUnicomRefreshAbsTxAbsoluteTransmission': 'UnicomAbs',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_plasma_source_position(client: UserLANClient, target: str='None', **kwargs):
    """
    Get signal for plasma and source position, signal: column_name:
    f'LUES.LUES_OASIS_POSITION_POSITION_{target}_X_TAG.1d.mean': 'x',
    f'LUES.LUES_OASIS_POSITION_POSITION_{target}_Y_TAG.1d.mean': 'y',
    f'LUES.LUES_OASIS_POSITION_POSITION_{target}_Z_TAG.1d.mean': 'z',
    With target being one of: ['PLASMA', 'SOURCE_RIGID']

    :param client: Influx client
    :param target: Choose target, 'PLASMA' or 'SOURCE_RIGID'
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    targets_allowed = ['PLASMA', 'SOURCE_RIGID', ]
    if target not in targets_allowed:
        return pd.DataFrame()

    signal_dict = {
        f'LUES.LUES_OASIS_POSITION_POSITION_{target}_X_TAG.1d.mean': 'x',
        f'LUES.LUES_OASIS_POSITION_POSITION_{target}_Y_TAG.1d.mean': 'y',
        f'LUES.LUES_OASIS_POSITION_POSITION_{target}_Z_TAG.1d.mean': 'z',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_previous_FSLIE(client: UserLANClient, **kwargs):
    """
    Retrieve earlier calculation results of POB_TMONI. This is necessary to prevent having to get the full history of 
    all signals as input to the analysis function every time. Using the this previous result only the data from the
    last collector onwards is necessary.

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.TMONI_POB.doe_name': 'doe_name',
        r'Scanner.TMONI_POB.colswap': 'colswap',
        r'Scanner.TMONI_POB._cumulative_dose_cumsum': 'cumulative_dose_cumsum',
        r'Scanner.TMONI_POB._FSLIE': 'FSLIE',
        r'Scanner.TMONI_POB._FSLIE_total_loss': 'FSLIE_total_loss',
        r'Scanner.TMONI_POB._FSLIE_pob_loss': 'FSLIE_pob_loss',
        r'Scanner.TMONI_POB._FSLIE_weight': 'FSLIE_weight',
        r'Scanner.TMONI_POB._UnicomAbs': 'UnicomAbs',
    }

    df = _get_signals(signal_dict, client, **kwargs)
    return df


def get_previous_SSCFl(client: UserLANClient, **kwargs):
    """
    Retrieve earlier calculation results of POB_TMONI for SSCFl. This is necessary to prevent having to get the full 
    history of all signals as input to the analysis function every time. Using the this previous result only the data 
    from the last collector onwards is necessary.

    :param client: Influx client
    :param kwargs: Keyword arguments given to _get_signals, as well as 'verbose'
    :return: Dataframe with signal(s)
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), kwargs['verbose'])

    signal_dict = {
        r'Scanner.TMONI_SSCF._SSCFl': 'SSCFl',
        r'Scanner.TMONI_SSCF._SSCFl_delta_ratio_corrected': 'SSCFl_delta_ratio_corrected'
    }

    kwargs.update({'from_time': TIMEZERO, 'to_time': TIMENOW})
    df = _get_signals(signal_dict, client, **kwargs)
    return df


def load_pupinfo(location: Path, verbose: bool = False):
    """
    Load pupil information from .csv file

    :param location: Path of .csv file (same as for this .py file)
    :param verbose: to switch internal debug info, defaults to False
    :return: Dataframe
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), verbose)

    pupinfo = pd.read_csv(location.joinpath('illumination_pupil_information.csv'))
    return pupinfo


def load_fiducial_losses(location: Path, verbose: bool = False):
    """
    Load fiducial loss information from .csv file

    :param location: Path of .csv file (same as for this .py file)
    :param verbose: to switch internal debug info, defaults to False
    :return: Dataframe
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), verbose)

    fiducial_losses = pd.read_csv(location.joinpath('fiducial_loss.csv'))
    return fiducial_losses


def load_manual_corrections(location: Path, verbose: bool = False):
    """
    Load manual FSLIE corrections from .csv file

    :param location: Path of .csv file (same as for this .py file)
    :param verbose: to switch internal debug info, defaults to False
    :return: Dataframe
    :rtype: pandas dataframe
    """
    do_it.do_it_verbose(currentframe(), verbose)

    manual_corrections = pd.read_csv(location.joinpath('manual_corrections.csv'),
                                     index_col='_ts_index_', parse_dates=True)
    return manual_corrections


def pickle(data_dict: dict={}, fname: str='', mode: str='w', verbose: bool= False):
    """
    Convenience function to facilitate fast zipped pickle/unpickle of the data within this class. 
    Everything that is returned from todict() will be pickled, excluding the 'log' key. 
    The idea is to just save data, independent of the (updated) functions in the class.

    While this function can also unpickle, the unpickle function should be used for that.

    :param data_dict: Dictionary with dataframes and meta-data, defaults to {}
    :param fname: Filename of pickle, if left empty then a default filename in the temp folder is used, defaults to ''
    :param mode: Mode, 'w' for write or 'r' for read, defaults to 'w'
    :param verbose: to switch internal debug info, defaults to False
    :return: Dictionary with all data, in pandas dataframes, and some metatags as to_time and from_time
    :rtype: dictionary
    """
    if fname == '':
        fname = Path(tempfile.gettempdir()) / 'POB_TMONI_pickle.zip'
        if verbose:
            print(f'No fname supplied, will use tempfile for pickling: {fname}')

    if not isinstance(fname, Path):
        fname = Path(fname)

    with ZipFile(fname.with_suffix('.zip'), mode=mode, compression=ZIP_DEFLATED) as arch:
        with arch.open(fname.with_suffix('.dill').name, mode=mode) as file:
            if mode == 'w':
                dill.dump(data_dict, file)
            elif mode == 'r':
                data_dict = dill.load(file)
    return data_dict


def unpickle(fname='', verbose: bool= False):
    """
    Convenience function to facilitate unpickling.

    :param fname: Filename of pickle, if left empty then a default filename in the temp folder is used, defaults to ''
    :param verbose: to switch internal debug info, defaults to False
    :return: Dictionary with all data, in pandas dataframes, and some metatags as to_time and from_time
    :rtype: dictionary
    """
    data_dict = pickle(mode='r', fname=fname, verbose=verbose)
    return data_dict
