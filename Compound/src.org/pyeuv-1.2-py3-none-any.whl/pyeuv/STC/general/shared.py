# This Python file uses encoding: utf-8

"""
To be filled with shared functions for all TMONI classes.
"""

import dill  # Used to save (serialize) the class/data
import numpy as np
import os
import pandas as pd
import re
import tempfile  # For pickling to temp file

from collections import OrderedDict
from pathlib import Path
from zipfile import ZIP_DEFLATED
from zipfile import ZipFile


def to_string(x):
    """
    Convert different input types to a string for printing. Supports lists, tuples, dicts, or Pandas DataFrames.
    Function is used recursively to simply dataframes/dictionaries to lists before transforming into strings.

    :param x: Object to be converted to string
    :type x: string, list, tuple, dictionary
    :return: String version of input object
    :rtype: str
    """
    if isinstance(x, str):
        return x
    elif isinstance(x, (list, tuple)):
        return ', '.join(str(y) for y in x)
    elif isinstance(x, (dict, OrderedDict)):
        return ' | '.join('{}: {}'.format(key, to_string(val)) for (key, val) in iter(x.items()))
    elif isinstance(x, pd.DataFrame):
        return to_string(x.to_dict(orient='list'))
    elif '__str__' in dir(x):
        return str(x)  # If all else fails, just try to make a string out of it directly
    else:
        raise Exception('Input type not supported: {}'.format(type(x)))


def glob_re(fname_pattern: str, directory: str, n_expected: int=0, warn_or_crash='warn', flatten: bool=True):
    """
    Combine regular expressions for 'fname_pattern' with finding all files in 'directory'

    :param fname_pattern: regexp pattern for filenames
    :type fname_pattern: str
    :param directory: Directory to search in (non-recursively)
    :type directory: str
    :param n_expected: Number of files expected, raise exception if deviating. Defaults to 0 (disabled)
    :type n_expected: int
    :param flatten: Flatten the output list to a string if only 1 result. Defaults to True
    :type flatten: bool
    :return: Filenames that match requirements
    :rtype: list or str
    """
    fnames = os.listdir(str(directory))
    ans = list(filter(re.compile(fname_pattern).match, fnames))

    if n_expected and len(ans) != n_expected:
        message = f'Expected {n_expected} files for pattern "{fname_pattern}", found {len(ans)}: {ans}'
        func = Exception if warn_or_crash == 'crash' else print
        func(message)

    if flatten and len(ans) == 1:
        ans = ans[0]
    elif flatten and len(ans) == 0:
        ans = ''
    return ans


def get_ziplist(df: pd.DataFrame, *args):
    """
    Function that returns two (or more) columns as a zipped list, this is useful for list comprehension functions and
    just a convenience function.

    :param df: Dataframe containing to be zipped columns
    :type df: pandas dataframe
    :param args: Columns names to be zipped, need at least 2
    :type args: string
    :return: List of zipped columns
    :rtype: list
    """
    if len(args) >= 2 and False not in [isinstance(x, str) for x in args]:
        flatlist = list()
        for extralist in args:
            flatlist.append(df[extralist])
    else:
        raise ValueError('Function get_ziplist requires at least two column names supplied as strings.')

    zippedlist = list(zip(*flatlist))
    return zippedlist


def get_unique_column_value(df: pd.DataFrame, cname: str):
    """
    Retrieve the unique value of a column, and raise error if more than one value present.
    Useful to validate assumption that only one value is present in a column.

    :param df: Dataframe containing column name
    :type df: pandas dataframe:
    :param cname: Column name
    :type cname: string
    :return: Unique value of column
    """
    value = set(df.loc[cname].tolist())
    if len(value) == 1:
        return next(iter(value))
    else:
        raise ValueError(f'Unexpectedly found more than one value in column: {cname}. Values: {to_string(value)}')


def drop_consecutive_duplicates(df: pd.DataFrame, cname: str):
    """
    Drop all consecutive duplicate rows based on one column.

    :param df: Input dataframe
    :type df: pandas.dataframe
    :param cname: Column to operate on
    :type cname: str
    :return: Dataframe with consecutive duplicates removed
    :rtype: pandas.dataframe
    """
    dfseries = df[cname].values
    return df[np.concatenate(([True], dfseries[:-1] != dfseries[1:]))]


def merge_ts_index(left: pd.DataFrame, right: pd.DataFrame, **kwargs):
    """
    DataFrames with a TimeIndex will lose the TimeIndex when merged with a integer based index.
    This function uses a trick to circumvent that annoyance.
    For help on args and kwargs, see: help(pandas.DataFrame.merge).
    Left dataframe is assumed to have a TimeIndex, while the Right dataframe does not.

    :param left: Left dataframe, with timeindex
    :type left: pandas dataframe
    :param right: Right dataframe, without timeindex
    :type right: pandas dataframe
    :param kwargs: Keyword arguments transferred to native pandas.dataframe.merge function
    :type kwargs: dictionary, unpacked
    """
    if left.index.is_all_dates:
        df = left.reset_index(drop=False).merge(right.drop_duplicates(), **kwargs).set_index(left.index.name)
    else:  # No time index, use regular merge
        df = left.merge(right, **kwargs)
    return df


def custom_join(left: pd.DataFrame, right: pd.DataFrame, right_cname: str, initial_value):
    """
    Wrapper for pd.DataFrame.join, where the column "right_cname" of the right df will be joined to the left df, forward filled, empty values filled with "initial_value", and then all new indices from the right df are removed.

    The goal of this is to add a new column to left, with values based on the time series index of right.

    :param left: Left dataframe for join
    :type left: pandas.DataFrame
    :param right: Right dataframe for join
    :type right: pandas.DataFrame
    :param right_cname: Column name to join, rest is discarded for dataframe right
    :type right_cname: string
    :param initial_value: Value used to (back-)fill if empty values remain
    :type initial_value: float
    :return: Dataframe with new column from right and only indices of left
    :rtype: pandas.DataFrame
    """
    left = left.copy(deep=True)
    right = right.copy(deep=True)

    right = right[[right_cname]]
    pre_shape = left.shape
    left['tmp_column'] = np.arange(left.shape[0])

    # Join, then forwardfill the new column, fill all initial values, and drop all empty cells
    if right.empty:
        df = left
        df[right_cname] = initial_value
    else:
        df = left.join(right, how='outer')
        df[right_cname] = df[right_cname].ffill()
        df[right_cname] = df[right_cname].fillna(initial_value)

    # Preserve index name
    df.index.name = left.index.name

    # Now do a trick in case the timeseries-index has duplicate values, preserve on values based on left dataframe
    df = df.reset_index(drop=False)
    df = df.loc[df['tmp_column'].dropna().index, :]
    df = df.set_index(left.index.name)
    del df['tmp_column']

    post_shape = df.shape
    if (pre_shape[0], pre_shape[1] + 1) != post_shape:  # Check in case function has unintended side-effects
        raise Exception(f'Function custom_join misbehaves for {right_cname}, shapes do not match up (pre/post): {pre_shape} / {post_shape}')
    return df


def pickle(data_dict: dict={}, fname: str='', mode: str='w', verbose: bool= False):
    """
    Convenience function to facilitate fast zipped pickle/unpickle of the data within this class. 
    Everything that is returned from todict() will be pickled, excluding the 'log' key. 
    The idea is to just save data, independent of the (updated) functions in the class.

    While this function can also unpickle, the unpickle function should be used for that.

    :param data_dict: Dictionary with dataframes and meta-data, defaults to {}
    :type data_dict: dictionary, optional
    :param fname: Filename of pickle, if left empty then a default filename in the temp folder is used, defaults to ''
    :type fname: str, optional
    :param mode: Mode, 'w' for write or 'r' for read, defaults to 'w'
    :type mode: str
    :param verbose: to switch internal debug info, defaults to False
    :type verbose: boolean, optional
    :return: Dictionary with all data, in pandas dataframes, and some metatags as to_time and from_time
    :rtype: dictionary
    """
    if fname == '':
        fname = Path(tempfile.gettempdir()) / 'POB_TMONI_pickle.zip'
        if verbose:
            print(f'No fname supplied, will use tempfile for pickling: {fname}')

    if not isinstance(fname, Path):
        fname = Path(fname)

    with ZipFile(fname.with_suffix('.zip'), mode=mode, compression=ZIP_DEFLATED) as arch:
        with arch.open(fname.with_suffix('.dill').name, mode=mode) as file:
            if mode == 'w':
                dill.dump(data_dict, file)
            elif mode == 'r':
                data_dict = dill.load(file)
    return data_dict


def unpickle(fname='', verbose: bool= False):
    """
    Convenience function to facilitate unpickling.

    :param fname: Filename of pickle, if left empty then a default filename in the temp folder is used, defaults to ''
    :type fname: str, optional
    :param verbose: to switch internal debug info, defaults to False
    :type verbose: boolean, optional
    :return: Dictionary with all data, in pandas dataframes, and some metatags as to_time and from_time
    :rtype: dictionary
    """
    data_dict = pickle(mode='r', fname=fname, verbose=verbose)
    return data_dict


def _progressbar(i, hundredpercent, title='', maxlen=80):
    if i == 1:
        print(f'Progress: {title}')
        print('"' + '-' * int(np.min([maxlen, hundredpercent]) - 2) + '"')

    # Always print
    if hundredpercent <= maxlen:
        print('*', end='')
    # Only print if above one character of maxlen
    elif np.floor(i / (hundredpercent / maxlen)) > np.floor((i - 1) / (hundredpercent / maxlen)):
        print('*', end='')

    if i == hundredpercent:  # Ensure newline when done with progressbar
        print('\n', end='\n')
    return None


def convert_time(x: str):
    """
    Convert time string to datetime objects, specifically by stripping the "us" part of the microseconds value.

    :param x: String with time
    :type x: str
    :return: Datetime object
    :rtype: pandas.datetime
    """
    repl = re.findall(r' \d{6}us ', x)[0]
    ans = pd.to_datetime(x.replace(repl, f'.{repl.strip(" us")}'))
    return ans
