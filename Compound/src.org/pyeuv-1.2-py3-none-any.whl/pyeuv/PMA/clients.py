"""
**PMA NG Readers**

SQL queries are based on the PMA Secure API Developer guide
which can be obtained from dl-pma-developer-support@asml.com.

Author: RLBL
Date: 2019-07-29
"""
import time
import textwrap
import pandas as pd
import psycopg2
import numpy as np


class PMAClient:
    """
    Downloads data from PMA and parses it into dataframes. Requires api-key and user with PMA-NG authorization.
    """

    def __init__(self, username, password, api_key, host='pma.asml.com', port=35432):
        """
        Initializes connection to PMA

        :param username: ASML account name with PMA NG authorizations
        :type username: str
        :param password: Password for the account
        :type password: str
        :param api_key: Secure API key for PMA NG. For more information on how to request a key contact
                        dl-pma-developer-support@asml.com.
        :type api_key: str
        :param host: Hostname of the PMA API provider, default: pma.asml.com
        :type host: str
        :param port: Port of the PMA API, default: 35432
        :type port: int
        """
        conn_str = "dbname=PMA.3 user={0}+{1} password={2} host={3} port={4};disableLocalTxn=true" \
                   "".format(username, api_key, password, host, port)

        print("Connecting to PMA NG")
        self.conn = psycopg2.connect(conn_str)

    def get_parameters(self, parameters, machine, tstart, tstop, verbose=False, n_retries=3, retry_sleep=30):
        """
        Downloads scanner parameters a.k.a. Scanner KPI from CDL trough the PMA NG interface.

        :param parameters: List of PMA parameters to download. Use list_parameters to find out
                           which parameter names are available
        :type parameters: list<str>
        :param machine: Machine information to download data for. Requires pyeuv machine dict.
        :type machine: dict
        :param tstart: Start time of the window
        :type tstart: pandas.Timestamp
        :param tstop: Stop time of the window
        :type tstop: pandas.Timestamp
        :param verbose: Print messages
        :type verbose: bool
        :param n_retries: Number of times to retry a query
        :type n_retries: int
        :param retry_sleep: Time to sleep in [s] between retries.
        :type retry_sleep: int
        :return: Dict containing a result dataframes per given parameter.
        :rtype: dict{parameter_name: pd.DataFrame}
        """

        qry_tpl = """
        SELECT
            fact.SAMPLE_DT AS "timestamp",
            CAST(fact.VALUE AS FLOAT) AS "value"
        FROM
              "PARAMETER_DIM" t, "PARAMETER_FACT" fact
        WHERE
          t.NAME = '{parameter}' AND
          fact.PARAMETER_DIM_ID = t.PARAMETER_DIM_ID AND
          fact.EQUIPMENT_NR = '{machine_nr}' AND 
          fact.SAMPLE_DT > PARSETIMESTAMP('{tstart}', 'yyyy-MM-dd hh:mm:ss') AND
          fact.SAMPLE_DT < PARSETIMESTAMP('{tstop}', 'yyyy-MM-dd hh:mm:ss')
        ORDER BY
              fact.SAMPLE_DT
        """
        qry_tpl = textwrap.dedent(qry_tpl)
        out = dict()
        for p in parameters:
            if verbose:
                print("Obtaining: {0} [{1} - {2}]".format(
                    p,
                    tstart.strftime("%Y-%m-%d %H:%M:%S"),
                    tstop.strftime("%Y-%m-%d %H:%M:%S")))

            qry = qry_tpl.format(**{
                "parameter": p,
                "machine_nr": machine['machine_nr'],
                "tstart": tstart.strftime("%Y-%m-%d %H:%M:%S"),
                "tstop": tstop.strftime("%Y-%m-%d %H:%M:%S")
            })

            cur = self.conn.cursor()
            try:
                self._qry_with_retry(cur, qry, n_retries=n_retries, retry_sleep=retry_sleep)
                result = cur.fetchall()
            finally:
                cur.close()

            signal = pd.DataFrame(result, columns=['timestamp', 'value']).set_index('timestamp')
            out[p] = signal

        return out

    def list_parameters(self, full=False, n_retries=3, retry_sleep=30):
        """
        Returns the list of available parameters. If full=True will also return the unit and
        description of the signal in a nested list of size Nx3. Currently (2019-07-15) the list
        of units is incomplete, and descriptions are missing completely so this option is
        disabled by default.

        :param full: Include unit and description (default: False)
        :type full: bool
        :param n_retries: Number of times to retry a query
        :type n_retries: int
        :param retry_sleep: Time to sleep in [s] between retries.
        :type retry_sleep: int
        :return: Dataframe with the test results

        :rtype: list<str> (default) or list<list<str>>> (full=True)
        """
        qry = """SELECT * FROM PARAMETER_DIM"""
        cur = self.conn.cursor()
        try:
            self._qry_with_retry(cur, qry, n_retries=n_retries, retry_sleep=retry_sleep)
            result = cur.fetchall()
        finally:
            cur.close()

        if full:
            return [[x[1], x[2], x[3]] for x in result]
        else:
            return [x[1] for x in result]

    @staticmethod
    def _pivot_cpd_results(df):
        """
        Transforms the dataframe with CPD results such that each TAG value becomes a column.

        :param df: Dataframe with cpd results
        :return: Pivoted df
        """
        # Formats starting with COL contain multiple columns. Make the columns names unique using the array index
        idx_col = df['FORMAT'].str.startswith('COL')  # get index of those lines in FORMAT column that start with COL
        # replace the column TAG content with the merging of the content of TAG and ARRAY_INDEX at the indices just
        # found
        df.loc[idx_col, 'TAG'] = df.loc[idx_col, 'TAG'] + '_' + df.loc[idx_col, 'ARRAY_INDEX'].astype('str')

        # create df having as index TEST_FACT_ID and column name from the column TAG, sort by VALUE
        dfp = df.pivot(index='TEST_FACT_ID', columns='TAG', values='VALUE')

        return dfp

    @staticmethod
    def _pivot_cpd_results(df, data_type):
        """
        Transforms the dataframe with CPD results such that each TAG value becomes a column.

        :param df: Dataframe with cpd results
        :return: Pivoted df
        """

        # create df having as index TEST_FACT_ID and column name from the column TAG, sort by VALUE
        # drop those columns that are all empty
        dfp = df.pivot(index='TEST_FACT_ID', columns='TAG', values='VALUE_' + data_type)

        return dfp

    @staticmethod
    def _pivot_cpd_results_eq(df, data_type):
        """
        Transforms the dataframe with CPD results such that each TAG value becomes a column.

        :param df: Dataframe with cpd results
        :return: Pivoted df
        """

        df.drop_duplicates(
            subset=['TEST_FACT_ID', 'EQUIPMENT_NR', 'TAG'], inplace=True
        )

        # create df having as index TEST_FACT_ID and column name from the column TAG, sort by VALUE
        # drop those columns that are all empty
        dfp = df.pivot(index=['TEST_FACT_ID','EQUIPMENT_NR'], columns='TAG', values='VALUE_' + data_type)

        return dfp

    @staticmethod
    def _get_tag(df):
        """
        Transforms the dataframe with CPD results such that each TAG value becomes a column name.

        :param df: Dataframe with cpd results
        :return:  Dataframe with cpd results with formatted columns names in 'TAG' column
        """
        # Formats starting with COL contain multiple columns. Make the columns names unique using the array index
        idx_col = df['FORMAT'].str.startswith('COL')  # get index of those lines in FORMAT column that start with COL
        # replace the column TAG content with the merging of the content of TAG and ARRAY_INDEX at the indices just
        # found
        df.loc[idx_col, 'TAG'] = df.loc[idx_col, 'TAG'] + '_' + df.loc[idx_col, 'ARRAY_INDEX'].astype('str')

    @staticmethod
    def _qry_with_retry(cur, qry, n_retries=3, retry_sleep=30):
        """
        Execute a query and retry on failure.

        :param cur: Cursor with qry() method
        :type cur: psycopg2 cursor
        :param qry: The query to execute
        :param qry: str
        :param n_retries: Number of retries
        :type n_retries: int
        :param retry_sleep: Number of seconds between retries
        :type retry_sleep: int
        """
        retry_count = 0
        while retry_count <= n_retries:
            try:
                cur.execute(qry)
                break
            except psycopg2.OperationalError as e:
                retry_count += 1
                print("Could not complete query: {0}".format(e))
                print("Retry in {0}s".format(retry_sleep))
                time.sleep(retry_sleep)

    def get_cpd_results(self, cpd_name, machines, tstart, tstop, pivot_results=True, verbose=False,
                        n_retries=3, retry_sleep=30):
        """
        Get CPD (Control Performance Diagnostics) test results.

        :param cpd_name: Name of the CPD, e.g. LUES or WDDC
        :type cpd_name: str
        :param machines: Machines to obtain the results for
        :type machines: list<dict>  (Pyeuv machine dict)
        :param tstart: Start time of the test must be greater than this
        :type tstart:  pandas.Timestamp()
        :param tstop: Start time of the test must be smaller than this
        :type tstop: pandas.Timestamp()
        :param pivot_results: Pivot results, see pivot_cpd_table
        :type pivot_results: bool
        :param verbose: Bitch and moan a lot
        :type verbose: bool
        :param n_retries: Number of times to retry a query
        :type n_retries: int
        :param retry_sleep: Time to sleep in [s] between retries.
        :type retry_sleep: int
        :return: Dataframe with the test results
        """
        pma_types = {
            'BOOL': 'bool',
            'INT': 'Int64',
            'DOUBLE': 'double',
            'TEXT': 'str'
        }

        cur = self.conn.cursor()
        # query template
        qry_tpl = r"""
        SELECT
          TESTREPORT_FACT_ID,
          TESTREPORT_FACT_TEST_DT as TEST_DT,
          TESTREPORT_FACT_EQUIPMENT_NR as EQUIPMENT_NR,
          TAG,
          FORMAT as FORMATORG,
          CASE WHEN FORMAT IN ('INT','COL_INT') THEN (
                                                       CASE WHEN TAG = 'LUES_MACHINE_NUMBER_TAG' THEN 'TEXT' ELSE FORMAT END
                                                     ) 
                                                ELSE FORMAT END  AS FORMAT,                 
          ARRAY_INDEX,
          CASE WHEN FORMAT IN ('TEXT','COL_TEXT') THEN VALUE_TEXT 
                                                  ELSE  (
                                                       CASE WHEN TAG = 'LUES_MACHINE_NUMBER_TAG' THEN  VALUE_TEXT ELSE NULL END
                                                     ) END
                                                      AS VALUE_TEXT,
          CASE WHEN FORMAT IN ('BOOL','COL_BOOL') THEN VALUE_BOOLEAN ELSE NULL END AS VALUE_BOOL,
          CASE WHEN FORMAT IN ('INT','COL_INT') THEN (
                                                       CASE WHEN TAG = 'LUES_MACHINE_NUMBER_TAG' THEN NULL ELSE VALUE_INTEGER END
                                                     ) 
                                                 ELSE NULL END AS VALUE_INT,
          CASE WHEN FORMAT IN ('DOUBLE','COL_DOUBLE') THEN VALUE_DOUBLE ELSE NULL END AS VALUE_DOUBLE,
          CASE WHEN FORMAT IN ('DOUBLE','COL_DOUBLE') THEN VALUE_EXPONENT ELSE NULL END AS VALUE_EXPONENT,
          TESTREPORT_FACT_TEST_NAME
        FROM     TESTREPORT_VALUE_FACT
         WHERE    TESTREPORT_FACT_EQUIPMENT_NR IN {1}
           AND     TESTREPORT_FACT_TEST_DT BETWEEN '{2}' AND '{3}'
           AND     TESTREPORT_FACT_TEST_NAME = '{0}'
         ORDER BY       TESTREPORT_FACT_EQUIPMENT_NR,
           TESTREPORT_FACT_TEST_DT,
           TAG,
           ARRAY_INDEX;
"""

        qry_tpl = textwrap.dedent(qry_tpl)
        tstart_str = tstart.strftime('%Y-%m-%d %H:%M:%S.%f')
        tstop_str = tstop.strftime('%Y-%m-%d %H:%M:%S.%f')
        machines_str = '(' + ','.join(["'{0}'".format(m['machine_nr']) for m in machines]) + ')'

        try:
            qry = qry_tpl.format(cpd_name, machines_str, tstart_str, tstop_str)  # fill in
            # the spots of the template table_type with the given parameters
            self._qry_with_retry(cur, qry, n_retries=n_retries, retry_sleep=retry_sleep)
            result = cur.fetchall()
            #
            all_results_df = pd.DataFrame(result, columns=[c.name for c in cur.description])
            table_types = [str(a) for a in pma_types.keys()]
            for table_type in table_types:
                if verbose:
                    print("Formatting {0} FACT TABLE".format(table_type))
                col_name = 'VALUE_' + table_type
                all_results_df[col_name] = all_results_df[col_name].dropna().astype(pma_types[table_type])
                if table_type == 'DOUBLE':
                    all_results_df[col_name] *= np.power(
                        10.0, all_results_df['VALUE_EXPONENT'].astype('double').fillna(0.0))
                    all_results_df.drop(columns='VALUE_EXPONENT', inplace=True)  # remove column once used
            all_results_df['TEST_FACT_ID'] = all_results_df['TESTREPORT_FACT_ID'].astype('int64')
            all_results_df.drop(columns='TESTREPORT_FACT_ID', inplace=True)  # remove column once used
        finally:
            cur.close()

        dfp = pd.DataFrame()
        if pivot_results and len(all_results_df) > 0:
            # Concatenate columns and sort along rows
            self._get_tag(all_results_df)
            for k in table_types:
                pivot_df=all_results_df.loc[all_results_df['FORMAT'].str.contains(k), ['TEST_FACT_ID', 'TAG', 'VALUE_' + k, 'EQUIPMENT_NR']]
                piv_sub_df = self._pivot_cpd_results_eq(pivot_df,
                                                     k)  # every time the tag is re considered, change it
                dfp = pd.concat([dfp, piv_sub_df], sort=True, axis=1)

            dfp = dfp.reset_index(drop=False).set_index('TEST_FACT_ID')
            dfp.drop(columns=['EQUIPMENT_NR'], inplace=True)

        else: # if no data retrieved do nothing
            pass
        # dfp = pd.concat([results[k] for k in results], sort=True)
        if len(all_results_df) > 0:
            # Add columns from TESTREPORT_FACT that were removed during pivoting
            dfp = pd.merge(
                left=dfp,
                # the merged dataframe are the columns TEST_FACT_ID', 'TEST_DT', 'EQUIPMENT_NR of the  the DOUBLE df from
                # which the duplicates in TEST_FACT_ID are removed
                right=all_results_df.drop_duplicates(
                    subset=['TEST_FACT_ID']).loc[:, ['TEST_FACT_ID', 'TEST_DT', 'EQUIPMENT_NR']],
                on='TEST_FACT_ID',
                how='inner')

            dfp.set_index('TEST_FACT_ID', inplace=True)
        else:
            pass

        return dfp

    def get_machine_constants(self, mc_name, machines, tstart, tstop, verbose=False, n_retries=3, retry_sleep=30):
        """
        Returns a dataframe with the requested machine constant data.

        :param mc_name: Name of the machine constant, e.g. MCULTF_FFMPeriph_MIRROR_STATE_MIRROR_STATE_TAG
        :type mc_name: str
        :param machines: List of machines to include
        :type machines: list<dict> (Pyeuv machine dict)
        :param tstart: Include machine constant changes after this timestamp
        :type tstart: pd.Timestamp
        :param tstop: Include machine constant changes before this timestamp
        :type tstop: pd.Timestamp
        :param verbose: Print the signal that's being retrieved
        :type verbose: bool
        :param n_retries: Number of times to retry a query
        :type n_retries: int
        :param retry_sleep: Time to sleep in [s] between retries.
        :type retry_sleep: int
        :return: Dataframe with the MC's
        :rtype: pd.DataFrame
        """
        cur = self.conn.cursor()
        qry_tpl = """
        SELECT
            MACHINE_NR,
            COMPONENT_NAME,
            CONSTANT_UNIT,
            CONSTANT_FORMAT,
            VALID_FROM_DATE,
            VALID_TO_DATE,
            ARRAY_INDEX,
            VALUE_TEXT,
            VALUE_NUMERICAL,
            VALUE_EXPONENT
        FROM    
            CONSTANT_SUMMARY
        WHERE    
            CONSTANT_NAME = '{mc_name}'
            AND     VALID_FROM_DATE BETWEEN '{tstart}' AND '{tstop}' 
            AND    MACHINE_NR IN {machines_str}
;"""


        qry_tpl = textwrap.dedent(qry_tpl)
        machines_str = '(' + ','.join(["'{0}'".format(m['machine_nr']) for m in machines]) + ')'
        qry_params = {
            'mc_name': mc_name,
            'machines_str': machines_str,
            'tstart': tstart.strftime('%Y-%m-%d %H:%M:%S'),
            'tstop': tstop.strftime('%Y-%m-%d %H:%M:%S')
        }

        qry = qry_tpl.format(**qry_params)

        try:
            if verbose:
                print("Loading MC for {3}: {0} [{1}- {2}]".format(
                    qry_params['mc_name'], qry_params['tstart'],
                    qry_params['tstop'], qry_params['machines_str']))
            self._qry_with_retry(cur, qry, n_retries=n_retries, retry_sleep=retry_sleep)
            results = cur.fetchall()
        finally:
            cur.close()

        columns = ['machine_nr', 'component', 'unit', 'format', 'from_time', 'to_time', 'array_index',
                   'value_text', 'value_numerical', 'value_exponent']
        df = pd.DataFrame(results, columns=columns)

        return df

    def get_machine_equipment_info(self, machines=None, type_filter='NXE:3', n_retries=3,
                                   retry_sleep=30, verbose=False):
        """
        Returns a dataframe with contents from the PMA MACHINE_EQUIPMENT_HIST
        table for the given machines. By default only NXE3xyz machines are returned
        but the filter behaviour can be changed with the type_filter parameter. The
        returned df will contain the entire known history of the equipment. Every
        entry has a validity date (UK_MACHINE_VALID_FROM) to indicate when the entry
        is valid. Entries are valid until the validity date of the next entry.

        :param machines: List of machines to get the data for. Can also be set
                         to None to include all machines.
        :type machines: list<dict> (pyeuv machine dict) or NoneType (default)
        :param type_filter: Return only results that match the given equipment
                            type. Some examples are:
                            - 'NXE:3': returns NXE3xyz scanners
                            - 'EUVSOURCE': Returns EUV Sources
        :type type_filter: str
        :param n_retries: Number of times to retry a query
        :type n_retries: int
        :param retry_sleep: Time to sleep in [s] between retries.
        :type retry_sleep: int
        :param verbose: Print the signal that's being retrieved
        :type verbose: bool

        :return: Dataframe with the equipment information
        """
        cur = self.conn.cursor()

        qry_params = {
            'type_filter': type_filter
        }
        qry_tpl = """
        SELECT *
        FROM MACHINE_EQUIPMENT_HIST
        WHERE A_EQ_COMMERCIAL_TYPE LIKE '%{type_filter}%'
        """
        if machines is not None:
            qry_tpl += """AND UK_MACHINE_EQUIPMENT_NR IN {machines_str}"""
            qry_params['machines_str'] = '(' + ','.join(
                ["'{0}'".format(m['machine_nr']) for m in machines]) + ')'

        qry_tpl = textwrap.dedent(qry_tpl)
        qry = qry_tpl.format(**qry_params)

        try:
            if verbose:
                print("Loading Equipment info for {0}".format([m['machine_nr'] for m in machines]))
            self._qry_with_retry(cur, qry, n_retries=n_retries, retry_sleep=retry_sleep)
            results = cur.fetchall()
        finally:
            cur.close()

        df = pd.DataFrame(results, columns=[c.name for c in cur.description])

        return df

    def get_pvp_config(self, machines, options, tstart, tstop, n_retries=3, retry_sleep=30, verbose=False):
        """
        Obtain scanner product variability items (PVP items). These high level settings
        provide the TWINSCAN software with information about the machine it's running
        on and which options have been enabled on it.

        :param machines: List of machines to get the data for. Can also be set
                         to None to include all machines.
        :type machines: list<dict> (pyeuv machine dict) or NoneType (default)
        :param options: List of PVP option names to include
        :type options: list<str>
        :param tstart: Return pvp config records newer than this
        :type tstart: pd.Timestamp
        :param tstop: return pvp config records older than this
        :type tstop: pd.Timestamp
        :param n_retries: Number of times to retry a query
        :type n_retries: int
        :param retry_sleep: Time to sleep in [s] between retries.
        :type retry_sleep: int
        :param verbose: Print the signal that's being retrieved
        :type verbose: bool

        :return: Dataframe with the equipment information
        """
        if type(options) != list:
            raise TypeError("Options parameter must be of type list<str>")

        cur = self.conn.cursor()

        qry_tpl = """
        SELECT 
            UK_MACHINE_EQUIPMENT_NR,
            UK_CONFIG_POINT_IN_TIME_DATE,
            UK_CONFIG_OPTION_NAME,
            UK_CONFIG_OPTION_DESCRIPTION,
            A_CONFIG_OPTION_VALUE_NAME,
            A_CONFIG_OPTION_VALUE_DESCRIPTION
        FROM CONFIG_OPTION_INFO
        WHERE UK_MACHINE_EQUIPMENT_NR IN {machs}
            AND UK_CONFIG_OPTION_NAME IN {opts}
            AND UK_CONFIG_POINT_IN_TIME_DATE > PARSETIMESTAMP('{tstart}', 'yyyy-MM-dd hh:mm:ss')
            AND UK_CONFIG_POINT_IN_TIME_DATE < PARSETIMESTAMP('{tstop}', 'yyyy-MM-dd hh:mm:ss');
        """

        qry_tpl = textwrap.dedent(qry_tpl)

        machs = '(' + ','.join("'{0}'".format(m['machine_nr']) for m in machines) + ')'
        opts = '(' + ','.join("'{0}'".format(o) for o in options) + ')'

        qry = qry_tpl.format(**{
            'machs': machs,
            'opts': opts,
            'tstart': tstart.strftime('%Y-%m-%d %H:%M:%S'),
            'tstop': tstop.strftime('%Y-%m-%d %H:%M:%S')})
        try:
            if verbose:
                print("Loading config items for {0}".format([m['machine_nr'] for m in machines]))
            self._qry_with_retry(cur, qry, n_retries=n_retries, retry_sleep=retry_sleep)
            results = cur.fetchall()
        finally:
            cur.close()

        df = pd.DataFrame(results, columns=[c.name for c in cur.description])

        cur.close()

        return df

    def close(self):
        """ Close the Postgress connection """
        self.conn.close()
