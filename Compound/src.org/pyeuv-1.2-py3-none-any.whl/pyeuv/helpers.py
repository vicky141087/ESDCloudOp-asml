import numpy as np
import pandas as pd
import io
import gzip
import datetime
import lzma


EPOCH_OFFSET = float(datetime.datetime(1970, 1, 1).toordinal())


def epoch2num(e):
    """
    Convert an epoch or sequence of epochs to the new date format,
    that is days since 0001.
    """

    return EPOCH_OFFSET + np.asarray(e) / 86400  # Number of seconds per day


def num2ts(x):
    """
    Convert matlab datenum to pandas timestamp
    """
    return pd.to_datetime(((x - EPOCH_OFFSET) * 86400e9).astype('int64'))


class LoadFile:
    """
    Loads content of given filename. Decompresses if gzip or LZMA compression is detected
    Acts as context manager, so must be called using a with statement. Will take care of opening/closing files.

    *Example*

    ::

        with LoadFile('somefile.xz') as file_handle:
            contents = file_handle.read()
            do_something_with(contents)

    """
    def __init__(self, f):
        self.fn = None
        self.f_in = None
        self.f_out = None
        if type(f) == str:
            self.fn = f
        else:
            self.f_in = f

    def __call__(self, *args, **kwargs):
        self.fn = args[0]
        return self.__enter__()

    def __enter__(self):
        if self.f_in is None:
            self.f_in = open(self.fn, 'rb')
        # Check header for lzma compression
        header = self.f_in.read(6)
        self.f_in.seek(0)
        if header == b"\xfd7zXZ\x00":  # Test for LZMA header
            self.f_out = io.BytesIO(lzma.decompress(self.f_in.read()))
        elif header[0:2] == b"\x1f\x8b":  # Test for Gzip
            self.f_out = io.BytesIO(gzip.GzipFile(fileobj=self.f_in).read())
        else:  # Return raw contents
            self.f_out = io.BytesIO(self.f_in.read())

        return self.f_out

    def __exit__(self, type, value, traceback):
        if self.f_in is not None:
            self.f_in.close()

        if self.f_out is not None:
            self.f_out.close()
