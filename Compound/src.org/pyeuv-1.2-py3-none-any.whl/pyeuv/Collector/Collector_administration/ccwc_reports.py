# -*- coding: utf-8 -*-
"""
ccwc_reports.py
Authors: RWKL
Date:  2019-10-03

This module releases functions for extraction of data from CCWC reports.
"""

import pandas as pd
import numpy as np
import os
import datetime
from pyeuv.Collector.Collector_administration.shared import extract_data, get_root_directory
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def process_ccwc_reports(ccwc_report_paths, verbose=False):
    """
    Process the CCWC reports
    This extracts:
    - inspection summary from the 'Data' sheet
    - inspection results from the 'Data' sheet

    :param ccwc_report_paths: list of full paths of CCWC reports
    :param verbose: switches debug mode (default=False)
    :return: tuple of 2 dataframes containing the extracted data and failed files
    """

    do_it.do_it_verbose(currentframe(), verbose)

    failed_files = dict()
    all_reports = pd.DataFrame()
    for path in ccwc_report_paths:
        if verbose:
            print(path)
        try:
            df = pd.read_excel(path, sheet_name='Data')
            df.columns = [str(i) for i in np.arange(0, len(df.columns))]
            inspection_summary = extract_inspection_summary(df, verbose=verbose)
            inspection_result = extract_inspection_result(df, verbose=verbose)

            inspection_report = \
                pd.DataFrame.from_dict({**inspection_summary, **inspection_result}, orient='index').transpose()
            inspection_report['filename'] = path
            if inspection_report.dropna(subset=get_inspection_required_fields()).empty:
                inspection_report['valid_report'] = False
            else:
                inspection_report['valid_report'] = True
            all_reports = pd.concat([all_reports, inspection_report], ignore_index=True)
            print("Successfully read inspection report:", path)

        except Exception as e:
            failed_files[path] = e
            if verbose:
                print("Failed to read inspection report:", path)
                print(e)

    try:
        # add some derived columns
        all_reports['collector_name'] = [np.NaN if np.isnan(mirror_nr) else 'SDMSC{:03d}'.format(mirror_nr)
                                         for mirror_nr in all_reports['mirror_number']]
        all_reports['report_date'] = [np.NaN if np.isnan(d) else
                                      datetime.datetime.strptime('20{}'.format(d).replace('.7', '.0'), "%Y%W.%w") -
                                      pd.Timedelta(1, 'w')
                                      for d in all_reports['date_asml_format']]
        for key in ['hardware_config_checked', 'inspection_stain_free', 'inspection_oasis_markers_clean',
                    'inspection_mechanical_parts', 'inspection_cone', 'inspection_shoebox_screws']:
            all_reports[key] = ['OK' if
                                i.lower() == 'y' or
                                i.lower() == 'yes'
                                else 'NOK'
                                for i in all_reports[key]]
    except Exception as e:
        print('Failed to add meta data:', e)

    # restructure dict to dataframe
    failed_files_df = pd.DataFrame()
    failed_files_df['file'] = list(failed_files.keys())
    failed_files_df['cause'] = list(failed_files.values())

    return all_reports, failed_files_df


def get_ccwc_reports(local=False, verbose=False):
    """
    returns a list of full paths of ccwc reports

    :param local: toggle local or remote location (default: False)
        The local location is the location ASML/windows creates when syncing the PQR sharepoint
    :param verbose: switches debug mode (default=False)
    :return: list of full paths of ccwc reports
    """

    do_it.do_it_verbose(currentframe(), verbose)

    root = get_root_ccwc_reports(local=False)
    files = [os.path.join(base, name)
             for base, dirs, files in os.walk(root)
             for name in files]

    reports = select_ccwc_reports(files)

    if verbose:
        print('ccwc: ({} of {} files)\n{}'.format(len(reports), len(files), reports))

    return reports


def get_root_ccwc_reports(local=False, verbose=False):
    """
    returns the root path of CCWC reports

    :param local: toggle local or remote location (default: False)
        The local location is './data/collector_history/CCWC_inspection_reports'.
        The remote is currently './collector_history/CCWC_inspection_reports' on the CPR share
    :param verbose: switches debug mode (default=False)
    :return: the root path in which the CCWC reports are stored
    """

    do_it.do_it_verbose(currentframe(), verbose)

    root = os.path.join(get_root_directory(local), 'CCWC_inspection_reports')

    return root


def get_ccwc_report_data_filename(verbose=False):
    """
    Returns the filename in which the extracted ccwc data is stored

    :param verbose: switches debug mode (default=False)
    :return: filename of extracted ccwc report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return 'ccwc_reports.csv'


def get_ccwc_failed_report_data_filename(verbose=False):
    """
    Returns the filename in which the CCWC reports are listed for which extraction failed

    :param verbose: switches debug mode (default=False)
    :return: filename of extracted ccwc report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return 'ccwc_failed_reports.csv'


def save_ccwc_report_data(report_data, failed_report_data, local=False, overwrite=False, verbose=False):
    """
    Save extracted data

    :param report_data: dataframe containing the extracted ccwc report data
    :param failed_report_data: dataframe containing all the reports that failed during extraction
    :param local: toggle local or remote location (default: False)
    :param overwrite: toggle to overwrite extracted data. If false, it appends data (default: False)
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # append existing data
    if not overwrite:
        report_data_existing = load_ccwc_report_data(local, verbose)
        report_data = pd.concat([report_data_existing, report_data], sort=False)

        failed_report_data_existing = load_ccwc_failed_report_data(local, verbose)
        failed_report_data = pd.concat([failed_report_data_existing, failed_report_data], sort=False)

    # save data
    filename = get_ccwc_report_data_filename(verbose)
    report_data.to_csv(os.path.join(get_root_directory(local, verbose), filename))

    filename = get_ccwc_failed_report_data_filename(verbose)
    failed_report_data.to_csv(os.path.join(get_root_directory(local, verbose), filename))


def load_ccwc_report_data(local=False, verbose=False):
    """
    Load extracted CCWC report data

    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    :return: dataframe with report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    full_path = os.path.join(get_root_directory(local, verbose),
                             get_ccwc_report_data_filename(verbose))
    try:
        report_data  = pd.read_csv(full_path, index_col=0)
    except Exception as e:
        print ('Failed to read {}. Exception: {}'.format(full_path, e))
        report_data = pd.DataFrame()

    return report_data


def load_ccwc_failed_report_data(local=False, verbose=False):
    """
    Load CCWC reports that failed to be extracted

    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    :return: dataframe with reports that failed to be extracted
    """

    do_it.do_it_verbose(currentframe(), verbose)

    full_path = os.path.join(get_root_directory(local, verbose),
                             get_ccwc_failed_report_data_filename(verbose))
    try:
        failed_report_data  = pd.read_csv(full_path, index_col=0)
    except Exception as e:
        print ('Failed to read {}. Exception: {}'.format(full_path, e))
        failed_report_data = pd.DataFrame()

    return failed_report_data


def select_ccwc_reports(file_name_list, verbose=False):
    """
     Filters the filenames that are valid for CCWC reports
     The only restrictions are that it contains 'outgoing' (case insensitive) and
     the extension should be either 'xlsm' or 'xlsx'

     :param file_name_list: list of filenames
     :param verbose: switches debug mode (default=False)
     :return: list of valid PQR report filenames
     """

    do_it.do_it_verbose(currentframe(), verbose)

    file_list = [f for f in file_name_list
                 if (f.endswith('.xlsm') or f.endswith('.xlsx')) and ('outgoing' in f.lower())]
    return file_list


def get_inspection_summary_items(verbose=False):
    """
    Get the summary items from the CCWC report

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing the extracted items. The key is the naming in this tooling.
        The value the key in the report
    """

    do_it.do_it_verbose(currentframe(), verbose)

    inspection_items = {
        'mirror_number': 'Outgoing inspection report                  SDMSC',
        'SAP_pwo_number': 'SAP PWO number',
        'date_asml_format': 'Inspection report finished                YYWW.D',
        'location': 'Location cleaning center',
        'qualification': 'band qualification (now)',
        'rejection_damage': 'Reject due to damage?',
        'hardware_config_checked': 'Hardware config checked OK?',
        '12NC outgoing': '12NC outgoing',
        'EUVR estimation outgoing': 'EUVR estimation outgoing (using calc v5)',
    }
    return inspection_items


def get_inspection_required_fields(verbose=False):
    """
    returns the required fields.
    Based on this, reports can be validated and possibly ignored

    :param verbose: switches debug mode (default=False)
    :return: list of required fields
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return [
        'mirror_number',
        'report_type'
    ]


def get_inspection_result_items(verbose=False):
    """
    Get the inspection result items from the CCWC report

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing the extracted items. The key is the naming in this tooling.
        The value the key in the report
    """

    do_it.do_it_verbose(currentframe(), verbose)

    inspection_items = {
        'report_type': 'CO2 clean or upgrade only or inspection only?',
        'inspection_damage_level': 'Damage on mirror - any NOK for customer?',
        'inspection_stain_free': 'Stain-free mirror?',
        'inspection_oasis_markers_clean': 'All 3 OASIS markers clean?',
        'inspection_mechanical_parts': 'Bellows and other mechanical parts OK?',
        'inspection_cone': 'Cone & closing disc OK?',
        'inspection_shoebox_screws': 'Screws at back and front of shoebox all present?',
        'inspection_surface_area_clean': 'Tinfree reflection surface (CQT "Clean Rel EUVR")',
    }
    return inspection_items


def extract_inspection_summary(input_data, verbose=False):
    """
    Extracts the inspection summary items.
    The tags are located in column 1, the values are in column 2

    :param input_data: dataframe of the imported excel sheet
    :param verbose: switches debug mode (default=False)
    :return: dictionary with extracted items
    """

    do_it.do_it_verbose(currentframe(), verbose)

    extracted_items = extract_data(input_data, get_inspection_summary_items(), '1', '2', verbose)

    return extracted_items


def extract_inspection_result(input_data, verbose=False):
    """
    Extracts the inspection results items.
    The tags are located in column 1, the values are in column 3

    :param input_data: dataframe of the imported excel sheet
    :param verbose: switches debug mode (default=False)
    :return: dictionary with extracted items
    """

    do_it.do_it_verbose(currentframe(), verbose)

    extracted_items = extract_data(input_data, get_inspection_result_items(), '1', '3', verbose)

    return extracted_items
