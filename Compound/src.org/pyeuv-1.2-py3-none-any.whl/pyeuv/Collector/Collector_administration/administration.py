# -*- coding: utf-8 -*-
"""
administration.py
Authors: RWKL
Date:  2019-10-03

This module releases functions for exposing collector history and administration information.
"""

import pandas as pd
import numpy as np
import os
import datetime
from pyeuv.Collector.Collector_administration.pqr_reports import load_pqr_report_data
from pyeuv.Collector.Collector_administration.ccwc_reports import load_ccwc_report_data
from pyeuv.Collector.Collector_administration.collector_swaps import load_collector_swaps

import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def load_report_data(check_ccwc=True, verbose=False):
    """
    Loads the different reports, combines them and sort them by report_date

    :param check_ccwc: switch to only include valid ccwc reports (default: True)
    :param verbose: switches debug mode (default=False)
    :return: dataframe containing the combined report
    """

    do_it.do_it_verbose(currentframe(), verbose)

    pqr_reports = load_pqr_report_data()
    ccwc_reports = load_ccwc_report_data()
    swap_reports = load_collector_swaps()

    if not swap_reports.empty:
        swap_reports['report_type'] = 'collector swap'
        swap_reports['report_date'] = pd.to_datetime(swap_reports.index).tz_localize(None)

    if not ccwc_reports.empty:
        ccwc_reports['report_type'].fillna('', inplace=True)
        if check_ccwc:
            ccwc_reports = ccwc_reports[ccwc_reports['valid_report']]

    if not pqr_reports.empty:
        pqr_reports['report_type'] = 'PQR'

    result = pd.concat([ccwc_reports, pqr_reports, swap_reports], sort=False)
    result['report_date'] = pd.to_datetime(result['report_date'])
    result = result.sort_values(by=['report_date']).drop_duplicates()
    result.index = result['report_date']

    return result


def get_collector_history(report_data, collector_number, verbose=False):
    """
    Returns the hsitory of a given collector. The history includes swaps, cleaning and refurbishments

    :param report_data: dataframe with all report data
    :param collector_number:
    :param verbose: switches debug mode (default=False)
    :return:
    """

    do_it.do_it_verbose(currentframe(), verbose)

    collector_name = 'SDMSC{:03d}'.format(int(collector_number))

    report_data_selection = report_data[report_data['collector_name'] == collector_name]
    result = report_data_selection[['collector_name', 'location', 'report_type']].fillna('unknown')

    return result


def get_collector_numbers(report_data, verbose=False):
    """
    Extract unique collector numbers from report data

    :param report_data: dataframe with all report data
    :param verbose: switches debug mode (default=False)
    :return: list of unique collector numbers (without SDMSC)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    collector_numbers = np.unique([int(i[5:8]) for i in report_data.collector_name.dropna().unique()])

    return collector_numbers
