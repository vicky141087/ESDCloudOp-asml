import pandas as pd
import numpy as np
import math
import os

from bokeh.models import ColumnDataSource
from bokeh.transform import dodge
from bokeh.plotting import figure, show
from bokeh.palettes import Category20 as palette
from bokeh.io import export_png
from pyeuv.Collector.Collector_administration.shared import get_asml_date_format, get_root_directory
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it

WEEKS_MAX_DEF = 15


def prepare_swap_prediction_data(swap_predictions, weeks_max=WEEKS_MAX_DEF, verbose=False):
    """
    Prepares the swap prediction data into number of swaps per week

    :param swap_predictions: dataframe with swap prediction per collector
    :param weeks_max: maximum number of weeks to be shown. (default-WEEKS_MAX_DEF)
        Last week will include all swaps predicted to be in that week and beyond
    :param verbose: switches debug mode (default=False)
    :return: tuple with list of swap criteria and dictionary with swaps per week
    """
    do_it.do_it_verbose(currentframe(), verbose)

    now = pd.Timestamp('now', tz='UTC')
    # get fourth day of the current week, to avoid problems in the last week of the year / first week next year)
    fourth_day_of_week = now - pd.Timedelta(int(get_asml_date_format(now).split('.')[-1]) - 4, 'days')
    week_numbers = [get_asml_date_format(fourth_day_of_week + pd.Timedelta(7 * i, 'days')).split('.')[0]
                    for i in np.arange(weeks_max + 1)]
    x_tags = week_numbers.copy()
    x_tags[-1] = 'later'
    test = swap_predictions.copy()
    criteria = [c.split('_')[-1] for c in test.columns if
                'swap_data_asml' in c]
    ds = dict()
    ds['week_numbers'] = x_tags
    for i, c in enumerate(criteria):
        column_asml = 'swap_data_asml_{}'.format(c)

        bars = [len(test[(test[column_asml] > wk_nr) & (test[column_asml] < '{}.8'.format(wk_nr))]) for wk_nr in
                week_numbers]
        bars[0] += len(test[test[column_asml] < week_numbers[0]])
        bars[-1] += len(test[test[column_asml] > '{}.8'.format(week_numbers[-1])])
        ds[c] = bars
    return criteria, ds


def create_swap_prediction_plot(criteria, ds, verbose=False):
    """
    Creates the swap prediction plot with number of swaps per week, nicely formatted labels, etc.

    :param criteria: list of swap criteria
    :param ds: dictionary of number of swaps per week
    :param verbose: switches debug mode (default=False)
    :return: bokeh plot
    """
    do_it.do_it_verbose(currentframe(), verbose)

    source = ColumnDataSource(data=ds)
    p = figure(x_range=ds['week_numbers'], width=900, height=400,
               toolbar_location=None, tools="")
    for i, c in enumerate(criteria):
        p.vbar(x=dodge('week_numbers', -0.25 + i * 0.25, range=p.x_range), top=c, width=0.2, source=source,
               line_color=palette[20][i * 2], fill_color=palette[20][i * 2 + 1], legend='{}%'.format(criteria[i]))
    p.x_range.range_padding = 0.1
    p.xaxis.major_label_orientation = math.pi / 4
    p.xaxis.axis_label_text_font_size = "15pt"
    p.xaxis.major_label_text_font_size = "15pt"
    p.yaxis.axis_label_text_font_size = "15pt"
    p.yaxis.major_label_text_font_size = "15pt"
    p.xgrid.grid_line_color = None
    p.legend.location = "top_center"
    p.legend.orientation = "horizontal"
    p.xaxis.axis_label = 'week number'
    p.yaxis.axis_label = '# collector swaps'
    p.legend.title = 'Different swap criteria:'
    return p


def show_swap_prediction(swap_predictions, weeks_max=WEEKS_MAX_DEF, verbose=False):
    """
    Shows the swap prediction in both a plot and a table

    :param swap_predictions: dataframe with swap prediction per collector
    :param weeks_max: maximum number of weeks to be shown. (default-WEEKS_MAX_DEF)
        Last week will include all swaps predicted to be in that week and beyond
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    show_swap_prediction_plot(swap_predictions, weeks_max, verbose)
    show_swap_prediction_table(swap_predictions, weeks_max, verbose)


def show_swap_prediction_table(swap_predictions, weeks_max=WEEKS_MAX_DEF, verbose=False):
    """
    Shows the swap prediction in a table

    :param swap_predictions: dataframe with swap prediction per collector
    :param weeks_max: maximum number of weeks to be shown. (default-WEEKS_MAX_DEF)
        Last week will include all swaps predicted to be in that week and beyond
    :param verbose: switches debug mode (default=False)
    :return:
    """

    do_it.do_it_verbose(currentframe(), verbose)

    criteria, ds = prepare_swap_prediction_data(swap_predictions, weeks_max, verbose=verbose)
    df = pd.DataFrame(ds, index=ds['week_numbers']).drop(columns='week_numbers')
    df.columns = ['{}%'.format(c) for c in criteria]
    display(df.transpose())


def show_swap_prediction_plot(swap_predictions, weeks_max=WEEKS_MAX_DEF, verbose=False):
    """
    Shows the swap prediction in a plot

    :param swap_predictions: dataframe with swap prediction per collector
    :param weeks_max: maximum number of weeks to be shown. (default-WEEKS_MAX_DEF)
        Last week will include all swaps predicted to be in that week and beyond
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    criteria, ds = prepare_swap_prediction_data(swap_predictions, weeks_max, verbose=verbose)
    p = create_swap_prediction_plot(criteria, ds, verbose=verbose)
    show(p)


def save_swap_prediction_plot(swap_predictions, weeks_max=WEEKS_MAX_DEF, local=False, verbose=False):
    """
    Saves the swap prediction in a plot

    :param swap_predictions: dataframe with swap prediction per collector
    :param weeks_max: maximum number of weeks to be shown. (default-WEEKS_MAX_DEF)
        Last week will include all swaps predicted to be in that week and beyond
    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    criteria, ds = prepare_swap_prediction_data(swap_predictions, weeks_max, verbose=verbose)
    p = create_swap_prediction_plot(criteria, ds)
    root = get_root_directory(local=local, verbose=verbose)
    export_png(p, filename=os.path.join(root, "swap_prediction_{}.png".format(
        get_asml_date_format(pd.Timestamp('now', tz='UTC')))))
