# -*- coding: utf-8 -*-
"""
collector_swaps.py
Authors: RWKL
Date:  2019-10-03

This module releases functions for collector swap history and prediction.
"""

import numpy as np
import pandas as pd
import os
from pyeuv.Shared.shared import get_collectors, get_machines
from pyeuv.Collector.Collector_administration.shared import get_root_directory, get_asml_date_format
from pyeuv.Shared.signal_processing import calculate_linear_fit
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def extract_collector_swaps(client, verbose=False):
    """
    Extracts all the collector swaps from influx

    :param client: connection to influx
    :param verbose: switches debug mode (default=False)
    :return: dataframe with all collector swaps
    """

    do_it.do_it_verbose(currentframe(), verbose)

    collector_swaps = pd.DataFrame()
    try:
        machine_list = client.get_machine_list(return_type='dataframe')
        machine_list['source_id'] = [np.NaN if np.isnan(s) else 's{}'.format(s) for s in machine_list['source_nr']]
        for i, row in machine_list.iterrows():
            if verbose:
                print (row.displayname, row.source_id)
            try:
                swaps = client.get_signals(['{}.Collector.Swap'.format(row.source_id)])
                swaps.columns = ['collector_name_extended']
                swaps['collector_name'] = [c[:8] for c in swaps.collector_name_extended]
                swaps['location'] = row.displayname
                swaps['report_date'] = swaps.index
                collector_swaps = pd.concat([collector_swaps, swaps])
            except Exception as e:
                print (row.source_id, swaps)
    except Exception as e:
        print('Failed to extract collector swaps:', e)

    return collector_swaps


def predict_collector_swap(client, fit_window=20.0, maximum_pulsecount=220.0, verbose=False):
    """
    Predict the collector swap.
    - fit slie/dt over the last <fit_window> Gp
    - linear extrapolate to the swap criterium to get a swap pulse count (different swap criteria assumed)
      - the swap pulse count is the minimum of the prediction and the maximum_pulsecount
    - Over the same window, determine the utilization
    - translate the swap prediction to a timestamp
    - convert to asml weeknumber format

    :param client: connection to influx
    :param fit_window: gp window used for the linear fit for predicting the swap
    :param maximum_pulsecount: maximum number of Gp before a collector will be swapped due to design limitations
    :param verbose: switches debug mode (default=False)
    :return: dataframe with swap prediction for each collector
    """

    do_it.do_it_verbose(currentframe(), verbose)

    machine_list = get_machines(client, exclude_non_scanner=False)
    machine_list = machine_list[machine_list.customer != 'ASML']
    machine_list['source_id'] = [np.NaN if np.isnan(s) else 's{}'.format(s) for s in machine_list['source_nr']]

    signals_dict = {
        'slie_dt': 'Collector._SLIE_DT_Norm',
        'pulse_count': 'Collector._PulseCount'
    }
    swap_criterium = [50, 65, 80]
    swap_overview = pd.DataFrame()

    for i, row in machine_list.iterrows():
        if verbose:
            print ('{}: {}'.format(row.source_id, row.displayname))
        try:
            swaps = get_collectors(client, row.source_id)
            swap = swaps.iloc[-1]
            collector_name = swap.swap[:8]
            if verbose:
                print (swap.swap, swap.start, swap.end)
            data = client.get_signals_dict(signals_dict, row.source_id, swap.start, swap.end, create_columns=True)
            data.pulse_count.interpolate(inplace=True)
            data.pulse_count.ffill(inplace=True)
            data.pulse_count.bfill(inplace=True)
            data.pulse_count *= 1e-9
            data.dropna(inplace=True)
            if data.empty:
                if verbose:
                    print ('No SLIE/DT + pulsecount data')
                continue
            if pd.Timestamp('now', tz='UTC') - data.index[-1] > pd.Timedelta(30, 'days'):
                if verbose:
                    print ('No recent data')
                continue

            data_fit = data[data.pulse_count >= data.pulse_count.max() - fit_window]
            slope, offset, conf_int, r_sq = calculate_linear_fit(data.pulse_count, data.slie_dt)
            if verbose:
                print ('fit:', slope, offset)
            gp_swap = []
            for sc in swap_criterium:
                gp_swap.append(min(maximum_pulsecount, (sc - offset) / slope))

            duration = data_fit.index[-1] - data_fit.index[0]
            duration_in_days = duration.days + duration.seconds/(60*60*24)
            utilization = fit_window / duration_in_days
            days_left = (np.array(gp_swap) - data_fit.pulse_count.max()) / utilization
            swap_timestamp = [pd.Timestamp('now', tz='UTC') + pd.Timedelta(days=d_l)
                              for d_l in days_left]
            column_names = ['swap_time_{}'.format(s) for s in swap_criterium]

            swap_overview_new = pd.DataFrame(index=[collector_name], columns=column_names, data=[swap_timestamp])

            # add swap day in ASML format (wk1943.2 for tuesday in week 43 in 2019)
            for s in swap_criterium:
                swap_overview_new['swap_data_asml_{}'.format(s)] = \
                    [get_asml_date_format(se) for se in swap_overview_new['swap_time_{}'.format(s)]]

            swap_overview = pd.concat([swap_overview, swap_overview_new])
        except Exception as e:
            if verbose:
                print('No collector for {}'.format(row.displayname))
                print (e)
        if verbose:
            print ('')

    return swap_overview


def save_collector_swaps(collector_swaps, local=False, verbose=False):
    """
    Stores all the collector swaps to a csv file in the root directory of the collector administration

    :param collector_swaps: dataframe with all collector swaps
    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # save data
    filename = get_collector_swaps_data_filename(verbose)
    collector_swaps.to_csv(os.path.join(get_root_directory(local, verbose), filename))


def save_collector_swap_prediction(swap_prediction, local=False, verbose=False):
    """
    Stores the collector swap prediction to a csv file in the root directory of the collector administration

    :param swap_prediction: dataframe with swap predictions
    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # save data
    filename = get_collector_swap_prediction_filename(verbose)
    swap_prediction.to_csv(os.path.join(get_root_directory(local, verbose), filename))


def load_collector_swaps(local=False, verbose=False):
    """
    Load collector swap data from the root directory of the collector administration

    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    :return: dataframe with report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    full_path = os.path.join(get_root_directory(local, verbose), get_collector_swaps_data_filename(verbose))
    try:
        report_data = pd.read_csv(full_path, index_col=0)
    except Exception as e:
        print ('Failed to read {}. Exception: {}'.format(full_path, e))
        report_data = pd.DataFrame()

    return report_data


def load_collector_swap_prediction(local=False, verbose=False):
    """
    Load collector swap predictions from the root directory of the collector administration

    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    :return: dataframe with report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    full_path = os.path.join(get_root_directory(local, verbose), get_collector_swap_prediction_filename(verbose))
    try:
        report_data = pd.read_csv(full_path, index_col=0)
    except Exception as e:
        print ('Failed to read {}. Exception: {}'.format(full_path, e))
        report_data = pd.DataFrame()

    return report_data


def get_collector_swaps_data_filename(verbose=False):
    """
    Returns the filename in which the historic collector swaps are stored

    :param verbose: switches debug mode (default=False)
    :return: filename of extracted PQR report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return 'collector_swaps.csv'


def get_collector_swap_prediction_filename(verbose=False):
    """
    Returns the filename in which the collector swap prediction is stored

    :param verbose: switches debug mode (default=False)
    :return: filename of extracted PQR report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return 'collector_swap_prediction.csv'
