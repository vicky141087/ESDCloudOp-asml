# -*- coding: utf-8 -*-
"""
ccwc_reports.py
Authors: RWKL
Date:  2019-10-03

This module releases functions for extraction of data from a dataframe.
Given tags, and the column names in which the tag and value should be, function will extract the data.
"""
import os

import numpy as np
from inspect import currentframe

from pyeuv.Collector.Shared.directory_structure import get_share_base_directory

from pyeuv.Do_It import do_it_library as do_it


def extract_data(input_data, items, tag_column_name, value_column_name, verbose=False):
    """
    Generic function to extracts items from a dataframe
    The tags are located in column 1, the values are located in column_name

    :param input_data: input dataframe
    :param items: dictionary containing the to be extracted items
    :param tag_column_name: name of the column in which the tags are
    :param value_column_name: name of the column in which the values are
    :param verbose: switches debug mode (default=False)
    :return: dictionary with extracted items
    """

    do_it.do_it_verbose(currentframe(), verbose)

    extracted_items = dict()
    for item, name in items.items():
        row = input_data[input_data[tag_column_name] == name]
        if row.empty:
            if verbose:
                print('failed to extract {}'.format(name))
            extracted_items[item] = np.NaN
        else:
            extracted_items[item] = row[value_column_name].values[0]
    return extracted_items


def get_root_directory(local=False, verbose=False):
    """
    returns the path where the from reports extracted data is stored

    :param local: toggle local or remote location (default: False)
        The local location is './data/collector_history/'.
        The remote is currently './collector_history/' on the CPR share
    :param verbose: switches debug mode (default=False)
    :return: the directory path where the extracted data is stored
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if local:
        root = os.path.join(os.getcwd(), 'data', 'collector_history')
    else:
        root = os.path.join(get_share_base_directory(), 'collector_history')
    return root


def get_asml_date_format(timestamp, verbose=False):
    """
    Convert timestamp to ASML week number format

    :param timestamp: pandas timestamp
    :param verbose: switches debug mode (default=False)
    :return: string in the format Wk<YY><WW>.<1-7>
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return 'wk{}{}.{}'.format(timestamp.strftime("%Y")[2:], timestamp.strftime("%V"), timestamp.weekday()+1)