# -*- coding: utf-8 -*-
"""
ccwc_reports.py
Authors: RWKL
Date:  2019-10-03

This module releases functions for extraction of data from PQR reports.
"""

import pandas as pd
import numpy as np
import os
import getpass
from pyeuv.Collector.Collector_administration.shared import extract_data, get_root_directory
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def process_pqr_reports(pqr_report_paths, verbose=False):
    """
    Process the PQR reports
    This extracts:
    - basic information from the 'Summary' sheet
    - module information from the 'Summary' sheet
    - performance information from the 'Coll Performance' sheet

    :param pqr_report_paths: list of full paths of report files
    :param verbose: switches debug mode (default=False)
    :return: tuple of 2 dataframes containing the extracted data and failed files
    """

    do_it.do_it_verbose(currentframe(), verbose)

    failed_files = dict()
    all_reports = pd.DataFrame()
    for path in pqr_report_paths:
        if verbose:
            print(path)
        try:
            # test for missing sheet names
            xl = pd.ExcelFile(path)
            collector_performance_sheet = [i for i in xl.sheet_names if i in
                                           ['Summary Collector performance',
                                            'Coll Performance',
                                            'Collector_performance']]
            if (('Summary' not in xl.sheet_names) or
                    len(collector_performance_sheet) == 0):
                raise Exception('Missing required sheet_names:', xl.sheet_names)

            try:
                # summary tab
                df = pd.read_excel(path, sheet_name='Summary')
                df.columns = [str(i) for i in np.arange(0, len(df.columns))]
                basic_information = extract_pqr_basic_information(df, verbose=verbose)
                module_information = extract_pqr_module_summary(df, verbose=verbose)
            except IOError:
                basic_information = dict()
                module_information = dict()
                if verbose:
                    print("Failed to read Summary tab of PQR report:", path)

            try:
                # performance tab
                df = pd.read_excel(path, sheet_name=collector_performance_sheet[0])
                df.columns = [str(i) for i in np.arange(0, len(df.columns))]
                performance = extract_pqr_performance(df, verbose=verbose)
            except IOError:
                performance = dict()
                if verbose:
                    print("Failed to read Coll Performance tab of PQR report:", path)

            pqr_report = pd.DataFrame.from_dict({**basic_information, **module_information, **performance},
                                                orient='index').transpose()
            pqr_report['filename'] = path

            all_reports = pd.concat([all_reports, pqr_report], ignore_index=True)
            if verbose:
                print("Succesfully read PQR report: ", path)
        except Exception as e:
            failed_files[path] = e
            if verbose:
                print("Failed to read PQR report: ", path)
                print(e)

    # add default values
    all_reports['location'] = 'Zeiss'

    # restructure dict to dataframe
    failed_files_df = pd.DataFrame()
    failed_files_df['file'] = list(failed_files.keys())
    failed_files_df['cause'] = list(failed_files.values())

    return all_reports, failed_files_df


def get_pqr_reports(local=False, verbose=False):
    """
    returns a list of full paths of pqr reports

    :param local: toggle local or remote location (default: True)
        The local location is the location ASML/windows creates when syncing the PQR sharepoint
    :param verbose: switches debug mode (default=False)
    :return: list of full paths of pqr reports
    """

    do_it.do_it_verbose(currentframe(), verbose)

    root = get_root_pqr_reports(local, verbose)
    files = [os.path.join(base, name)
             for base, dirs, files in os.walk(root)
             for name in files]

    reports = select_pqr_reports(files, verbose)

    if verbose:
        print('pqr : ({} of {} files)\n{}'.format(len(reports), len(files), reports))

    return reports


def get_root_pqr_reports(local=False, verbose=False):
    """
    returns the root path of the PQR reports

    :param local: toggle local or remote location (default: True)
        The local location is the location ASML/windows creates when syncing the PQR sharepoint
    :param verbose: switches debug mode (default=False)
    :return: the root path in which the PQR reports are stored
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if local:
        # when one syncs the sharepoint, this becomes the local path
        root = os.path.join('c:/', 'Users', getpass.getuser(), 'ASML', 'EUV Collection Project - individual_collectors')
    else:
        root = os.path.join(get_root_directory(local), 'PQR_reports')
    return root


def get_pqr_report_data_filename(verbose=False):
    """
    Returns the filename in which the extracted PQR data is stored
    :param verbose: switches debug mode (default=False)
    :return: filename of extracted PQR report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return 'pqr_reports.csv'


def get_pqr_failed_report_data_filename(verbose=False):
    """
    Returns the filename in which the PQR reports are listed for which extraction failed

    :param verbose: switches debug mode (default=False)
    :return: filename of PQR reports for which extraction failed
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return 'pqr_failed_reports.csv'


def save_pqr_report_data(report_data, failed_report_data, local=False, overwrite=False, verbose=False):
    """
    Save extracted PQR data

    :param report_data: dataframe containing the extracted pqr report data
    :param failed_report_data: dataframe containing all the reports that failed during extraction
    :param local: toggle local or remote location (default: False)
    :param overwrite: toggle to overwrite extracted data. If false, it appends data (default: False)
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # append existing data
    if not overwrite:
        report_data_existing = load_pqr_report_data(local, verbose)
        report_data = pd.concat([report_data_existing, report_data], sort=False)

        failed_report_data_existing = load_pqr_failed_report_data(local, verbose)
        failed_report_data = pd.concat([failed_report_data_existing, failed_report_data], sort=False)

    # save data
    filename = get_pqr_report_data_filename(verbose)
    report_data.to_csv(os.path.join(get_root_directory(local, verbose), filename))

    filename = get_pqr_failed_report_data_filename(verbose)
    failed_report_data.to_csv(os.path.join(get_root_directory(local, verbose), filename))


def load_pqr_report_data(local=False, verbose=False):
    """
    Load extracted PQR report data

    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    :return: dataframe with report data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    full_path = os.path.join(get_root_directory(local, verbose), get_pqr_report_data_filename(verbose))
    try:
        report_data = pd.read_csv(full_path, index_col=0)
    except Exception as e:
        print ('Failed to read {}. Exception: {}'.format(full_path, e))
        report_data = pd.DataFrame()

    return report_data


def load_pqr_failed_report_data(local=False, verbose=False):
    """
    Load PQR reports that failed to be extracted

    :param local: toggle local or remote location (default: False)
    :param verbose: switches debug mode (default=False)
    :return: dataframe with reports that failed to be extracted
    """

    do_it.do_it_verbose(currentframe(), verbose)

    full_path = os.path.join(get_root_directory(local, verbose), get_pqr_failed_report_data_filename(verbose))
    try:
        failed_report_data = pd.read_csv(full_path, index_col=0)
    except Exception as e:
        print ('Failed to read {}. Exception: {}'.format(full_path, e))
        failed_report_data = pd.DataFrame()

    return failed_report_data


def select_pqr_reports(file_name_list, verbose=False):
    """
    Filters the filenames that are valid for PQR reports
    The valid format is './**/SDMSC*.xlsx'

    :param file_name_list: list of filenames
    :param verbose: switches debug mode (default=False)
    :return: list of valid PQR report filenames
    """

    do_it.do_it_verbose(currentframe(), verbose)

    file_list = [f for f in file_name_list if (f.endswith('.xlsx')) and ('SDMSC' in f)]
    return file_list


def get_pqr_performance_items(verbose=False):
    """
    Get the items on performance from the PQR report

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing the extracted items. The key is the naming in this tooling.
        The value the key in the report
    """

    do_it.do_it_verbose(currentframe(), verbose)

    performance_items = {
        'EUV_transmission_average': 'OP08',
        'IR_transmission_average': 'OP12a',
        'IR_transmission_max': 'OP12b',
    }
    return performance_items


def get_pqr_basic_items(verbose=False):
    """
    Get the basic items from the PQR report

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing the extracted items. The key is the naming in this tooling.
        The value the key in the report
    """

    do_it.do_it_verbose(currentframe(), verbose)

    basic_items = {
        'collector_name': 'CZ Serial-No.:',
        'uid_cz': 'CZ Material-No.:',
        'uid': 'ASML Material-No.:',
        'barcode': 'Barcode ID:',
        'report_date': 'Date of Report:',
    }
    return basic_items


def get_pqr_module_items(verbose=False):
    """
    Get the module items from the PQR report

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing the extracted items. The key is the naming in this tooling.
        The value the key in the report
    """

    do_it.do_it_verbose(currentframe(), verbose)

    module_items = {
        'SPF': 'SPF Type',
        'SBL': 'SBL Type',
        'ERL': 'ERL Type',
        'PCL': 'PCL Type',
        'Oasis_marker': 'Oasis Marker Type',
    }
    return module_items


def extract_pqr_performance(input_data, verbose=False):
    """
    Extracts the performance items.
    The tags are located in column 2, the values in column 3

    :param input_data: dataframe of the imported excel sheet
    :param verbose: switches debug mode (default=False)
    :return: dictionary with extracted items
    """

    do_it.do_it_verbose(currentframe(), verbose)

    extracted_items = extract_data(input_data, get_pqr_performance_items(), '2', '3', verbose)

    return extracted_items


def extract_pqr_module_summary(input_data, verbose=False):
    """
    Extracts the module items.
    Per item we extract the type, revision and parameter
    The tags are located in column 0, the extracted data in columns 1, 2 and 3

    :param input_data: dataframe of the imported excel sheet
    :param verbose: switches debug mode (default=False)
    :return: dictionary with extracted items
    """

    do_it.do_it_verbose(currentframe(), verbose)
    extracted_items = dict()
    post_fixes = ['type', 'revision', 'parameter']
    items = get_pqr_module_items()
    for item, name in items.items():
        row = input_data[input_data['0'] == name]
        if row.empty:
            if verbose:
                print('failed to extract {}'.format(name))
            for post_fix in post_fixes:
                extracted_items['{}_{}'.format(item, post_fix)] = np.NaN
        else:
            for i, post_fix in enumerate(post_fixes):
                extracted_items['{}_{}'.format(item, post_fix)] = row['{}'.format(i + 1)].values[0]

    return extracted_items


def extract_pqr_basic_information(input_data, verbose=False):
    """
    Extracts the basic information items.
    Per item we extract the type, revision and parameter
    The tags are located in column 0, the extracted data in columns 1, 2 and 3

    :param input_data: dataframe of the imported excel sheet
    :param verbose: switches debug mode (default=False)
    :return: dictionary with extracted items
    """

    do_it.do_it_verbose(currentframe(), verbose)

    extracted_items = dict()
    items = get_pqr_basic_items()
    for item, name in items.items():
        row = input_data[input_data['0'] == name]
        if row.empty:
            if verbose:
                print('failed to extract {}'.format(name))
            extracted_items[item] = np.NaN
        else:
            sub_dict = dict()
            sub_dict['value'] = row['1'].values[0]
            if len(row.columns) >= 3:
                sub_dict['revision'] = row['2'].values[0]
                sub_dict['parameter'] = row['3'].values[0]
            else:
                sub_dict['revision'] = np.NaN
                sub_dict['parameter'] = np.NaN

            extracted_items[item] = sub_dict
            extracted_items[item] = row['1'].values[0]
    return extracted_items
