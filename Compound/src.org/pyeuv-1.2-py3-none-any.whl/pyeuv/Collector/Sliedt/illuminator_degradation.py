"""InfluxURLClient.py
Originally created by JBKH
Modified by RWKL to be usable as library by different teams
Date: 2018-07-21
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pyeuv.Collector.Sliedt.illumination_mode import get_mode_map, get_mirror_states  # contains custom illumination mode correction factors per system
from inspect import currentframe  # internal tooling functions
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.Shared.signal_processing import make_monotonically_increasing

# Number of Pupil Facets on the PFM allocated to each Field Facet of the FFM
N_PFM = 5

# Number of Field Facets on the FFM
N_FFM = 336


class degradation_model:
    """
    The model of exponential decay is described by the initial degradation rate
    and the maximum amount of degradation.
    By default it uses the a rate 0f 0.0325%/Gp and the total degradation is
    limited by 15%. The initialization allows the user to modify these two 
    parameters of the model.
    """

    def __init__(self, rate = 0.0325, limit = 0.15):
        self.rate = rate
        self.limit = limit


def calc_transmission(model, pulse_count, verbose=False):
    """
    Empirical estimate of transmission of Pupil Facet as function of exposed 
    gigapulses. Assumes exponential decay.

    :param model: the model parameters to be applied
    :param pulse_count: Pulsecount seen by this pupil facet in Gp
    :param verbose: to switch internal debug info
    :return: the relative transmission of a pupil facet after an amount of Gps 
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return (1.0 - model.limit) + model.limit * np.exp(-pulse_count * model.rate)


def calc_degradation_rate(model, pulse_count, verbose=False):
    """
    The Pupil Facet transmission derivative to gigapulse, ie. degradation rate.

    :param model: the model parameters to be applied
    :param pulse_count: Pulse count seen by this pupil facet in Gp
    :param verbose: to switch internal debug info
    :return: the derivative of the relative transmission of a pupil facet after an amount of Gps
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return -model.limit * model.rate * np.exp(-pulse_count * model.rate)


def get_signal(client, source_nr, input_signals, from_time, to_time, selection='', verbose=False):
    """
    Helper function to load the influx signals and change column names to 
    signal aliases.

    :param client: influx client
    :param source_nr: source number
    :param input_signals: influx signals to be downloaded from influx
    :param from_time: start of window in time domain
    :param to_time: end of window in time domain
    :param selection: optional paramater to append grouping of data
    :param verbose: to switch internal debug info
    :return: pandas dataframe containing requested influx data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signals = [(str(source_nr) + "." + signal + selection) for signal in input_signals[:, 0]]
    df = client.get_signals(
            signals=signals,
            from_time=from_time,
            to_time=to_time
    )

    if len(df) == 0:
        raise Exception("Invalid signal name: %s" % signals)
    if len(df.keys()) < len(input_signals):
        raise Exception("Some singals are not available. {} out of {} available".
                        format(len(df.keys()), len(input_signals)))

    # Replace column names with signal aliases.
    df.columns = input_signals[:, 1]

    return df


def add_mode_names(df, verbose=False):
    """
    Identify the known illumination modes in the dataframe. Makes use of the 
    mapping contained in the mode_map table defined above.
    Return the mode name and the es_correction factor.

    :param df: dataframe containing illumination mode data
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    df['mode_id'] = df['DW_SLIE_FSLIE_PS_doe_id'] * 1e6
    df['mode_id'] += df['DW_SLIE_FSLIE_PS_sigma_inner'] * 1e6
    df['mode_id'] += df['DW_SLIE_FSLIE_PS_sigma_outer'] * 1e3

    # Name "Other" is used for unknown modes
    df['mode_name'] = "Other"

    # Loop through all known mode indicators
    for _id in get_mode_map().keys():
        
        # Check if mode does not use doe_id as indicator
        if not get_mode_map()[_id][4]:
            # Use the mode identification number obtained above
            _filter = df['mode_id'].values == _id
            
        else:
            # Use the doe_id identification
            _filter = df['DW_SLIE_FSLIE_PS_doe_id'].values == _id

        # Update the rows acquired above (contained in _filter) with the
        # corresponding mode name
        df.loc[_filter, 'mode_name'] = get_mode_map()[_id][2]
        df.loc[_filter, 'es_correction'] = get_mode_map()[_id][1]

    df = df.drop(columns=['mode_id'])

    df = df.drop(columns=['DW_SLIE_FSLIE_PS_doe_id',
                          'DW_SLIE_FSLIE_PS_sigma_inner',
                          'DW_SLIE_FSLIE_PS_sigma_outer'])
    
    return df


def load_df(client, source_id, verbose=False):
    """
    Load the signals necessary to estimate the Pupil Facet degradation.

    :param client: influx client
    :param source_id: source id
    :param verbose: to switch internal debug info
    :return: dataframe with all required data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # Define the signal list
    signals = np.array([['Scanner.DW_total_nr_pulses', 'DW_total_nr_pulses'],
                        ['Scanner.DW_SLIE_FSLIE_PS_doe_id', 'DW_SLIE_FSLIE_PS_doe_id'],
                        ['Scanner.DW_SLIE_FSLIE_PS_sigma_inner', 'DW_SLIE_FSLIE_PS_sigma_inner'],
                        ['Scanner.DW_SLIE_FSLIE_PS_sigma_outer', 'DW_SLIE_FSLIE_PS_sigma_outer']])

    df = get_signal(client, source_id, signals, '2000-01-01', '2099-12-30')
    
    print("ok")
    
    return df


def prepare_df(df, verbose=False):
    """
    Prepare the dataframe.

    :param df: pandas dataframe to be prepared
    :param verbose: to switch internal debug info
    :return: dataframe with prepared data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    print("Preparing data... ", end='')
    
    # Convert pulsecount from mp to gp
    df['DW_total_nr_pulses'] = df['DW_total_nr_pulses'].values * 1e-3

    # Interpolate missing pulsecounts
    df['DW_total_nr_pulses'] = df['DW_total_nr_pulses'].interpolate().bfill().ffill()

    # Swap the time index of the dataframe with gigapulses for ease
    df['timestamp'] = df.index
    df = df.set_index('DW_total_nr_pulses')

    # Remove all rows mising mode information
    for col in ['DW_SLIE_FSLIE_PS_doe_id',
                'DW_SLIE_FSLIE_PS_sigma_inner',
                'DW_SLIE_FSLIE_PS_sigma_outer']:
        df = df[~np.isnan(df[col].values)]

    # Correct for drops in cumulative scanner pulsecount: set any drops in count
    # to zero and recalculate the cumulative.
    df.index = make_monotonically_increasing(df.index.values)

    # Identify the illumination modes.
    df = add_mode_names(df)

    # Uncomment to remove sequences of data rows with the same mode (reduces data size)
    # df = df.loc[df['mode_name'].shift(1).values != df['mode_name'].values]

    # Add column to track deltas in gigapulses
    df['dGP'] = np.append(np.diff(df.index.values), 0)

    # For each mode add a column with total cumulative pulsecount for that mode
    for mode in df['mode_name'].unique():
        diff = df['dGP'].values.copy()
        
        # Filter out changes in total gigapulse when other modes are being used 
        diff[df['mode_name'].values != mode] = 0
        
        df[mode] = np.cumsum(diff)

    # Drop the delta gigapulse column
    df = df.drop(columns=['dGP'])
    
    print("ok")
    
    return df

    
def load_PFM_states(verbose=False):
    """
    Load the FF-to-PF mapping per illumination mode from the mirror_states.csv file.

    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    mirror_states = pd.DataFrame.from_dict(get_mirror_states())
    
    # Acquire the dimensions of the map, ie. number of Field Facets by number
    # of known modes    
    _, N_modes = mirror_states.shape

    # Define dict of modes, each containing a two-dimensional array of Field Facets 
    # and corresponding Pupil Facets mirrors. Zero indicates not in use, one 
    # indicates in use. This allows for convenient matrix multiplication.
    PFM_states = {}
    
    # For each known mode:
    for mode in mirror_states.columns:
        
        # Initialize the mirror state map with zeros (none in use)
        mode_state = np.zeros((N_FFM, N_PFM))
        
        # For each Field Facet mirror:
        for FFM in np.arange(N_FFM):
            
            # Acquire the setting of the Field Facet in this illumination mode.
            # It indicates which of the 5 allocated Pupil Facets it is illuminating.
            # If the setting equals to 6, the beam dump is indicated.
            FFM_setting = int(mirror_states.loc[FFM, mode])
                        
            # Set the state of the Pupil Facet mirror corresponding to the
            # setting to 1 (in use).
            if FFM_setting < 6:
                mode_state[FFM, FFM_setting - 1] = 1
                
        PFM_states[mode] = mode_state
        
    return PFM_states


def get_mode_details(mode, verbose=False):
    """
    Returns the values in the mode_map dict given the name of a mode.

    :param mode: name of the mode
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    for known_mode in get_mode_map():
        if(get_mode_map()[known_mode][2] == mode):
            return get_mode_map()[known_mode]

    return None


def get_PFM_map(mode, verbose=False):
    """
    Returns the name of the Pupil Facet map given the name of a mode.
    These are not necessarily the same, hence this function.

    :param mode: name of the mode
    """

    do_it.do_it_verbose(currentframe(), verbose)

    mode_details = get_mode_details(mode)
    if(mode_details is not None):
        return mode_details[3]
    
    return None


def calc_PFM_transmission(df, PFM_states, model = degradation_model(), verbose=False):
    """
    Estimate the transmission of the Pupil Facets (N_FFM * N_PFM) as a function 
    of time using the cumulative gigapulse count per mode and the map of Pupil
    Facet mirrors per mode.
    
    This consists of two consecutive steps:
    1) Obtain the cumulative gigapulse count per Pupil Facet.
    2) Apply the Pupil Facet transmission model.

    :param df: dataframe containing illumination mode data
    :param PFM_states: map of pupil faced mirrors per mode
    :param model: degradation model (default: exponential decay using default parameters)
    :param verbose: to switch internal debug info
    :return: transmission per pupil facet and degradation rate per pupil facet
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # Initialize the mirror usage (ie. cumulative gigapulse count per Pupil Facet)
    # to zero.
    PFM_usage = np.zeros((len(df), N_FFM, N_PFM))

    # Step 1. For each known mode:
    for mode in df['mode_name'].unique():
        
        # Obtain the Pupil Facet mapping for this mode
        PFM_map = get_PFM_map(mode)
        
        # If the map is found:
        if(PFM_map is not None):
            
            # For each timestep:
            for i in np.arange(len(df)):
                
                # Increase the Pupil Facet usages by the cumulative gigapulse count
                # of the mode multiplied by the Pupil Facet states of the mode,
                # indicating which ones are being used.
                PFM_usage[i, :, :] += df[mode].values[i] * PFM_states[PFM_map]

    # Step 2. From the usage per mirror obtain an estimate of the transmission
    # and degradation rate.
    PFM_transmission = calc_transmission(model, PFM_usage)
    PFM_degradation_rate = calc_degradation_rate(model, PFM_usage)
    
    return PFM_transmission, PFM_degradation_rate


def calc_mode_transmission(df, PFM_states, PFM_transmission, verbose=False):
    """
    With the PFM transmission, calculate the mode transmission as a function 
    of time

    :param df: dataframe containing illumination mode data
    :param PFM_states: map of pupil faced mirrors per mode
    :param PFM_transmission: transmission per pupil facet
    :param verbose: to switch internal debug info
    :return: transmission per illumination mode as function of pulsecount of the machine
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # Create a new dataframe with a time index for mode transmission.
    mode_transmission = pd.DataFrame(index=df['timestamp'])

    # For each known mode:
    for mode in df['mode_name'].unique():
        
        # Obtain the Pupil Facet mapping for this mode
        PFM_map = get_PFM_map(mode)
        
        # If the map exists:
        if(PFM_map is not None):
            
            # create a temporary array of transmission for this mode
            transmission = np.zeros(len(df))

            # For each timestep:
            for i in np.arange(len(df)):
                
                # Set the transmission to the average transmission of the used
                # Pupil Facet mirrors.
                transmission[i] = np.sum(PFM_transmission[i, :, :] * PFM_states[PFM_map]) / N_FFM

            # Copy the temporary array into the dataframe
            mode_transmission[mode] = transmission

    return mode_transmission


def calc_mode_degradation(df, mode, PFM_states, PFM_degradation_rate, verbose=False):
    """
    For a specific mode, calculate the current degradation rate. This is 
    normalized to t=0, ie. start of illuminator life.

    :param df: dataframe containing illumination mode data
    :param mode: illumination mode
    :param PFM_states: map of pupil faced mirrors per mode
    :param PFM_degradation_rate: map of degradation rate per pupil faced mirror
    :param verbose: to switch internal debug info
    :return: degradation per mode as function of pulsecount of the machine
    """

    do_it.do_it_verbose(currentframe(), verbose)

    PFM_map = get_PFM_map(mode)    
    
    if PFM_map is not None:
        
        # The mode degradation rate is the average of the current degradation
        # rates of the Pupil Facets being used.
        return np.sum(PFM_degradation_rate[-1, :, :] * PFM_states[PFM_map]) / N_FFM
    else:
        return np.NaN


def calc_illuminator_transmission(df, verbose=False):
    """
    Calculate the transmission of an illuminator as function of time given
    the loaded dataframe.

    :param df: dataframe containing illumination mode data
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # Preprocess the data and identify illumination modes.
    df = prepare_df(df)
    
    # Read the map containing Field Facet to Pupil Facet states per mode
    PFM_states = load_PFM_states()
    
    # Obtain the Pupil Facet transmission and degradation as function of time
    PFM_transmission, PFM_degradation_rate = calc_PFM_transmission(df, 
                                                                   PFM_states, 
                                                                   model = degradation_model())
    
    # Obtain the transmission per known illumination mode as function of time
    mode_transmission = calc_mode_transmission(df, 
                                               PFM_states, 
                                               PFM_transmission)
    
    return mode_transmission, df, PFM_degradation_rate


def plot_mode_usage(df, mode_transmission, verbose=False):
    """
    Extra function to plot the mode usage (ie. cumulative gigapulse count per mode)

    :param df: dataframe containing illumination mode data
    :param mode_transmission: dataframe containing transmission per mode as function of pulsecount of the system
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    f, ax = plt.subplots(figsize=(14,6))
    
    i = 0
    line = '-'
    for mode in mode_transmission:
        if i == 10:
            line='--'
        ax.plot(df.index, df[mode].values, line, label=mode)
        i = i + 1
        
    modes = (set([mode for mode in mode_transmission]) ^ set(df['mode_name'].unique()))
    for mode in modes:
        if i == 10:
            line='--'
        ax.plot(df.index, df[mode].values, line, label=mode)
        i = i + 1
    
    ax.plot(df.index, np.sum(df[df['mode_name'].unique()].values, axis=1), 'k'+line, label="Sum")
    
    ax.set_title("IM mode usage")
    ax.set_ylabel("IM mode pulsecount (gp)")
    ax.legend(loc=2)
    ax.grid(True)


def plot_mode_transmission(df, mode_transmission, verbose=False):
    """
    Extra function to plot the mode transmission, ie. transmission of the known 
    illumination modes normalized to 100% at beginning of illuminator life.

    :param df: dataframe containing illumination mode data
    :param mode_transmission: dataframe containing transmission per mode as function of pulsecount of the system
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    f, ax = plt.subplots(figsize=(14,6))
    i = 0
    line = '-'
    for mode in mode_transmission:
        if i == 10:
            line='--'
        ax.plot(df.index, 100 * mode_transmission[mode].values, line, label=mode)
        i = i + 1
    ax.set_title("IM mode degradation")
    ax.set_ylabel("Transmission (%)")

    ax.legend(loc=3)

    ax.grid(True)


def print_degradation_rates(df, mode_transmission, PFM_degradation_rate, verbose=False):
    """
    Extra function to print the current degradation rates of each known mode,
    normalized to 100% at beginning of illuminator life.

    :param df: dataframe containing illumination mode data
    :param mode_transmission: dataframe containing transmission per mode as function of pulsecount of the system
    :param PFM_degradation_rate: dataframe containing degradation rate per mode as function of pulsecount of the system
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    for mode in mode_transmission:
        print("%s: %.3f %%/gp" % (mode, 100 * calc_mode_degradation(df, mode, load_PFM_states(), PFM_degradation_rate)))


def get_pf_transmission_data(client, source_id, verbose=False):
    """
    Get the pupil facet transmission data

    :param client: connection to influx
    :param source_id: the source_id for which the pupil facet degradation has to be estimated
    :param verbose: to switch internal debug info
    :return: dataframe containing input data to calculate transmission per illumination mode
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # load the required data
    df = load_df(client, source_id)

    return df


def calculate_pf_transmission(df, verbose=False):
    """
    calculate the pupil facet transmission.
    The illuminator degradation library is used for this calculation.
    It is based on the model assuming exponential decay proposed by JHAG

    :param df: dataframe containing input data to calculate transmission per illumination mode
    :param verbose: to switch internal debug info
    :return: dataframe containing transmission per illumination mode
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # the transmission per illumination mode over time
    mode_transmission, df, PFM_degradation_rate = calc_illuminator_transmission(df)

    return mode_transmission


def get_pf_transmission(client, source_id, verbose=False):
    """
    Get the pupil facet transmission.
    The illuminator degradation library is used for this calculation.
    It is based on the model assuming exponential decay proposed by JHAG

    :param client: connection to influx
    :param source_id: the source_id for which the pupil facet degradation has to be estimated
    :param verbose: to switch internal debug info
    :return: dataframe containing transmission per illumination mode
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # load the required data
    df = get_pf_transmission_data(client, source_id, verbose=verbose)

    # the transmission per illumination mode over time
    mode_transmission = calculate_pf_transmission(df, verbose=verbose)

    return mode_transmission