"""
es_ratio.py
Authors: DANT
Date:  2020-06-08

Ownership: SF-18 (FC-079, FC-086)

Code is based on ES-ratio from EUVDB
ES-ratio calculations including filtering and corrections.

Change history:
Date       | Author | Feature
-----------+--------+------------------------------------------------------------------------------------------------
2020-06-12 | DANT   | SSPT-564-collector-reflectivity-slie-dt-pyeuv-create-function-for-es_ratio_norm
2020-09-07 | DANT   | bugfix/SSPT-599-fix-bug-in-filter_dose_target_at_slie-function


"""

from inspect import currentframe
import pandas as pd

from pyeuv.Collector.Sliedt.sliedt_io import get_ecal_signal_names, get_illumination_mode_names, \
    get_scanner_signal_names
from pyeuv.Collector.Sliedt.sliedt import apply_threshold_filter, apply_normalization
from pyeuv.Collector.Sliedt.illuminator_degradation import add_mode_names
from pyeuv.Do_It import do_it_library as do_it


def get_es_ratio_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required data from InfluxDB:

        **ecal** =>> factor between source side sensors and scanner ES sensors

        - RT12.ECALextSensorFactor,
        - RT12.ECALextSensorFactorRatio,

        **scanner** =>> Illumination pupil shape data in order to later on retrieve the scanner ES transmission
                        correction data

        - Scanner.DW_SLIE_FSLIE_PS_doe_id,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_inner,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_outer,

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')
    signals = dict()

    try:
        df = client.get_signals_dict(get_ecal_signal_names(), source_id, from_time, to_time)

        if df.empty:
            signals['ecal'] = pd.DataFrame(columns=get_ecal_signal_names().keys())
        else:
            signals['ecal'] = df

        df = client.get_signals_dict(get_illumination_mode_names(), source_id, from_time, to_time)

        if df.empty:
            signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())
        else:
            signals['scanner'] = df

    except Exception as e:
        print('Error:', e)
        signals['ecal'] = pd.DataFrame(columns=get_ecal_signal_names().keys())
        signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def prepare_es_ratio(data, verbose=False):
    """
    Prepare the dataframe. Function that merges dataframes of ecal and es_transmission.
    The forward filling of the es_transmission

    :param data: dataframe containing es ratio input data
    :param verbose: to switch internal debug info
    :return: dataframe with prepared data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    print("Retrieving data... ", end='')
    es_transmission = add_mode_names(data['scanner'])

    print("Preparing data... ", end='')
    data = pd.DataFrame(data['ecal']).copy()
    data = pd.concat([data, es_transmission], axis=1)

    data.sort_index(inplace=True)
    data['mode_name'] = data['mode_name'].ffill()
    data['es_correction'] = data['es_correction'].ffill()
    data.drop(columns=['DW_SLIE_FSLIE_PS_im_mode'], inplace=True)
    data.dropna(inplace=True)

    print("ES-ratio data prepared. ", end='')

    return data


def get_es_ratio(data, verbose=False):
    """
    Function that calculates 'es_ratio_transmission_corrected'

    :param data: dataframe containing ecal data
    :param verbose: to switch internal debug info
    :return: dataframe containing ecal and es_transmission data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    data['es_ratio_transmission_corrected'] = 1.0 / (data['ecal_sensor_factor'] * data['es_correction'])
    data.dropna(inplace=True)

    if data.empty:
        if verbose:
            print("No es_ratio_transmission_corrected after combining ES-ratio and ES Transmission correction data.")

    data.drop(columns='ecal_sensor_factor', inplace=True)

    return data


def get_es_normalization_factor(data, quantile=0.99, verbose=False):
    """
    Determines the normalization factor required to normalize ES-ratio to 100%
    The normalization is based on the 99th (optional parameter) percentile

    :param data: dataframe containing es_ratio data
    :param quantile: the quantile to be used on the data to determine the maximum.
                     This quantile is used to normalize on the bulk, instead of a single outlier
    :param verbose: to switch internal debug info
    :return: the normalization factor for ES-ratio
    """

    do_it.do_it_verbose(currentframe(), verbose)
    if data.empty:
        # nothing to be done
        es_normalization_factor = 1.0

    else:
        try:
            value_to_normalize = data.quantile(quantile)['es_ratio_transmission_corrected']
            es_normalization_factor = 100.0 / value_to_normalize
            if verbose:
                print('{} data points used for es-ratio normalization. level = {:.2f}'
                      .format(len(data), value_to_normalize))
        except Exception as e:
            raise Exception('in get_es_normalization_factor:', e)

    return es_normalization_factor


def apply_es_normalization_clip(data, clip=100.0, verbose=False):
    """
    Clip 'es_ratio_norm' to max 100%

    :param data: dataframe containing es_ratio_norm
    :param clip: clip factor (default = 100%)
    :param verbose: to switch internal debug info
    :return: the dataframe with the normalized and cliped ES-Ratio
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        temp = data[(data['es_ratio_norm']) >= clip]
        data.loc[data['es_ratio_norm'] > clip, 'es_ratio_norm'] = clip
        if verbose:
            print('{} es_ratio_norm data points above clip level. Clipped to {}%'.format(
                len(temp), clip))

    except Exception as e:
        raise Exception('in apply_es_normalization_clip:', e)

    return data


def calculate_es_ratio(data, threshold_es_ratio_lower=300.0, threshold_es_ratio_upper=5000.0,
                       quantile=0.99,
                       clip=100.0,
                       verbose=False):
    """
        1. Get the ECAL and Scanner data
        2. Get the ES transmission correction based on the Illumination mode
        3. Combine data from previous steps, interpolate and filter out the custom modes (PS_im_mode > 0 as 0=custom mode)
        4. Calculates the ES-ratio corrected per illumonation mode transmission; output signal =>> es_ratio_transmission_corrected
        5. Apply range filter
        6. Find the max of ES ratio within this collector by using the 99th percentile method
        7. clip the 'es-ratio' to max 100% =>> es_ratio_norm

    Function to calculate the 'es_ratio_transmission_corrected' and 'es_ratio_norm' based on a dictionary of
    dataframes (dataframe per signal group)
    It includes:
     - correction: illumination mode transmission
     - filtering: threshold filtering
     - calculates the 'es_ratio_transmission_corrected'
     - and 'es_ratio_norm' which is the normalized ES-ratio and also clipped to max 100%
    Input signals: dictionary containing dataframes of data per signal group. Expected groups and signals are:
        **ecal**
        - RT12.ECALextSensorFactor,
        - RT12.ECALextSensorFactorRatio,

        **scanner**
        - Scanner.DW_SLIE_FSLIE_PS_doe_id,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_inner,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_outer

    :param data: dictionary containing dataframes of data per signal group. Expected groups and signals are:

        **ecal**

        - RT12.ECALextSensorFactor,
        - RT12.ECALextSensorFactorRatio,

        **scanner**

        - Scanner.DW_SLIE_FSLIE_PS_doe_id,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_inner,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_outer,

    :param threshold_es_ratio_lower: lower threshold for es-ratio (default=300.0)
    :param threshold_es_ratio_upper: upper threshold for es-ratio (default=5000.0)
    :param quantile: the quantile to be used on the data to determine the maximum.
                 This quantile is used to normalize on the bulk, instead of a single outlier (default=0.99)
    :param clip: clipping factor of the normalized es-ratio (default=100%)
    :param verbose: to switch internal debug info
    :return: dataframe with 'es_ratio_transmission_corrected' and 'es_ratio_norm'
    """

    do_it.do_it_verbose(currentframe(), verbose)

    t0 = pd.Timestamp('now')

    # Prepare the relevant ES-ratio data
    data = prepare_es_ratio(data, verbose=verbose)

    # Calculate the ES_Ratio_Transmission_Corrected
    data = get_es_ratio(data, verbose=verbose)

    # Apply threshold filter on the ES_Ratio_Transmission_Corrected
    data = apply_threshold_filter(data, 'es_ratio_transmission_corrected',
                                  threshold_es_ratio_lower, threshold_es_ratio_upper, verbose=verbose)

    # Get and apply the ES-ratio normalization factor
    es_normalization_factor = get_es_normalization_factor(data, quantile=quantile, verbose=verbose)
    # Rename column to be able to make use of common function "apply_normalization"
    data.rename(columns={'es_ratio_transmission_corrected': 'es_ratio'}, inplace=True)
    data = apply_normalization(data, 'es_ratio', es_normalization_factor, verbose=verbose)

    # Correct all ES-ratio data above clip level to the set clipping level
    data = apply_es_normalization_clip(data, clip=clip, verbose=verbose)

    # Remove the supporting data
    data.drop(columns=['es_correction', 'mode_name', 'ecal_sensor_factor_ratio'], inplace=True)

    duration = pd.Timestamp('now') - t0
    print('\nES-ratio Norm calculated in {:.2f} seconds\n'.format(duration.microseconds * 1e-6))

    return data
