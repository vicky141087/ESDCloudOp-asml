# -*- coding: utf-8 -*-
"""
sliedt.py
Authors: RWKL
Date:  2018-09-21

Ownership: SF-18 (FC-079, FC-086)

Code is based on SLIE/DT from Grafana
SLIE/DT calculation including filters and corrections that can optionally be turned on and off

Change history:
Date       | Author | Feature
-----------+--------+------------------------------------------------------------------------------------------------
2020-09-07 | DANT   | bugfix/SSPT-599-fix-bug-in-filter_dose_target_at_slie-function


"""

import pandas as pd
import numpy as np
import pyeuv.Shared.smoothing_algorithms as smoothers
import pyeuv.Shared.signal_processing as signal_processing
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from pyeuv.Shared.signal_processing import make_monotonically_increasing
from inspect import currentframe  # internal tooling functions

from pyeuv.Collector.Sliedt.illuminator_degradation import calculate_pf_transmission
from pyeuv.Collector.Sliedt.sliedt_io import get_illumination_mode_corrections


def get_collector_pulse_count(pulse_count_cumm, verbose=False):
    """
    Function to determine the collector pulse count, based on the collector pulsecount
    It assumes the cummulative pulse count from the start of the collector

    :param pulse_count_cumm: dataframe containing the cummulative pulse count in Mp from the start of a collector onwards
    :param verbose: to switch internal debug info
    :return: dataframe containing the cummulative pulse count and collector pulse count in Gp
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # Filter out wrong pulse counts
    pulse_count_cumm = pd.DataFrame(pulse_count_cumm)
    pulse_count = pulse_count_cumm[pulse_count_cumm['pulse_count_cumm'] > 0]

    if not pulse_count.empty:
        # From scanner mega pulses to collector giga pulses
        pulse_count['pulse_count_cumm'] *= 1e-3
        offset = pulse_count.loc[pulse_count.index[0], 'pulse_count_cumm']
        pulse_count['pulse_count'] = pulse_count['pulse_count_cumm'] - offset
        pulse_count['pulse_count'] = make_monotonically_increasing(pulse_count['pulse_count'].values)
    else:
        # No cumulative pulse count found
        pulse_count['pulse_count'] = []

    return pulse_count


def add_pulse_count_to_data(data, pulse_count, verbose=False):
    """
    Short function merging pulse count data into another dataframe.
    The pulse count data is linearly interpolated in time domain to the

    :param data: the dataframe we are working with
    :param pulse_count: dataframe containing pulse_count data
        (multiple columns allowed (collector and cummulative pulse_count))
    :param verbose: to switch internal debug info
    :return: Dataframe containing the original data and the pulse count columns merged into it
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        result = pd.DataFrame(data).join(pulse_count, how='outer')
        for key in pulse_count.keys():
            # both pulse_count and pulse_count_cumm
            result[key] = result[key].interpolate()
        result.dropna(inplace=True)
    except Exception as e:
        raise Exception('in add_pulse_count_to_data:', e)

    return result


def get_normalization_factor(data, window=5.0, quantile=0.99, verbose=False):
    """
    Determines the normalization factor requered to normalize SLIE/DT to 100%
    The normalization is based on the 99th (optional parameter) percentile within a window
    in the Gp domain at the start of the data

    :param data: dataframe containing slie_dt and pulse_count
    :param window: window in Gp at start of the data used to determine the normalization factor (default: 5.0)
    :param quantile: the quantile to be used on the data to determine the maximum.
                     This quantile is used to normalize on the bulk, instead of a single outlier
    :param verbose: to switch internal debug info
    :return: the normalization factor for SLIE/DT
    """

    do_it.do_it_verbose(currentframe(), verbose)
    if data.empty:
        # nothing to be done
        normalization_factor = 1.0

    else:
        try:
            reference = data.loc[data.pulse_count < data.pulse_count[0] + window, 'slie_dt']
            value_to_normalize = reference.quantile(quantile)
            normalization_factor = 100.0 / value_to_normalize
            if verbose:
                print('{} data points used for normalization. level = {:.2f}'.format(
                    len(reference), value_to_normalize))

        except Exception as e:
            raise Exception('in get_normalization_factor:', e)

    return normalization_factor


def apply_normalization(data, key, factor, verbose=False):
    """
    Normalizes slie_dt and adds it as a new column to the original dataframe

    :param data: dataframe containing slie_dt
    :param key: column name in the data to be used in this function
    :param factor: normalization factor
    :param verbose: to switch internal debug info
    :return: the dataframe including an additional column with the normalized SLIE/DT
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        data['{}_norm'.format(key)] = data[key] * factor

    except Exception as e:
        raise Exception('in apply_normalization:', e)

    return data


def apply_ecal_ratio_correction(data, slie_key, ecal, verbose=False):
    """
    The slie data is corrected for the ecal measurement.
    Ecal refresh is only actuated when the deviation is >1%. The deviation is
    represented in ecal_sensor_factor_ratio. After the ecal refresh, the ratio
    is back to a value close to 1, after which it will start to deviate, until the next
    ecal refresh will take place.

    The first ecal sensor factor ratio data point after the refresh is untrustworthy,
    and should in theory be 1. This is corrected in the data, before being applied to slie

    :param data: slie dataframe
    :param slie_key: the column name within dataframe refering to the slie data
    :param ecal: ecal dataframe, containing columns for ecal_sensor_factor and ecal_sensor_factor_ratio
    :param verbose: to switch internal debug info
    :return: dataframe with column dw_slie
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # At ecal refreshes, ecal_sensor_factor_ratio contains incorrect values
    # find ecal refreshes
    ecal['ecal_refresh'] = ecal['ecal_sensor_factor'].diff() != 0
    # correct ecal_sensor_factor_ratio to 1
    ecal.loc[ecal['ecal_refresh'], 'ecal_sensor_factor_ratio'] = 1.0

    # merge data
    result = data.join(ecal['ecal_sensor_factor_ratio'], how='outer')
    if not result.empty and np.isnan(result.loc[result.index[0], 'ecal_sensor_factor_ratio']):
        # avoid losing data when ecal is missing at the start of the dataframe
        result.loc[result.index[0], 'ecal_sensor_factor_ratio'] = 1.0

    result['ecal_sensor_factor_ratio'] = result['ecal_sensor_factor_ratio'].ffill()

    result.dropna(subset=[slie_key], inplace=True)

    tmp0 = len(result)
    # filter for invalid values of ecal_sensor_factor_ratio
    result = result[(result['ecal_sensor_factor_ratio'] > 0.98) &
                    (result['ecal_sensor_factor_ratio'] < 1.02)]
    tmp1 = len(result)
    print('Losing {} data points ({}%) after ecal ratio correction'.format(
        tmp0 - tmp1, 0 if tmp0 == 0 else (tmp0 - tmp1) / tmp0 * 100.0))

    # apply correction
    result[slie_key] = result[slie_key] / result['ecal_sensor_factor_ratio']

    return result[data.keys()]


def apply_artifact_correction(data, key, artifact_corrections, verbose=False):
    """
    the slie data is corrected for artificial jumps, such as
    - insertion of a membrane (or replacement)
    - g-mirror swap
    - other upgrades / changes in the optical path

    To correct for the artifact, the slie has to be multiplied by a factor
    slie_artifact_corrections contains a time series of corrections, which are the valid
    factors from the timestamp of the entry until the next entry or end of collector

    Another possibility is to correct the SLIE/DT ratio by multiplying it with a factor
    sliedt_artefact. It also contains a time series of corrections.

    TODO: replace this by a signal that contains the correction factor and description
    Example:
    Replacing a membrane of type 3 to type 4 should be 2 entries:
    - removal: factor = 1/0.88 (assuming a spec of 12% loss by the membrane type 3)
    - insertion: factor = 0.9 (assuming a spec of 10% loss by the membrane type 4)
    The effective correction at time t should be the product of all corrections before t
    The description could be used to annotate graphs.

    :param data: dataframe containing slie as first (and only) column
    :param key: column name in the data to be used in this function
    :param artifact_corrections: dataframe containing start times for correction factors to be applied
    :param verbose: to switch internal debug info
    :return: returns the dataframe with the corrected value for slie
    """

    do_it.do_it_verbose(currentframe(), verbose)

    key_correction = artifact_corrections.keys()[0]
    result = data.join(artifact_corrections, how='outer')

    if not result.empty and np.isnan(result.loc[result.index[0], key_correction]):
        result.loc[result.index[0], key_correction] = 1.0

    result[key_correction] = result[key_correction].ffill()
    result = result.dropna()

    result[key] = result[key] * result[key_correction]

    return result[data.keys()]


def calculate_rolling_median(data, window=31, verbose=False):
    """
    Adds a column with the rolling median of slie_dt

    :param data: dataframe containing slie_dt
    :param window: number of datapoints used for the rolling median, typically an odd number (default=31)
    :param verbose: to switch internal debug info
    :return: dataframe with an additional column for the rolling median of the slie/dt
    """

    do_it.do_it_verbose(currentframe(), verbose)

    data['slie_dt_median'] = data['slie_dt'].rolling(window=window, min_periods=1, center=True).median()
    return data


def apply_rolling_median_filter(data, ratio=0.05, verbose=False):
    """
    Applies a rolling median filter to the slie_dt,
    The filter is applies on all the data points of slie_dt deviates for which
    the data point deviates more than ratio from the rolling median.
    First a copy of the slie_dt_norm values are stored as slie_dt_no_filter
    Then, the filter is applied by setting the filtered values to NaN.

    :param data: dataframe containing the normalized slie/dt and rolling median
    :param ratio: maximum relative deviation considered ok. Data set to np.NaN for larger deviation (default=0.05)
    :param verbose: to switch internal debug info
    :return: dataframe with an additional column for the slie_dt before filtering
    """

    do_it.do_it_verbose(currentframe(), verbose)

    data['slie_dt_no_filter'] = data['slie_dt']
    data.loc[((data['slie_dt'] - data['slie_dt_median']) /
             data['slie_dt_median']).abs() > ratio, 'slie_dt'] = np.NaN

    return data


def calculate_sg_filter(data, window=31, verbose=False):
    """
    Applies the Savitsky Golay filter on slie_dt_norm and stores it as slie_dt_norm_sg

    :param data: dataframe containing the normalized slie/dt
    :param window: number of datapoints used for the Savitsky Golay filter,
        typically an odd number (default=31)
    :param verbose: to switch internal debug info
    :return: dataframe with the additional column slie_dt_sg_norm
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # the sg filter needs data without NaN.
    # make a temporary variable for the slie_dt_norm data without nan
    data_no_nan = data.dropna(subset=['slie_dt_norm']).copy()
    if data_no_nan.empty or len(data_no_nan) < window:
        data['slie_dt_norm_sg'] = np.NaN
        result = data
    else:
        data_no_nan['slie_dt_norm_sg'] = smoothers.savitzky_golay(data_no_nan.slie_dt_norm, window, 3)
        # merge the sg filtered data in
        result = data.join(data_no_nan.slie_dt_norm_sg, how='outer')

    return result


def filter_dose_target_at_slie(dt, data, use_dt_of_slie_measurement=True, verbose=False):
    """
    This function filters the dose target (RT05) signal at the time of when SLIE was measured but with a max time offset
    of 1 second into the future (to prevent a not relevant point is selected)

    :param dt: dataframe containing dose target data
    :param data: dataframe containing dw_slie data
    :param use_dt_of_slie_measurement: method to select the DT used for the SLIE measurement (default: True),
    :param verbose: to switch internal debugging info
    :return: dataframe containing dose target at slie measurement time
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # Get only the dw_slie data
    data_slie = data.dropna(subset=['dw_slie']).copy()
    # Merge the dose_target and dw_slie data
    dt = dt.join(data_slie['dw_slie'], how='outer')

    if use_dt_of_slie_measurement:
        # create helper column with time delta between dw_slie and dose_target
        dt['time_delta'] = dt.index.to_series(keep_tz=True).diff().shift(-1).dt.total_seconds()
        # find 1st dose_target value after the dw_slie with a max time delta (default = 1 sec)
        # step 1: check if time_delta is smaller than 1 second
        # step 2: if true check if dw_slie is not null (there should be a value present)
        # step 3: if true shift the dose_target value 1 row up so that it's at the same row as the dw_slie.
        #         Now also check if the dose_target is not null (there should be a value present)
        # step 4: if all previous conditions are fullfilled store the new 'dose_target' at the timestamp of dw_slie
        max_time_delay = 1.0
        dt = dt.shift(-1)[(dt['time_delta'] < max_time_delay) &
                          (dt['dw_slie'].notnull()) &
                          (dt['dose_target'].shift(-1).notnull())]

        # rename 'dose_target' as the new 'dose_target_at_slie' signal
        dt.rename(columns={'dose_target': 'dose_target_at_slie'}, inplace=True)
        # remove the helper columns
        dt.drop(columns=['time_delta', 'dw_slie'], inplace=True)

    result = dt

    return result


def get_slie_dt(slie, dt, verbose=False):
    """
    Function that calculates slie/dt by merging dataframes of slie and dose target.
    The forward filling of the dose target is limited to 1 row
    to avoid incorrect dose target values used in case of missing data

    :param slie: dataframe containing slie data
    :param dt: dataframe containing dose target data
    :param verbose: to switch internal debug info
    :return: dataframe containing slie and slie/dt data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    result = slie.join(dt, how='outer')
    result['dose_target_at_slie'] = result['dose_target_at_slie'].ffill(limit=1)
    result.dropna(inplace=True)

    result['slie_dt'] = result['dw_slie'] / result['dose_target_at_slie']
    result.dropna(inplace=True)

    if result.empty:
        if verbose:
            print("No SLIE/DT after combining SLIE and DT data")

    result.rename(columns={'dose_target_at_slie': 'dose_target'}, inplace=True)

    return result


def apply_filter(data, fltr, verbose=False):
    """
    Filters data based on the provided filter.
    The filter is merged into data, and forward filled since the timestamps of
    the data and filter do not coincide.

    :param data: dataframe containing one column with the filter to be applied
    :param fltr: timebased filter to be applied
    :param verbose: to switch internal debug info
    :return: dataframe after filtering out using the provided filter
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if fltr.empty:
        # nothing to filter
        result = data.dropna()
    else:
        fltr_key = fltr.keys()[0]
        result = pd.DataFrame(data).join(fltr, how='outer')
        result[fltr_key] = result[fltr_key].ffill()

        result = result.dropna()
        result = result[result[fltr_key]]

    return result[data.keys()]


def apply_threshold_filter(data, key, lower_threshold=-np.Inf, upper_threshold=-np.Inf, verbose=False):
    """
    Function to apply a simple threshold filter

    :param data: dataframe to be filtered
    :param key: key in data to be used to apply the filter
    :param lower_threshold: lower threshold (default=-inf)
    :param upper_threshold: upper threshold (default=inf)
    :param verbose: to switch internal debug info
    :return: Dataframe after filtering
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        result = data[(data[key] >= lower_threshold) & (data[key] <= upper_threshold)]
    except Exception as e:
        print('Error:', e)
        result = data
    return result


def apply_uniformity_refresh_filter(data, verbose=False):
    """
    Uniformity Refresh filtering
    SLIE measurements are performed in pairs.
    The first is with the LULU calibrated finger positions, so more honest SLIE measurement
    The second is with the fingers positions such that uniformity is improved, blocking some light
    The first of the 2 successive measurements is used

    :param data: dataframe containing a time series of slie data
    :return: slie measurements with LULU calibrated finger positions
    :param verbose: to switch internal debug info
    :rtype: pandas dataframe
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # diff takes the delta with the previous row.
    # so shift one row up to get the timedelta with to the next datapoint.
    data['time_delta'] = data.index.to_series().diff().shift(-1).dt.total_seconds()
    data.dropna(inplace=True)

    # Take the first of two successive datapoints. Assume:
    # 2 successive measurements are within 10 seconds,
    # and a wafer always takes more then 10 seconds.
    data = data[data['time_delta'] < 10]
    data.drop(columns=['time_delta'], inplace=True)
    data.dropna(inplace=True)

    return data


def apply_illumination_mode_correction(data, key, illumination_modes, correction_factors, verbose=False):
    """
    Apply corrections for efficiency of different illumination modes.
    This correction is only performed when the illumination mode is provided and known.
    Otherwise, the slie data will be ignored

    :param data: dataframe containing slie
    :param key: column name of slie data
    :param illumination_modes: dataframe containing illumination mode information
    :param correction_factors: dictionary containing correction factors for standard illumination modes
    :param verbose: to switch internal debug info
    :return: dataframe containing corrected slie dataand the illumination mode for known illumination modes only
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        illumination_modes['ill_mode_id'] = illumination_modes['doe_id'] * 1000000 + \
                                           illumination_modes['sigma_inner'] * 1000000 + \
                                           illumination_modes['sigma_outer'] * 1000

    except Exception as e:
        print('Error:', e)

    # pop* modes used by illumination team on in-house systems
    fltr = (illumination_modes['doe_id'] >= 20000) & (illumination_modes['doe_id'] <= 20010)
    illumination_modes.loc[fltr, 'ill_mode_id'] = illumination_modes.loc[fltr, 'doe_id']

    # add the illumination mode name
    illumination_modes['ill_mode_name'] = illumination_modes['ill_mode_id'].\
        apply(lambda x: correction_factors[x][2] if x in correction_factors else np.NaN)
    # add the correction for the illumination mode
    illumination_modes['ill_mode_transmission'] = illumination_modes['ill_mode_id'].\
        apply(lambda x: correction_factors[x][0] if x in correction_factors else np.NaN)

    # merge with data
    ill_signals = ['ill_mode_name', 'ill_mode_transmission']

    result = data.join(illumination_modes[ill_signals], how='outer')
    ill_signals.append(key)
    result.dropna(subset=ill_signals, inplace=True)
    if result.empty and verbose:
        print("No SLIE info after custom mode filtering")

    result[key] = result[key] / result['ill_mode_transmission']

    return result


def apply_pf_degradation_correction(data, slie_key, pf_transmission, verbose=False):
    """
    Corrects slie for pupil facet degradation

    :param data: dataframe containing slie
    :param slie_key: column name of the slie data
    :param pf_transmission: dataframe containing transmission (1 - loss) per illumination mode over time
    :param verbose: to switch internal debug info
    :return: dataframe with slie corrected for illumination mode degradation and column
             containing the relative transmission per illumination mode
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # merge pf_transmission
    result = data.join(pf_transmission, how='outer')
    for key in pf_transmission.keys():
        result[key] = result[key].interpolate()
    result.dropna(inplace=True)

    # correct dw_slie
    result['pf_transmission_loss'] = np.NaN
    for illmode in result['ill_mode_name'].unique():
        curmode = result['ill_mode_name'] == illmode

        result.loc[curmode, slie_key] = result.loc[curmode, slie_key] / result.loc[curmode, illmode]
        result.loc[curmode, 'pf_transmission_loss'] = result.loc[curmode, illmode]

    # remove pf_transmission columns
    result = result.drop(columns=pf_transmission.keys())

    result.dropna(inplace=True)

    return result


def build_valid_measurement_filter(filter_signals, sv_gate, verbose=False):
    """
    Function to build filter. It combines several filter signals and uses the default values in case
    filter data is unavailable

    :param filter_signals: signals from the filter signal group
    :type: dataframe
    :param sv_gate: scanner gate signal (1 means open)
    :type: dataframe
    :param verbose: to switch internal debug info
    :return: dataframe with True/False filter signal
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # default filter state in case data is missing
    default_filter_values = dict([('sv_gate', 1),
                                  ('lot_signal', 0),
                                  ('manual_block_collector', 0)])

    slie_filter = filter_signals.join(sv_gate, how='outer')

    # in case data is missing at all, fill with default value
    for key in default_filter_values:
        if key not in slie_filter.keys():
            slie_filter[key] = default_filter_values[key]

    # in case first datapoint is nan, fill it with the default value
    if not slie_filter.empty:
        for signal in slie_filter.keys():
            if np.isnan(slie_filter.loc[slie_filter.index[0], signal]) & (signal in default_filter_values.keys()):
                slie_filter.loc[slie_filter.index[0], signal] = default_filter_values[signal]

    slie_filter.fillna(method='ffill', inplace=True)
    slie_filter.dropna(inplace=True)

    # enabled during lot_signal, when scanner_valve is open, not during manual_block_collector
    slie_filter['filter'] = False
    slie_filter.loc[(slie_filter['lot_signal'] != 0) &
                    (slie_filter['sv_gate'] != 0) &
                    (slie_filter['manual_block_collector'] != 1),
                    'filter'] = True

    return pd.DataFrame(slie_filter['filter'])


def calculate_degradation_rate(df, key, windows=[1.0, 3.0, 5.0, 20.0], post_fix='',
                               previous_only=True, advanced_analysis=False, verbose=False):
    """
    Calculates the overall degradation rate as well as the rate and confidence interval for different pulse count
    windows of a given signal. A window of x has at least a range of x pulsecounts, so the data point in that window
    is at least x (max - min >= x)

    :param df: input dataframe containing a column 'pulse_count' (in Gp) and key
    :param key: key of the signal for which the rate is calculated
    :param windows: list of pulse count windows (in Gp) to be calculated (default: [1.0, 3.0, 5.0, 20.0])
    :param post_fix: in case one needs to add a postfix to the created degradation rate signals, for instance '_nonSG',
        one can use this post_fix (default: '')
    :param previous_only: when true calculates only the previous x Gp window (default) and skips the
        centered x Gp window (less relevant for Grafana dashboards). False calculates both.
    :param advanced_analysis: when true calculate linear fit including the confidence interval and adjusted R squared.
        Otherwise only the linear fit slope (faster calculation)
    :param verbose: to switch internal debug info
    :return: dataframe containing the original signals and degradation rates.
    """

    from pyeuv.Shared.signal_processing import calculate_linear_fit

    do_it.do_it_verbose(currentframe(), verbose)

    # create helper columns, to easily select the rows including the first row that is >= x Gp from the current row
    # without, this, the 5 Gp window would in fact be <5 Gp, where the functional requirement is a fit of at least 5 Gp.
    pc = 'pulse_count'

    result = df.dropna()

    result[pc + '_up'] = result[pc].shift(-1)
    result[pc + '_down'] = result[pc].shift(1)

    for i, row in result.iterrows():
        overall_degradation_rate = (100.0 - result[key][i]) / result[pc][i]
        result.loc[i, 'overall_degradation_rate{}'.format(post_fix)] = overall_degradation_rate
        for window in [window for window in windows]:
            # filter data for previous x Gp window
            tmp = result[(result[pc] <= row[pc]) & (result['{}_up'.format(pc)] >= (row[pc] - window))]

            if tmp[pc].max() - tmp[pc].min() > window:
                linear_fit = calculate_linear_fit(tmp[pc], tmp[key], round_to_significant_digit=False,
                                                  advanced_analysis=advanced_analysis)
                slope, offset, confidence_interval, adjusted_r_squared = linear_fit
                result.loc[i, 'degradation_rate_previous_{}Gp{}'.format(window, post_fix)] = slope
                result.loc[i, 'degradation_rate_previous_{}Gp_confidence_interval{}'.format(window, post_fix)] = \
                    confidence_interval

            if not previous_only:
                # filter data for centered x Gp window
                tmp = result[(result['{}_down'.format(pc)] <= row[pc] + 0.5 * window) &
                             (result['{}_up'.format(pc)] >= row[pc] - 0.5 * window)]

                if ((tmp[pc].max() - row[pc] >= 0.5 * window) &
                        (row[pc] - tmp[pc].min() >= 0.5 * window)):
                    # valid if at least half the window is available in both the past and future of the current row
                    linear_fit = calculate_linear_fit(tmp[pc], tmp[key], round_to_significant_digit=False,
                                                      advanced_analysis=advanced_analysis)
                    slope, offset, confidence_interval, adjusted_r_squared = linear_fit
                    result.loc[i, 'degradation_rate_centered_{}Gp{}'.format(window, post_fix)] = slope
                    result.loc[i, 'degradation_rate_centered_{}Gp_confidence_interval{}'.format(window, post_fix)] = \
                        confidence_interval

    # remove the helper columns
    result.drop(columns=['{}_up'.format(pc), '{}_down'.format(pc)], inplace=True)

    return result


def calculate_slie_dt(slie_data,
                      use_ecal_ratio_correction=True,
                      use_pf_degradation_correction=False,
                      use_dt_of_slie_measurement=True,
                      threshold_slie_lower=100.0, threshold_slie_upper=23000.0,
                      threshold_sliedt_lower=10.0, threshold_sliedt_upper=500.0,
                      threshold_dose_lower=5.0, threshold_dose_upper=100.0,
                      window_normalization=5.0, window_sg=31,
                      window_median=31, margin_median_filter=0.05, verbose=False):
    """
    Function to calculate slie_dt and supporting signals (normalized signals, illumination mode, etc),
    based on a dictionary of dataframes (dataframe per signal group)
    It includes:

    - filtering: lot filter, uniformity refresh, threshold,
    - corrections: illumination mode, artefacts, ecal_ratio
    - determining the collector pulse count (should it be extracted? required for normalization)
    - normalized slie/dt calculation

    :param slie_data: dictionary containing dataframes of data per signal group. Expected groups and signals are:

        **collector**

        - Collector._NormalizationCorrection

        **dose**

        - RT05.BDenergyTargetAvg

        **ecal**

        - RT12.ECALextSensorFactor,
        - RT12.ECALextSensorFactorRatio,

        **filter**

        - Filter._LotSignal,
        - Filter._ManualBlockCollector,

        **pf_transmission**

        - dataframe with transmission per known illumination mode

        **scanner**

        - Scanner.DW_SLIE,
        - Scanner.DW_total_nr_pulses,
        - Scanner.DW_SLIE_FSLIE_PS_doe_id,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_inner,
        - Scanner.DW_SLIE_FSLIE_PS_sigma_outer,
        - Scanner.DW_SV_state

    :param use_ecal_ratio_correction: switch for the correction to SLIE using ECALextSensorFactorRatio (default=True)
    :param use_pf_degradation_correction: switch for the correction of pf degradation,
           using a model assuming exponential decay as function of usage (default=True)
    :param use_dt_of_slie_measurement: method to select the DT used for the SLIE measurement (default: False),
    :param threshold_slie_lower: lower threshold for slie (default=100.0)
    :param threshold_slie_upper: upper threshold for slie (default=15000.0)
    :param threshold_sliedt_lower: lower threshold for sliedt (default=10.0)
    :param threshold_sliedt_upper: upper threshold for sliedt (default=500.0)
    :param threshold_dose_lower:  lower threshold for dose (default= 5.0)
    :param threshold_dose_upper: upper threshold for slie (default=100.0)
    :param window_normalization: Gp window at the start of the collector (counting from the first data point)
        to be used for normalization (default=5.0)
    :param window_sg: window used for the sg filter of slie/dt (default=31, advise: odd number)
    :param window_median: window used for the rolling median of slie/dt (default=31, advise: odd number)
    :param margin_median_filter: margin (relative ratio) used to build the rolling median filter (default=0.05)
    :param verbose: to switch internal debug info
    :return: dataframe with slie_dt and supporting signals
    """

    do_it.do_it_verbose(currentframe(), verbose)

    t0 = pd.Timestamp('now')
    required_keys = ['collector', 'dose', 'ecal', 'filter', 'scanner']
    if use_pf_degradation_correction:
        required_keys.append('pf_transmission')

    if not all([item in slie_data for item in required_keys]):
        raise Exception('{}\n {}\n{}'
                        .format('Dict slie_data does not contain all required keys.',
                                'Required keys: {}'.format(required_keys),
                                'Available keys: {}'.format(slie_data.keys())
                                )
                        )
    data = pd.DataFrame(slie_data['scanner']['dw_slie']).copy()

    if 'sv_gate' not in slie_data['scanner'].columns:
        raise ValueError("Scanner dataframe does not contain required 'sv_gate' column")
    valid_measurement_filter = build_valid_measurement_filter(slie_data['filter'], slie_data['scanner']['sv_gate'],
                                                              verbose=verbose)
    data = apply_filter(data, valid_measurement_filter, verbose=verbose)

    data = apply_uniformity_refresh_filter(data, verbose=verbose)

    data = apply_threshold_filter(data, 'dw_slie', threshold_slie_lower, threshold_slie_upper, verbose=verbose)

    dose_target = apply_threshold_filter(slie_data['dose'], 'dose_target', threshold_dose_lower, threshold_dose_upper,
                                         verbose=verbose)
    dose_target_at_slie = filter_dose_target_at_slie(dose_target, data, use_dt_of_slie_measurement, verbose=verbose)

    try:
        illumination_mode_corrections = get_illumination_mode_corrections(verbose=verbose)
        data = apply_illumination_mode_correction(data, 'dw_slie', slie_data['scanner'],
                                                  illumination_mode_corrections, verbose=verbose)
    except Exception as e:
        print('No correction for different illumination modes applied')
        print(e)

    if 'slie_artifact_correction' in slie_data['collector'].columns:
        # only apply it in case there are artifact corrections
        data = apply_artifact_correction(data, 'dw_slie', pd.DataFrame(slie_data['collector']['slie_artifact_correction']),
                                         verbose=verbose)

    if use_ecal_ratio_correction:
        data = apply_ecal_ratio_correction(data, 'dw_slie', slie_data['ecal'], verbose=verbose)

    if use_pf_degradation_correction:
        pf_transmission = calculate_pf_transmission(slie_data['pf_transmission'], verbose=verbose)
        data = apply_pf_degradation_correction(data, 'dw_slie', pf_transmission, verbose=verbose)

    data = get_slie_dt(data, dose_target_at_slie, verbose=verbose)

    if 'sliedt_artefact' in slie_data['collector'].columns:
        # only apply it in case there are sliedt artifact corrections
        data = apply_artifact_correction(data, 'slie_dt', pd.DataFrame(slie_data['collector']['sliedt_artefact']),
                                         verbose=verbose)
    data = apply_threshold_filter(data, 'slie_dt', threshold_sliedt_lower, threshold_sliedt_upper, verbose=verbose)

    if 'pulse_count_cumm' not in slie_data['scanner'].columns:
        raise ValueError("Scanner dataframe does not contain required 'pulse_count_cumm' column")
    pulse_count = get_collector_pulse_count(pd.DataFrame(slie_data['scanner']['pulse_count_cumm']), verbose=verbose)
    data = add_pulse_count_to_data(data, pulse_count, verbose=verbose)

    data = calculate_rolling_median(data, window_median, verbose=verbose)
    data = apply_rolling_median_filter(data, margin_median_filter, verbose=verbose)

    normalization_factor = get_normalization_factor(data, window_normalization, verbose=verbose)
    data = apply_normalization(data, 'slie_dt', normalization_factor, verbose=verbose)

    data['slie_dt_norm_variance'] = signal_processing.calculate_relative_variance(
        data['slie_dt_norm'], window_median, verbose=verbose)
    data = calculate_sg_filter(data, window_sg, verbose=verbose)

    # add dose_target_at_slie
    data = data.join(dose_target_at_slie, how='outer')

    duration = pd.Timestamp('now') - t0
    print('\nslie_dt family calculated in {:.2f} seconds\n'.format(duration.microseconds*1e-6))

    return data
