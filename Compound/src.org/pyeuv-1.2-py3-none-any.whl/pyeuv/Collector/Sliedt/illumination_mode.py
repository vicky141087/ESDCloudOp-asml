def get_mode_map():
    try:
        from .company_secret.illumination_mode_factors import mode_map
    except ImportError:
        raise ImportError(
            "Could not illumination_mode_factors.py as it's not included in this release of pyeuv. "
            "Contact the SF-18 or the current pyeuv maintainer if you need this functionality." 
            )
    return mode_map


def get_mirror_states():
    try:
        from .company_secret.illumination_mode_factors import mirror_states
    except ImportError:
        raise ImportError(
            "Could not illumination_mode_factors.py as it's not included in this release of pyeuv. "
            "Contact the SF-18 or the current pyeuv maintainer if you really need this functionality." 
            )

    return mirror_states
