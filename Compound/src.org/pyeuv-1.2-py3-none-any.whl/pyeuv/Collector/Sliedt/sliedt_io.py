# -*- coding: utf-8 -*-
"""
sliedt_io.py
Authors: RWKL
Date:  2019-08-21

Ownership: SF-18 (FC-079, FC-086)

Code is extracted from sliedt.py
It handles all the data retrieval, such that sliedt only deals with the calculation
"""

import pandas as pd

from inspect import currentframe  # internal tooling functions
from pyeuv.Collector.Sliedt.illuminator_degradation import get_pf_transmission_data
from pyeuv.Collector.Sliedt.illumination_mode import get_mode_map  # contains custom illumination mode correction factors per system
from pyeuv.Do_It import do_it_library as do_it


def get_collector_transmission_names(verbose=False):
    """
    Function that returns a dictionary with required collector_transmission signals:
        'Collector._SLIE_Transmission',
        'Collector._SLIE_Transmission_Corrected'

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
        '_SLIE_Transmission': 'Collector._SLIE_Transmission',
        '_SLIE_Transmission_Corrected': 'Collector._SLIE_Transmission_Corrected'
    }
    return signal_names_mapping


def get_collector_slie_filtered_names(verbose=False):
    """
    Function that returns a dictionary with required collector._SLIE_Filtered signals:
        'Collector._SLIE_Filtered'

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
        '_SLIE_Filtered': 'Collector._SLIE_Filtered'
    }
    return signal_names_mapping


def get_collector_transmission_corrected_names(verbose=False):
    """
    Function that returns a dictionary with required collector_transmission signals:
        'Collector._SLIE_Transmission_Corrected'

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
        '_SLIE_Transmission_Corrected': 'Collector._SLIE_Transmission_Corrected'
    }
    return signal_names_mapping


def get_illumination_mode_corrections(verbose=False):
    """
    Provide dictionary with illumination mode correction factors

    :param verbose: to switch internal debug info
    :return: dictionary containing the default illumination mode correction factors
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return get_mode_map()


def get_scanner_signal_preparation_names(verbose=False):
    """
    Function that returns a dictionary with required scanner signals:
        'Scanner.DW_SLIE',
        'Scanner.DW_SV_state',  # Scanner gate valve closed = 0, open = 1

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
            'dw_slie': 'Scanner.DW_SLIE',
            'sv_gate': 'Scanner.DW_SV_state',  # Scanner gate valve closed = 0, open = 1
            }

    return signal_names_mapping


def get_scanner_signal_names(verbose=False):
    """
    Function that returns a dictionary with required scanner signals:
            'Scanner.DW_SLIE',
            'Scanner.DW_total_nr_pulses',
            'Scanner.DW_SLIE_FSLIE_PS_doe_id',
            'Scanner.DW_SLIE_FSLIE_PS_sigma_inner',
            'Scanner.DW_SLIE_FSLIE_PS_sigma_outer',
            'Scanner.DW_SV_state',  # Scanner gate valve closed = 0, open = 1

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
            'dw_slie': 'Scanner.DW_SLIE',
            'pulse_count_cumm': 'Scanner.DW_total_nr_pulses',
            'doe_id': 'Scanner.DW_SLIE_FSLIE_PS_doe_id',
            'sigma_inner': 'Scanner.DW_SLIE_FSLIE_PS_sigma_inner',
            'sigma_outer': 'Scanner.DW_SLIE_FSLIE_PS_sigma_outer',
            'sv_gate': 'Scanner.DW_SV_state',  # Scanner gate valve closed = 0, open = 1
            }

    return signal_names_mapping


def get_collector_signal_names(verbose=False):
    """
    Function that returns a dictionary with required collector signals:
            'Collector._NormalizationCorrection'
            'Collector._SLIEDT_Artefact'

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
            'slie_artifact_correction': 'Collector._NormalizationCorrection',
            'sliedt_artefact': 'Collector._SLIEDT_Artefact',
            }
    return signal_names_mapping


def get_ecal_signal_names(verbose=False):
    """
    Function that returns a dictionary with required ecal signals:
            'RT12.ECALextSensorFactor',
            'RT12.ECALextSensorFactorRatio',

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
            'ecal_sensor_factor': 'RT12.ECALextSensorFactor',
            'ecal_sensor_factor_ratio': 'RT12.ECALextSensorFactorRatio',
            }
    return signal_names_mapping


def get_filter_signal_names(verbose=False):
    """
    Function that returns a dictionary with required filter signals:
            'Filter._LotSignal',
            'Filter._ManualBlockCollector',

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
            'lot_signal': 'Filter._LotSignal',
            'manual_block_collector': 'Filter._ManualBlockCollector',
            }
    return signal_names_mapping


def get_dt_at_slie_measurement_time_signal_names(verbose=False):
    """
    Function that returns a dictionary with required dose target signals:
            '_DT_at_SLIE_measurement',

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
            'dt_at_slie_measurement': '_DT_at_SLIE_measurement',
        }
    return signal_names_mapping


def get_dose_signal_names(use_dt_of_slie_measurement=True, verbose=False):
    """
    Function that returns a dictionary with required dose target signals (depending on aggregation)
            'RT05.BDenergyTargetAvg.10s.median', (only when aggregation=True)
            'RT05.BDenergyTargetAvg',
            'RT05.BDburstLength',

    :param use_dt_of_slie_measurement: use dt of actual slie measurement, otherwise aggregate dt to 10s (default: True)
    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if use_dt_of_slie_measurement:
        signal_names_mapping = {
            'dose_target': 'RT05.BDenergyTargetAvg'
        }
    else:
        signal_names_mapping = {
            'dose_target': 'RT05.BDenergyTargetAvg.10s.median',
        }
    return signal_names_mapping


def get_illumination_mode_names(verbose=False):
    """
    Function that returns a dictionary with required illumination mode signals:
        'Scanner.DW_SLIE_FSLIE_PS_doe_id',
        'Scanner.DW_SLIE_FSLIE_PS_im_mode',
        'Scanner.DW_SLIE_FSLIE_PS_sigma_inner',
        'Scanner.DW_SLIE_FSLIE_PS_sigma_outer'

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
        'DW_SLIE_FSLIE_PS_doe_id': 'Scanner.DW_SLIE_FSLIE_PS_doe_id',
        'DW_SLIE_FSLIE_PS_im_mode': 'Scanner.DW_SLIE_FSLIE_PS_im_mode',
        'DW_SLIE_FSLIE_PS_sigma_inner': 'Scanner.DW_SLIE_FSLIE_PS_sigma_inner',
        'DW_SLIE_FSLIE_PS_sigma_outer': 'Scanner.DW_SLIE_FSLIE_PS_sigma_outer'
    }
    return signal_names_mapping


def get_dose_data(client, source_id, from_time, to_time, use_dt_of_slie_measurement=False, verbose=False):
    """
    obtain all the required Dose data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param use_dt_of_slie_measurement: use dt of actual slie measurement, otherwise aggregate dt to 10s (default: False)
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')

    try:
        df = client.get_signals_dict(get_dose_signal_names(use_dt_of_slie_measurement=use_dt_of_slie_measurement),
                                     source_id, from_time, to_time, create_columns=True)

        if df.empty:
            signals = pd.DataFrame(columns=get_dose_signal_names(
                use_dt_of_slie_measurement=use_dt_of_slie_measurement).keys())
        else:
            signals = df

    except Exception as e:
        print('Error:', e)
        signals = pd.DataFrame(columns=get_dose_signal_names(
            use_dt_of_slie_measurement=use_dt_of_slie_measurement).keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def get_collector_slie_filtered_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required Collector SLIE Filtered data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp(u'now')

    try:
        df = client.get_signals_dict(get_collector_slie_filtered_names(),
                                     source_id, from_time, to_time, create_columns=True)

        if df.empty:
            signals = pd.DataFrame(columns=get_collector_slie_filtered_names().keys())
        else:
            signals = df

    except Exception as e:
        print('Error:', e)
        signals = pd.DataFrame(columns=get_collector_slie_filtered_names().keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def get_collector_transmission_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required Collector Transmission data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')

    try:
        df = client.get_signals_dict(get_collector_transmission_names(),
                                     source_id, from_time, to_time, create_columns=True)

        if df.empty:
            signals = pd.DataFrame(columns=get_collector_transmission_names().keys())
        else:
            signals = df

    except Exception as e:
        print('Error:', e)
        signals = pd.DataFrame(columns=get_collector_transmission_names().keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def get_collector_transmission_corrected_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required Collector Transmission data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')

    try:
        df = client.get_signals_dict(get_collector_transmission_corrected_names(),
                                     source_id, from_time, to_time, create_columns=True)

        if df.empty:
            signals = pd.DataFrame(columns=get_collector_transmission_corrected_names().keys())
        else:
            signals = df

    except Exception as e:
        print('Error:', e)
        signals = pd.DataFrame(columns=get_collector_transmission_corrected_names().keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def get_collector_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required collector data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')
    signals = dict()

    try:
        df = client.get_signals_dict(get_collector_signal_names(),
                                     source_id, from_time, to_time)

        if df.empty:
            signals['artifact_correction'] = pd.DataFrame(columns=get_collector_signal_names().keys())
        else:
            signals['artifact_correction'] = df

    except Exception as e:
        print('Error:', e)
        signals['artifact_correction'] = pd.DataFrame(columns=get_collector_signal_names().keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def get_illumination_mode_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required Illumination mode data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')
    signals = dict()

    try:
        df = client.get_signals_dict(get_illumination_mode_names(),
                                     source_id, from_time, to_time)

        if df.empty:
            signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())
        else:
            signals['scanner'] = df

    except Exception as e:
        print('Error:', e)
        signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def get_scanner_and_filter_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required SCANNER data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')
    signals = dict()

    try:
        df = client.get_signals_dict(get_filter_signal_names(),
                                     source_id, from_time, to_time)
        if df.empty:
            signals['filter'] = pd.DataFrame(columns=get_filter_signal_names().keys())
        else:
            signals['filter'] = df

        df = client.get_signals_dict(get_scanner_signal_names(),
                                     source_id, from_time, to_time)
        if df.empty:
            signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())
        else:
            signals['scanner'] = df

    except Exception as e:
        print('Error:', e)
        signals['filter'] = pd.DataFrame(columns=get_filter_signal_names().keys())
        signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals


def get_data(client, source_id, from_time, to_time, use_dt_of_slie_measurement=True, use_pf_degradation=False,
             verbose=False):
    """
    obtain all the required data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param use_dt_of_slie_measurement: use dt of actual slie measurement, otherwise aggregate dt to 10s (default: True)
    :param use_pf_degradation: switch to get data for pf degradation (default: False)
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')
    signals = dict()

    try:
        df = client.get_signals_dict(get_collector_signal_names(),
                                     source_id, from_time, to_time)
        if df.empty:
            signals['collector'] = pd.DataFrame(columns=get_collector_signal_names().keys())
        else:
            signals['collector'] = df

        df = client.get_signals_dict(get_filter_signal_names(),
                                     source_id, from_time, to_time)
        if df.empty:
            signals['filter'] = pd.DataFrame(columns=get_filter_signal_names().keys())
        else:
            signals['filter'] = df

        df = client.get_signals_dict(get_scanner_signal_names(),
                                     source_id, from_time, to_time)
        if df.empty:
            signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())
        else:
            signals['scanner'] = df

        df = client.get_signals_dict(get_ecal_signal_names(),
                                     source_id, from_time, to_time)
        if df.empty:
            signals['ecal'] = pd.DataFrame(columns=get_ecal_signal_names().keys())
        else:
            signals['ecal'] = df

        if use_pf_degradation:
            signals['pf_transmission'] = get_pf_transmission_data(client, source_id)

        df = client.get_signals_dict(get_dose_signal_names(use_dt_of_slie_measurement=use_dt_of_slie_measurement),
                                     source_id, from_time, to_time)
        if df.empty:
            signals['dose'] = pd.DataFrame(columns=get_dose_signal_names(
                use_dt_of_slie_measurement=use_dt_of_slie_measurement).keys())
        else:
            signals['dose'] = df

    except Exception as e:
        print('Error:', e)
        signals['collector'] = pd.DataFrame(columns=get_collector_signal_names().keys())
        signals['filter'] = pd.DataFrame(columns=get_filter_signal_names().keys())
        signals['scanner'] = pd.DataFrame(columns=get_scanner_signal_names().keys())
        signals['ecal'] = pd.DataFrame(columns=get_ecal_signal_names().keys())
        signals['dose'] = pd.DataFrame(columns=get_dose_signal_names(
            use_dt_of_slie_measurement=use_dt_of_slie_measurement).keys())

    if verbose:
        duration = pd.Timestamp('now') - time_start
        print('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals