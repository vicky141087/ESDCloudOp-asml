# -*- coding: utf-8 -*-
"""
Created on Thu Oct 18 10:38:37 2018

@author: rwiegger

A library containing collector incident detection algorithms. 
It includes:
- Collector Degradation Limiter (CDL)
"""
import pandas as pd
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def get_cdl_signal_names(sg_filter=True, verbose=False):
    """
    Function that returns a dictionary with required signals to calculate the CDL

    :param sg_filter: cwitch for the SG filtered slie/dt (SG filter used by default)
    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the dataframes, and influx signal names as value.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if sg_filter:
        reflectivity_signal = 'Collector._SLIE_DT_SG_Norm'
    else:
        reflectivity_signal = 'Collector._SLIE_DT_Norm'
        
    signal_names_mapping = {
            'reflectivity' : reflectivity_signal,
            'pulse_count' : 'Collector._PulseCount'
            }
    return signal_names_mapping


def prep_data(data, verbose=False):
    """
    Prepare the cdl data before usage. 
    - Interpolate pulse count to reflectivity datapoints
    - convert pulse count to Gp
    - remove NaN

    :param data: connection to influx
    :type: pandas dataframe
    :param verbose: to switch internal debug info
    :return: series of timestamp, pulse_count and 
    """

    do_it.do_it_verbose(currentframe(), verbose)

    data['pulse_count'] = data['pulse_count'].interpolate()
    data.dropna(inplace=True)
    
    data.pulse_count *= 1.0e-9
    
    return data


def get_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required data from influx

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with dataframes per signal group
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp('now')
    try:
        signals = dict()
        signals['collector'] = client.get_signals_dict(get_cdl_signal_names(), 
               source_id, from_time, to_time)
        
    except Exception as e:
        print ('Error:', e)
        return dict()
    
    duration = pd.Timestamp('now') - time_start
    print ('\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))
    
    return signals  


def get_start_of_cdl(x, data, threshold_loss, verbose=False):
    """
    Gets start of a fast degradation event

    :param x:
    :param data:
    :param threshold_loss:
    :param verbose: to switch internal debug info
    :return:
    """

    do_it.do_it_verbose(currentframe(), verbose)

    test = data[(data.reflectivity > x.reflectivity + threshold_loss) & (data.index < x.name)].tail(1)
    if len(test)>0:
        x['timestamp_start'] = test.index[0]
        x['reflectivity_start'] = test.reflectivity[0]
        x['pulse_count_start'] = test.pulse_count[0]
    return x


def calculate_cdl(data, threshold_loss=5.0, verbose=False):
    """
    Collector Degradation Limiter (CDL) Algo by TBAV
    The CDL is the signal how many Gp ago SLIE/DT was threshold_loss higher.
    
    :param data: Series with pulse count (in Gp) and SLIE/DT
    :type data: pandas.DataFrame
    :param threshold_loss: threshold for reflectivity loss
    :type threshold_loss: float
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    cdl_window  = data.copy()
    cdl_window = cdl_window.apply(lambda x: 
        get_start_of_cdl(x, data, threshold_loss), axis=1)

    # cdl_window.dropna(inplace=True)
    cdl_window['pulse_count_delta'] = cdl_window['pulse_count'] - cdl_window['pulse_count_start']
    
    return cdl_window

    
def calculate_cdl_triggers(cdl_window, threshold_pulse_count=1.0, verbose=False):
    """
    Calculates the CDL triggers, and adds useful data 
    (start, end, delta for timestamp (unix), gp, reflectivity)
    The CDL is triggered when within 'threshold_pulse_count' 'threshold_loss' is lossed.
    - The start of the event is the last data point the reflectivity was 'threshold_loss' higher than the moment of the trigger.
    - The event extends in the future to the minimum reflectivity within the window where the CDL continues to be triggered.
    So successive datapoints for which the CDL would be triggered will not 
    result in multiple CDL events. These triggers get merged to 1 event.
    
    :param threshold_pulse_count: threshold for maximum pulse ccount range
    :type threshold_pulse_count: float
    :param verbose: to switch internal debug info
    """

    do_it.do_it_verbose(currentframe(), verbose)

    cdl_window['trigger'] = (cdl_window['pulse_count_delta'] <= threshold_pulse_count).astype(int)
    cdl_window['label'] = cdl_window['trigger'].diff()
    cdl_window.loc[cdl_window['label'] != 1, 'label'] = 0
    cdl_window['label'] = cdl_window['label'].cumsum()
    cdl_window.dropna(inplace=True)
    
    cdl_triggers = pd.DataFrame()
    
    for label, trigger in cdl_window[cdl_window['trigger'] > 0].groupby('label'):
        # get the trigger event (the first row)
        trigger_event = trigger.head(1).copy()
        
        # is it a valid trigger? It should start after the previous trigger
        if ((len(cdl_triggers) > 0) and
            (trigger_event.pulse_count_start.values[0] < 
             cdl_triggers.tail(1).pulse_count_end.values[0])):
            # the new trigger should start after the previous trigger has ended
            continue
        
        # the trigger continues as long as
        # - the trigger conditions are met
        # - the reflectivity is decreasing
        
        # get end of the trigger
        trigger_end = trigger[trigger.reflectivity == trigger.reflectivity.min()]

        # add data for end of trigger
        trigger_event['reflectivity_end'] = trigger_end.reflectivity[0]
        trigger_event['timestamp_end'] = pd.to_datetime(trigger_end.index)
        trigger_event['pulse_count_end'] = trigger_end.pulse_count[0]
        
        # add trigger to dataframe of triggers
        cdl_triggers = cdl_triggers.append(trigger_event)
        
    # add derived data to cdl_triggers
    if len(cdl_triggers) > 0:
        cdl_triggers['pulse_count_delta'] = cdl_triggers.pulse_count_end - cdl_triggers.pulse_count_start
        cdl_triggers['timestamp_start'] = pd.to_datetime(cdl_triggers.timestamp_start, utc=True)
        cdl_triggers['timestamp_delta'] = cdl_triggers.timestamp_end - cdl_triggers.timestamp_start
        cdl_triggers['reflectivity_delta'] = cdl_triggers.reflectivity_end - cdl_triggers.reflectivity_start
    
    return cdl_triggers
