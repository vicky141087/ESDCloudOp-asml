# -*- coding: utf-8 -*-
"""
Created on Wed Feb  6 13:34:31 2019

@author: rwiegger

This contains a set of functions to be able to browse through the collector performance reports drive.
"""

import os
import shutil
import re
import pandas as pd
from pyeuv.EUVDashboard.common import has_hpc_environment, has_sf18_environment
from pyeuv.Shared.shared import get_collectors, get_machine_from_machine_id
from pyeuv.Shared.configuration import Configuration
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


# functions to search for directories
def get_directories_from_substring(directory, substring, verbose=False):
    """
    this function looks for directory names of the subdirectories within 'directory', 
    which contain 'substring'.
    
    :param directory: directory in which one tries to find directory names
    :param substring: the substring to look for
    :param verbose: switches debug mode (default=False)
    :return: list of directory names
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        matching = [s for s in os.listdir(directory) if substring in s]
        matching.sort()
    except Exception as e:
        raise Exception(e)  
    
    return matching
    

def get_annotations_directory(collector_directory, verbose=False):
    """
    returns the annotations directory, a sub directory of the collector directory
    
    :param collector_directory: the collector directory, in which an annotations_directory is expected to exist()
    :param verbose: switches debug mode (default=False)
    :return: path of annotations directory
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return os.path.join(collector_directory, '2.in-use', 'collector_monitoring')


def get_luer_directory(collector_directory=None, client=None, base_dir=None, machine_id=None, collector_name=None,
                       verbose=False):
    """
    returns the luer directory, a sub directory of the collector directory
    If the collector directory is provided, it uses this to determine the luer directory.
    Otherwise, it will be determined based on the other parameters

    :param collector_directory: the collector directory (default=None)
    :param client: connection to influx (default=None)
    :param base_dir: base directory of the directory structure of all machines and collectors (default=None)
    :param machine_id: machine id, e.g. 'm1234' (default=None)
    :param collector_name: collector name, used to select collector properties from influx (default=None)
    :param verbose: switches debug mode (default=False)
    :return: path of luer directory
    :raise: Exception in case the required input parameters are not provided
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if collector_directory is not None:
        pass

    elif client is not None and base_dir is not None and machine_id is not None and collector_name is not None:
        machine = get_machine_from_machine_id(client, machine_id)
        conf = Configuration()
        conf.set_configuration(client, machine, collector_name, verbose=verbose)
        collector_directory = get_collector_directory(conf, base_dir, verbose)

    else:
        raise Exception('Missing input (collector directory or both source_id and collector_name)')

    luer_directory = os.path.join(collector_directory, '2.in-use', 'RADON')

    return luer_directory


def get_machine_directory(conf, base_dir, verbose=False):
    """
    returns the directory within the collector performance directory structure that
    belongs tothe specified machine
    
    :param conf: object containing properties of a machine
    :param base_dir: root directory in which data for all machines is stored
    :param verbose: switches debug mode (default=False)
    :return: the directory for the specified machine
    """

    do_it.do_it_verbose(currentframe(), verbose)

    source_generation_path = os.path.join(base_dir, conf.source_generation)

    try:
        matches = get_matching_machine_directories(conf, base_dir, verbose)
        if len(matches) == 0:
            raise Exception('Could not find the shared drive for {}'.format(conf.machine_name))

        machine_path = os.path.join(source_generation_path, matches[0])

    except Exception as e:
        print('Warning: Could not find the shared drive for {}'.format(conf.machine_name))
        print('Looking in {}'.format(source_generation_path))
        raise Exception(e)

    return machine_path


def get_matching_machine_directories(conf, base_dir, verbose):
    """
    Finds all matching machine directories. It checks for the substring containing the vessel_id and source_id.
    In case multiple directories are found, it will also return multiple. This could happen in case:

     - a pilot system goes to the customer. The vessel_id and source_id do not change, however,
       the machine identifier changes.
     - For some reason, a directory is duplicated (suspecting some user doing this manually,
       at the risk of breaking tooling

    :param conf: the machine configuration, based on the machine list
    :param base_dir: The (CPR) base directory
    :param verbose: switches debug mode (default=False)
    :return: list of matching directories
    :raise: Exception from get_directories_from_substring
    """

    do_it.do_it_verbose(currentframe(), verbose)

    source_generation_path = os.path.join(base_dir, conf.source_generation)

    # find correct machine directory
    vessel_nr = conf.vessel_id[conf.vessel_id.find('#') + 1:]
    substring = 'V{}_{}'.format(vessel_nr, conf.source_id.replace('s', ''))

    try:
        matches = get_directories_from_substring(source_generation_path, substring, verbose=verbose)
    except Exception as e:
        raise Exception(e)
    return matches


def get_collector_directory(conf, base_dir, verbose=False):
    """
    returns the directory within the collector performance directory structure that
    belongs to the specified collector

    :param conf: object containing properties of a machine
    :param base_dir: root directory in which data for all machines is stored
    :param verbose: switches debug mode (default=False)
    :return: the directory for the specified machine
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # find correct collector directory
    try:
        machine_directory = get_machine_directory(conf, base_dir, verbose=verbose)
        matches = get_directories_from_substring(machine_directory, conf.collector_name)
    except Exception as e:
        raise Exception(e)

    try:
        # filter all directories that do not have the correct format
        matches = [c for c in matches if is_collector_directory(c, verbose=verbose)]

        # take SDMSCXXX(.Rxx.Hxx) (remove prefix and postfix)
        matches = [m for m in matches if m.split('_')[1] == conf.collector_name]

        # 'SDMSC123' is in ['#11_SDMSC123.R01', '#1_SDMSC123_34SC0208', '#2_SDMSC124', ...] twice,
        # take part between '_', take exact match
        collector_path = os.path.join(machine_directory, matches[0])
        return collector_path

    except Exception as e:
        print('Warning: Could not find the shared drive for {}'.format(conf.machine_name))
        print('Looking in {}'.format(base_dir))
        print('Expected directory name containing {}'.format(conf.collector_name))
        print(e)


def is_collector_directory(directory, verbose=False):
    """
    Checks for several conditions to validate a string is a collector directory name
    The format of a valid collector directory is '#X_SDMSCxxx_Y', where X and xxx are numeric

    :param directory: the string to be checked
    :param verbose: switches debug mode (default=False)
    :return: True in case the string is formatted correctly, otherwise it return False
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        if not directory.startswith('#'):
            return False

        directory_split = directory.split('_')
        if len(directory_split) < 2:
            return False

        counter = directory_split[0]
        if not counter[1:].isdigit():
            return False

        collector_name_with_extension = directory_split[1]
        collector_name = collector_name_with_extension.split('_')[0]

        if len(collector_name) < 8:
            return False

        if not collector_name.startswith('SDMSC'):
            return False

        if not collector_name[5:8].isdigit():
            return False

    except Exception as e:
        if verbose:
            print(e)
        return False

    return True



def get_share_base_directory(local=False, verbose=False):
    """ 
    Obtain the collector performance base directory

    :param verbose: switches debug mode (default=False)
    :return: path of the collector performance base directory
    :rtype: string
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if has_hpc_environment():
        return r'/shared/nl011087/Collector/PIT/Collector_Performance_Reports'
    elif has_sf18_environment():
        if local:
            return r'/home/anaconda/cpr'
        else:
            return r'/asml_shared/nl011150/Collector/PIT/Collector_Performance_Reports'
    else:
        if local:
            return r'c:\Localdata\CPR'
        else:
            return r'\\asml.com\eu\shared\nl011150\Collector\PIT\Collector_Performance_Reports'


def create_directory_structure(client, root, machine_list, verbose=False):
    """
    Creates the directory structure as used on the Collector Performance Reports share drive

    :param client: connection to influxDB
    :param root: root path of the directory structure
    :param machine_list: dataframee of machines
    :param verbose: switches debug mode (default=False)x
    """

    do_it.do_it_verbose(currentframe(), verbose)

    start = pd.Timestamp('now')
    created_directories = False
    create_directory(root)

    for i, row in machine_list.iterrows():
        if verbose:
            print('Create directory structure for', row.displayname)
        hardware_dir = os.path.join(root, row.hardware)
        create_directory(hardware_dir)
        machine_name = row.displayname
        source_id = 's{}'.format(row.source_nr)
        machine_name = convert_display_name_to_simplified_name(machine_name, verbose=verbose)
        if machine_name == '':
            print("Warning: machine_name is empty, do not create directory")
            continue
        if '?' in row.vessel:
            # content of machine_list inferior, skip this machine
            print('incorrect vessel id {} at {}'.format(row.vessel, row.displayname))
            # continue
        machine_dir = os.path.join(hardware_dir, '{}_{}_{}_{}'.format(machine_name, row.machine_nr,
                                                                      row.vessel.replace("e #", "").replace('?', 'x'),
                                                                      row.source_nr))
        create_directory(machine_dir)
        try:
            collectors = get_collectors(client, source_id, verbose=verbose)
        except Exception as e:
            print('Skip machine {}'.format(row.displayname))
            print(e)
            continue

        index = 0
        for j, collector in collectors.iterrows():
            index = index + 1
            collector_name = collector.swap
            if len([s for s in os.listdir(machine_dir) if collector_name in s]) > 0:
                # already exists, skip it
                continue
            print('create collector_dir for {} | {} in {}'.format(machine_name, collector_name, machine_dir))
            created_directories = True
            collector_dir = os.path.join(machine_dir, '#{}_{}'.format(index, collector_name))
            create_directory(collector_dir)
            create_directory(os.path.join(collector_dir, '1.new'))
            create_directory(os.path.join(collector_dir, '2.in-use'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'collector_monitoring'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'Escalation'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'Escalation', 'Log'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'Escalation', 'PCCSTRAIM'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'Escalation', 'Presentations'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'Photo'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'Photo', '1_ddmmmyy'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'RADON'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'RADON', '13FP'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'RADON', 'radon_output'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'RADON', 'unblurred'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'RSF'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'RSF', 'Backup'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', '_Reports'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', '_Reports', 'Daily'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', '_Reports', 'Daily', 'Operation'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', '_Reports', 'Daily', 'RADON'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', '_Reports', 'Weekly'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', 'Backup'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', 'CFO'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', 'CFO', 'Backup'))
            create_directory(os.path.join(collector_dir, '2.in-use', 'SCP_Reports', 'RBD'))
            create_directory(os.path.join(collector_dir, '3.used'))
            create_directory(os.path.join(collector_dir, '3.used', '1.pre-clean'))
            create_directory(os.path.join(collector_dir, '3.used', '2.post-clean'))

    now = pd.Timestamp('now')
    if created_directories:
        print(
            '{}: Created directory tree. Elapsed time: {}.{}s'.format(pd.Timestamp('now').strftime('%Y-%m-%d %H:%M:%S'),
                                                                      (now - start).seconds,
                                                                      (now - start).microseconds))


def update_directory_structure(root, machine_list):
    """
    Updates the machine directory name for old machines by adding the tag '_old' to the directory name

    :param root: root path of the directory structure
    :param machine_list: dataframee of machines
    """

    start = pd.Timestamp('now')
    updated_directories = False
    for i, row in machine_list.iterrows():
        hardware_dir = os.path.join(root, row.hardware)
        create_directory(hardware_dir)
        machine_name = row.displayname
        machine_name = convert_display_name_to_simplified_name(machine_name)

        if machine_name == '':
            print ("machine_name is empty, do not create directory")
            continue
        postfix = '_{}_{}'.format(row.vessel.replace("e #", ""), row.source_nr)
        found = [s for s in os.listdir(hardware_dir) if postfix in s]
        if len(found) != 1:
            continue
        machine_directory_name = found[0]
        suffix = '_old'
        if suffix in machine_directory_name:
            continue
        machine_directory_name_updated = '{}{}'.format(machine_directory_name, suffix)
        shutil.move(os.path.join(hardware_dir, machine_directory_name),
                    os.path.join(hardware_dir, machine_directory_name_updated))
        print('Update {} to {}'.format(machine_directory_name, machine_directory_name_updated))
        updated_directories = True
    now = pd.Timestamp('now')
    if updated_directories:
        print('{}: Updated directory tree. Elapsed time: {}.{}s'.format(
            pd.Timestamp('now').strftime('%Y-%m-%d %H:%M:%S'), (now - start).seconds, (now - start).microseconds))


def create_directory(directory_name, force=False, verbose=False):
    """
    Creates, in case it did not exist, the directory given by directory_name.
    In case the directory name already exists as a file, and force is enabled,
    it removes the file and creates the directory

    :param directory_name: Full path of directory name to be made
    :param force: Enforces to create the directory, even if it currently exists as file instead of directory
        (default: False)
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if not os.path.isdir(directory_name):

        if os.path.exists(directory_name):
            if verbose:
                print('path for directory already exists, but is no directory!')
                # path exists, but is not a directory
            if force:
                os.remove(directory_name)
                if verbose:
                    print('create', directory_name)
                os.makedirs(directory_name)

        else:
            if verbose:
                print('create', directory_name)
            os.makedirs(directory_name)


def convert_display_name_to_simplified_name(display_name, verbose=False):
    """
    Creates the simplified name from a machine's display name, using some regular expressions.
    These names are typically used oin the directory names of machines, etc.

    :param display_name: the display name of a machine
    :param verbose: switches debug mode (default=False)
    :return: simplified machine name
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if re.compile('[GFASML]* \(P[ilotr]{4} [0-9]*\)').match(display_name): # ASML (Pilot 1), GF (Pilot 8) etc.
        name = display_name.strip().replace("Pilot ", "Pi").replace("Proto ", "Pr").replace("ASML", "VHV")
        name = name.replace(" ", "_").replace("(", "").replace(")", "")
    elif re.compile('[a-zA-Z]*-[0-9]*').match(display_name): # TSMC-5, Intel-3 etc.
        found = re.search('[a-zA-Z]*-[0-9]*', display_name).group(0)
        name = found.strip().replace("-", "#")
    elif re.compile('[a-zA-Z]*').match(display_name): # Micron etc.
        found = re.search('[a-zA-Z]*', display_name).group(0)
        name = found.strip()
    else:
        if verbose:
            print('Regex could not extract name', display_name)
        name = ''
    return name
