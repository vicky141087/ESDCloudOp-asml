# -*- coding: utf-8 -*-
"""
radon_image_processing.py
Authors: JJCW
Date:  2019-07-05

This module releases functions for generating delta image.
"""

import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def create_delta_image(reference_image_df, current_image_df, scaling_factor_reference, scaling_factor_current,
                       threshold=1.2, verbose=False):
    """
    Function to create delta image between reference and to be compared.
    Delta image provides relative transmission map with respect to the reference image.
    Make sure that dimension of input be same (reference_image and current_image)

    :param reference_image_df: luer dataframe to be reference
    :param current_image_df: luer dataframe to be compared
    :param scaling_factor_reference: scaling factor of reference image
    :type scaling_factor_reference: float
    :param scaling_factor_current: scaling factor of current image
    :type scaling_factor_current: float
    :param threshold: upper limit of delta transmission (default = 1.2)
    :type threshold: float
    :param verbose: switches debug mode (default=False)
    :return: dataframe of delta (ratio) between reference and input
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # copy structure of input (to cope with both blurred and unblurred images)
    delta = reference_image_df.copy()
    reference_image = reference_image_df['intensity'].copy()
    current_image = current_image_df['intensity'].copy()

    # create mask for nonzero points (True for nonzero points)
    mask_delta = reference_image > 0

    # apply scaling factors to reference and current
    reference_image *= scaling_factor_reference
    current_image *= scaling_factor_current

    # create delta image and clipping
    delta['intensity'][mask_delta] = current_image[mask_delta] / reference_image[mask_delta]  # nonzero points
    delta['intensity'][~mask_delta] = 0  # zero points on either image
    delta['intensity'][delta['intensity'] > threshold] = threshold  # points over threshold

    return delta

def smooth_luer_using_nearby_ffms(luer_data, ffm_modules, ffm_window=5, verbose=False):
    """
    Smooth luer using nearby ffms in the ffm modules by averaging the intensity over each single facet, fit the
    intensity over the facets by taking a rolling median, and compensating the intensity by scaling with the difference
    of the fit.

    :param luer_data: import luer data
    :param ffm_modules: facet id ranges of ffm module
    :param ffm_window: rolling median window size
    :param verbose: switches debug mode (default=False)
    :return: dataframe containing ffm-based smoothed luer intensity data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # loop through all modules
    for ffm in ffm_modules['facet_id_ranges']:
        # consider range of facets in the ffm module
        _subset = (luer_data['facet'] >= ffm[0]) & (luer_data['facet'] <= ffm[1])

        # calculate the mean of each facet (average over dots)
        mean_intensity_facets = luer_data[_subset][['facet', 'intensity']].groupby(['facet']).mean()
        # fit the data using a rolling median with a to be defined window size (standard 5 facets)
        fit = mean_intensity_facets.rolling(ffm_window, center=True, min_periods=1).median()

        # loop over each facet
        for facet in mean_intensity_facets.index.unique():

            # calcualte the relative difference between the facet mean-intensity with the fit
            rel_intensity_diff = fit.loc[facet].values[0] / mean_intensity_facets.loc[facet].values[0]

            # compensate for the difference by scaling the intensity with the relative difference (except zeros)
            luer_data.loc[luer_data['facet'] == facet, 'intensity'] *= rel_intensity_diff \
                if mean_intensity_facets.loc[facet].values[0] > 0 else 0

    return luer_data

def blur_image(luer_data, system_type='SYSTEM_TYPE_3400', npup=13):
    """
    Blur the image according to Zeiss approved blrring method.

    :param luer_data: import luer data
    :param system_type: select scanner type
    :param npup: number of pupils in the slit
    :return: dataframe luer intensity values
    """
    import pandas as pd

    luer_data.fillna(0, inplace=True)

    # Flip collector coordinates into Farfield
    luer_data['x'] *= -1
    luer_data['y'] *= -1

    # Interpolate data
    (bmp_x, bmp_y, bmp_intensity) = grid_interpolation2(luer_data.x.values, luer_data.y.values,
                                                         luer_data.intensity.values, npup, system_type)
    bmp_x, bmp_y, bmp_intensity = resize_image(bmp_x, bmp_y, bmp_intensity, 256)

    # Flip farfield coordinates into collector
    bmp_x *= -1.0
    bmp_y *= -1.0

    blurred_data = pd.DataFrame(data=bmp_x.reshape(len(bmp_x) * len(bmp_x), 1), columns=['x'])
    blurred_data['y'] = bmp_y.reshape(len(bmp_x) * len(bmp_x), 1)
    blurred_data['intensity'] = bmp_intensity.reshape(len(bmp_x) * len(bmp_x), 1)

    return blurred_data

def grid_interpolation2(x, y, z, n_pup, system_type):
    """
    Interpolate and Filter the given data to an equidistant grid

    :param x: x position
    :param y: y position
    :param z: intensity
    :param npup: number of pupils in the slit
    :param system_type: select scanner type
    return: x,y,z data
    """
    import pylab
    import copy
    import numpy as np
    from scipy import ndimage as nd
    from scipy.interpolate import griddata as griddata

    # Points for interpolation

    if (system_type == 'SYSTEM_TYPE_3100'):
        n_grid_x = 6 * 13  # n_pup
        n_grid_y = 6 * 13
        r_min = 60 / 2
        r_max = 324 / 2
        co_y_left = 40 / 2
        co_y_right = co_y_left
        co_x_left = 0.
        co_x_right = co_x_left

    if (system_type == 'SYSTEM_TYPE_3300'):
        n_grid_x = 7 * 13  # n_pup
        n_grid_y = 7 * 13
        r_min = 82.5 / 2
        r_max = 451.1 / 2
        co_y_left = 55 / 2
        co_y_right = co_y_left
        co_x_left = 0.
        co_x_right = co_x_left

    if (system_type == 'SYSTEM_TYPE_3400'):
        n_grid_x = 7 * 13  # n_pup
        n_grid_y = 7 * 13
        r_min = 82.5 / 2
        r_max = 451.1 / 2
        co_y_left = 23.5 / 2
        co_y_right = -1.
        co_x_left = 0.
        co_x_right = co_x_left

    # ROHDATEN FUER SPAETERE INTERPOLATION KUENSTLICH ERWEITERN

    theta = np.transpose(np.linspace(0, 2 * np.pi, 100))
    x = np.concatenate((x, r_max * 1.2 * np.cos(theta)), axis=0)
    y = np.concatenate((y, r_max * 1.2 * np.sin(theta)), axis=0)
    z = np.concatenate((z, np.zeros((100,))), axis=0)

    # KARTESISCHE INTERPOLATION

    xg = np.linspace(-r_max, r_max, n_grid_x)
    yg = np.linspace(-r_max, r_max, n_grid_y)
    xi, yi = np.meshgrid(xg, yg)

    x_y = np.zeros((len(x), 2))
    x_y[:, 0] = x
    x_y[:, 1] = y

    zi = griddata(x_y, z, (xi, yi), 'linear')
    zi[np.isnan(zi)] = 0

    # NULLSETZEN AUSSENBEREICHE

    # Indizes Balken
    indb = (((abs(yi) <= co_y_left) & (xi <= co_x_left)) | ((abs(yi) <= co_y_right) & (xi >= co_x_right)))
    # Indizes Zentrum
    indb |= ((abs(xi) < r_min) * (abs(yi) < r_min))
    # Indizes Aussenrand
    indb |= ((xi ** 2 + yi ** 2) >= (r_max) ** 2)
    # Alle Indizes auf 0 setzen
    zi[indb] = 0

    # POLARKOORDINATEN-INTERPOLATION

    rg = np.linspace(r_min, r_max, 100)
    phig = np.linspace(0, 2 * np.pi, 200)
    delta_phi_g = phig[1] - phig[0]

    ri, phii = np.meshgrid(rg, phig)
    xi_pol = ri * np.cos(phii)
    yi_pol = ri * np.sin(phii)

    x_y = np.zeros((len(x), 2))
    x_y[:, 0] = x
    x_y[:, 1] = y

    zi_pol = griddata(x_y, z, (xi_pol, yi_pol), 'linear')
    zi_pol[np.isnan(zi_pol)] = 0

    # TIEFPASS
    filterbreite = np.int(np.floor(0.4 / delta_phi_g))

    zi_pol_extend = np.concatenate((zi_pol[-filterbreite:-1, :],
                                    zi_pol, zi_pol[0:filterbreite - 1, :]),
                                   axis=0)

    zi_pol_extend_f2 = np.zeros(zi_pol_extend.shape)
    for i in range(0, zi_pol_extend.shape[1] - 1):
        zi_pol_extend_f2[:, i] = nd.gaussian_filter1d(
            zi_pol_extend[:, i], filterbreite * r_min / rg[i])

    # ..smoothing over r
    for i in range(0, zi_pol_extend.shape[0] - 1):
        zi_pol_extend_f2[i, :] = nd.gaussian_filter1d(zi_pol_extend_f2[i, :], 3.)

    zi_pol_f2 = zi_pol_extend_f2[
                filterbreite - 1:filterbreite - 1 + zi_pol.shape[0], :]

    x_y = np.zeros((len(xi_pol.flatten()), 2))
    x_y[:, 0] = xi_pol.flatten()
    x_y[:, 1] = yi_pol.flatten()

    zi_f2 = griddata(x_y,
                     zi_pol_f2.flatten(),
                     (xi, yi), 'linear')
    zi_f2[np.isnan(zi_f2)] = 0

    # NULLSETZEN AUSSENBEREICHE

    # Alle Indizes auf 0 setzen
    zi_f2[indb] = 0

    # initialer Tiefpass
    # Hochpass aus Original minus initialer Tiefpass
    zi_f3 = zi - zi_f2

    # ..mask to cut outer rim
    indb_dilated = indb | ((xi ** 2 + yi ** 2) >= (r_max - 2) ** 2)
    zi_f3[indb_dilated] = 0

    zi_f3_fft = np.fft.fftshift(np.fft.fft2(zi_f3))

    size_x_fft = zi_f3_fft.shape[0]
    size_y_fft = zi_f3_fft.shape[1]
    size_x_fft_half = np.floor(size_x_fft / 2) + 1
    size_y_fft_half = np.floor(size_y_fft / 2) + 1
    xi_fft, yi_fft = np.meshgrid(range(0, size_x_fft),
                                 range(0, size_y_fft))

    # Dimmers
    dmm_1 = _normpdf_shaper(xi_fft, yi_fft,
                                 size_x_fft_half,
                                 np.floor(2.3 / 30 * size_x_fft),
                                 size_y_fft_half + np.floor(7. / 30 * size_y_fft),
                                 np.floor(3.5 / 30 * size_y_fft), 0.3, 0)

    dmm_2 = _normpdf_shaper(xi_fft, yi_fft,
                                 size_x_fft_half,
                                 np.floor(2.3 / 30 * size_x_fft),
                                 size_y_fft_half - np.floor(7. / 30 * size_y_fft),
                                 np.floor(3.5 / 30 * size_y_fft), 0.3, 0)

    dmm_3 = _normpdf_shaper(xi_fft, yi_fft,
                                 size_x_fft_half,
                                 np.floor(3.5 / 30 * size_x_fft),
                                 size_y_fft_half + np.floor(15. / 30 * size_y_fft),
                                 np.floor(2.5 / 30 * size_y_fft), 0.3, 0)

    dmm_4 = _normpdf_shaper(xi_fft, yi_fft,
                                 size_x_fft_half,
                                 np.floor(3.5 / 30 * size_x_fft),
                                 size_y_fft_half - np.floor(15. / 30 * size_y_fft),
                                 np.floor(2.5 / 30 * size_y_fft), 0.3, 0)


    # Remove narrow peaks

    peaks = []

    peaks.append({'x': -6.0 + size_x_fft_half, 'y': 0.0 + size_y_fft_half, 'r1': 3.3, 'r2': 5.0})
    peaks.append({'x': -13.0 + size_x_fft_half, 'y': 0.0 + size_y_fft_half, 'r1': 3.1, 'r2': 4.7})
    peaks.append({'x': -19.0 + size_x_fft_half, 'y': 0.0 + size_y_fft_half, 'r1': 2.2, 'r2': 3.0})
    peaks.append({'x': -25.0 + size_x_fft_half, 'y': 0.0 + size_y_fft_half, 'r1': 2.2, 'r2': 3.0})

    # ..add symmetric regions on the right hand side
    for i in range(len(peaks)):
        peak = copy.deepcopy(peaks[i])
        peak['x'] = -peak['x'] + 2.0 * size_x_fft_half
        peaks.append(peak)

    # ..circle objects to plot
    circles = [pylab.Circle((peak['x'], peak['y']), peak['r1'], fill=False, color='w') for peak in peaks]

    # ..remove peaks by interpolating the amplitude and randomizing the phase
    for peak in peaks:
        zi_f3_fft = _fill_fft_circle(peak['x'], peak['y'], peak['r1'], peak['r2'], xi_fft, yi_fft, zi_f3_fft)

    zi_f3_fft *= dmm_1 * dmm_2 * dmm_3 * dmm_4

    zi_f3 = np.real(np.fft.ifft2(np.fft.ifftshift(zi_f3_fft)))

    n_y = np.floor(2. + (13. - n_pup) / 6.)  # ..smoothing in X-direction depends on n_pup

    zi_f3 = nd.median_filter(zi_f3, [2, np.int(n_y)], mode='nearest')

    # Gewichtete Addition aus Tiefpass und gefiltertem Hochpass
    gewicht = zi.max() / zi_f2.max()
    zi = gewicht * zi_f2 + 2. * zi_f3

    zi[zi < 0] = 0

    # ..apply mask again to eliminate features in masked area
    zi[indb] = 0

    return xi, yi, zi

def resize_image(x, y, z, n_grid):
    """
    Rescales given image x,y,z to an image with new resolution
    n_grid x n_grid with NN-interpolation. So no interpolation
    is done and the image is not changed.

    :param x: x position
    :param y: y position
    :param z: intensity
    :param ngrid: number of grid points
    return: x,y,z data
    """
    import numpy as np
    import scipy.ndimage as nd

    xi, yi = np.meshgrid(np.linspace(0, x.shape[1] - 1, n_grid),
                         np.linspace(0, x.shape[0] - 1, n_grid))
    zn = nd.map_coordinates(z,
                            np.concatenate(
                                (yi.reshape(1, -1), xi.reshape(1, -1)), axis=0),
                            order=0,
                            mode='constant').reshape(n_grid, n_grid)
    xn = nd.map_coordinates(x,
                            np.concatenate(
                                (yi.reshape(1, -1), xi.reshape(1, -1)), axis=0),
                            order=1,
                            mode='nearest').reshape(n_grid, n_grid)

    yn = nd.map_coordinates(y,
                            np.concatenate(
                                (yi.reshape(1, -1), xi.reshape(1, -1)), axis=0),
                            order=1,
                            mode='nearest').reshape(n_grid, n_grid)

    return xn, yn, zn

def _fill_fft_circle(x, y, r1, r2, xi_fft, yi_fft, zi_fft):
    """
    A helper function for grid_interpolation2. It modifies the amplitude in a complex 2D fft map
    (zi_fft) inside a circle of a radius r1 centered at (x,y) making it equal to the mean amplitude inside
    a ring with the same center and with inner and outer radii of r1 and r2, respectively.
    The corresponding complex phase is randomized;
    The purpose of the function is to remove peaks in fft map located at (x,y)

    :param x: x position
    :param y: y position
    :param r1: inner circle radius
    :param r2: outer circle radius
    :param xi_fft: x position 2D fft map
    :param yi_fft: y position 2D fft map
    :param zi_fft: intensity 2D fft map
    return: intensity 2D fft map
    """
    import numpy as np

    k = 1.0  # oblateness factor
    R = np.hypot((xi_fft - x) / k, (yi_fft - y) * k)

    ndx = (R > r1) & (R < r2)
    Amean = np.mean(np.abs(zi_fft[ndx]))

    ndx = R < r1
    zi_fft[ndx] = Amean * np.exp(np.random.rand(ndx.sum()) * 2.0 * np.pi * 1j)

    return zi_fft

def _normpdf_shaper(x, y, mu_x, sigma_x, mu_y, sigma_y, threshold, flag):
    """
    generate truncated normpdf

    :param x: x position
    :param y: y position
    :param mu_x: mean of x position
    :param sigma_x: sigma of x position
    :param mu_y: mean of y position
    :param sigma_y: sigma of y position
    :param threshold: filter on threshold
    :param flag: if False, return 1 - Dimmer
    return: Dimmer
    """
    import numpy as np

    mu_vec = np.array([mu_x, mu_y])
    sigma = np.array([[sigma_x ** 2, 0], [0, sigma_y ** 2]])

    sigma_inv = np.linalg.inv(np.array(sigma))
    prefactor = (1.0 / ((2.0 * np.pi) ** (3.0 / 2.0) * np.linalg.det(sigma)))

    u_vec = np.array([x.flatten() - mu_vec[0], y.flatten() - mu_vec[1]])
    wgrid = np.exp(-(
            u_vec[0] ** 2 * sigma_inv[0, 0] + (sigma_inv[1, 0] + sigma_inv[0, 1]) * u_vec[0] * u_vec[1] + u_vec[
        1] ** 2 * sigma_inv[1, 1]) / 2.0)

    wgrid = np.reshape(wgrid.T, x.shape)
    dmm = wgrid * prefactor

    dmm /= dmm.max()
    dmm[dmm > threshold] = threshold
    dmm /= threshold

    if flag == 0:
        dmm = 1 - dmm

    return dmm

def smooth_luer_using_nearby_ffms(luer_data, ffm_modules, ffm_window=5, verbose=False):
    """
    Smooth luer using nearby ffms in the ffm modules by averaging the intensity over each single facet, fit the
    intensity over the facets by taking a rolling median, and compensating the intensity by scaling with the difference
    of the fit.

    :param luer_data: import luer data
    :param ffm_modules: facet id ranges of ffm module
    :param ffm_window: rolling median window size
    :param verbose: switches debug mode (default=False)
    :return: dataframe containing ffm-based smoothed luer intensity data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # loop through all modules
    for ffm in ffm_modules['facet_id_ranges']:
        # consider range of facets in the ffm module
        _subset = (luer_data['facet'] >= ffm[0]) & (luer_data['facet'] <= ffm[1])

        # calculate the mean of each facet (average over dots)
        mean_intensity_facets = luer_data[_subset][['facet', 'intensity']].groupby(['facet']).mean()
        # fit the data using a rolling median with a to be defined window size (standard 5 facets)
        fit = mean_intensity_facets.rolling(ffm_window, center=True, min_periods=1).median()

        # loop over each facet
        for facet in mean_intensity_facets.index.unique():

            # calcualte the relative difference between the facet mean-intensity with the fit
            rel_intensity_diff = fit.loc[facet].values[0] / mean_intensity_facets.loc[facet].values[0]

            # compensate for the difference by scaling the intensity with the relative difference (except zeros)
            luer_data.loc[luer_data['facet'] == facet, 'intensity'] *= rel_intensity_diff \
                if mean_intensity_facets.loc[facet].values[0] > 0 else 0

    return luer_data