# -*- coding: utf-8 -*-
"""
roi_io.py
Authors: RWKL
Date:  2019-05-13

Roi_io contains functionality to read and write ROI definitions from json files into a dict format.
The dictionary contains per unique key one ROI. For ewach ROI, the following properties are defined:
- 'type': 'ROI'
- 'format': 'polar' or 'polygon'
- 'UCC': 1 means under change control, 0 is not under change control

Depending on the format:
for polar:
- 'r_min': the minimum radius (edge excluded, relative radial position)
- 'r_max': the maximum radius (edge included, relative radial position)
- 'phi_min': the minimum angle (edge excluded, in degrees)
- 'phi_max': the maximum angle (edge included, in degrees)

for polygon:
- 'positions': [[x0, y0], [x1, y1], ..., [xn, yn]] (in absolute coordinates, x0 != xn)
"""

import json
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def read_rois_from_json(json_file, verbose=False):
    """
    Read rois from json file and return it as a dict. 
    It ignores all json objects of different tpyes than 'ROI'
    
    :param json_file: full path to json file
    :param verbose: switches debug mode (default=False)
    :return: dict containing the ROIs
    :raises: exception in case file cannot be opened
    :raises: exception in case json cannot be parsed
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        with open(json_file, 'r') as fp:
            try:
                roi_dict = json.load(fp)
            except Exception as e:
                raise e

        keys_to_delete = []
        for key, item in roi_dict.items():
            if (type(item) is not dict) | ('type' not in item.keys()) | (item['type'] != 'ROI'):
                keys_to_delete.append(key)

        for key in keys_to_delete:
            del roi_dict[key]

    except Exception as e:
        raise e
        
    return roi_dict


def write_rois_to_json(roi_dict, json_file, verbose=False):
    """
    Writes roi dictionary to a json file.
    
    :param roi_dict: The dictionary containing the ROIs
    :param json_file: the pfile in which the ROIs should be stored
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        with open(json_file, 'w') as fp:
            json.dump(roi_dict, fp, indent=4)

    except Exception as e:
        raise e


def read_spiderweb_kpis_from_json(json_file, verbose=False):
    """
    Read spiderweb KPI mapping from json file and return it as a dict.

    :param json_file: full path to json file
    :param verbose: switches debug mode (default=False)
    :return: dict containing the spiderweb KPI mapping
    :raises: exception in case file cannot be opened
    :raises: exception in case json cannot be parsed
    """

    do_it.do_it_verbose(currentframe(), verbose)
    try:
        with open(json_file, 'r') as fp:
            try:
                spiderweb_mapping = json.load(fp)
            except Exception as e:
                raise e

        keys_to_delete = []

        for key, item in spiderweb_mapping.items():
            # Reminder: syntax as below ('string is string') is not py27 compatible
            # if (type(item) is not dict) | ('type' not in item.keys()) | (item['type'] is 'ROI_KPI'):
            if (type(item) is not dict) | ('type' not in item.keys()) | (item['type'] != 'ROI_KPI'):
                keys_to_delete.append(key)

        for key in keys_to_delete:
            del spiderweb_mapping[key]

    except Exception as e:
        raise "{}: {}".format(currentframe(), e)

    return spiderweb_mapping
