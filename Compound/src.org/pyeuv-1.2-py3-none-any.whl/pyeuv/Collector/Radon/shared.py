# -*- coding: utf-8 -*-
"""
radon_roi.py
Authors: RWKL
Date:  2019-05-13

Radon shared contains a number of common functionality on luer files
"""

import numpy as np
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def get_normalized_intensity(luer_data, verbose=False):
    """
    Returns the normalized intensity, such that the sum of all intensities equals 1.0
    
    :param luer: dictionary containing a dataframe with luer image data and a format type specification
    :return: dataframe containing normalized intensities
    """

    do_it.do_it_verbose(currentframe(), verbose)

    return luer_data['intensity'] / luer_data['intensity'].sum()


def get_normalized_radius(luer_df, verbose=False):
    """
    Calculate the normalized radius, given a dataframe with x, y, intensity.
    The normalization sets the maximum radius to 1.0
    
    :param luer_df: dataframe (x, y, intensity) of a luer file
    :param verbose: switches debug mode (default=False)
    :return: normalized radius
    """

    do_it.do_it_verbose(currentframe(), verbose)

    r = get_radius(luer_df, verbose=verbose)
    r = r / np.max(r)
    return r


def get_radius(luer_df, verbose=False):
    """
    Calculate the radius, given a dataframe with x, y, intensity.
    
    :param luer_df: dataframe (x, y, intensity) of a luer file
    :param verbose: switches debug mode (default=False)
    :return: radius
    """

    do_it.do_it_verbose(currentframe(), verbose)

    r = np.sqrt(np.power(luer_df.x, 2) + np.power(luer_df.y, 2))
    return r


def get_phi(luer_df, verbose=False):
    """
    Calculate the phi coordinate in degrees for each datapoint of the luer file.
    3 oc equals 0 degrees. 12 oc is 90 degrees, 6 oc is 270 degrees etc. 
    
    :param luer_df: dataframe (x, y, intensity) of a luer file
    :param verbose: switches debug mode (default=False)
    :return: normalized radius
    """

    do_it.do_it_verbose(currentframe(), verbose)

    import math
    
    if 'x' not in luer_df.keys() or 'y' not in luer_df.keys():
        raise Exception('Luer file does not contain the expected keys. Expected: \'x\', \'y\'. Found: {}'.format(luer_df.keys()))
    
    phi = np.arctan2(luer_df.y, luer_df.x) * (180 / math.pi)
    phi = phi.to_frame(name='phi')
    
    phi[phi['phi'] < 0] += 360
    
    return phi


def phi_to_hour(phi, verbose=False):
    """
    Convert phi to an hour representation.
    phi = 0 becomes 3.0, phi = 15 becomes 2.5 etc.

    :param phi: float between 0-360, 0 at 3oc, running counterclockwise
    :param verbose: switches debug mode (default=False)
    :return: float value between 0-12 indicating the time on a clock
    """

    do_it.do_it_verbose(currentframe(), verbose)

    hour = (-phi / 360 * 12 + 15) % 12
    return hour


