# -*- coding: utf-8 -*-
"""
radon_scaling.py
Authors: RWKL, JJCW
Date:  2019-05-12

This module releases functions for different scaling algorithms for radon images.
It includes various implementations for slie/dt based scaling, and intensity based scaling

New functions (DAAU): get_scaling_factor_from_intensities, pre_scale_reflectivity, determine_approx_position_peak, narrow_down_region_near_peak
gaussian, fit_gaussian_peak, determine_stain_area, calculate_intensity_ratio
Date:  2020-06-02

"""

import pandas as pd
import numpy as np
import pyeuv.Shared.shared as shared
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions
from scipy.stats import norm
from scipy.optimize import curve_fit

THRESHOLD_UPPER_DEF = 110.0


def get_scaling(client, source_id, luer_timestamps, reflectivity_data=None, scaling_method='sliedt_interpolate',
                threshold_upper=THRESHOLD_UPPER_DEF,
                use_sg_filtering=False, verbose=False, icrm = False):
    """
    Return the scaling factor for a luer file. Different scaling methods can be applied.
    Implemented scaling methods are:

    - no_scaling: returning 1.0
    - sliedt_ffill: forward fill the slie/dt to the luer timestamp. In case no slie/dt is available, return 1.0
    - sliedt_interpolate : linear (in time dimension) interpolate slie/dt at the luer timestamp.
    - sliedt_nearest : nearest slie/dt value to the luer timestamp.

    :param client: instance of Network connection (UserLANClient)
    :type client: instance
    :param source_id: source number (eg. s44481)
    :type source_id: str
    :param luer_timestamps: timestamp of LUER
    :type luer_timestamps: list of pandas timestamps
    :param reflectivity_data: dataframe with reflectivity values in the 'slie_dt' column, and timestamps in the index
    :type reflectivity_data: pandas Dataframe
    :param scaling_method: method for scaling
    :type threshold_upper: string
    :raises ValueError: not supported scaling method
    :param threshold_upper: upper threshold for reflectivity
    :type threshold_upper: float
    :param use_sg_filtering: switch to turn on the sg filter for slie/dt (default=False)
    :type use_sg_filtering: boolean
    :param verbose: switches debug mode (default=False)
    :param icrm: use icrm data instead of SLIE/DT
    :return: scaling factor ~1.0
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        if not isinstance(luer_timestamps, list):
            luer_timestamps = [luer_timestamps]

        if scaling_method == 'no_scaling':
            scaling_factor = pd.DataFrame(index=luer_timestamps, data=np.ones(len(luer_timestamps)),
                                          columns=['scaling_factor'])

        elif scaling_method in ['sliedt_ffill', 'sliedt_interpolate', 'sliedt_nearest']:
            scaling_factor = get_scaling_factor_from_sliedt(client, source_id, luer_timestamps,
                                                            reflectivity_data=reflectivity_data,
                                                            method=scaling_method,
                                                            threshold_upper=threshold_upper,
                                                            use_sg_filtering=use_sg_filtering,
                                                            verbose=verbose,
                                                            icrm=icrm)
        else:
            raise Exception('Scaling method \'{}\' not implemented'.format(scaling_method))

        if verbose:
            print('scaling factor:', scaling_factor)
    except Exception as e:
        print(e)
        print('No scaling applied')
        scaling_factor = pd.DataFrame(index=luer_timestamps, data=np.ones(len(luer_timestamps)),
                                      columns=['scaling_factor'])

    return scaling_factor


def get_scaling_factor_from_intensities(luer_intensity, reference_intensity, ref_scaling_method = 'clean_area',
                                        min_bound = 0.619, max_bound = 2.5, n_bins = 150, min_bin =3,
                                        percentage_max = 0.45, fit_min_x = 0.5, fit_max_x = 1.7):
    """
    Calculates the calibration factor by computing the average intensity ratio (over all pixels) between the currect
    luer and the reference. It does this by two methods:
     1) taking the median of the intensity ratios bounded by a min and max value.
     2) fitting the peak in the reflectivity histogram due to non-stains (=clean area) by a Gaussian, and taking the
     mu of the peak.

    :param luer_intensity: intensity map of the current luer
    :param reference_intensity: intensity map of the reference
    :param ref_scaling_method: method to scale the reference to the right global reflectivity value
    :param min_bound: minimum value for intensity
    :param max_bound: maximum value for intensity
    :param n_bins: number of bins for the histogram
    :param min_bin: minimum number of bins of a peak in the histogram to be counted as a meaningful
    :param percentage_max: percentage of the maximum the histogram, used to recognize the peak
    :param fit_min_x: the lower bound x-values (reflectivity) for fitting
    :param fit_max_x: the upper bound x-values (reflectivity) for fitting
    :return:
        parameters: dataframe with various values associated to the scaling method
    """

    reflectivity = calculate_intensity_ratio(luer_intensity, reference_intensity)

    applied_fit = False

    if ref_scaling_method == 'clean_area':

        # consider only the clean area of the collector between manually selected 'min_bound' and 'max_bound'
        peak_reflectivity = reflectivity.loc[(reflectivity > min_bound) & (reflectivity < max_bound)].median()

        # Make histogram of reflectivity per pixel
        counts, bins = np.histogram(reflectivity, bins=np.linspace(0, max_bound, n_bins))
        bins = bins[:-1]

    elif ref_scaling_method == 'clean_area_offset':

        # Use the median offset between 98% percentile and center of the non-stain area to determine the approximate
        # position of the clean-area reflectivity. See EPS D000884328-00
        peak_reflectivity = reflectivity.quantile(.98) - 0.1406

        # Make histogram of reflectivity per pixel
        counts, bins = np.histogram(reflectivity, bins=np.linspace(0, max_bound, n_bins))
        bins = bins[:-1]

    elif ref_scaling_method == 'clean_area_98p':

        # Use the 98% percentile to approximate the position of the clean-area reflectivity. See EPS D000884328-00
        peak_reflectivity = reflectivity.quantile(.98)

        # Make histogram of reflectivity per pixel
        counts, bins = np.histogram(reflectivity, bins=np.linspace(0, max_bound, n_bins))
        bins = bins[:-1]

    elif 'clean_area_auto' in ref_scaling_method:
        # Make histogram of reflectivity per pixel
        counts, bins = np.histogram(reflectivity, bins=np.linspace(0, max_bound, n_bins))
        bins = bins[:-1]

        # Determine the distribution of the selected pixels and determine the approximate position of the peak
        approx_position_peak = determine_approx_position_peak(counts, bins, min_bound, percentage_max)

        # In case of multiple peaks, select the one most to the left
        approx_position_peak = narrow_down_region_near_peak(counts, bins, approx_position_peak)

        if len(approx_position_peak) < min_bin:
            # not enough info, apply same method as 'clean_area'
            peak_reflectivity = reflectivity.loc[(reflectivity > min_bound) & (reflectivity < max_bound)].median()
            applied_fit = False
        else:
            # Extend the approx_position_peak fitting range to the maximum reflectivity value
            fit_range = np.arange(min(approx_position_peak), len(bins), 1)
            # Fit a Gaussian distribution on the clean-area reflectivity peak
            peak_reflectivity, error_peak, sigma_peak, error_sigma, amplitude_peak, error_amplitude, popt, perr = \
              fit_gaussian_peak(counts, bins, reflectivity, fit_range, min_bound, fit_min_x, fit_max_x)

            # Detect the stains using the intersection of fit with the delta between the fit and the data.
            df_remainder, min_bound = determine_stain_area(counts, bins, peak_reflectivity, sigma_peak, popt)
            applied_fit = True
    else:
        raise Exception('Unknown reference scaling method {}'.format(ref_scaling_method))

    parameters = {'counts' : counts,
                  'bins': bins,
                  'min_bound': min_bound,
                  'max_bound': max_bound,
                  'fit_min_x': fit_min_x,
                  'fit_max_x': fit_max_x,
                  'peak_reflectivity': peak_reflectivity,
                  'applied_fit': False,
                  'ref_scaling_method': ref_scaling_method}
    if applied_fit:
        parameters['applied_fit'] = True
        fit_parameters=  {'error_peak': error_peak,
                          'sigma_peak': sigma_peak,
                          'error_sigma': error_sigma,
                          'amplitude_peak': amplitude_peak,
                          'error_amplitude': error_amplitude,
                          'popt': popt,
                          'perr': perr,
                          'gaussian': gaussian,
                          'df_remainder' : df_remainder,
                          'fit_range' : fit_range}
        parameters.update(fit_parameters)

    return parameters


def pre_scale_reflectivity(reflectivity):
    """
    Filter out hot-spots by taking values below the 98% percentile and than find the approximate peak of the distribution
    by considering an offset, based on population data.

    :param reflectivity: the raw reflectivity values
    :return:
        pre_calibration_factor: ratio used for the initial reference scaling
    """

    # Consider the 'clean area' peak around 100% (98% percentile at 114%, with spread of ~14%). See EPS D000884328-00
    # N.B. fails if the peak width is large!
    maximum_reflectivity = reflectivity.quantile(0.98)
    pre_calibration_factor = maximum_reflectivity / 1.1406

    return pre_calibration_factor


def determine_approx_position_peak(counts, bins, min_bound, percentage_max):
    """
    Determine approximately where the peak of the non-stain area is by considering a minimum for the reflectivity value
    and a minimum for the counts (> above percentage_max).

    :param counts: the counts of the histogram
    :param bins: the bins of the histogram
    :param min_bound: lower limit of clean area in terms of reflectivity
    :param percentage_max: percentage of the maximum the histogram, used to recognize the peak
    :return:
        approx_position_peak: indices of approximate location of the non-stain peak
    """

    approx_position_peak = np.where((bins > min_bound) & (counts > percentage_max * max(counts[1:])))[0]

    return approx_position_peak


def narrow_down_region_near_peak(counts, bins, approx_position_peak, n_avg = 3):
    """
    Smooth the data and find the first peak from the right, and - if present - a local minimum left of the peak.

    :param counts: the counts of the histogram
    :param bins: the bins of the histogram
    :param approx_position_peak: indices of approximate location of the non-stain peak
    :param n_avg: window for smoothing
    :return:
        approx_position_peak: indices of approximate location of the non-stain peak
    """
    # smooth the data and find peaks
    data_smoothed = pd.DataFrame(index = approx_position_peak)
    data_smoothed['bins'] = bins[approx_position_peak]
    data_smoothed['counts'] = counts[approx_position_peak]
    data_smoothed['counts_smoothed'] = data_smoothed['counts'].rolling(n_avg, center=True).mean().values
    data_smoothed['counts_diff'] = data_smoothed.counts_smoothed.diff()
    data_smoothed['idx'] = data_smoothed.index
    data_smoothed['idx_diff_pos'] = data_smoothed.loc[data_smoothed['counts_diff'] > 0].idx.diff()
    data_smoothed['idx_diff_neg'] = data_smoothed.loc[data_smoothed['counts_diff'] < 0].idx.diff()

    # Find the peak most to the right which has at least two consecutive points of decreasing values left of the peak
    peak_left = data_smoothed.loc[(data_smoothed.counts_diff > 0) & (data_smoothed.idx_diff_pos == 1)].bins
    if not peak_left.empty:
        peak = peak_left.iloc[-1]
        # Find the local minimum at the left hand side of the peak which has at least two consecutive points of
        # increasing values left of the peak; if present, correct approx_position_peak
        bottom_left = data_smoothed.loc[(data_smoothed.bins < peak) & (data_smoothed.counts_diff < 0) & \
                                        (data_smoothed.idx_diff_neg == 1)].bins
        if not bottom_left.empty:
            bottom = bottom_left.iloc[-1]
            approx_position_peak_updated = data_smoothed.loc[data_smoothed.bins > bottom].index.values
        else:
            approx_position_peak_updated = data_smoothed.index
    else:
        approx_position_peak_updated = data_smoothed.index

    return approx_position_peak_updated


def gaussian(x, A, x0, sig):
    """
    Calculate a Gaussian curve using given parameters and the position on the x-axis.

    :param x: position on the x-axis
    :param A: amplitude
    :param x0: off-set in x-direction
    :param sig: sigma of the distribution
    :return:
        funct: y-value belong to the x-value
    """
    funct = A * np.exp(-(x - x0) ** 2 / (2 * sig ** 2))

    return funct


def fit_gaussian_peak(counts, bins, reflectivity, fit_range, min_bound, fit_min_x, fit_max_x):
    """
    Fit the Gaussian peak of the histogram.

    :param counts: the counts of the histogram
    :param bins: the bins of the histogram
    :param reflectivity: the raw reflectivity values
    :param fit_range: range to be fitted
    :param min_bound: lower limit of clean area in terms of reflectivity
    :param fit_min_x: the lower bound x-values (reflectivity) for fitting
    :param fit_max_x: the upper bound x-values (reflectivity) for fitting
    :return:
        peak_reflectivity: the reflectivity at the peak of the histogram
        error_peak: the error in the value of peak_reflectivity
        sigma_peak: sigma of the peak
        amplitude_peak: amplitude of the peak
        popt: final fitting parameters
        pcov: additional data on fitting (incl. errors)
    """

    # Do initial fit to find initial parameters extended fit
    mu, sigma = norm.fit(reflectivity.loc[reflectivity > min_bound])

    bins_fit = bins[fit_range]
    counts_fit = counts[fit_range]
    df_bins_counts = pd.DataFrame(index=bins_fit, data=counts_fit)

    # Set parameters bounds for A (amplitude), x0 (position), and sig (sigma)
    param_bounds = ([0, fit_min_x, -1], [1.05 * max(df_bins_counts[0]), fit_max_x, 1])

    # Fit the data
    popt, pcov = curve_fit(gaussian, bins_fit, counts_fit, p0=[max(counts_fit), mu, sigma], bounds=param_bounds)
    # Calculate error of parameters
    perr = np.sqrt(np.diag(pcov))

    peak_reflectivity = popt[1]
    error_peak = perr[1]
    sigma_peak = abs(popt[2])
    error_sigma = abs(perr[2])
    amplitude_peak = abs(popt[0])
    error_amplitude = abs(perr[0])

    return peak_reflectivity, error_peak, sigma_peak, error_sigma, amplitude_peak, error_amplitude, popt, pcov


def determine_stain_area(counts, bins, peak_reflectivity, sigma_peak, popt, n_avg = 4):
    """
    Calculate the stain region using the intersection of the averaged remainder of the data after subtraction of the
    Gauss fit and the fit.

    :param bins: the bins of the histogram
    :param peak_reflectivity: the reflectivity at the peak of the histogram
    :param sigma_peak: sigma of the peak
    popt: final fitting parameters
    :param n_avg: number of datapoint to average/smooth over
    :return:
        df_remainder: remainder of histogram after subtraction of the fit
        min_bound: lower limit of clean area in terms of reflectivity
    """

    # Determine initial bounds
    min_bound_sigma = peak_reflectivity - 1 * sigma_peak
    min_bound_3sigma = peak_reflectivity - 3 * sigma_peak

    # Determine delta between histogram and fit
    remainder = counts[1:] - gaussian(bins[1:], *popt)
    df_remainder = pd.DataFrame(index=bins[1:], data=remainder, columns=['delta_counts'])

    # Smooth data
    df_remainder['delta_counts_smoothed'] = df_remainder.loc[df_remainder.index < peak_reflectivity].rolling(n_avg, \
                                                                                                center=True).mean()

    range_bounds = (df_remainder.index > min_bound_3sigma) & (df_remainder.index < min_bound_sigma)
    df_bins = df_remainder.loc[range_bounds].index
    df_counts = df_remainder.loc[range_bounds, 'delta_counts_smoothed']

    # Determine intersection of remainder and the fit
    min_bound = df_bins[np.argmin(abs(gaussian(df_bins, *popt) - df_counts))]

    return df_remainder, min_bound

def get_min_max_sigma_values():
    """
    Get values for the min and max sigma population data of the width of the reflectivity histogram. See EPS D000884328-00

    :return: min and max sigma estimates of the width of the reflectivity histogram
    """
    min_sigma_value = 4.73 / 100 # Value based on 10% percentile sigma's clean collector analysis,
    max_sigma_value = 8.43 / 100 # Value based on 90% percentile sigma's clean collector analysis
    mean_sigma_value = 6.06 / 100  # Value based on 90% percentile sigma's clean collector analysis

    return min_sigma_value, max_sigma_value, mean_sigma_value

def calculate_min_max_compensation_factor(peak_reflectivity, sigma_peak, ref_scaling_method, sigma_correction_factor = 2):
    """
    Calculate the compensation factor for the Gaussian fit for the case of a smaller peak width (loss = upper bound / max),
    and larger or maximum peak width (loss = lower limit / min).

    :param peak_reflectivity: the reflectivity at the peak of the histogram
    :param sigma_peak: sigma of the peak
    :param ref_scaling_method: method to scale the reference to the right global reflectivity value
    :param sigma_correction_factor: select at what sigma level to fixate the correction (e.g. 1 sigma or 2 sigma)
    :return: compensation_factor: factor to compenate the Gaussian peak position with
    """

    min_sigma_value, max_sigma_value, mean_sigma_value = get_min_max_sigma_values()

    initial_peak_reflectivity = 1
    if ref_scaling_method == 'clean_area_auto_max':
        initial_sigma_peak = min_sigma_value if min_sigma_value < sigma_peak / peak_reflectivity * initial_peak_reflectivity \
            else sigma_peak / peak_reflectivity * initial_peak_reflectivity
    if ref_scaling_method == 'clean_area_auto_mean':
        initial_sigma_peak = mean_sigma_value if mean_sigma_value < sigma_peak / peak_reflectivity * initial_peak_reflectivity \
            else sigma_peak / peak_reflectivity * initial_peak_reflectivity
    if ref_scaling_method == 'clean_area_auto_min':
        initial_sigma_peak = max_sigma_value if max_sigma_value < sigma_peak/peak_reflectivity * initial_peak_reflectivity \
            else sigma_peak/peak_reflectivity*initial_peak_reflectivity
    compensation_factor = (1 + sigma_correction_factor * sigma_peak / peak_reflectivity) / \
                          (1 + sigma_correction_factor * initial_sigma_peak / initial_peak_reflectivity)

    return compensation_factor, initial_peak_reflectivity, initial_sigma_peak

def determine_location_initial_distribution(bins, counts, initial_peak_reflectivity, initial_sigma_peak):
    """
    Correct the Gaussian distribution based on the intial fit

    :param bins: bins of the histogram
    :param counts: counts of the histogram
    :param initial_peak_reflectivity: center of initial distribution
    :param initial_sigma_peak: sigma_peak of initial distribution
    :return:
        popt: final fitting parameters
    """

    # calculate bin index of fit at center of first peak
    nearest_bin = np.abs(bins[1:] - initial_peak_reflectivity).argmin()
    desired_max = np.mean(counts[nearest_bin - 2:nearest_bin + 2])

    # solve amplitude for given peak
    scan_abs_input = np.linspace(desired_max * 0.5, desired_max * 2, 200)
    result_peaks = gaussian(bins[1:][nearest_bin], *[scan_abs_input, initial_peak_reflectivity, initial_sigma_peak])
    nearest_max = np.abs(result_peaks - desired_max).argmin()

    popt = [scan_abs_input[nearest_max], initial_peak_reflectivity, initial_sigma_peak]

    return popt

def calculate_intensity_ratio(luer_intensity, reference_intensity):
    """
    This function calculates the reflectivity based on the intensity ratio of the luer with its reference.

    :param luer_intensity: intensity of luer
    :param reference_intensity: intensity of reference luer
    return
        intensity_ratio: the intensity ratio
    """

    intensity_ratio = (luer_intensity / reference_intensity).loc[reference_intensity != 0]

    return intensity_ratio

def get_scaling_factor_from_sliedt(client, source_id, luer_timestamps, reflectivity_data=None,
                                   method='sliedt_interpolate',
                                   threshold_upper=THRESHOLD_UPPER_DEF,
                                   use_sg_filtering=False, verbose=False, icrm = False):
    """
    This function retrieves scaling_factor for a LUER measurement timestamp.

     1. if there's no collector swap signal ; return 1.0
     2. if there's no SLIE/DT measurement between collector swap and LUER measurement; return 1.0
     3. remove invalid SLIE/DT data (above threshold_upper)

     4.

      a. if method is 'sliedt_interpolate', linear interpolate SLIE/DT to luer timestamps (in the time domain)
      b. if method is 'sliedt_nearest', take SLIE/DT nearest to luer timestamps
      c. if method is 'sliedt_ffill', continue at next step, since this step will perform it implicitly

     5. forward fill the SLIE/DT data to the luer timestamps after the last SLIE/DT data
     6. backward fill SLIE/DT to the luer timestamps before the first SLIE/DT data

    You can choose SG filtered and non SG-filtered SLIE/DT

    :param client: instance of Network connection (UserLANClient)
    :type client: instance
    :param source_id: source number (eg. s44481)
    :type source_id: str
    :param luer_timestamps: timestamp of LUER
    :type luer_timestamps: pandas timestamp
    :param reflectivity_data: dataframe with reflectivity values in the 'slie_dt' column, and timestamps in the index
    :type reflectivity_data: pandas Dataframe
    :param method: method of mapping SLIE/DT to the luer timestamps (default:'interpolate')
    :param threshold_upper: upper threshold for reflectivity
    :type threshold_upper: float
    :param use_sg_filtering: switch to turn on the sg filter for slie/dt (default=False)
    :type use_sg_filtering: boolean
    :param verbose: switches debug mode (default=False)
    :param icrm: use icrm data instead of SLIE/DT
    :type icrm: boolean
    :return: dataframe with scaling factors [0 - threshold_upper/100]
    :raises Exception: data retrieval from influx fails.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # signal for slie_dt depending on use_sg_filtering
    slie_dt_signal_dict = get_sliedt_signal_dict(use_sg_filtering = use_sg_filtering, icrm = icrm)

    try:
        scaling_factors = pd.DataFrame(columns=['timestamps'], index=luer_timestamps,
                                       data=luer_timestamps)

        if reflectivity_data is None:
            current_collector = shared.get_current_collector(client, source_id, luer_timestamps[0], verbose=verbose)
            reflectivity_data = client.get_signals_dict(slie_dt_signal_dict, source_id,
                                                        from_time=current_collector.start,
                                                        to_time=current_collector.end)
        if reflectivity_data.empty:
            # No SLIE/DT measurement for current collector
            scaling_factors['scaling_factor'] = 1.0
        else:
            # We have SLIE/DT measurement for the current collector, before the luer measurement
            reflectivity_data = reflectivity_data[reflectivity_data['slie_dt'] < threshold_upper]
            if reflectivity_data.empty:
                # all measurements are above threshold (means all invalid)
                scaling_factors['scaling_factor'] = 1.0
            else:
                # Now we have valid SLIE/DT for the current collector
                # merge it with the luer timestamps and determine the SLIE/DT at the luer timestamps
                scaling_factors = scaling_factors.join(reflectivity_data, how='outer')

                if method == 'sliedt_interpolate':
                    scaling_factors.slie_dt.interpolate(method='time', inplace=True)

                elif method == 'sliedt_nearest':
                    scaling_factors.slie_dt.interpolate(method='nearest', inplace=True)

                # forward fill at the start of the collector
                scaling_factors.slie_dt.ffill(inplace=True)

                # backward fill at the start of the collector
                scaling_factors.slie_dt.bfill(inplace=True)

                scaling_factors.dropna(inplace=True)

                scaling_factors['scaling_factor'] = scaling_factors.slie_dt / 100.0
    except Exception as e:
        if verbose:
            print('Error:', e)
        # set default values before returning
        scaling_factors = pd.DataFrame(columns=['scaling_factor'], index=[luer_timestamps])
        scaling_factors['scaling_factor'] = 1.0

    if verbose:
        print("Scaling factor for LUERs calculated.")

    return scaling_factors['scaling_factor']


def get_sliedt_signal_dict(use_sg_filtering=False, verbose=False, icrm = False):
    """
    Returning a dictionary with 'reflectivity' as the key, and the slie/dt signal name as value.
    The slie/dt signal name depends on using the SG filtering.

    :param use_sg_filtering: use / skip SG filter for slie/dt (default=False: skip SG filter)
    :type use_sg_filtering: boolean
    :param verbose: switches debug mode (default=False)
    :param icrm: use icrm data instead of SLIE/DT
    :type icrm: boolean
    :return: dictionary with 'reflectivity' as key, and the influx signal name as value
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if use_sg_filtering:
        slie_dt_signal = 'Collector._SLIE_DT_SG_Norm'
    else:
        slie_dt_signal = 'Collector._SLIE_DT_Norm'
    if icrm:
        slie_dt_signal = 'Scanner.OCRM_CollectorLifetimeRelativeReflectivity'

    slie_dt_signal_dict = {'slie_dt': slie_dt_signal}

    return slie_dt_signal_dict
