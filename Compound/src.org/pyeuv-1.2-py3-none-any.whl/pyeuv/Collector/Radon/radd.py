import numpy as np
import pandas as pd
from skimage import measure
from scipy.interpolate import griddata
import os
import json
import pickle
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from skimage.filters import threshold_isodata

from pyeuv.Collector.Radon.radon_plotting import plot_luer
from pyeuv.EUVDashboard.clients import UserLANClient


def detect_split_off_roi(roi_nr_new, max_roi_nr_new):
    """
    If roi is splitted in 2 both rois should get a new number

    :param max_roi_nr_new: the current max roi nr for the new rois
    :param roi_nr_new: the original roi nr new
    :return: updated roi_nr_new, max_roi_nr_new
    """

    roi_nr_new_groupby = roi_nr_new.groupby(roi_nr_new)
    for _, group in roi_nr_new_groupby:
        if group.count() > 1:
            for i in group.index:
                max_roi_nr_new = max_roi_nr_new + 1
                roi_nr_new.loc[i] = max_roi_nr_new
    return roi_nr_new, max_roi_nr_new


def deal_with_zero_crossing(data):
    """
    Function to solve the min max calculation of hour position
    For example if the roi is from 11 to 1 hour then min = 1 and max = 11
    Solved by converting all values left of 0 to minus values

    :param data: hour positions of dots within roi
    :return: updated hour positions of dots within roi
    """

    if (int(data.max()) == 11) & (int(data.min()) == 0):
        # find the correct max hour
        # find the jump in the hour
        correct_hour_max = np.array(sorted(data)[:-1])[np.diff(np.unique(sorted(data))) > 1]
        # could be the case for a roi around the cone
        # TODO: make roi detection around cone smarter, do something with it
        if len(correct_hour_max) > 1:
            data = np.array([i - 12 if i > correct_hour_max[-1] else i for i in data])
        else:
            data = np.array([i - 12 if i > correct_hour_max else i for i in data])
    return data


def extract_pixel_value_history_per_roi(pixels_in_rois_dict, images_all):
    """
    Get for all dots in rois the reflectivity of all history LUERs

    :param pixels_in_rois_dict: keys are rois, values are coordinates
    :param images_all: dictionary with x,y as keys and intensity as value
    :return: a dataframe with the keys and reflectivities
    """

    key_list = []
    value_list = []
    # loop over all previous images
    for image_id in images_all:
        image_data = images_all[image_id]
        # loop over all rois and keys inside the roi
        for j in pixels_in_rois_dict:
            key_list.append(image_data.loc[pixels_in_rois_dict[j]].index.values)
            value_list.append(image_data.loc[pixels_in_rois_dict[j]].reflectivity.values)

    # flatten the lists
    value_list = [item for items in value_list for item in items]
    key_list = [item for items in key_list for item in items]
    pixel_value_history_per_roi_df = pd.DataFrame()
    pixel_value_history_per_roi_df['key'] = key_list
    pixel_value_history_per_roi_df['value'] = value_list
    pixel_value_history_per_roi_df = pixel_value_history_per_roi_df.astype({'value': float})
    return pixel_value_history_per_roi_df


def extract_info_from_ts(keys_in_rois_dict, images_all, n_clusters=2):
    """
    Extract info from ts
    1. Put al pixel values inside rois into a df
    2. Cluster rois into n_clusters

    :param images_all: x, y, intensity_scaled of all previous images
    :param n_clusters: number of cluster to cluster the data in
    :param keys_in_rois_dict: keys are rois, values are coordinates
    :return: clusters
    """

    # then clustering doesn't work
    if np.sum([len(value) for key, value in keys_in_rois_dict.items()]) < 2:
        return np.nan, np.nan

    pixel_value_history_per_roi_df = extract_pixel_value_history_per_roi(keys_in_rois_dict, images_all)

    def largest_drop(x):
        return x.diff().sort_values(ascending=True).values[0]

    def second_largest_drop(x):
        return x.diff().sort_values(ascending=True).values[1]

    df_aggr = pixel_value_history_per_roi_df.groupby('key')['value'].agg([largest_drop, second_largest_drop])
    df_aggr_scaled = StandardScaler().fit_transform(df_aggr)
    y_pred_kmeans = KMeans(n_clusters=n_clusters).fit_predict(df_aggr_scaled)

    # TODO: this last part could be smarter
    # assign drips (biggest drop) and stains (smallest drop)
    df_aggr['cluster'] = y_pred_kmeans
    df_aggr_groupby_mean = df_aggr.groupby('cluster').mean()['largest_drop']
    if df_aggr_groupby_mean[0] > df_aggr_groupby_mean[1]:
        # cluster 1 has a bigger drop than cluster 0
        y_pred_kmeans = ['drip' if i == 1 else 'stain' for i in y_pred_kmeans]
    else:
        y_pred_kmeans = ['drip' if i == 0 else 'stain' for i in y_pred_kmeans]

    cluster_per_feature = {}
    for unique_y in np.unique(y_pred_kmeans):
        for i, feature in enumerate(df_aggr.index):
            if y_pred_kmeans[i] == unique_y:
                cluster_per_feature[feature] = y_pred_kmeans[i]

    clusters = {}
    for i in keys_in_rois_dict:
        roi_clusters = []
        for key in cluster_per_feature.keys():
            if key in keys_in_rois_dict[i]:
                roi_clusters.append(cluster_per_feature[key])
        clusters[i] = roi_clusters
    return clusters


def calc_growth(parent_return, prev_rois, keys_in_roi, intensity_scaled):
    """
    Calculate the growth of the roi
    If totally new --> growth is current size
    If from 1 parent --> compare it to the size of the parent
    TODO: bit strange if it's a split off of 1 parent
    If from 2 parents --> compare it to the sum of the 2 parents

    :param intensity_scaled: intensities of all the pixels on a roi
    :param parent_return: parent of the roi
    :param prev_rois: rois in previous luer
    :param keys_in_roi: keys in roi
    :return: the calculated growth
    """

    if len(parent_return) == 1:
        len_prev_pixels = len(prev_rois['reflectivity'][parent_return[0]])
        return (len(keys_in_roi) - len_prev_pixels) / len(intensity_scaled) * 100
    elif len(parent_return) > 1:
        len_prev_pixels = np.sum([len(prev_rois['reflectivity'][parent]) for parent in parent_return])
        return (len(keys_in_roi) - len_prev_pixels) / len(intensity_scaled) * 100
    else:
        return len(keys_in_roi) / len(intensity_scaled) * 100


def load_processed_radd_data(output_folder, reprocess_collector):
    """
    Loads processed radd data: image data, rois per luer image, and ros per roi id

    :param output_folder: Folder to store RADD output
    :param reprocess_collector: switch to return data or empty dicts
    :return: tuple of dictionaries of image data, rois per luer image, and ros per roi id
    """

    if reprocess_collector:
        roi_props_by_luer_key = {}
        roi_props_by_roi_key = {}
        image_data_all = {}
    elif os.path.isfile(os.path.join(output_folder, 'roi_props_by_luer_key.pkl')) & \
            os.path.isfile(os.path.join(output_folder, 'roi_props_by_roi_key.pkl')) & \
            os.path.isfile(os.path.join(output_folder, 'image_data_all.pkl')):
        with open(os.path.join(output_folder, 'roi_props_by_luer_key.pkl'), "rb") as f:
            roi_props_by_luer_key = pickle.load(f)
        with open(os.path.join(output_folder, 'roi_props_by_roi_key.pkl'), "rb") as f:
            roi_props_by_roi_key = pickle.load(f)
        with open(os.path.join(output_folder, 'image_data_all.pkl'), "rb") as f:
            image_data_all = pickle.load(f)
    else:
        roi_props_by_luer_key = {}
        roi_props_by_roi_key = {}
        image_data_all = {}

    return image_data_all, roi_props_by_luer_key, roi_props_by_roi_key


def load_radd_metrics_data(output_folder):
    """
    Loads RADD metrics data

    :param output_folder: Folder to store RADD output
    :return: dictionary with metrics data per roi, per image
    """

    if os.path.isfile(os.path.join(output_folder, 'roi_metrics_by_roi_key.pkl')):
        with open(os.path.join(output_folder, 'roi_metrics_by_roi_key.pkl'), "rb") as f:
            roi_metrics_by_roi_key = pickle.load(f)
    else:
        roi_metrics_by_roi_key = dict()

    return roi_metrics_by_roi_key


def save_luer_plots_with_rois(images_to_save, luer_images, output_folder, roi_props_all_image_nr):
    """
    Saves luer plots including detected ROIs

    :param images_to_save: luer images to be saved
    :param luer_images: all luer images
    :param output_folder: Folder to store RADD output
    :param roi_props_all_image_nr: dictionary with information of detected ROIs
    """

    for image in images_to_save:
        if image in roi_props_all_image_nr:
            plot_luer(luer_images[image],
                      save_image=True, output_folder=output_folder,
                      image_name='processed_image_{0:04d}'.format(image),
                      rois=roi_props_all_image_nr[image])


def store_roi_metrics(output_folder, rois_roi_as_key):
    """
    Stores RADD roi metrics

    :param output_folder: Folder to story RADD output
    :param rois_roi_as_key: dictionary of rois, ordered by roi id
    """

    if not os.path.isdir(output_folder):
        os.makedirs(output_folder)

    with open(os.path.join(output_folder, 'roi_metrics_by_roi_key.pkl'), "wb") as f:
        pickle.dump(rois_roi_as_key, f)


def store_processed_radd_data(output_folder, image_data_all, roi_props_by_luer_key, roi_props_by_roi_key):
    """
    Stores the RADD output

    :param output_folder: Folder to story RADD output
    :param image_data_all: dictionary with luer images
    :param roi_props_by_luer_key: dictionary with ROI info, data per luer
    :param roi_props_by_roi_key: dictionary with ROI info, data per roi
    """

    if not os.path.isdir(output_folder):
        os.makedirs(output_folder)

    with open(os.path.join(output_folder, 'image_data_all.pkl'), "wb") as f:
        pickle.dump(image_data_all, f)
    with open(os.path.join(output_folder, 'roi_props_by_luer_key.pkl'), "wb") as f:
        pickle.dump(roi_props_by_luer_key, f)
    with open(os.path.join(output_folder, 'roi_props_by_roi_key.pkl'), "wb") as f:
        pickle.dump(roi_props_by_roi_key, f)


def prepare_selected_data(roi_props_all_roi_nr, luer_file_properties):
    """
    To check: Obsolete?

    :param roi_props_all_roi_nr: dict with roi nr as key and dataframe with metrics per luer as value
    :param luer_file_properties: dataframe with all info about the luers
    :return:
    """

    print('Data for ROIs {0}'.format(sel_rois) + ' up to image ' + str(sel_image) + ' is being prepared...')
    dict_sel = {}
    # create a df with all roi info in all luers
    df = pd.DataFrame()
    for index, value in roi_props_all_roi_nr.items():
        value['luer_id'] = value.index
        value['roi_id'] = index
        value['gp'] = luer_file_properties.loc[value.index].pulse_count.values
        value['timestamp'] = luer_file_properties.loc[value.index].timestamp.values
        value.reset_index(drop=True)
        df = pd.concat([df, value], ignore_index=True)

    for sel_roi in sel_rois:
        merged_list = []
        roi_props_all_roi_nr_filt = roi_props_all_roi_nr[sel_roi].loc[:sel_image]
        # create a merged list which contains all parents of a roi
        for l in roi_props_all_roi_nr_filt.parent.values:
            for item in l:
                if item not in merged_list:
                    merged_list.append(item)

        # use the rois in the merged list to find all parents
        new_parents = 1
        while new_parents > 0:
            new_parents = 0
            for parent in merged_list:
                for l in roi_props_all_roi_nr[parent].loc[:sel_image].parent.values:
                    for item in l:
                        if item not in merged_list:
                            merged_list.append(item)
                            new_parents = 1
        # extract the portion of the data selected by the user
        df_sel = df[(df.roi_id.isin(merged_list)) & (df.luer_id <= sel_image)]
        # write selected roi information into a dictionary
        dict_sel[sel_roi] = df_sel

    # very inefficient way of collecting cumulative info
    merged_list = []
    for sel_roi in sel_rois:
        roi_props_all_roi_nr_filt = roi_props_all_roi_nr[sel_roi].loc[:sel_image]
        # create a merged list which contains all parents of a roi
        for l in roi_props_all_roi_nr_filt.parent.values:
            for item in l:
                if item not in merged_list:
                    merged_list.append(item)

        # use the rois in the merged list to find all parents
        new_parents = 1
        while new_parents > 0:
            new_parents = 0
            for parent in merged_list:
                for l in roi_props_all_roi_nr[parent].loc[:sel_image].parent.values:
                    for item in l:
                        if item not in merged_list:
                            merged_list.append(item)
                            new_parents = 1
    df = pd.DataFrame()
    # create a df with all roi info in all luers
    for index, value in roi_props_all_roi_nr.items():
        value['luer_id'] = value.index
        value['roi_id'] = index
        value['gp'] = luer_file_properties.loc[value.index].pulse_count.values
        value['timestamp'] = luer_file_properties.loc[value.index].timestamp.values
        value.reset_index(drop=True)
        df = pd.concat([df, value], ignore_index=True)
    # extract the portion of the data selected by the user
    df_sel = df[(df.roi_id.isin(merged_list)) & (df.luer_id <= sel_image)]
    dict_sel[-1] = df_sel

    print('Done')
    return dict_sel


def prepare_plot_data(dict_sel_c, x_axis, y_axis):
    """
    To check: obsolete?

    :param dict_sel_c:
    :param x_axis:
    :param y_axis:
    :return:
    """
    dict_sel = dict_sel_c.copy()
    df_plot = dict_sel[list(dict_sel.keys())[0]].sort_values(by=['luer_id'])[[y_axis, x_axis]].groupby(by=x_axis).sum()
    df_plot.rename(columns={y_axis: y_axis + '_' + str(list(dict_sel.keys())[0])}, inplace=True)
    dict_sel.pop(list(dict_sel.keys())[0])
    for key in dict_sel:
        df_sel_sum = dict_sel[key].sort_values(by=['luer_id'])[[y_axis, x_axis]].groupby(by=x_axis).sum()
        df_plot = pd.merge(df_plot, df_sel_sum, on=x_axis, how='outer').fillna(0)
        df_plot.rename(columns={y_axis: y_axis + '_' + str(key)}, inplace=True)

    # drop the cumulative for now
    df_plot.drop(y_axis + '_' + '-1', axis=1, inplace=True)

    return df_plot


def detect_rois(luers_dict, key, max_threshold=70.0, nr_images_for_threshold=10, verbose=False):
    """
    Detect ROIs in current luer reflectivity image

    :param luers_dict: the luers to use for determining the threshold
    :param key: the key of the luer to process
    :param max_threshold: maximum threshold to be used to avoid detection of noise (default=70.0)
    :param nr_images_for_threshold: number of images used to determine threshold (default=10)
    :param verbose: switches debug mode (default=False)
    :return: dictionary for this luer including the detected ROIs
    """

    if verbose:
        print('Start ROI detection for {}: {}'.format(key, pd.Timestamp('now')))

    threshold = get_threshold(luers_dict, key, max_threshold=max_threshold,
                              nr_images_for_threshold=nr_images_for_threshold, verbose=verbose)
    # and process the image
    if verbose:
        print('determine segmentation', pd.Timestamp('now'))
    luer_dict = luers_dict[key]
    luer_dict['threshold'] = threshold
    luer_dict = add_segmentation(luer_dict, threshold)

    if len(np.unique(luer_dict['data']['segmentation'])) == 1:
        luer_dict['rois'] = dict()
        if verbose:
            print('No stains detected')
    else:
        if verbose:
            print('interpolate to image', pd.Timestamp('now'))
        luer_dict = add_interpolated_image(luer_dict, verbose=verbose)
        if verbose:
            print('add rois', pd.Timestamp('now'))
        luer_dict = add_rois(luer_dict, verbose=verbose)
        if verbose:
            print('to original luer keys', pd.Timestamp('now'))
        luer_dict = to_original_keys(luer_dict, verbose=verbose)

        del luer_dict['image']
        del luer_dict['image_x']
        del luer_dict['image_y']
        del luer_dict['image_rois']

    if verbose:
        print('Finished ROI detection', pd.Timestamp('now'))

    return luer_dict


def get_threshold(luers_dict, key, max_threshold=70.0, nr_images_for_threshold=10,
                  reflectivity_threshold=10.0, verbose=False):
    """
    Determine threshold for roi detection

    :param luers_dict: the luers to use for determining the threshold
    :param key: the key of the luer to process 
    :param max_threshold: maximum threshold to be used to avoid detection of noise (default=70.0)
    :param nr_images_for_threshold: number of images used to determine threshold (default=10)
    :param reflectivity_threshold: lower limit of reflectivity to include in threshold calculation
    :param verbose: switches debug mode (default=False)
    :return: roi detection threshold
    """

    if verbose:
        print('Getting the threshold to use for roi detection')

    # select the images to base the threshold on
    keys_for_threshold = [k for k in luers_dict.keys() if k < key]
    keys_for_threshold = keys_for_threshold[-nr_images_for_threshold:]
    luers_dict_for_threshold = {k: luers_dict[k] for k in keys_for_threshold}

    reflectivity_all = []
    if verbose:
        print('luer_keys', luers_dict.keys())
    for key, luer_dict in luers_dict_for_threshold.items():
        if verbose:
            print('key: {}, luer_dict data columns: {}'.format(key, luer_dict['data'].columns))
        reflectivity_data = luer_dict['data'][luer_dict['data'].reflectivity > reflectivity_threshold]
        reflectivity_all = np.append(reflectivity_all, reflectivity_data.reflectivity)

    if len(reflectivity_all) == 0:
        if verbose:
            print('No reflectivity data: Threshold is set to max threshold')
        threshold = max_threshold
    else:
        if verbose:
            print('extreme reflectivities:', min(reflectivity_all), max(reflectivity_all))
        try:
            threshold = threshold_isodata(reflectivity_all)
        except Exception as e:
            if verbose:
                print(e)
            threshold = max_threshold
        if threshold > max_threshold:
            if verbose:
                print('Threshold is based on insufficient amount of images with debris')
            threshold = max_threshold

    if verbose:
        print('Setting threshold to {}'.format(threshold))

    return threshold


def add_segmentation(luer_dict, threshold, verbose=False):
    """
    Adds a column with boolean values to the data df indicating which data points are part of a ROI

    :param luer_dict: dictionary containing luer data
    :param threshold: threshold to be used for segmentation of luer image
    :param verbose: switches debug mode (default=False)
    :return: luer dictionary containing the segmentation as well
        The segmentation is a boolean column in data to
    """

    luer_dict['data']['segmentation'] = luer_dict['data'].reflectivity < threshold
    return luer_dict


def add_interpolated_image(luer_dict, dimension=256, verbose=False):
    """
    Calculates an interpolated image (on a uniform grid) and adds it to the luer_dict

    :param luer_dict: dictionary containing luer data
    :param dimension: dimension of the image (default=256)
    :param verbose: switches debug mode (default=False)
    :return: luer dictionary including interpolated image data
    """

    image = pd.DataFrame()

    # make uniform mesh
    x_coords = np.linspace(luer_dict['data'].x.min(), luer_dict['data'].x.max(), dimension)
    y_coords = np.linspace(luer_dict['data'].y.min(), luer_dict['data'].y.max(), dimension)
    xi, yi = np.meshgrid(x_coords, y_coords)

    # interpolate
    image = griddata((luer_dict['data'].x.values, luer_dict['data'].y.values),
                     luer_dict['data']['segmentation'].values, (xi, yi), method='nearest')

    # add data to luer_dict
    luer_dict['image'] = image
    luer_dict['image_x'] = xi
    luer_dict['image_y'] = yi

    return luer_dict


def add_rois(luer_dict, verbose=False):
    """
    Find rois in a boolean image

    :param luer_dict: dictionary containing luer data
    :param verbose: switches debug mode (default=False)
    :return: luer dictionary including interpolated image data
    """

    # Make a labelled image based on the thresholding rois
    image_labels = measure.label(luer_dict['image'], background=0)

    # Apply regionprops to characterise each of the rois
    props = measure.regionprops(image_labels, intensity_image=luer_dict['image'])

    # set all labels to -1
    luer_dict['image_labels'] = np.zeros(np.shape(luer_dict['image'])) - 1
    luer_dict['image_labels'][:] = np.nan
    rois = {}
    for i, prop in enumerate(props):
        x = [pc[0] for pc in prop.coords]
        y = [pc[1] for pc in prop.coords]
        rois[i] = {
            'x': x,
            'y': y,
        }
        luer_dict['image_labels'][x, y] = i
    luer_dict['image_rois'] = rois

    if verbose:
        print('{} rois detected'.format(len(rois)))
        # print (rois)
    return luer_dict


def to_original_keys(luer_dict, verbose=False):
    """
    Converts the roi coordinates back to original image coordinates
    removes the interpolated pixels

    :param luer_dict: dictionary containing luer data
    :param verbose: switches debug mode (default=False)
    :return: luer dictionary including interpolated image data
    """

    unique_x = np.unique(luer_dict['image_x'])
    unique_y = np.unique(luer_dict['image_y'])

    luer_dict['data']['roi_labels'] = np.nan
    for i, row in luer_dict['data'].iterrows():
        nearest_ix = (np.abs(unique_x - row.x)).argmin()
        nearest_iy = (np.abs(unique_y - row.y)).argmin()

        label = luer_dict['image_labels'][nearest_iy][nearest_ix]
        if label != -1:
            luer_dict['data'].loc[i, 'roi_labels'] = luer_dict['image_labels'][nearest_iy][nearest_ix]

    luer_dict['data'].roi_labels = luer_dict['data'].roi_labels.astype('Int64')

    unique_roi_labels = np.unique(luer_dict['data'].roi_labels.dropna().values)
    rois = dict()
    for label in unique_roi_labels:
        rois[label] = {'elements': list(luer_dict['data'][luer_dict['data'].roi_labels == label].index)}
    luer_dict['rois'] = rois

    return luer_dict


def link_to_existing_rois(luers_dict, key, verbose=False):
    """
    Links the current ROI to a ROI in a previous RADON

    We use the following names:

    - parents: the indices of the ROIs in the previous Luer that partially overlap with the current ROI.
    - ancestors: the list of all parents, recursively from all previous luers
    - main ancestor: the most important ancestor, which is the main ancestor of the largest parent of the previous luer.
      This is useful to keep track over an ROI over time. This is the stable number you can refer to, and can for
      instance be used for colors in drawing the ROIs.

    4 options:

    1. Totally new --> parent_return = [], roi_nr = i
    2. Continuation of a previous roi --> parent_return = matched prev roi nr,
       roi_nr = matched prev roi nr
    3. Combination of 2 previous rois --> parent_return = [prev roi 1, prev roi 2]
       roi_nr = give it a new number
    4. Split of previous roi: multiple rois have the same parent
       roi_nr = give it a new number

    :param luers_dict: dictionary with all luers
    :param key: key of current luer
    :param verbose: switches debug mode (default:False)
    :return: current luer dictionary, now containing parent and ancestor information
    """

    luer_dict_curr = luers_dict[key]
    # select previous luer
    keys_prev = [k for k in luers_dict if k < key]
    if len(keys_prev) == 0:
        # no previous luers available, only initialize ancestor fields
        for roi_curr, roi_keys_curr in luer_dict_curr['rois'].items():
            luer_dict_curr['rois'][roi_curr]['ancestors'] = list()
            luer_dict_curr['rois'][roi_curr]['main_ancestor'] = roi_curr

    else:
        # initialize dictionary to restructure the keys for the detected rois
        rename_roi_index = dict()
        roi_splitting_detection = dict()

        # get previous images
        key_prev = max(keys_prev)
        luer_dict_prev = luers_dict[key_prev]

        # get maximum roi index used so far.
        max_roi_index = get_maximum_roi_key(keys_prev, luers_dict)

        for roi_curr, roi_keys_curr in luer_dict_curr['rois'].items():
            # get all parents (ROIs with some overlap)
            parents = []
            for roi_prev, roi_keys_prev in luer_dict_prev['rois'].items():
                overlapping_keys = np.intersect1d(roi_keys_curr['elements'], roi_keys_prev['elements'])
                if len(overlapping_keys) > 0:
                    # option 2 or 3
                    parents.append(roi_prev)

            # fill ancestor list be the roi keys of the parents and their ancestors
            luer_dict_curr['rois'][roi_curr]['parents'] = parents.copy()
            ancestors = parents.copy()
            for parent in parents:
                ancestors += list(luer_dict_prev['rois'][parent]['ancestors'])

            luer_dict_curr['rois'][roi_curr]['ancestors'] = np.unique(ancestors)

            # set parent and main ancestor for the different cases
            if len(parents) == 1:
                # option 2: set key to the key of the only parent found, take main ancestor from the parent
                rename_roi_index[roi_curr] = parents[0]

                # set main ancestor: main ancestor of parent
                luer_dict_curr['rois'][roi_curr]['main_ancestor'] = luer_dict_prev['rois'][parents[0]][
                    'main_ancestor']

                # potential split: update roi_splitting_detection
                if parents[0] in roi_splitting_detection:
                    roi_splitting_detection[parents[0]] = roi_splitting_detection[parents[0]] + [roi_curr]
                else:
                    roi_splitting_detection[parents[0]] = [roi_curr]
            else:
                # option 1 or 3
                # give a new key
                max_roi_index = max_roi_index + 1
                rename_roi_index[roi_curr] = max_roi_index

                # set main ancestor:
                if len(parents) == 0:
                    # main ancestor is current index, no parent since it is a new roi
                    luer_dict_curr['rois'][roi_curr]['main_ancestor'] = roi_curr
                else:
                    # multiple parents. Main ancestor is main ancestor of main parent
                    # main parent is the parent with largest roi
                    max_size = 0
                    main_parent = -1
                    for parent in parents:
                        cur_size = len(luer_dict_prev['rois'][parent]['elements'])
                        if cur_size > max_size:
                            max_size = cur_size
                            main_parent = parent
                    luer_dict_curr['rois'][roi_curr]['main_ancestor'] = luer_dict_prev['rois'][main_parent][
                        'main_ancestor']

                    # potential split: update roi_splitting_detection
                    if parents[0] in roi_splitting_detection:
                        roi_splitting_detection[parents[0]] = roi_splitting_detection[parents[0]] + [roi_curr]
                    else:
                        roi_splitting_detection[parents[0]] = [roi_curr]

        # option 4: detect and deal with ROI splits
        # a split happens in case multiple ROIs have the same parent, data is collected in roi_splitting_detection
        # roi_splitting_detection has parent as key, and a list of roi keys as value.
        # In case the list contains multiple keys, it is a split: All ROIs get a new index
        for parent, roi_keys in roi_splitting_detection.items():
            if len(roi_keys) > 1:
                for roi_curr in roi_keys:
                    max_roi_index = max_roi_index + 1
                    rename_roi_index[roi_curr] = max_roi_index

        # rename the roi names
        # this is done by building a new roi_dict, to avoid overwriting and losing data
        rois_dict_updated = dict()
        for old_key, new_key in rename_roi_index.items():
            rois_dict_updated[new_key] = luer_dict_curr['rois'][old_key]
        luer_dict_curr['rois'] = rois_dict_updated

    return luer_dict_curr


def get_maximum_roi_key(keys_prev, luers_dict):
    """
    Determines the maximum roi key used in the previous luers. Returns -1 in case no luer was detected yet.

    :param keys_prev: list of all the luer keys of previous luers
    :param luers_dict: dictionary with all available luers
    :return: maximum roi key used in the previous luers.
    """

    max_roi_key = -1
    for key in keys_prev:
        if 'rois' in luers_dict[key]:
            rois = luers_dict[key]['rois']
            if len(rois.keys()) > 0:
                max_roi_key = max(max_roi_key, max(rois.keys()))

    return max_roi_key


def update_rois_with_roi_as_key(rois_roi_as_key, luer_dict, luer_key, verbose=False):
    """
    Updates the rois (with roi as key) dictionary with detected rois

    :param rois_roi_as_key: dictionary with rois as key
    :param luer_dict: dictionary with luer image data
    :param luer_key: key of the luer image
    :param verbose: switches debug mode (default: False)
    :return: updated rois_roi_as_key
    """

    for key, roi in luer_dict['rois'].items():
        if not key in rois_roi_as_key:
            rois_roi_as_key[key] = dict()
        rois_roi_as_key[key][luer_key] = roi

    return rois_roi_as_key
