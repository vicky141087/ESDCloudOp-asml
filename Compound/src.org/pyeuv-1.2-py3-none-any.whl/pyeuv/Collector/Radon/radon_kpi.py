# -*- coding: utf-8 -*-
"""
radon_kpi.py
Authors: RWKL
Date:  2019-05-12

Spiderweb KPI calculations based on spiderweb elements

"""

import pandas as pd
import numpy as np
import pyeuv.Collector.Radon.radon_io as radon_io
import pyeuv.Collector.Radon.roi_io as roi_io
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def get_spiderweb_kpis(client, source_id, from_time, to_time, verbose=False):
    """
    Get spiderweb KPIs, by downloading the spiderweb element contributions, and apply the mapping to KPIs

    :param client: connection to influx
    :param source_id: source id of system for which we are calculating the ROI contributions
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dataframe with spiderweb KPIs
    """

    do_it.do_it_verbose(currentframe(), verbose)

    kpi_mapping = get_spiderweb_kpi_mapping(verbose=verbose)
    spiderweb_contributions = get_spiderweb_contributions(client, source_id, from_time, to_time)
    result = calculate_spiderweb_kpis(spiderweb_contributions, kpi_mapping, verbose=verbose)

    return result


def get_spiderweb_contributions(client, source_id, from_time, to_time, verbose=False):
    """
    Get spiderweb contributions from influx

    :param client: connection to influx
    :param source_id: source id of system for which we are calculating the ROI contributions
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dataframe with 60 columns of spiderweb contributions
    """

    do_it.do_it_verbose(currentframe(), verbose)
    spiderweb_contributions = client.get_signals('{}.Collector._ROI_contribution[*]'.format(source_id),
                                                 from_time, to_time)

    return spiderweb_contributions


def calculate_spiderweb_kpis(spiderweb_contributions, kpi_mapping, verbose=False):
    """
    Calculate the spiderweb KPIs, given the 60 spiderweb contributions, and the mapping.

    :param spiderweb_contributions: dataframe with 60 columns of data
    :param kpi_mapping:
    :param verbose: to switch internal debug info
    :return:
    """

    do_it.do_it_verbose(currentframe(), verbose)

    result = pd.DataFrame()
    for key, value in kpi_mapping.items():
        roi_list = value['roi_list']
        try:
            result[key] = spiderweb_contributions[roi_list].sum(axis=1)
        except Exception as e:
            # Not all column names do exist. Reason is most likely na data in the spiderweb_contributions at all
            result[key] = np.NaN

    return result


def get_spiderweb_kpi_mapping(verbose=False):
    """
    Reads the spiderweb KPI mapping from the json file in the RADON data directory and returns it as dictionary

    :raises Error: when reading kpi mapping fails
    :param verbose: switches debug mode (default=False)
    :return dictionary: with the rois
    """

    do_it.do_it_verbose(currentframe(), verbose)

    import os

    try:
        path_to_spiderweb_kpi_mapping = os.path.join(radon_io.get_roi_directory(), 'spiderweb_kpi_mapping.json')
        kpi_mapping = roi_io.read_spiderweb_kpis_from_json(path_to_spiderweb_kpi_mapping, verbose=verbose)
    except Exception as e:
        raise Exception('{}: {}'.format(currentframe(), e))

    return kpi_mapping
