# -*- coding: utf-8 -*-
"""
radon_plotting.py
Authors: RWKL

This module releases functions plotting collector related images.

New functions (DAAU): plot_fit_generic_ref_scaling, make_title, plot_radon, plot_histogram, plot_sliedt, plot_rois
Date:  2020-06-02

"""


import os
import random

import imageio
import numpy as np

def init():
    """
    Load matplotlib only if needed

    :return: plt, patches
    """

    from matplotlib import pyplot as plt, patches as patches

    return plt, patches

def save_movie_with_rois(output_folder):
    """
    Loads all luer images in the output_folder and creates a movie and stores it

    :param output_folder: folder to which the image is saved
    """

    images = []
    for file_name in os.listdir(output_folder):
        if file_name.startswith('processed_image_') & file_name.endswith('.png'):
            file_path = os.path.join(output_folder, file_name)
            images.append(imageio.imread(file_path))
    print('Creating gif')
    imageio.mimsave(os.path.join(output_folder, 'movie_processed.gif'), images)
    print('Done with gif')


def plot_luer(luer_dict, save_image=False, output_folder='', image_name='',
              centre_mass=None, grid=False, verbose=False):
    """
    Obtain data for a reference plot and create it. Show or save as requested.

    :param luer_dict: luer_dict data
    :param save_image: only display the image or save it
    :param output_folder: folder to which the image is saved
    :param image_name: name to give the saved image
    :param centre_mass: series with the centre of mass to plot
    :param grid: display a grid
    """

    plt, patches = init()

    title_fontsize = 14
    label_fontsize = 13
    dot_size = 20
    color_range_slider = [0, 120]

    plt.figure(figsize=(7.5, 6))
    plt.scatter(luer_dict['data'].x.values, luer_dict['data'].y.values, c=luer_dict['data'].reflectivity,
                cmap=plt.get_cmap('inferno'), s=dot_size)  # RdYlGn #Reds #inferno #jet_r
    plot_collector(luer_dict['data'].x, luer_dict['data'].y)

    plt.clim(*color_range_slider)
    plt.gca().set_aspect('equal')

    cbar = plt.colorbar()
    cbar.set_label(label="Reflectivity", fontsize=label_fontsize)

    if not grid:
        plt.xticks([], [])
        plt.yticks([], [])

    title = ("{}: {}".format(image_name, luer_dict['timestamp'].strftime('%y-%m-%d %H:%m')))
    plt.title(title, fontweight='bold', fontsize=title_fontsize)

    if 'rois' in luer_dict.keys():
        if len(luer_dict['rois']) > 0:
            plt.text(0., 0, 'threshold: {:.2f}'.format(luer_dict['threshold']))

            # Display the image and plot all contours found
            n_colors = 1000
            mymap = plt.cm.get_cmap('gist_ncar', n_colors)
            colors_list = list(range(n_colors))
            random.Random(5).shuffle(colors_list)
            my_colors = mymap(colors_list)
            i = 0

            for index, roi in luer_dict['rois'].items():
                data_sel = luer_dict['data'].loc[roi['elements']]
                x_coords = data_sel.x.values
                y_coords = data_sel.y.values
                if i < 5:
                    plt.scatter(x_coords, y_coords, s=dot_size + 1, label=str(index),
                                edgecolors=my_colors[roi['main_ancestor'] % 1000], facecolors='none')
                else:
                    plt.scatter(x_coords, y_coords, s=dot_size + 1,
                                edgecolors=my_colors[roi['main_ancestor'] % 1000], facecolors='none')
                i = i + 1
            plt.legend(fontsize='x-small')

    if centre_mass is not None:
        # Display the image and plot all contours found
        for i in centre_mass:
            plt.scatter(centre_mass[i][0], centre_mass[i][1], marker='*', s=100)

    plt.tight_layout()
    plt.gca().set_aspect('equal')

    plt.gcf()

    if save_image:
        if verbose:
            print('save plot to:', os.path.join(output_folder, "{}.png".format(image_name)))
        if not os.path.isdir(output_folder):
            os.makedirs(output_folder)
        plt.savefig(os.path.join(output_folder, "{}.png".format(image_name)), dpi=300)
        plt.close('all')


def plot_collector(x, y):
    """
    Plot a circle around the optical axis (0, 0) confining the sample points. Use only when
    plotting collector coordinates.

    :param x: x coordinates
    :param y: y coordinates
    """

    plt, patches = init()

    collector_radius_approx = calc_collector_radius_approx(x, y)

    plt.gca().add_artist(patches.Circle((0, 0), radius=collector_radius_approx, fill=False, color='k'))
    plt.gca().add_artist(patches.Circle((0, 0), radius=1, fill=True, color='k'))

    plt.xlim([-collector_radius_approx, collector_radius_approx])
    plt.ylim([-collector_radius_approx, collector_radius_approx])

    plt.gca().grid(color='k', linestyle='--', linewidth=0.5)


def calc_collector_radius_approx(x, y):
    """
    Calculate the radius of the collector

    :param x: x coordinates
    :param y: y coordinates
    :return: the approximate collector radius
    """

    collector_radius_approx = np.max(np.sqrt(x ** 2 + y ** 2)) + 2
    return collector_radius_approx


def show_images(luer_roi_dir):
    """
    Show processed luer images using widgets

    :param luer_roi_dir: string of the luer dir
    """
    from os import path, listdir
    from IPython import display as disp
    from ipywidgets import widgets, interact

    processed_list = sorted(list(filter(lambda fn: fn.lower().startswith('processed') and fn.lower().endswith('.png'),
                                        listdir(luer_roi_dir))))
    raw_list = sorted(list(filter(lambda fn: fn.lower().startswith('raw') and fn.lower().endswith('.png'),
                                  listdir(luer_roi_dir))),
                      key=lambda x: int(x.replace('raw_image_', '').replace('.png', '')))
    file_lists = {
        'processed': processed_list,
        'raw': raw_list
    }
    global sel_image
    sel_image = int(''.join(filter(str.isdigit, raw_list[0])))

    image_type_select = widgets.Dropdown(
        options=['raw', 'processed'],
        value='processed',
        description='Image Type:',
        continuous_update=False,
    )
    image_slider = widgets.SelectionSlider(
        options=file_lists[image_type_select.value],
        description='Image:',
        continuous_update=True,
        layout={'width': '66%'},
    )

    def return_image(*args):
        global sel_image
        sel_image = int(''.join(filter(str.isdigit, image_slider.value)))

    def update_slider(*args):
        oldindex = image_slider.index
        image_slider.options = file_lists[image_type_select.value]
        image_slider.value = image_slider.options[oldindex]

    image_type_select.observe(update_slider, 'value')
    image_slider.observe(return_image, 'value')

    def show_img(img, select):
        global image_type_select, image_slider
        disp.display(disp.Image(open(path.join(luer_roi_dir, img), 'rb').read(), width=600))

    show = interact(show_img, select=image_type_select, img=image_slider)


def select_rois_images(roi_props_all_image_nr, roi_props_all_roi_nr):
    """
    Display widgets to select rois

    :param roi_props_all_image_nr: dictionary with luer number as key and dataframe
    :param roi_props_all_roi_nr: dict with roi nr as key and dataframe with metrics per luer as value
    """
    from ipywidgets import widgets, interact
    image_list = [*roi_props_all_image_nr]
    roi_list = [*roi_props_all_roi_nr]
    global sel_rois, sel_image
    sel_rois = (roi_list[0],)

    roi_select = widgets.SelectMultiple(
        options=roi_list,
        value=(roi_list[0],),
        description='ROIs (use shift/ctrl to select multiple):',
        continuous_update=True,
        rows=10,
        style={'description_width': 'initial'}
    )

    history_select = widgets.Checkbox(
        value=False,
        description='Use all historical data?',
        style={'description_width': 'initial'}
    )

    #     image_slider = widgets.SelectionSlider(
    #         options = image_list,
    #         value = image_list[-1],
    #         description = 'Data to investigate up to and including image #:',
    #         continuous_update=True,
    #         layout = {'width': '66%'},
    #         style = {'description_width': 'initial'}
    #     )

    def return_rois(*args):
        global sel_rois
        sel_rois = roi_select.value

    def return_image(*args):
        global sel_image
        if history_select.value:
            sel_image = [*roi_props_all_image_nr][-1]

    roi_select.observe(return_rois, 'value')
    history_select.observe(return_image, 'value')

    def print_widget_values(widget_rois, widget_history):
        if history_select.value:

            print('ROIs {0}'.format(widget_rois) + ' will be investigated for all historical data')
        else:
            print('ROIs {0}'.format(widget_rois) + ' will be investigated up to image shown above')

    show = interact(print_widget_values, widget_rois=roi_select, widget_history=history_select)


def plot_fit_generic_ref_scaling(parameters, conf = None, luer = None, reference = None, \
                                 custom_dir = None, add_deltas=True, add_key=True, suffix = ''):
    """
    Plot the histogram + fit used in the generic reference scaling method.

    :param parameters: dataframe with various values associated to the scaling method
    :param conf: object with machine/collector info
    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary containing the reference image
    :param custom_dir: custom directory to store images/analysis results
    :param add_deltas: add delta pulsecount, SLIEDT, etc. to the image
    :param add_key: add luer id to the image
    :param suffix: add txt to the end of the filename
    :return: None
    """

    plt, patches = init()

    colors = plt.cm.viridis(np.linspace(0, 1, 5))
    bins = parameters['bins']
    counts = parameters['counts']
    range_above_min_bound = np.where(bins > parameters['min_bound'])[0]
    range_between_bounds = np.where((bins > parameters['min_bound']) & (bins < parameters['max_bound']))[0]
    range_not_between_bounds = np.where(~((bins > parameters['min_bound']) & (bins < parameters['max_bound'])))[0]
    max_y = max(counts[np.where(bins[1::] > parameters['fit_min_x'])[0]])

    plt.bar(bins[range_not_between_bounds], counts[range_not_between_bounds], alpha=0.1, width=bins[1]-bins[0], color = 'k')
    plt.bar(bins[range_between_bounds], counts[range_between_bounds], alpha=0.2, width=bins[1] - bins[0], color='k', \
            label='Raw reflectivity data')
    plt.plot([parameters['peak_reflectivity'], parameters['peak_reflectivity']], [0, 1.04*max_y], color = colors[4],
             label='Peak value')
    plt.plot([parameters['min_bound'], parameters['min_bound']], [0, 1.04 * max(counts)], color='gray',
             label='Lower bound')
    plt.text(parameters['peak_reflectivity'] - 0.04*(parameters['fit_max_x']-parameters['fit_min_x']), 1.05*max_y, \
             "{:0.2f}".format(parameters['peak_reflectivity']), fontsize=10, color='k')
    plt.text(parameters['min_bound'] - 0.04*(parameters['fit_max_x']-parameters['fit_min_x']), 1.05*max_y, \
             "{:0.2f}".format(parameters['min_bound']), fontsize=10, color='k')

    if parameters['applied_fit']:
        max_bound_sigma = parameters['peak_reflectivity'] + parameters['sigma_peak']
        min_bound_sigma = parameters['peak_reflectivity'] - 1 * parameters['sigma_peak']
        min_bound_3sigma = parameters['peak_reflectivity'] - 3 * parameters['sigma_peak']

        # Plot bounds of reflectivity
        plt.plot([parameters['peak_reflectivity'] + parameters['error_peak'], parameters['peak_reflectivity'] + \
                  parameters['error_peak']], [0, max(counts)], linestyle='dashed', color = colors[4])
        plt.plot([parameters['peak_reflectivity'] - parameters['error_peak'], parameters['peak_reflectivity'] - \
                  parameters['error_peak']], [0, max(counts)], linestyle='dashed', color = colors[4])

        # Plot fit
        plt.plot(bins[range_above_min_bound], parameters['gaussian'](bins[range_above_min_bound], *parameters['popt']), \
                 color= colors[3], marker='o', label='Gaussian fit')
        plt.plot(bins, parameters['gaussian'](bins, *parameters['popt']),  color= colors[3], linestyle='dotted', marker='o')
        plt.plot(bins[parameters['fit_range']], counts[parameters['fit_range']],  color= 'gray', linestyle='dashed',
                 marker='v', label='Fitted range')

        # Plot remainder after subtraction fit
        plt.plot(parameters['df_remainder'].index, parameters['df_remainder'].delta_counts, color = colors[1], \
                 label='Remainder subtraction fit')
        plt.plot(parameters['df_remainder'].index, parameters['df_remainder'].delta_counts_smoothed, color = colors[1], \
                 linestyle='dotted', label='Smoothed remainder')

        # Plot obtained bounds
        plt.plot([min_bound_sigma, min_bound_sigma], [0, 1.04*max(counts)], color='gray', linestyle='dotted')
        plt.plot([min_bound_3sigma, min_bound_3sigma], [0, 1.04*max(counts)], color='gray', linestyle='dotted')
        plt.plot([max_bound_sigma, max_bound_sigma], [0, 1.04*max(counts)], color='gray', linestyle='dotted')

    plt.xlim([parameters['fit_min_x'], parameters['fit_max_x']])
    plt.ylim([0, 1.1 * max_y])
    plt.legend(fontsize=10)

    plt.xlabel('Intensity ratio', fontsize=16)
    plt.ylabel('Counts', fontsize=16)

    if conf is not None:
        plt.title(make_title(luer, reference, conf, add_deltas=add_deltas), fontweight='bold', fontsize=14, loc='center')

    # save figure
    key = str(luer['luer_key'])
    if add_key is False:
        key = ''
    fname = conf.machine_name + '_' + conf.collector_name + '_' + key + '_' + parameters['ref_scaling_method'] + suffix + '_fit.png'
    plt.savefig(os.path.join(custom_dir,fname))  # or plt.show()
    plt.close()

    return


def make_title(luer, reference, conf, add_key=True, add_deltas=True):
    """
    Make a title for the graph

    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary containing the reference image
    :param conf: object with machine/collector info
    :param add_key: add luer id to the image
    :param add_deltas: add delta pulsecount, SLIEDT, etc. to the image
    :return:
        title: title string
    """

    plt, patches = init()

    title = r"%s | S%s | %s UTC" % (conf.machine_name,
                                     conf.collector_name[5:],
                                     luer['timestamp'].strftime('%y-%m-%d %H:%m')) + "\n"
    if add_key:
        title = title + r"LUER ref$\to$%04d | " % (luer['luer_key'])

    if add_deltas:
        delta_gp = (luer['collector_pulse_count'] - reference['collector_pulse_count'])
        delta_sliedt = (reference['scaling_factor'] - luer['scaling_factor']) / reference['scaling_factor'] * 100
        title = title + r"$\Delta$Gp: %.1fGp | $\Delta$SLIEDT: %.2f%%" % (delta_gp, delta_sliedt)
    else:
        title = title + r"Est. refl. loss: %.2f%%" % (reference['initial_reflectivity_loss'])

    return title


def plot_radon(luer, reference, custom_dir, conf, ref_scaling_method, max_bin=1.2, suffix = '', mask=None,
        plot_option = 'local_reflectivity'):
    """
    Plot a radon image + optinally mark the stain area

    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary containing the reference image
    :param custom_dir: custom directory to store images/analysis results
    :param conf: object with machine/collector info
    :param ref_scaling_method: scaling method for reference
    :param max_bin: maximum reflectivity value
    :param suffix: additional text to be added to filename
    :param mask: mask to be used to mark the stain area
    :param plot_option: select to plot 'local_reflectivity' or 'reflectivity_loss'
    :return: None
    """

    plt, patches = init()

    color_range = [0, max_bin*100]

    figsize = (6, 4.8)
    plt.figure(figsize=figsize, facecolor='white')
    plt.scatter(luer['data']['x'],
                luer['data']['y'],
                c=luer['data'][plot_option],
                cmap=plt.get_cmap('inferno'), s=22)
    cbar = plt.colorbar();
    plt.clim(color_range)
    plt.gca().set_aspect('equal')
    plt.xticks([], [])
    plt.yticks([], [])

    if plot_option == 'local_reflectivity': label = "SLIE/DT scaled local reflectivity (%)"
    if plot_option == 'reflectivity_loss': label = "SLIE/DT scaled reflectivity loss (%)"
    cbar.set_label(label=label, fontsize=13)

    if mask is not None:
        plt.scatter(luer['data'].loc[mask, 'x'],
                    luer['data'].loc[mask, 'y'],
                    c='white', s=22, alpha=0.3)

    plt.title(make_title(luer, reference, conf, add_key = False), fontweight='bold', fontsize=14, loc='left')

    ref_nr_text = r"LUER ref$\rightarrow$%04d" % (luer['luer_key'])
    plt.annotate(ref_nr_text, xy=(0, -0.01), verticalalignment='top', horizontalalignment='left',
                 xycoords='axes fraction', fontsize=13)

    plt.gca().grid(color='k', linestyle='--', linewidth=0.5)
    plt.gca().set_aspect('equal');
    plt.tight_layout()

    # save figure
    fname = conf.machine_name + '_' + conf.collector_name + '_' + str(luer['luer_key']) + '_' + ref_scaling_method + '_radon' + suffix + '.png'
    plt.savefig(os.path.join(custom_dir,fname))  # or plt.show()
    plt.close()


def plot_histogram(luer, reference, custom_dir, conf, ref_scaling_method, parameters = None, parameters_first = None,
                   n_bins = 100, max_bin = 1.4, suffix = '',  mask = None, plot_option = 'local_reflectivity'):
    """
    Plot the histogram of the reflectivity + optinally mark the stain area

    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary containing the reference image
    :param custom_dir: custom directory to store images/analysis results
    :param conf: object with machine/collector info
    :param ref_scaling_method: scaling method for reference
    :param parameters: dataframe with various values associated to the scaling method of the current LUER
    :param parameters_first: dataframe with various values associated to the scaling method of the first LUER
    :param n_bins: number of bins used in the histogram
    :param max_bin: maximum reflectivity value
    :param suffix: additional text to be added to filename
    :param mask: mask to be used to mark the stain area
    :param plot_option: select to plot 'local_reflectivity' or 'reflectivity_loss'
    :return: None
    """

    plt, patches = init()

    color_range = [0,100*max_bin]
    bins = np.linspace(0,100*max_bin,n_bins)

    figsize = (6, 4.5)
    plt.figure(figsize=figsize, facecolor='white')

    bin_centers = 0.5 * (bins[:-1] + bins[1:])
    col = bin_centers - min(bin_centers)
    col /= max(col)
    cm = plt.cm.get_cmap('inferno')

    counts, bins, patches = plt.hist(luer['data'][plot_option], bins=bins, range=color_range)
    max_y = max(counts[1::])
    for c, p in zip(col, patches):
        plt.setp(p, 'facecolor', cm(c))

    if parameters is not None:
        # If the parameters exists of the fitted peak in the histogram, correct for binning variation and plot the result.
        if parameters['applied_fit']:
            bin_factor = (bins[1] - bins[0])/100 / (parameters['bins'][1] - parameters['bins'][0])
            popt = parameters['popt'].copy()
            # compensate the amplitude of the fit, because a different bin window is used
            popt[0] *= bin_factor
            plt.plot(bins[1:], parameters['gaussian'](bins[1:]/100, *popt),'k:')

    if parameters_first is not None:
        # If the parameters exists of the fitted peak in the histogram of the first LUER, correct for binning variation
        # and height(/counts) differences, and plot the result.
        if parameters_first['applied_fit']:
            bin_factor_first = (bins[1] - bins[0])/100 / (parameters_first['bins'][1] - parameters_first['bins'][0])
            popt_first = parameters_first['popt'].copy()
            # compensate the amplitude of the fit, because a different bin window is used
            popt_first[0] *= bin_factor_first

            # If the upper bound and lower bound automated clean area detection algo is used, apply population data for
            # the min and max values for the sigma
            initial_peak_reflectivity = popt_first[1]
            initial_sigma_peak = popt_first[2]
            if 'clean_area_auto_' in ref_scaling_method:
                from pyeuv.Collector.Radon.radon_scaling import calculate_min_max_compensation_factor
                _, initial_peak_reflectivity, initial_sigma_peak = \
                    calculate_min_max_compensation_factor(initial_peak_reflectivity, initial_sigma_peak, ref_scaling_method)

            # Determine the associated counts of the clean area reflectivity peak
            from pyeuv.Collector.Radon.radon_scaling import determine_location_initial_distribution
            popt_first = determine_location_initial_distribution(bins/100, counts, initial_peak_reflectivity, initial_sigma_peak)
            counts_first_peak = parameters_first['gaussian'](bins[1:]/100, *popt_first)

            # Plot the 'fitted' initial clean area reflectivity peak
            plt.plot(bins[1:], counts_first_peak,'g',linewidth = 1.5)
            plt.plot([popt_first[1]*100, popt_first[1]*100], [0, max(counts_first_peak)], color='green', linewidth = 1.5)

    if mask is not None:
        n, bins, patches = plt.hist(luer['data'][plot_option].loc[mask],  bins=bins, range=color_range)
        plt.setp(patches, 'facecolor', 'white', alpha=0.6)

    if parameters is not None:
        plt.plot([parameters['peak_reflectivity']*100, parameters['peak_reflectivity']*100], [0, 1.04*max_y], color='gray',
                 label='Peak value')
        plt.plot([parameters['min_bound']*100, parameters['min_bound']*100], [0, 1.04 * max(counts)], color='gray',
                 linestyle='-.', label='Lower bound')

        plt.text(parameters['peak_reflectivity']*100 - max_bin*4, 1.05*max_y, "{:0.0f}%".format(parameters['peak_reflectivity']*100),
                 fontsize=10, color='k')
        plt.text(parameters['min_bound']*100 - max_bin*4, 1.05*max_y, "{:0.0f}%".format(parameters['min_bound']*100),
                 fontsize=10, color='k')

    if plot_option == 'local_reflectivity': plt.xlabel("SLIE/DT scaled local reflectivity (%/Gp)", fontsize=16)
    if plot_option == 'reflectivity_loss': plt.xlabel("SLIE/DT scaled reflectivity loss (%/Gp)", fontsize=16)
    plt.ylabel("Histogram", fontsize=16)
    plt.title(make_title(luer, reference, conf), fontweight='bold', fontsize=14, loc='center')
    plt.ylim([0,1.1*max_y])
    plt.tight_layout()

    # save figure
    fname = conf.machine_name + '_' + conf.collector_name + '_' + str(luer['luer_key']) + '_' + ref_scaling_method + '_histogram' + suffix + '.png'
    plt.savefig(os.path.join(custom_dir,fname))  # or plt.show()
    plt.close()



def plot_sliedt(client, loss_per_roi, luer, reference, custom_dir, conf, ref_scaling_method, suffix, icrm = False):
    """
    Plot the evolution of the global reflectivity loss and the peak non-stain reflectivity versus pulse count.

    :param client: connection to influx
    :param loss_per_roi: dataframe with the end results on reflectivity
    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary containing the reference image
    :param custom_dir: custom directory to store images/analysis results
    :param conf: object with machine/collector info
    :param ref_scaling_method: scaling method for reference
    :param suffix: additional text to be added to filename
    :param icrm: use icrm data instead of SLIE/DT
    :return: None
    """

    plt, patches = init()

    colors = plt.cm.viridis(np.linspace(0, 1, 5))

    figsize = (8, 6)
    plt.figure(figsize=figsize, facecolor='white')

    plt.ylabel("Reflectivity (%)", fontsize=16)
    plt.xlabel("Delta pulse count (Gp)", fontsize=16)
    plt.title(make_title(luer, reference, conf), fontweight='bold', fontsize=14, loc='center')

    from pyeuv.Collector.Radon.radon_io import load_reflectivity_data
    df_slie_pulsecount = load_reflectivity_data(client, conf, reference['timestamp'], icrm = icrm)

    # interpolate data
    df_slie_pulsecount.collector_pulse_count.interpolate(method='time',inplace=True)
    df_slie_pulsecount.scanner_pulse_count.interpolate(method='time', inplace=True)
    df_slie_pulsecount.dropna(subset=['slie_dt'],inplace=True)

    plt.plot((df_slie_pulsecount['collector_pulse_count'] - loss_per_roi['collector_pulse_count'].iloc[0]),
             df_slie_pulsecount['slie_dt'], '*', color=colors[0], alpha=0.2, label='Raw SLIE/DT')
    plt.plot((loss_per_roi['collector_pulse_count']-loss_per_roi['collector_pulse_count'].iloc[0]),
                    loss_per_roi['sliedt_luer'], '-.', color=colors[0],
                    label='Collector reflectivity')
    plt.plot((loss_per_roi['collector_pulse_count']-loss_per_roi['collector_pulse_count'].iloc[0]), loss_per_roi['peak_reflectivity'], '-o', color=colors[3],
                    label='Peak non-stain area')
    plt.plot((loss_per_roi['collector_pulse_count']-loss_per_roi['collector_pulse_count'].iloc[0]), 100 - loss_per_roi['est_scanner_loss'], '-.', color=colors[2],
                    label='Est. Scanner degradation')
    plt.fill_between((loss_per_roi['collector_pulse_count'] - loss_per_roi['collector_pulse_count'].iloc[0]),
                     loss_per_roi['peak_reflectivity'] - loss_per_roi['sigma_peak'],
                     loss_per_roi['peak_reflectivity'] + loss_per_roi['sigma_peak'],
                     color='gray', alpha=0.2, label='St.dev. non-stain area')

    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    plt.legend(loc='best', fontsize=12)
    plt.tight_layout()

    # save figure
    fname = conf.machine_name + '_' + conf.collector_name + '_' + ref_scaling_method + suffix + '_clt.png'
    plt.savefig(os.path.join(custom_dir,fname))  # or plt.show()
    plt.close()

def plot_rois(loss_per_roi, luer, reference, custom_dir, conf, ref_scaling_method, suffix):
    """
    Plot the evolution of the ROI global reflectivity loss versus pulse count.

    :param loss_per_roi: dataframe with the end results on reflectivity
    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary containing the reference image
    :param custom_dir: custom directory to store images/analysis results
    :param conf: object with machine/collector info
    :param ref_scaling_method: scaling method for reference
    :param suffix: additional text to be added to filename
    :return: None
    """

    plt, patches = init()

    colors = plt.cm.viridis(np.linspace(0, 1, 5))

    figsize = (8, 6)
    plt.figure(figsize=figsize, facecolor='white')

    plt.ylabel("Global reflectivity loss (%)", fontsize=16)
    plt.xlabel("Delta pulse count (Gp)", fontsize=16)
    plt.title(make_title(luer, reference, conf), fontweight='bold', fontsize=14, loc='center')

    plt.plot((loss_per_roi['collector_pulse_count']-loss_per_roi['collector_pulse_count'].iloc[0]), loss_per_roi['reflectivity_loss'],
             '-', color=colors[1], label='Total collector')

    plt.plot((loss_per_roi['collector_pulse_count'] - loss_per_roi['collector_pulse_count'].iloc[0]),
             loss_per_roi['stain_reflectivity_loss'], '-o', color=colors[2], label='Stain area')
    plt.plot((loss_per_roi['collector_pulse_count'] - loss_per_roi['collector_pulse_count'].iloc[0]),
             loss_per_roi['non_stain_reflectivity_loss'], '-o', color=colors[3], label='Non-stain area')

    plt.plot((loss_per_roi['collector_pulse_count']-loss_per_roi['collector_pulse_count'].iloc[0]),
             loss_per_roi['est_scanner_loss'], '-.', color=colors[2],
             label='Est. Scanner degradation')

    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    plt.legend(loc='best', fontsize=12)
    plt.tight_layout()

    # save figure
    fname = conf.machine_name + '_' + conf.collector_name + '_' + ref_scaling_method + suffix + '_roi.png'
    plt.savefig(os.path.join(custom_dir,fname))  # or plt.show()
    plt.close()
