# -*- coding: utf-8 -*-
"""
radon_roi.py
Authors: RWKL
Date:  2019-05-12

Radon ROI calculated the contribution within a region of interest, as part of the total loss within a radon image.

Usage:

::

    from pyeuv.EUVDashboard.clients import UserLANClient
    from pyeuv.Collector.Radon.radon_roi import get_predefined_rois
    from pyeuv.Collector.Radon.radon_roi import radon_io
    from pyeuv.Collector.Radon.radon_roi import calculate_roi_contributions

    client = UserLANClient()
    raw_luer_file = 'LUER_mYYYY_timestamp.XXXX.raw'
    processed_luer_file = 'LUER.XXXX._SN_FAR_FIELD_WITH_DOTS.dat'
    processed_luer = radon_io.load_dots(processed_luer_file)
    luer_dict = radon_io.get_luer_dict_object(processed_luer, raw_luer_file)
    loss_per_roi = calculate_roi_contributions(client, source_id, luer_dict, roi_dict)

New functions (DAAU): scale_generic_ref, calculate_stains, generate_analysis_results,
    calculate_initial_reflectivity_loss, add_local_reflectivity
Date:  2020-06-02

"""
import os
import numpy as np
import pandas as pd
import pyeuv.Collector.Radon.radon_reference_image as radon_reference
import pyeuv.Collector.Radon.radon_scaling as radon_scaling
import pyeuv.Collector.Radon.shared as radon_shared
import pyeuv.Collector.Radon.roi_io as roi_io
import pyeuv.Collector.Radon.radon_io as radon_io
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions
from pyeuv.Collector.Radon.radon_plotting import plot_radon, plot_histogram, plot_fit_generic_ref_scaling, plot_sliedt, plot_rois
from pyeuv.Collector.Radon.radon_scaling import gaussian, calculate_intensity_ratio, pre_scale_reflectivity

def calculate_roi_contributions(client, source_id, luer_dict, roi_dict,
                                reference_type='new_collectors_per_mirror_and_pupil',
                                scaling_method='sliedt_interpolate',
                                ref_scaling_method=None,
                                threshold_slie_dt_upper=110,
                                use_sg_filtering=False,
                                use_keys=True,
                                verbose=False,
                                analyze_stains=False,
                                conf=None,
                                custom_dir=None,
                                use_first_stain_area=False,
                                icrm=False,
                                compensate_shift=False,
                                min_bound_correction=False,
                                custom_reference_filepath=None):
    """
    This function calculates calculates the contribution per ROI.
    
    :param client: connection to influx
    :param source_id: source id of system for which we are calculating the ROI contributions
    :param luer_dict: dictionary containing luers to process, scaling factors, etc.
    :param roi_dict: dictionary with roi definitions. The dictionary contains one roi per luer_key.
        Each roi contains 'type' (polygon, polar_bounds) and a set of keys depending on the type.
    :param reference_type: string to specify what type of reference image has to be used.
    :param scaling_method: string to specify which scaling method to be applied. Options are 'sliedt_interpolate'
        (default), 'sliedt_nearest', 'sliedt_ffill', 'intensity'
    :param ref_scaling_method: method to scale the reference to the right global reflectivity value
    :param threshold_slie_dt_upper: upper limit fir slie_dt
    :param use_sg_filtering: apply sg filter for slie/dt scaling of luers (default: False)
    :param use_keys: switch to use with_keys format for with_dots luer files
    :param verbose: switches debug mode (default=False)
    :param analyze_stains: provide extensive extra info + plots on the generic reference scale in the results file
    :param conf: object with machine/collector info
    :param custom_dir: custom directory to store images/analysis results
    :param use_first_stain_area: only use the stains detected in the first luer for processing the other luers
    :param icrm: use icrm data instead of SLIE/DT
    :param compensate_shift: compensate the shift of the non-stain peak, and use this to estimate the scanner loss
    :param min_bound_correction: use a specific width of a histogram (e.g. from the first LUER) to correct the min-bound
            for stain detection
    :param custom_reference_filepath: select a custom reference path
    :return: dataframe with loss per roi. The key should be the luer timestamp.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    first_key = list(luer_dict.keys())[0]
    reference = radon_reference.get_reference(client, source_id, start_time=luer_dict[first_key]['timestamp'],
                                              reference_type=reference_type, use_keys=use_keys,
                                              custom_reference_filepath=custom_reference_filepath, verbose=verbose)

    # get scaling factors
    timestamps = [luer['timestamp'] for luer in luer_dict.values()]

    scaling_factors = pd.DataFrame(radon_scaling.get_scaling(client, source_id,
                                                             luer_timestamps=timestamps,
                                                             scaling_method=scaling_method,
                                                             threshold_upper=threshold_slie_dt_upper,
                                                             use_sg_filtering=use_sg_filtering, verbose=verbose,
                                                             icrm=icrm))

    # add collector and scanner pulse count data to the scaling factors
    scaling_factors = radon_io.connect_scaling_factors_to_influx_data(scaling_factors, client, conf,
                                                                      luer_dict[first_key]['timestamp'], icrm=icrm)

    for luer_key, luer in luer_dict.items():
        luer['scaling_factor'] = scaling_factors.loc[luer['timestamp'], 'scaling_factor']
        luer['luer_key'] = luer_key

        luer['collector_pulse_count'] = scaling_factors.loc[luer['timestamp'], 'collector_pulse_count']
        luer['scanner_pulse_count'] = scaling_factors.loc[luer['timestamp'], 'scanner_pulse_count']

        # If a generic reference is selected as collector, instead of assuming that the this reference is at the
        # normalized reflectivity (SLIEDT) value of the start, it calculates the actual reflectivity based on comparing
        # the intensity map of the 1st luer with the generic reference. If only the non-stain area is considered, and
        # it is assumed that this area is not degraded/contaminated, the reflectivity of the generic reference can be
        # back-calculated:
        # 1) first the intensity of the generic ref is calibrated (may differ due to different integration time/plasma
        # conditions) using the median ratio of intensity of the non-stain (=~clean) area.
        # 2) the reflectivity of the generic reference can now be computed using the ratio of the summed intensity of the
        # current luer over the summed intensity of the generic reference.

        if luer_key == first_key:
            reference['collector_pulse_count'] = luer['collector_pulse_count']
            reference['scanner_pulse_count'] = luer['scanner_pulse_count']
            if ('clean' in ref_scaling_method) and (reference_type != 'first_luer'):
                reference = scale_generic_ref(reference, luer, ref_scaling_method=ref_scaling_method,
                                              conf=conf, custom_dir=custom_dir)
            else:
                reference['scaling_factor'] = luer['scaling_factor']

    loss_per_roi = determine_roi_contributions(client, luer_dict, reference, roi_dict, use_keys=use_keys, verbose=verbose, \
                                               analyze_stains=analyze_stains, \
                                               conf=conf,
                                               custom_dir=custom_dir,
                                               ref_scaling_method=ref_scaling_method,
                                               use_first_stain_area=use_first_stain_area,
                                               compensate_shift=compensate_shift,
                                               icrm=icrm,
                                               min_bound_correction=min_bound_correction)

    return loss_per_roi


def determine_roi_contributions(client, luer_dict, reference, roi_dict, use_keys=True, verbose=False,
                                analyze_stains=True, conf=None, custom_dir=None,
                                ref_scaling_method=None, use_first_stain_area=False,
                                compensate_shift=False, sigma_correction=True,
                                sigma_correction_factor=2, icrm=False, min_bound_correction=False):
    """
    This function calculates the contribution per ROI,
    given a luer_dict including scaling information and a set of roi's.

    :param client: connection to influx
    :param luer_dict: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary containing the reference image
    :param roi_dict: dictionary with roi definitions. The dictionary contains one roi per key.
        Each roi contains 'type' (polygon, polar_bounds) and a set of keys depending on the type.
    :param use_keys: switch to use with_keys format for with_dots luer_dict files
    :param verbose: switches debug mode (default=False)
    :param analyze_stains: provide extensive extra info + plots on the generic reference scale in the results file
    :param conf: object with machine/collector info
    :param custom_dir: custom directory to store images/analysis results
    :param ref_scaling_method: method to scale the reference to the right global reflectivity value
    :param use_first_stain_area: only use the stains detected in the first luer for processing the other luers
    :param compensate_shift: instead of SLIEDT, always scale the images compared to generic reference
    :param sigma_correction: correct for widening in reflectivity distribution of the non-stain area
    :param sigma_correction_factor: select at what sigma level to fixate the correction (e.g. 1 sigma or 2 sigma)
    :param icrm: use icrm data instead of SLIE/DT
    :param min_bound_correction: use a specific width of a histogram (e.g. from the first LUER) to correct the min-bound
            for stain detection
    :return dataframe: with loss per roi. The key should be the luer_dict timestamp.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    loss_per_roi = pd.DataFrame()
    n_keys = len(list(luer_dict.keys()))
    first_key = list(luer_dict.keys())[0]
    mask_dict = {}

    for luer_key, luer in luer_dict.items():

        # Instead of SLIEDT, always scale the images compared to generic reference; differences are attributed to the
        # scanner degradation (but could also be due to uniform contamination and SLIE/DT artefacts!).
        if compensate_shift:
            luer, reference = add_local_reflectivity(luer, reference, verbose=False)
            parameters = radon_scaling.get_scaling_factor_from_intensities(
                luer['data']['intensity_scaled'], reference['data']['intensity_scaled'],
                ref_scaling_method='clean_area_auto' if 'clean' not in ref_scaling_method else ref_scaling_method)

            # Determine initial conditions
            if (luer_key == first_key):
                initial_scaling_factor = luer['scaling_factor']
                initial_sigma_peak = parameters['sigma_peak']
                initial_peak_reflectivity = parameters['peak_reflectivity']

            # Assume that the uniform area is not contaminated. Additionally, assume that the widening of the peak
            # reflectivity is due to convolution of stains. By correcting for this by assuming that "2*sigma + mu"
            # (position at 2 sigma) stays the same, we can now correlate the remaining shift in reflectivity to the
            # scanner loss. See EPS D000884328-00
            compensation_factor = (parameters['peak_reflectivity'] + sigma_correction_factor * parameters['sigma_peak']) / \
                                  (initial_peak_reflectivity + sigma_correction_factor * initial_sigma_peak)
            # The estimated compensation factor is
            luer['est_scanner_loss'] = 100 * (1 - compensation_factor)
            luer['scaling_factor'] = luer['scaling_factor'] / compensation_factor
        else:
            luer['est_scanner_loss'] = 0

        luer, reference = add_reflectivity_loss(luer, reference, verbose)

        if verbose:
            print('luer:', luer_key)
            print('reflectivity_loss: {}'.format(luer['data']['reflectivity_loss'].sum()))

        for roi_key, roi in roi_dict.items():
            if use_keys:
                # dark facets have NaNs for x, y, intensity, so use the reference to obtain the position based mask.
                mask = get_roi_mask(reference, roi, verbose=verbose)
            else:
                # for backward compatibility, determine the mask (for now) on the current image.
                mask = get_roi_mask(luer, roi, verbose=verbose)
            loss_per_roi.loc[luer_key, roi_key] = luer['data'].loc[mask, 'reflectivity_loss'].sum()

        if analyze_stains:
            luer, reference = add_local_reflectivity(luer, reference, verbose)

            if luer_key == first_key:
                if 'clean' not in ref_scaling_method:
                    reference['initial_reflectivity_loss'] = 0
                    reference['calibration_factor'] = np.nan
                    reference['pre_calibration_factor'] = np.nan

            loss_per_roi, parameters, mask_dict, stain_range = calculate_stains(loss_per_roi, luer_key, luer, reference,
                        roi_dict, mask_dict, ref_scaling_method, conf, custom_dir, use_first_stain_area, first_key, verbose,
                        min_bound_correction = min_bound_correction)
            # store parameters of first LUER
            if luer_key == first_key: parameters_first = parameters

    if analyze_stains:
        generate_analysis_results(client, luer, reference, custom_dir, conf, ref_scaling_method, loss_per_roi, parameters,
                                  use_first_stain_area, stain_range, n_keys, parameters_first=parameters_first,
                                  icrm=icrm)

    return loss_per_roi


def calculate_stains(loss_per_roi, luer_key, luer, reference, roi_dict, mask_dict, ref_scaling_method, conf, custom_dir,
                     use_first_stain_area, first_key, verbose, min_bound_correction=False):
    """
    Analyzes the ROI in more detail by looking at the stain vs non-stain region

    :param loss_per_roi: dataframe with the end results on reflectivity
    :param luer_key: luer id
    :param luer: luer information including intensity, reflectivity
    :param reference: reference information including intensity, reflectivity
    :param roi_dict: dictionary with roi definitions. The dictionary contains one roi per luer_key.
        Each roi contains 'type' (polygon, polar_bounds) and a set of keys depending on the type.
    :param mask_dict: dictionary of custom rois.
    :param ref_scaling_method: refernece scaling method
    :param conf: object with machine/collector info
    :param custom_dir: custom directory to store images/analysis results
    :param use_first_stain_area: fixate the stain vs non-stain region using the first luer
    :param first_key: the luer id of the first luer
    :return:
        loss_per_roi: dataframe with the end results on reflectivity per ler
    """

    loss_per_roi.loc[luer_key, 'luer_key'] = luer_key

    # add information retrieved from InfluxDB
    loss_per_roi.loc[luer_key, 'sliedt_luer'] = luer['scaling_factor'] * 100
    loss_per_roi.loc[luer_key, 'sliedt_reference'] = reference['scaling_factor'] * 100
    loss_per_roi.loc[luer_key, 'est_scanner_loss'] = luer['est_scanner_loss']
    loss_per_roi.loc[luer_key, 'collector_pulse_count'] = luer['collector_pulse_count']
    loss_per_roi.loc[luer_key, 'scanner_pulse_count'] = luer['scanner_pulse_count']

    # add luer intensity
    loss_per_roi.loc[luer_key, 'intensity_luer'] = luer['data']['intensity'].sum()
    loss_per_roi.loc[luer_key, 'intensity_reference'] = reference['data']['intensity'].sum()

    # Go from the relative SLIEDT scale to an absolute scale, by dividing the reflectivity loss by the scale \
    # factor of the first luer. In the case of local reflectivity this is not needed, as it already is compensated in
    # the fraction: R = (I * SLIE/DT) / (I_ref * SLIE/DT_ref)
    luer['data']['reflectivity_loss'] /= reference['scaling_factor']
    loss_per_roi.loc[luer_key, 'reflectivity_loss'] = luer['data']['reflectivity_loss'].sum()
    for roi_key, roi in roi_dict.items():
        loss_per_roi.loc[luer_key, roi_key] /= reference['scaling_factor']

    # scale calibration factor of the generic reference intensity as function of the first radon map
    parameters = radon_scaling.get_scaling_factor_from_intensities(
        luer['data']['intensity_scaled'], reference['data']['intensity_scaled'],
        ref_scaling_method='clean_area_auto' if 'clean' not in ref_scaling_method else ref_scaling_method)

    # In the case of compensating the reflectivity based on the conditions of the first LUER, as well as in the case of
    # the upper and lower bound method, the actual position of the clean area reflectivity peak in the
    # histogram is different as the value from the parameters dictionary. Hence, we have to correct the border between
    # stain and non-stain area. See EPS D000884328-00
    if min_bound_correction and ((luer_key is not first_key) or ('clean_area_auto_' in ref_scaling_method)):
        # Correct the amplitude based on the last fit. Calculate bin index of fit at center of first peak
        bins = parameters['bins']
        counts = parameters['counts']
        if (luer_key is not first_key):
            # Use the parameters of the first LUER
            initial_peak_reflectivity = loss_per_roi['peak_reflectivity'].iloc[0] / 100
            initial_sigma_peak = loss_per_roi['sigma_peak'].iloc[0] / 100
        elif 'clean_area_auto_' in ref_scaling_method:
            # If the upper bound and lower bound automated clean area detection algo is used, the fitted peak is not the
            # peak which is used to derive the normalization value. Recalculate the corrected peak position and width.
            from pyeuv.Collector.Radon.radon_scaling import calculate_min_max_compensation_factor
            _, initial_peak_reflectivity, initial_sigma_peak = \
                calculate_min_max_compensation_factor(parameters['peak_reflectivity'], parameters['sigma_peak'],
                                                      ref_scaling_method)

        # determine initial Gauss
        popt = radon_scaling.determine_location_initial_distribution(bins, counts, initial_peak_reflectivity,
                                                                     initial_sigma_peak)

        # determine min bound using this initial Gauss
        remainder, min_bound = radon_scaling.determine_stain_area(counts, bins, initial_peak_reflectivity,
                                                                  initial_sigma_peak, popt)
        parameters['min_bound'] = min_bound

    # add scaling related values
    loss_per_roi.loc[luer_key, 'initial_reflectivity_loss'] = reference['initial_reflectivity_loss']
    loss_per_roi.loc[luer_key, 'calibration_factor'] = reference['calibration_factor']
    loss_per_roi.loc[luer_key, 'pre_calibration_factor'] = reference['pre_calibration_factor']

    # add fitting parameters
    loss_per_roi.loc[luer_key, 'min_bound'] = parameters['min_bound'] * 100
    loss_per_roi.loc[luer_key, 'peak_reflectivity'] = parameters['peak_reflectivity'] * 100
    if parameters['applied_fit']:
        loss_per_roi.loc[luer_key, 'error_peak'] = parameters['error_peak'] * 100
        loss_per_roi.loc[luer_key, 'sigma_peak'] = parameters['sigma_peak'] * 100
        loss_per_roi.loc[luer_key, 'error_sigma'] = parameters['error_sigma'] * 100
        loss_per_roi.loc[luer_key, 'amplitude_peak'] = parameters['amplitude_peak']
        loss_per_roi.loc[luer_key, 'error_amplitude'] = parameters['error_amplitude']
    else:
        loss_per_roi.loc[luer_key, 'error_peak'] = np.nan
        loss_per_roi.loc[luer_key, 'sigma_peak'] = np.nan
        loss_per_roi.loc[luer_key, 'error_sigma'] = np.nan
        loss_per_roi.loc[luer_key, 'amplitude_peak'] = np.nan
        loss_per_roi.loc[luer_key, 'error_amplitude'] = np.nan

    # add stain/non-stain reflectivity values
    stain_range = luer['data'].local_reflectivity < parameters['min_bound'] * 100
    non_stain_range = luer['data'].local_reflectivity >= parameters['min_bound'] * 100

    if use_first_stain_area:
        if (luer_key is first_key):
            mask_dict['stain_range'] = stain_range
            mask_dict['non_stain_range'] = non_stain_range
        stain_range = mask_dict['stain_range']
        non_stain_range = mask_dict['non_stain_range']

    loss_per_roi.loc[luer_key, 'stain_reflectivity_loss'] = luer['data'].loc[stain_range, 'reflectivity_loss'].sum()
    loss_per_roi.loc[luer_key, 'stain_local_reflectivity'] = luer['data'].loc[stain_range, 'local_reflectivity'].median()
    loss_per_roi.loc[luer_key, 'non_stain_reflectivity_loss'] = luer['data'].loc[non_stain_range, 'reflectivity_loss'].sum()
    loss_per_roi.loc[luer_key, 'non_stain_local_reflectivity'] = luer['data'].loc[non_stain_range, 'local_reflectivity'].median()
    loss_per_roi.loc[luer_key, 'area_percentage_stain'] = luer['data'].loc[stain_range, 'reflectivity_loss'].count() / \
                            luer['data']['reflectivity_loss'].count() * 100

    loss_per_roi.loc[luer_key, 'max_local_reflectivity'] = luer['data']['local_reflectivity'].max()
    loss_per_roi.loc[luer_key, '98p_local_reflectivity'] = luer['data']['local_reflectivity'].quantile(.98)

    # add region of interest used by ES-ratio
    es_ratio_range = luer['data'].index.str.contains('_1') | luer['data'].index.str.contains('_13')
    luer, reference = add_reflectivity_loss(luer, reference, verbose, mask = es_ratio_range, mask_prefix = 'es_ratio_')
    loss_per_roi.loc[luer_key, 'es_ratio_reflectivity_loss'] = luer['data'].loc[es_ratio_range, 'es_ratio_reflectivity_loss'].sum()
    loss_per_roi.loc[luer_key, 'es_ratio_local_reflectivity'] = luer['data'].loc[es_ratio_range, 'local_reflectivity'].median()

    if (custom_dir is not None) & (conf is not None):
        # create a subdir to save the more detailed figures
        custom_subdir = os.path.join(custom_dir, conf.machine_name + '_' + conf.collector_name + \
                                     '_' + ref_scaling_method)
        if not os.path.exists(custom_subdir):
            os.makedirs(custom_subdir)

        use_first_stain_area_txt = ''
        if use_first_stain_area: use_first_stain_area_txt = '_use_first_stain_area'

        plot_histogram(luer, reference, custom_subdir, conf, ref_scaling_method, parameters=parameters, suffix=use_first_stain_area_txt,
            mask=stain_range)
        plot_radon(luer, reference, custom_subdir, conf, ref_scaling_method, mask=None)
        plot_radon(luer, reference, custom_subdir, conf, ref_scaling_method, suffix='_stains' + use_first_stain_area_txt,
            mask=stain_range)

        if 'clean' in ref_scaling_method:
            plot_fit_generic_ref_scaling(parameters, conf=conf, luer=luer, reference=reference,
                custom_dir=custom_subdir)

    return loss_per_roi, parameters, mask_dict, stain_range


def generate_analysis_results(client, luer, reference, custom_dir, conf, ref_scaling_method, loss_per_roi, parameters,
                              use_first_stain_area, stain_range, n_keys, parameters_first = None, icrm = False):
    """
    This generates analysis results, including:
    * Local reflectivity histogram
    * RADON reflectivity image
    * RADON reflectivity image - stain area marked with white
    If more than one image:
    * SLIEDT + non-stain local reflectivity evolution
    * ROI (stain/non stain) contribution to global loss evolution

    :param client: connection to influx
    :param luer: luer information including intensity, reflectivity
    :param reference: reference information including intensity, reflectivity
    :param custom_dir: custom directory to store images/analysis results
    :param conf: object with machine/collector info
    :param ref_scaling_method: refernece scaling method
    :param loss_per_roi: dataframe with the end results on reflectivity per ler
    :param parameters: dataframe with various values associated to the scaling method of the current LUER
    :param use_first_stain_area: fixate the stain vs non-stain region using the first luer
    :param stain_range: indices of locations of collector area with a stain
    :param n_keys: total number of luers
    :param parameters_first: dataframe with various values associated to the scaling method of the first LUER
    :param icrm: use icrm data instead of SLIE/DT
    :return: None
    """

    use_first_stain_area_txt = ''
    if use_first_stain_area: use_first_stain_area_txt = '_use_first_stain_area'

    plot_histogram(luer, reference, custom_dir, conf, ref_scaling_method, parameters=parameters,
                   parameters_first=parameters_first, suffix=use_first_stain_area_txt, mask=stain_range)
    plot_radon(luer, reference, custom_dir, conf, ref_scaling_method, mask=None)
    plot_radon(luer, reference, custom_dir, conf, ref_scaling_method, suffix='_stains' + use_first_stain_area_txt,
               mask=stain_range)

    if n_keys > 1:
        plot_sliedt(client, loss_per_roi, luer, reference, custom_dir, conf, ref_scaling_method,
                    use_first_stain_area_txt, icrm = icrm)
        plot_rois(loss_per_roi, luer, reference, custom_dir, conf, ref_scaling_method, use_first_stain_area_txt)

        fname = 'results_' + conf.machine_name + '_' + conf.collector_name + '_' + ref_scaling_method + \
                use_first_stain_area_txt + '.csv'
        loss_per_roi.to_csv(os.path.join(custom_dir, fname))

        return


def scale_generic_ref(reference, luer, ref_scaling_method = 'clean_area', conf=None, custom_dir=None):
    """
    Function to calibrate the intenstiy of the generic ref and to estimate its reflectivity.
    For this, it uses the reference scaling method.

    :param reference: dictionary containing the reference image
    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param ref_scaling_method: method to scale
    :param conf: object with machine/collector info
    :param custom_dir: custom directory to store images/analysis results
    :return:
        reference: the scaled reference dataframe
    """

    # reference intensity is normalized, so is difficult to compare with the luer; hence, scale the reference to
    # similar values as the current luer
    reflectivity = calculate_intensity_ratio(luer['data']['intensity'], reference['data']['intensity'])
    pre_calibrate_factor = pre_scale_reflectivity(reflectivity)
    reference['data']['intensity'] *= pre_calibrate_factor
    reference['pre_calibration_factor'] = pre_calibrate_factor
    reference['timestamp'] = luer['timestamp']

    # scale calibration factor of the generic reference intensity as function of the first radon map
    parameters = radon_scaling.get_scaling_factor_from_intensities(luer['data']['intensity'],
                                                                   reference['data']['intensity'],
                                                                   ref_scaling_method = ref_scaling_method)
    reference['calibration_factor'] = parameters['peak_reflectivity']

    # calculating the relative reflectivity loss
    initial_reflectivity_loss = calculate_initial_reflectivity_loss(luer, reference, parameters['peak_reflectivity'])

    # calibrate the reference intensity to the same scaling as the first luer (i.e. if this factor is applied, the clean
    # area in the radon image has a more or less 100% median reflectivity).
    if 'clean_area_auto_' in ref_scaling_method:
        # If the upper bound and lower bound automated clean area detection algo is used, we will compensate the center
        # of the fit by correcting for a smaller/larger width of the peak. The basic assumption is that "2*sigma + mu"
        # (position at 2 sigma) stays the same.
        from pyeuv.Collector.Radon.radon_scaling import calculate_min_max_compensation_factor
        compensation_factor, _, _ = calculate_min_max_compensation_factor(parameters['peak_reflectivity'], \
                                                                          parameters['sigma_peak'],
                                                                          ref_scaling_method)
        parameters['peak_reflectivity'] *= compensation_factor
        initial_reflectivity_loss = calculate_initial_reflectivity_loss(luer, reference, parameters['peak_reflectivity'])

    reference['initial_reflectivity_loss'] = initial_reflectivity_loss
    reference['data']['intensity'] *= parameters['peak_reflectivity']

    # calculate what the reflectivity of the generic ref is, starting from the reflectivity of the first luer, and
    # multiplying that by the inverse of the relative reflectivity drop ratio
    reflectivity_first_luer = luer['scaling_factor']
    reflectivity_generic_ref = reflectivity_first_luer * 100. / (100. - initial_reflectivity_loss)
    reference['scaling_factor'] = reflectivity_generic_ref

    if custom_dir:
        plot_fit_generic_ref_scaling(parameters, conf = conf, luer = luer, reference = reference,
                                     custom_dir=custom_dir, add_deltas=False, add_key=False)

    return reference


def calculate_initial_reflectivity_loss(luer, reference, calibration_factor):
    """
    This function calculates the initial reflectivity loss.

    :param luer: dictionary containing luers to process, scaling factors, etc.
    :param reference: dictionary with reference luer data
    :param calibration_factor: the calibration factor for the reference intensity
    :return: dataframe:
        initial_reflectivity_loss: the estimation of the initial relative reflectivity loss
    """

    # estimate the reflectivity loss in between the generic reference and the first radon map
    initial_reflectivity_loss = \
        ((calibration_factor * reference['data']['intensity'].sum()) - luer['data']['intensity'].sum()) / \
        (calibration_factor * reference['data']['intensity'].sum())*100

    return initial_reflectivity_loss


def add_local_reflectivity(luer, reference, verbose):
    """
    Adds the local reflectivity per data point to the luer dataframe

    :param luer: dictionary with luer data
    :param reference: dictionary with reference luer data
    :param verbose: switches debug mode (default=False)
    :return: dictionary with luer data including local reflectivity
    """

    # normalize luer
    intensity_norm = radon_shared.get_normalized_intensity(luer['data'], verbose=verbose)
    intensity_ref_norm = radon_shared.get_normalized_intensity(reference['data'], verbose=verbose)

    # scale luer
    intensity_scaled = intensity_norm * luer['scaling_factor']
    intensity_ref_scaled = intensity_ref_norm * reference['scaling_factor']

    luer['data']['intensity_scaled'] = intensity_scaled
    reference['data']['intensity_scaled'] = intensity_ref_scaled

    # calculate the local reflectivity
    luer['data']['local_reflectivity'] = calculate_intensity_ratio(intensity_scaled, intensity_ref_scaled) * 100

    return luer, reference


def add_reflectivity_loss(luer, reference, verbose, mask = None, mask_prefix = ''):
    """
    Adds the reflectivity loss contribution per data point to the luer dataframe
    The sum of all these loss contributions sum up to the total loss (as percentage)

    :param luer: dictionary with luer data
    :param reference: dictionary with reference luer data
    :param verbose: switches debug mode (default=False)
    :param mask: apply on to limited area of luer data
    :param mask: add mask_prefix to not confuse with non-masked column name
    :return: dictionary with luer data including reflectivity loss
    """

    # if no mask_prefix is defined in case of using as mask, create default name
    if (mask is not None) and (mask_prefix is ''): mask_prefix = 'mask_'

    # apply mask if available
    luer_data = luer['data'] if mask is None else luer['data'][mask]
    reference_data = reference['data'] if mask is None else reference['data'][mask]

    # normalize luer
    intensity_norm = radon_shared.get_normalized_intensity(luer_data, verbose=verbose)
    intensity_ref_norm = radon_shared.get_normalized_intensity(reference_data, verbose=verbose)

    # scale luer
    intensity_scaled = intensity_norm * luer['scaling_factor']
    intensity_ref_scaled = intensity_ref_norm * reference['scaling_factor']

    ## Bring specific ROIs to zero if needed
    # for roi_key, roi in roi_dict.items():
    #     mask = get_roi_mask(reference, roi, verbose=verbose)
    #     intensity_scaled.loc[mask] = 0

    # calculate intensity loss
    intensity_loss = intensity_ref_scaled - intensity_scaled

    # calculate the reflectivity loss
    column_name = mask_prefix + 'reflectivity_loss'
    luer['data'][column_name] = reference['scaling_factor'] * intensity_loss / intensity_ref_scaled.sum() * 100

    return luer, reference


def get_roi_mask(luer, roi, verbose=False):
    """
    Return the mask that selects the datapoints within the specified region of interest
    The roi can be defined by a polygon ('format' = 'polygon'), or by limits in polar coordinates ('format' = 'polar')
    
    :param luer: dictionary containing the luer image
    :param roi: dictionary containing the roi
    :param verbose: switches debug mode (default=False)
    :return mask: dictionary containing the mask for the LUER image
    """

    do_it.do_it_verbose(currentframe(), verbose)

    verbose = False
    from matplotlib import path
    if roi['type'] != 'ROI':
        raise Exception('Object is of type {}, expected type \'ROI\''.format(roi['type']))

    if roi['format'] == 'polar':
        if (('r_min' not in roi.keys()) or
                ('r_max' not in roi.keys()) or
                ('phi_min' not in roi.keys()) or
                ('phi_max' not in roi.keys())):
            raise Exception(
                'ROI (polar) should have keys \'r_min\', \'r_max\', \'phi_min\', and \'phi_max\'. Keys are {}'.format(
                    roi.keys()))

        if verbose:
            print('ROI properties (r_min, r_max, phi_min, phi_max): {}'.format(
                  roi['r_min'], roi['r_max'], roi['phi_min'], roi['phi_max']))
            print('types:', type(roi['r_min']), type(roi['r_max']), type(roi['phi_min']), type(roi['phi_max']))

        luer['data']['r'] = radon_shared.get_radius(luer['data'], verbose=verbose)
        luer['data']['phi'] = radon_shared.get_phi(luer['data'], verbose=verbose)
        if verbose:
            print('minimum and max radius', luer['data']['r'].min(), luer['data']['r'].max())

        if roi['phi_min'] <= roi['phi_max']:
            # this is typically the case
            mask = ((luer['data']['r'] > roi['r_min']) &
                    (luer['data']['r'] <= roi['r_max']) &
                    (luer['data']['phi'] > roi['phi_min']) &
                    (luer['data']['phi'] <= roi['phi_max'])
                    )
        else:
            # if phi_min=345, phi_max=15, it means from 2:30 (phi_max) to 3:30 (phi_min)
            # so 2:30 to 3 and 3 to 3:30 (<15 and >354)
            mask = (
                    (luer['data']['r'] > roi['r_min']) &
                    (luer['data']['r'] <= roi['r_max']) &
                    (
                            (luer['data']['phi'] > roi['phi_min']) |
                            (luer['data']['phi'] <= roi['phi_max'])
                    )
            )

    elif roi['format'] == 'polygon':
        try:
            # create a list of coordinates ([[x0, y0], ..., [xn, yn]])
            points = []
            for i in zip(luer['data'].x, luer['data'].y):
                points.append(list(i))

            # create a polygon and and create mask for all points in the polygon
            polygon = path.Path(roi['positions'])
            mask = polygon.contains_points(points)

        except Exception as e:
            print('get_roi_mask fails for ROI with format: {}'.format(roi['format']))
            raise Exception(e)

    else:
        print('get_roi_mask not implemented for roi type: {}'.format(roi['type']))
        raise Exception('get_roi_mask not implemented for roi type: {}'.format(roi['type']))

    return mask


def deal_with_dark_facets(luer, use_keys=True, verbose=False):
    """
    Update the dark pupil facets (that are np.NaN in the with_keys files), to 0.
    This correction can only be performed in case use_keys = True.
    Otherwise, nothing is done
    This should be used for SLIE/DT scaling to ensure that the sum of all losses adds up to the SLIE/DT loss.
    
    :param luer: dictionary containing the luer image
    :param use_keys: indicator of the format of the luer (default=False)
    :param verbose: switches debug mode (default=False)
    :return: dictionary with the luer with updated intensities
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if verbose:
        print(type(luer))
        print('luer keys:', luer.keys())

    if use_keys:
        luer['data']['intensity'].fillna(0, inplace=True)

    return luer


def get_predefined_rois(roi_definition='spiderweb', verbose=False):
    """
    Load roi definitions from a json file. Depending on the value of roi_definition it loads:
    - 'spiderweb': the 60 spiderweb elements
    - 'rois_from_field': a few roi definitions based on commonly observed roi patterns in the field

    :param roi_definition: string refering to the predifined roi definition
    :raises ValueError: not supported roi definition
    :param verbose: switches debug mode (default=False)
    :return dictionary: with the rois
    """

    do_it.do_it_verbose(currentframe(), verbose)

    import os

    # Reminder: syntax as below ('string is string') is not py27 compatible
    # if roi_definition is 'spiderweb':
    if roi_definition == 'spiderweb':
        path_to_roi_definition = os.path.join(radon_io.get_roi_directory(), 'spiderweb.json')
        roi_dict = roi_io.read_rois_from_json(path_to_roi_definition, verbose=verbose)

    elif roi_definition == 'rois_from_field':
        path_to_roi_definition = os.path.join(radon_io.get_roi_directory(), 'roi_definitions_from_field.json')
        roi_dict = roi_io.read_rois_from_json(path_to_roi_definition, verbose=verbose)

    else:
        raise Exception('ROI definition  \'{}\' not implemented'.format(roi_definition))

    return roi_dict

if __name__ == '__main__':

    from pyeuv.EUVDashboard.clients import UserLANClient
    from pyeuv.Collector.Radon.radon_roi import get_predefined_rois, radon_io, calculate_roi_contributions
    from pyeuv.Shared.configuration import Configuration

    conf = Configuration()

    verbose = False
    roi_dict_field = get_predefined_rois(roi_definition='rois_from_field', verbose=verbose)
    end_time = pd.Timestamp('2020-04-21 13:23:00')
    client = UserLANClient()
    source_id = 's62280'
    collector = 'SDMSC161.H01'
    path = r'W:\Collector_Performance_Reports\3400\Intel#1_4129_V51_62280\#14_'+collector+r'\2.in-use\RADON'
    raw_luer_file = path + r'\LUER_m4129_202004192309.0296.raw'
    processed_luer_file = path + r'\LUER.0296_SN_FAR_FIELD_WITH_DOTS_WITH_KEYS.DAT'
    ref_scaling_method = 'clean_area_auto'
    analyze_stains = True

    custom_dir = r'W:\Collector_Performance_Reports\3400\database_initial_reflectivity_loss'

    machine_list = client.get_machine_list(return_type='dataframe')
    machine = machine_list[machine_list.source_nr == int(source_id[1:])]
    conf.set_configuration(client, machine.iloc[0], collector)

    processed_luer = radon_io.load_dots(processed_luer_file)
    luer_dict = {}
    luer_dict[1] = radon_io.get_luer_dict_object(processed_luer, raw_luer_file)
    loss_per_roi = calculate_roi_contributions(client, source_id, luer_dict, roi_dict_field,
                                               ref_scaling_method = ref_scaling_method,
                                               analyze_stains = analyze_stains,
                                               conf=conf,
                                               custom_dir=custom_dir)

    print('end')