# -*- coding: utf-8 -*-
"""
radon_io.py
Authors: RWKL
Date: 2019-05-12

Part of this code is extracted from the unblurred radon tool, originally developed by JBKH
This code handles reading in different radon related files, such as '.raw', 'with_dots.dat', and 'with_keys.dat'
"""

import os
import pandas as pd
import numpy as np
import ntpath
import json
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions
from pyeuv.Collector.Radon.radon_image_processing import smooth_luer_using_nearby_ffms, blur_image

def read_ffm_module_info_from_json(json_file, verbose=False):
    """
    Read ffm module ids from json file and return it as a dict.
    :param json_file: full path to json file
    :param verbose: switches debug mode (default=False)
    :return: dictionary with ffm ranges for each module
    """

    do_it.do_it_verbose(currentframe(), verbose)

    with open(json_file, 'r') as fp:
        try:
            ffm_module_dict = json.load(fp)
        except Exception as e:
            raise e

    return ffm_module_dict

def get_luer_dict_object(luer_data, raw_filename=None, raw_file_object=None, verbose=False):
    """
    Creates a dictionary containing the luer_data and other supporting metadata

    :param luer_data: dataframe containing the luer data
    :param raw_filename: full path to the luer raw file
    :param raw_file_object: handle to the raw file
    :param verbose: switches debug mode (default: False)
    :return: dictionary with luer data
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if (raw_file_object is None) and (raw_filename is None):
        timestamp = pd.Timestamp(0).tz_localize('UTC')
        pulse_count = np.NaN
        
    else:
        timestamp = get_timestamp_from_luer_raw(raw_filename, raw_file_object, verbose)
        pulse_count = get_pulse_count_from_luer_raw(raw_filename, raw_file_object, verbose)
        
    luer_dict = dict()
    luer_dict['timestamp'] = timestamp
    luer_dict['pulse_count'] = pulse_count
    
    luer_dict['data'] = luer_data

    return luer_dict


def load_dots(luer_file, use_keys=True, remove_zeros=True, dark_facets_to_zero=True, verbose=False, correct_ffm=False,
              ffm_window=5, blurred=False):
    """
    Loads a luer with_dots file.
    It takes care of the x and y coordinate transformation.

    :param luer_file: full path of the luer file to be loaded
    :param use_keys: switch to read old format (x, y, i), versus new format ()
    :param remove_zeros: for luer output without keys, the data is snapped to a uniform grid. Where there is no data,
        the grid contains zeros. By default, we remove them. However, when using it to make a bitmap, the zeros should
        not be thrown away. (default: True)
    :param dark_facets_to_zero: switch to set dark facets from nan to 0, only when using keys (default: True)
    :param correct_ffm: correct for varying intensity of the field-facet mirrors
    :param ffm_window: smoothing window for intensity smoothing field-facet mirrors
    :param blurred: blur radon image
    :param verbose: switches debug mode (default: False)
    :returns: dataframe with columns x, y and intensity
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if use_keys:
        try:
            luer_data = pd.read_csv(luer_file, sep=',', index_col=0, header=None, skipinitialspace=True)
            luer_data.drop([4], axis=1, inplace=True)
            luer_data.columns = ['x', 'y', 'intensity']
            if dark_facets_to_zero:
                luer_data.intensity.fillna(0, inplace=True)
        except Exception as e:
            raise Exception("Could not load data for unblurred luer .dat file {}\n{}".format(luer_file, e))
    else:
        try:
            luer_data = pd.read_csv(luer_file, sep=' ', names=['x', 'y', 'intensity'])
            if remove_zeros:
                luer_data = luer_data.loc[luer_data['intensity'] != 0]

        except Exception as e:
            raise Exception("Could not load data for unblurred luer .dat file {}\n{}".format(luer_file, e))

    # Flip Far Field to collector coordinates
    luer_data['x'] *= -1.0
    luer_data['y'] *= -1.0

    info_facets = np.array([v.split('_') for v in luer_data.index.values], dtype=np.int)

    luer_data['facet'] = info_facets[:, 0]
    luer_data['dot'] = info_facets[:, 1]

    if correct_ffm:

        # import ffm module config
        path_to_ffm_module_info = os.path.join(get_roi_directory(), 'ffm_module_info.json')
        ffm_modules = read_ffm_module_info_from_json(path_to_ffm_module_info)

        # smooth luer over ffm modules
        luer_data = smooth_luer_using_nearby_ffms(luer_data, ffm_modules, ffm_window=ffm_window, verbose=verbose)

    if blurred:
        # blur RADON image
        luer_data = blur_image(luer_data)

    return luer_data

def connect_scaling_factors_to_influx_data(scaling_factors, client, conf, start_time, icrm = False):
    """
    Add additional collector pulse count and scanner pulse count to the LUERs from InfluxDB.

    :param scaling_factors: dataframe with scaling factors [0 - threshold_upper/100]
    :param client: connection to influx
    :param conf: object with machine/collector info
    :param start_time: luer start time
    :param icrm: use icrm data instead of SLIE/DT
    :return: dataframe with scaling factors [0 - threshold_upper/100] + scanner/collector pulse count data
    """
    df_slie_pulsecount = load_reflectivity_data(client, conf, start_time, icrm = icrm)

    scaling_factors = scaling_factors.join(df_slie_pulsecount, how='outer')
    columns = ['slie_dt','collector_pulse_count','scanner_pulse_count']
    scaling_factors[columns] = scaling_factors[columns].interpolate(method='time')

    # forward fill at the start of the collector
    scaling_factors[columns] = scaling_factors[columns].ffill()

    # backward fill at the start of the collector
    scaling_factors[columns] = scaling_factors[columns].bfill()

    scaling_factors.dropna(inplace=True)

    return scaling_factors

def load_reflectivity_data(client, conf, timestamp, icrm = True):
    """
    Load all SLIE/DT data, including pulse count data from InfluxDB

    :param client: connection to influx
    :param conf: object with machine/collector info
    :param luer: luer information including intensity, reflectivity
    :param icrm: use icrm data instead of SLIE/DT
    """
    import pyeuv.Shared.shared as shared
    current_collector = shared.get_current_collector(client, conf.source_id, timestamp)
    slie_pulsecount_signal_dict = {'slie_dt': 'Collector._SLIE_DT_Norm',
                                   'collector_pulse_count': 'Collector._PulseCount',
                                   'scanner_pulse_count': 'Scanner.DW_total_nr_pulses'}
    if icrm:
        slie_pulsecount_signal_dict = {'slie_dt': 'Scanner.OCRM_CollectorLifetimeRelativeReflectivity',
                                       'collector_pulse_count': 'Collector._PulseCount',
                                       'scanner_pulse_count': 'Scanner.DW_total_nr_pulses'}

    # download data
    df_slie_pulsecount = client.get_signals_dict(slie_pulsecount_signal_dict, conf.source_id,
                                                from_time=current_collector.start,
                                                to_time=current_collector.end)
    # transform to Gp
    df_slie_pulsecount.scanner_pulse_count *= 1e-3
    if not icrm: df_slie_pulsecount.collector_pulse_count *= 1e-9

    return df_slie_pulsecount

def load_luer_list(radon_directory, use_keys=True, dark_facets_to_zero=False,
                   luers_to_ignore=[], verbose=False):
    """
    Loads all processed luers within the provided directory.

    :param radon_directory: The radon directory
    :param use_keys: switch to load with_keys files, otherwise loads dots (default: True)
    :param dark_facets_to_zero: switch to set dark facets from nan to 0 (default: False)
    :param luers_to_ignore: list of luer keys to ignore (default: [])
    :param verbose: switches debug mode (default: False)
    :return: dictionary with all luer images. The timestamp, if available in the .dat filename, as key.
        otherwise luer index as key.
    """

    files = os.listdir(radon_directory)
    luer_files_raw = [f for f in files if is_valid_raw_luer_filename(f)]
    if use_keys:
        luer_files = [f for f in files if is_valid_with_keys_luer_filename(f)]
    else:
        luer_files = [f for f in files if is_valid_with_dots_luer_filename(f)]

    luer_list = dict()
    luer_files_raw.sort()
    for file_raw in luer_files_raw:
        key = get_key_from_raw_luer_filename(file_raw, verbose=verbose)
        if key in luers_to_ignore:
            # skip this luer
            continue
        if isinstance(key, int):
            if use_keys:
                file_dots = [f for f in luer_files if get_index_from_with_keys_luer(f) == key]
            else:
                file_dots = [f for f in luer_files if get_index_from_with_dots_luer(f) == key]
        else:
            if use_keys:
                file_dots = [f for f in luer_files if get_timestamp_from_processed_luer_filename(f) == key]
            else:
                file_dots = [f for f in luer_files if get_timestamp_from_processed_luer_filename(f) == key]

        if len(file_dots) == 0:
            continue

        luer_data = load_dots(os.path.join(radon_directory, file_dots[0]), use_keys=use_keys,
                              dark_facets_to_zero=dark_facets_to_zero, verbose=verbose)
        luer_dict = get_luer_dict_object(luer_data, raw_filename=os.path.join(radon_directory, file_raw),
                                         verbose=verbose)

        luer_list[key] = luer_dict

    return luer_list


def save_dots(luer_data, filename, use_keys=True, verbose=False):
    """
    Saves a luer with_dots file.
    It takes care of the x and y coordinate transformation.

    :param luer_data: 
    :param filename: full path of the luer file to be saved
    :param use_keys: switch to read old format (index, x, y, i), versus new format (key, x, y, i)
    :param verbose: switches debug mode (default=False)
    :raises: Exception if writing to disk fails
    """

    do_it.do_it_verbose(currentframe(), verbose)

    import os
    
    # Flip Far Field to collector coordinates
    luer_data['x'] *= -1.0
    luer_data['y'] *= -1.0
    
    if use_keys:
        try:
            luer_data.to_csv(filename, sep=',', line_terminator=',{}'.format(os.linesep), header=False)
        except Exception as e:
            raise Exception("Could not save data to {}\n{}".format(filename, e))
    else:
        try:
            luer_data.to_csv(filename, sep=' ', header=False, index=False)

        except Exception as e:
            raise Exception("Could not save data to {}\n{}".format(filename, e))


def get_luer_with_dots_filename(path_raw, include_machine_name=False, with_keys=True, verbose=False):
    """
    Return the luer with keys filename.
    In the cache (EUV-DB backend) it should include the machine_number, since the cache is a flat dump:
    - LUER_m1234_201906300020.0123.raw --> LUER.m1234.201906300020.0123_SN_FAR_FIELD_WITH_DOTS_WITH_KEYS.dat
    On the CPR it should not  include the machine_number:
    - LUER_m1234_201906300020.0123.raw --> LUER.201906300020.0123_SN_FAR_FIELD_WITH_DOTS_WITH_KEYS.dat

    Use the raw filename to extract the information.
    In case the raw file does not have it (for instance for the 33X0s),
    extract the timestamp from the content of the file.

    :param path_raw: the full path to the raw luer file
    :param include_machine_name: Option to include the machine number in the luer output filename (default: False)
    :param with_keys: switch post-fix to include 'WITH_KEYS' (default: True)
    :param verbose: switches debug mode (default=False)
    :raises: Exception if filename_raw has incorrect format (in filename and content) or does not exist
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if verbose:
        print('Converting \n{}\n to with_keys filename'.format(path_raw))

    if with_keys:
        post_fix = '_SN_FAR_FIELD_WITH_DOTS_WITH_KEYS.dat'
    else:
        post_fix = '_SN_FAR_FIELD_WITH_DOTS.dat'
    
    # get filename without path
    filename_raw = ntpath.basename(path_raw)
    
    if not is_valid_raw_luer_filename(filename_raw, verbose=verbose):
        raise Exception('filename {} is not a valid LUER.*.raw filename'.format(filename_raw))
    
    chunks = filename_raw.split('.')
    
    if len(chunks[0]) == 4:
        # no machine name and timestamp, only 'LUER'
        timestamp = get_timestamp_from_luer_raw(path_raw, from_header=True)
        if include_machine_name:
            machine_nr = get_machine_id_from_luer_raw(path_raw)
            filename = '{}.{}.{}.{}{}'.format(chunks[0], machine_nr, timestamp.strftime('%Y%m%d%H%M'),
                                              chunks[1], post_fix)

        else:
            filename = '{}.{}.{}{}'.format(chunks[0], timestamp.strftime('%Y%m%d%H%M'), chunks[1], post_fix)
    else:
        # machine name and timestamp available
        pre_chunks = chunks[0].split('_')
        if include_machine_name:
            filename = '{}.{}.{}.{}{}'.format(pre_chunks[0], pre_chunks[1], pre_chunks[2], chunks[1], post_fix)
        else:
            pre_chunks = chunks[0].split('_')
            filename = '{}.{}.{}{}'.format(pre_chunks[0], pre_chunks[2], chunks[1], post_fix)
    return filename
    

def validate_format_of_luer_filename(filename, prefix, suffix, verbose=False):
    """
    Validates the format of the luer filename and throws an exception in case it fails.
    It tests for correct prefix, suffix and 3 chunks when splitting on '.'.
    
    :param filename: filename to be validated
    :param prefix: expected start of the filename
    :param suffix: expected end of the filename
    :param verbose: switches debug mode (default=False)
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # remove path (if full path is provided), such that we only use the filename
    filename = ntpath.basename(filename)
    
    if not filename.endswith(suffix):
        raise Exception('{} does not end with {}'.format(filename, suffix))
    
    if not filename.startswith(prefix):
        raise Exception('{} does not start with {}'.format(filename, prefix))
        
    chunks = filename.split('.')
    if len(chunks) not in [3, 4, 5]:
        raise Exception('{} is not conform {}.[*]_[0-9]{} format'.format(filename, prefix, suffix))
        

def convert_string_to_int(index_string, length=4, verbose=False):
    """
    Converts a string to an integer, and throws an error in case it fails
    
    :param index_string: String to be converted
    :param length: length of the string, by default 4.
    :param verbose: switches debug mode (default=False)
    :returns: integer value
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if not index_string.isdigit():
        raise Exception('{} should be numeric'.format(index_string))
    
    if len(index_string) != length:
        raise Exception('{} should contain {} characters. Found {}'.format(index_string, length, len(index_string)))
        
    return int(index_string)


def get_index_from_raw_luer(filename, verbose=False):
    """
    Extract LUER index from a raw LUER file name. Raises an exception when unsuccessful

    :param filename: character string of the filename of the raw luer.
    :param verbose: switches debug mode (default=False)
    :returns: luer index
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = '.raw'
    prefix = 'LUER'

    if verbose:
        print('Extract luer index from', filename)
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        chunks = filename.split('.')
        index_string = chunks[1]
        index = convert_string_to_int(index_string, verbose=verbose)

    except Exception as e:
        raise Exception(e)

    return index


def get_timestamp_from_raw_luer_filename(filename, verbose=False):
    """
    Extract timestamp from a raw LUER file name. Raises an exception when unsuccessful
    The timestamp is only available in the 3400s and beyond

    :param filename: character string of the filename of the raw luer.
    :param verbose: switches debug mode (default=False)
    :returns: timestamp string ('YYYYMMDDHHMMSS')
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = '.raw'
    prefix = 'LUER'

    if verbose:
        print('Extract timestamp from filename', filename)
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        chunks = filename.split('_')
        timestamp = chunks[-1].split('.')[0]

    except Exception as e:
        raise Exception(e)

    return timestamp


def get_key_from_raw_luer_filename(filename, verbose=False):
    """
    Extract key from a raw LUER file name. Raises an exception when unsuccessful
    The key is the timestamp in the filename, when available (3400), otherwise, it is the index

    :param filename: character string of the filename of the raw luer.
    :param verbose: switches debug mode (default=False)
    :returns: unique key
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        if len(filename.split('_')) > 1:
            # 3400 and beyond
            # key = get_timestamp_from_raw_luer_filename(filename, verbose=verbose)
            key = get_index_from_raw_luer(filename, verbose=verbose)

        else:
            # 33X0
            key = get_index_from_raw_luer(filename, verbose=verbose)

    except Exception as e:
        raise Exception(e)

    return key


def get_index_from_with_dots_luer(filename, verbose=False):
    """
    Extract LUER index from a processed LUER file name. Raises an exception when unsuccessful
    
    :param filename: character string of the filename of the with_dots luer.
    :param verbose: switches debug mode (default=False)
    :returns: luer index
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = 'WITH_DOTS.dat'
    prefix = 'LUER'

    if verbose:
        print('Extract luer index from', filename)
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        chunks = filename.split('.')
        
        index_string = chunks[-2].split('_')[0]
        
        index = convert_string_to_int(index_string, verbose=verbose)
    
    except Exception as e:
        raise Exception(e)

    return index


def get_index_from_with_keys_luer(filename, verbose=False):
    """
    Extract LUER index from a processed LUER with_keys file name. Raises an exception when unsuccessful

    :param filename: character string of the filename of the with_dots luer.
    :param verbose: switches debug mode (default=False)
    :returns: luer index
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = 'WITH_DOTS_WITH_KEYS.dat'
    prefix = 'LUER'

    if verbose:
        print('Extract luer index from', filename)
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        chunks = filename.split('.')
        
        index_string = chunks[-2].split('_')[0]
        
        index = convert_string_to_int(index_string, verbose=verbose)
    
    except Exception as e:
        raise Exception(e)
    
    return index


def get_timestamp_from_processed_luer_filename(filename, verbose=False):
    """
    Extract timestamp from a processec LUER file name. Raises an exception when unsuccessful
    The timestamp is only available in the 3400s and beyond

    :param filename: character string of the filename of the raw luer.
    :param verbose: switches debug mode (default=False)
    :returns: timestamp string ('YYYYMMDDHHMMSS')
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = '.dat'
    prefix = 'LUER.'

    if verbose:
        print('Extract timestamp from filename', filename)
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        timestamp = filename.split('.')[1]

    except Exception as e:
        raise Exception(e)

    return timestamp


def is_valid_with_dots_luer_filename(filename, verbose=False):
    """
    Validate format of with dots LUER file name.

    :param filename: character string of the filename of the with_dots luer.
    :param verbose: switches debug mode (default=False)
    :returns: boolean
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = 'WITH_DOTS.dat'
    prefix = 'LUER'
    
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        convert_string_to_int(filename.split('.')[-2].split('_')[0])
        return_value = True
    except Exception as e:
        if verbose:
            print('Invalid filename:', e)
        return_value = False

    return return_value


def is_valid_with_keys_luer_filename(filename, verbose=False):
    """
    Validate format of with keys LUER file name.

    :param filename: character string of the filename of the with_keys luer.
    :param verbose: switches debug mode (default=False)
    :returns: boolean
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = 'WITH_DOTS_WITH_KEYS.dat'
    prefix = 'LUER'
    
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        convert_string_to_int(filename.split('.')[-2].split('_')[0])
        return_value = True
    except Exception as e:
        if verbose:
            print('Invalid filename:', e)
        return_value = False

    return return_value


def is_valid_raw_luer_filename(filename, verbose=False):
    """
    Validate format of raw LUER file name.

    :param filename: character string of the filename of theraw luer.
    :param verbose: switches debug mode (default=False)
    :returns: boolean
    """

    do_it.do_it_verbose(currentframe(), verbose)

    suffix = '.raw'
    prefix = 'LUER'
    
    try:
        validate_format_of_luer_filename(filename, prefix, suffix)
        convert_string_to_int(filename.split('.')[1])
        return_value = True
    except Exception as e:
        if verbose:
            print('Invalid filename:', e)
        return_value = False
    
    return return_value


def is_valid_raw_luer_file(path, filename, verbose=False):
    """
    Validate both the filename and some of the content of a raw luer file.
    It checks for:
    - valid filename format
    - valid content --> checksum field should be available and not an empty string
    - valid content --> should contain tag 'time_data'

    :param filename: character string of the path in which the raw luer is stored
    :param filename: character string of the filename of theraw luer.
    :param verbose: switches debug mode (default=False)
    :returns: boolean
    """

    do_it.do_it_verbose(currentframe(), verbose)

    import os 
    
    if not is_valid_raw_luer_filename(filename, verbose=verbose):
        return_value = False
    else:
        try:
            line = get_line_with_tag_from_luer_raw(os.path.join(path, filename), 'checksum = ')
            line = line.replace(" ", "")
            if verbose:
                print ('checksum', len(line), line)
            
            if len(line) < 30:
                # 'checksum=' is <25, checksum string itself is ~30. So 25 is a save value in the middle
                return_value = False
            else:
                try:
                    line = get_line_with_tag_from_luer_raw(os.path.join(path, filename), 'time_data')
                    return_value = True
                except Exception as e:
                    # no time_data tag in the file
                    return_value = False
        
        except Exception as e:
            print ('Validating raw luer file')
            print (e)
            return_value = False
    
    return return_value


def get_pulse_count_from_luer_raw(filename=None, file_handler=None, verbose=False):
    """
    Extract the pulse_count from a raw luer file. Raises an exception when unsuccessful

    :param filename: character string of the filename of the raw luer
    :param file_handler: file object of the raw luer
    :param verbose: switches debug mode (default=False)
    :returns: pulse count
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if (file_handler is None) and (filename is None):
        raise Exception('Either a file handler or the full path of the raw luer should be provided')

    if file_handler is not None:
        file_handler.seek(0)
        line = get_line_from_file_with_tag(file_handler, 'EUV_pulse_count')
    else:
        try:
            with open(filename) as file_handler:
                line = get_line_from_file_with_tag(file_handler, 'EUV_pulse_count')
        except Exception as e:
            raise Exception(e)

    try: 
        pulsecount = float(line.split(' ')[-1][:-2])
    except Exception as e:
        raise Exception(e)

    return pulsecount


def get_timestamp_from_luer_raw(filename=None, file_handler=None, from_header=False, verbose=False):
    """
    Extract the timestamp from a raw luer file. Raises an exception when unsuccessful
    By default it takes the timestamp from the body, at the measurement. 
    This timestamp includes timezone information and is at the start of the LUER measurement
    
    If from_header is True, the timezone from the header is taken.
    This timestamp is in local time, and at the end of the measurement. This is the timezone used in the LUER filename
    
    :param filename: character string of the filename of the raw luer
    :param file_handler: file object of the raw luer
    :param from_header: extract the timestamp from the header (default: False)
    :param verbose: switches debug mode (default=False)
    :returns: pandas timestamp
    """

    do_it.do_it_verbose(currentframe(), verbose)

    if from_header:
        tag = 'timestamp'
    else:
        tag = 'time_data'
    
    if (file_handler is None) and (filename is None):
        raise Exception('Either a file handler or the full path of the raw luer should be provided')

    if file_handler is not None:
        file_handler.seek(0)
        line = get_line_from_file_with_tag(file_handler, tag)
    else:
        try:
            with open(filename) as file_handler:
                line = get_line_from_file_with_tag(file_handler, tag)
        except Exception as e:
            raise Exception('filename: {}\n{}'.format(filename, e))

    try: 
        if verbose:
            print (line)
        # line is formatted as 
        # 'timestamp = "2019-06-28 00:08:00.759033",' or
        # 'time_data = "Thu, 09 May 2019 09:12:27 796975us +0800",'
        # get all after '=', and clean up quotes and , --> 'Thu 09 May 2019 09:12:27 796975us +0800'
        time_string = line.split(" = ")[-1].replace("\"", "").replace(",", "")
        if verbose:
            print(time_string)
        
        if from_header:
            timestamp = pd.Timestamp(time_string)
        else:
            # split by space, and merge index 1, 2, 3, 4 of the list. Add the timezone bit
            timestamp = pd.Timestamp(" ".join(time_string.split(' ')[1:5]) + time_string.split(' ')[-1])
            
            # convert to UTC
            timestamp = timestamp.tz_convert('UTC')
            if verbose:
                print(timestamp)
    except Exception as e:
        raise Exception('filename: {}\n{}'.format(filename, e))

    return pd.to_datetime(timestamp)


def get_machine_id_from_luer_raw(filename=None, file_handler=None, verbose=False):
    """
    Extract the machine id from a raw luer file. 
    
    :param filename: character string of the filename of the raw luer
    :param file_handler: file object of the raw luer
    :param verbose: switches debug mode (default=False)
    :returns: string machine number
    :raises: exception when filename cannot be opened or extraction of machine_id fails
    """

    do_it.do_it_verbose(currentframe(), verbose)

    tag = 'machine_id'
    if (file_handler is None) and (filename is None):
        raise Exception('Either a file handler or the full path of the raw luer should be provided')

    if file_handler is not None:
        file_handler.seek(0)
        line = get_line_from_file_with_tag(file_handler, tag)
    else:
        try:
            with open(filename) as file_handler:
                line = get_line_from_file_with_tag(file_handler, tag)
        except Exception as e:
            raise Exception('filename: {}\n{}'.format(filename, e))

    try: 
        if verbose:
            print (line)
        #line is formatted as 'machine_id = "1234",'
        # get all after '=', and clean up quotes and line ending --> '1234'
        machine_number = line.split(" = ")[-1].replace("\"", "")[:4]
        if verbose:
            print (machine_number)
        
        # split by space, and merge index 1, 2, 3, 4 of the list. Add the timezone bit
        machine_id = 'm{}'.format(machine_number)
        
        if verbose:
            print (machine_id)
    except Exception as e:
        raise Exception('filename: {}\n{}'.format(filename, e))

    return machine_id


def get_line_with_tag_from_luer_raw(filename, tag, verbose=False):
    """
    Extract the first line containing the tag from a raw luer file. Raises an exception when unsuccessful
    
    :param filename: character string of the filename of the raw luer
    :param tag: the string we look for in the file
    :param verbose: switches debug mode (default=False)
    :returns: pandas timestamp
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        with open(filename) as file_handler:
            line = get_line_from_file_with_tag(file_handler, tag)
    except Exception as e:
        raise Exception('filename: {}\n{}'.format(filename, e))
    return line

    
def get_line_from_file_with_tag(file_handler, tag, verbose=False):
    """
    Scans a file for a tag and returns the first occurrence of that tag
    
    :param file_handler: file handler
    :param tag: tag to search for
    :param verbose: switches debug mode (default=False)
    :returns: line  of first occurence of tag 
    """

    do_it.do_it_verbose(currentframe(), verbose)

    line_to_return = None
    file_handler.seek(0)
    for line in file_handler:
        if (tag in line):
            line_to_return = line
            break

    if line_to_return is None:
        raise Exception('Tag {} not found in file'.format(tag))

    return line_to_return


def get_reference_directory(verbose=False):
    """
    This returns directory name which contains generic references.

    :param verbose: switches debug mode (default=False)
    :return: directory of reference file
    """

    do_it.do_it_verbose(currentframe(), verbose)

    import os 
    
    dir_path = os.path.dirname(os.path.realpath(__file__))
    reference_path = os.path.join(dir_path, 'data')
    
    return reference_path


def get_roi_directory(verbose=False):
    """
    This returns directory name which contains generic roi definition files.

    :param verbose: switches debug mode (default=False)
    :return: directory of generic roi definition files
    """

    do_it.do_it_verbose(currentframe(), verbose)

    import os 
    
    dir_path = os.path.dirname(os.path.realpath(__file__))
    roi_path = os.path.join(dir_path, 'data')
    
    return roi_path


def convert_lurado_image_to_encoded_bitmap(lurado_image, image_type, reference=None, threshold=1.2, verbose=False):
    """
    Convert a lurado image with intensities or reflectivities into an encoded string representation of a png
    The lurado image is a 2d numpy array (256x256) with positive x-axis to the left, and positive y-axis down
    A bitmap image has its origin on the top left, so positive x-axis to the right, and positive y-axis down

    :param lurado_image: lurado formatted 2d array
    :param image_type: type of image. Options are 'intensity', 'reflectivity', 'no_scaling'
    :param reference: reference image (dataframe) with columns 'x', 'y', 'intensity', only required for 'intensity'
    :param threshold: threshold factor resulting in a threshold value to which the image is clipped (default: 1.2)
    :param verbose: switches debug mode (default=False)
    :return: encoded string containing the png image
    :raises: exception when incorrect image type is passed or reference is not provided
    """

    import PIL
    import base64
    try:
        from StringIO import StringIO as BytesIO  # for Python 2, renaming StringIO to BytesIO
    except ImportError:
        from io import BytesIO

    do_it.do_it_verbose(currentframe(), verbose)

    # the bitmap image has values between 0 and 255,
    # type 'reflectivity' should have values between 0 and 100*threshold
    # type 'intensity' should have values between 0 and max(reference.intensity)*threshold
    # the 'no_scaling' has unknown values
    # the lurado_image should be scaled to the range of the bitmap
    if image_type == 'intensity':
        if reference is None:
            raise Exception('For image_type={}, reference should be provided'.format(image_type))
        factor = 255.0 / (reference.intensity.max() * threshold)

    elif image_type == 'reflectivity':
        factor = 255.0 / 100.0 / threshold

    elif image_type == 'no_scaling':
        factor = 255.0 / lurado_image.max()

    else:
        raise Exception('image_type = {} not implemented. Expecting '.format(image_type))

    image = lurado_image * factor

    # clip values outside of the ranges ([0.0, 255.0]) to the edge of the range
    # not likely to happen, since the input data should already be corrected for this.
    # however, better safe than sorry
    image = np.clip(image, 0.0, 255.0).astype('uint8')

    # flip x-axis
    image = np.fliplr(image)

    # convert to bitmap
    bitmap_image = PIL.Image.fromarray(image, mode='L')  # 'L' refers to 8 bit integer

    # convert the bitmap image to an encoded string
    buffered = BytesIO()
    bitmap_image.save(buffered, format="PNG")
    encoded_bitmap = base64.b64encode(buffered.getvalue())
    encoded_bitmap = "data:image/png;base64,.{}".format(encoded_bitmap)

    return encoded_bitmap


def convert_encoded_bitmap_to_lurado_image(encoded_bitmap, image_type, reference=None, threshold=1.2, verbose=False):
    """
    Convert an encoded bitmap with intensities or reflectivities to a lurado image
    The lurado image is a 2d numpy array (256x256) with positive x-axis to the left, and positive y-axis down
    A bitmap image has its origin on the top left, so positive x-axis to the right, and positive y-axis down

    :param encoded_bitmap: 8bit encoded bitmap
    :param image_type: type of image. Options are 'intensity', 'reflectivity', 'no_scaling'
    :param reference: reference image (dataframe) with columns 'x', 'y', 'intensity', only required for 'intensity'
    :param threshold: threshold factor resulting in a threshold value to which the image is clipped (default: 1.2)
    :param verbose: switches debug mode (default=False)
    :return: lurado image (2d array)
    :raises: exception when incorrect image type is passed or reference is not provided
    """

    import PIL
    import base64
    try:
        from StringIO import StringIO as BytesIO  # for Python 2, renaming StringIO to BytesIO
    except ImportError:
        from io import BytesIO

    do_it.do_it_verbose(currentframe(), verbose)

    # remove the "data:image/png;base64,.b" part from the string and decode
    image_decoded = base64.b64decode(str(encoded_bitmap[24:]))

    # convert to image
    pil_image = PIL.Image.open(BytesIO(image_decoded))
    image = np.array(pil_image).astype(float)

    # flip x-axis
    lurado_image = np.fliplr(image)

    # the bitmap image has values between 0 and 255,
    # type 'reflectivity' should have values between 0 and 100*threshold
    # type 'intensity' should have values between 0 and max(reference.intensity)*threshold
    # the 'no_scaling' has unknown values
    # the lurado_image should be scaled to the range of the bitmap
    if image_type == 'intensity':
        if reference is None:
            raise Exception('For image_type={}, reference should be provided'.format(image_type))
        factor = reference.intensity.max() * threshold / 255.0

    elif image_type == 'reflectivity':
        factor = 100.0 * threshold / 255.0

    elif image_type == 'no_scaling':
        factor = 1.0

    else:
        raise Exception('image_type = {} not implemented. Expecting '.format(image_type))

    lurado_image = lurado_image * factor

    return lurado_image


def get_pma_luer_directory(root, machine_nr, verbose=False):
    """
    Returns the full path of the LUER files on PMA, given the PMA root directory, and the machine number

    :param root: The PMA root directory (the mapped network drive (e.g. 'v:\') or mounted disk (e.g. '/pma')
    :param machine_nr: the 4 character machine number (so without the 'm' in front)
    :param verbose: switches debug mode (default=False)
    :return: The full path of the LUER files at PMA for this machine
    """

    do_it.do_it_verbose(currentframe(), verbose)

    pma_luer_directory = os.path.join(root, machine_nr, 'service_data', 'LU', 'LUER')
    return pma_luer_directory

if __name__ == '__main__':

    path = r'W:\Collector_Performance_Reports\3400\TSMC#12_GS71_V45_62293\#6_SDMSC151\2.in-use\RADON\LUER.0579_SN_FAR_FIELD_WITH_DOTS_WITH_KEYS.dat'
    df = load_dots(path, correct_ffm = True)