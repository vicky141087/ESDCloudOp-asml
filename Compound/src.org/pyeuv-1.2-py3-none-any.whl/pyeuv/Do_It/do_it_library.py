# -*- coding: utf-8 -*-
"""
do_it_library.py
Authors: NGER
Date: 2019-05-10

This file contains the generic library functions for:
    - 'do_it',
    - 'do_it_something',

these can be used externally

The _do_it_verbose function is a local utility that displays
    - the name,
    - the arguments,
    - the values of the arguments,

from the function that it is called from, when its 'verbose' parameter is True

To facilitate this utility, all functions in the library must have 'verbose'
as last parameter (default value False),
and a call to _do_it_verbose() as first action, as shown in the examples below.
"""

# Instruction for use:
# Copy the section between '# -->' and # '<--' into each generic library module

# -->
# imports required for verbose on function parameters and values
from inspect import currentframe, getargvalues, getframeinfo

# internal tooling functions required in every generic library module


def do_it_verbose(frame, verbose):
    """
    _do_it_verbose(...): Shows the name, parameters and values of the function
                         that this is called from (the calling function).

    :param frame: frame object of the calling function,
    :param verbose: to switch internal debug info (default: False)

    Change History:
    NGER 20190513 SSPT-202 Creation of template for generic function in library
    """

    if verbose:
        print("\nVerbose:")
        print("Library: %s" % __file__)
        args, _, _, values = getargvalues(frame)
        print("Function name: %s" % getframeinfo(frame)[2])
        count = 0
        for i in args:
            print("    parameter %s: %s = %s" % (count, i, values[i]))
            count += 1

    return


# <--
# -- generic functions in this library module  --------------------------------


def do_it(param1=True, wave_nr=3, verbose=False):
    """
    do_it(...): Returns the value of the parameter supplied.

    :param param1: value to be returned,

        **details**
            - 'Exception1' is not allowed as value for param1,
            - default value = True,

    :param wave_nr: dummy parameter giving the nr of 'waves',

        **details**
            - default = 3,

    :param verbose: to switch internal debug info,

        **details**
            - default = False,

    :Raises ValueError: not allowed value is passed as parameter,

    :return: the value of param1,

    :Change History:
        NGER 20190513 SSPT-202:
        Creation of template for generic function in library,
    """

# Following code snippet prints function name
# and all parameters and actual values passed when called
# This snippet is to be copied into every library function, following the doc
    do_it_verbose(currentframe(), verbose)

    try:
        if param1 == "Exception1":
            raise ValueError("A not allowed value was passed for param1",
                             "Exception1")
    except ValueError:
        print("### Not allowed value passed as parameter: %s ###" % param1)

    print("Wave hello for %s times!" % wave_nr)

    do_it_some_function(verbose)

    return param1


def do_it_some_function(verbose=False):
    """
    do_it_nothing (...): Does nothing, just shows 'verbose' propagation.

    :param verbose: to switch internal debug info,

        **details**
            - default = False,

    :return:

    :Change History:
        NGER 20190513 SSPT-202
        Creation of template for generic function in library,
    """

# Following code snippet prints function name
# and all parameters and actual values passed when called
# This snippet is to be copied into every library function, following the doc
    do_it_verbose(currentframe(), verbose)

    return
