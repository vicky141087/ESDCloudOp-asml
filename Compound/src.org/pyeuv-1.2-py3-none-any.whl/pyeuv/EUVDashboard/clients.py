"""
clients.py
Author: RLBL
Date:  2019-01-10

The UserClient provides a single interface to the EUVDashboard for use with Jupyter Notebooks or external tooling
created by users. It exposes convenient functions without requiring complex setup, loggers or Redis.

*Example usage*

::

    from EUVDashboardClient.clients import UserLANClient
    c = UserLANClient()
    df = c.get_signals('s62253.Scanner.DW_SLIE', from_time=pd.Timestamp('2017-01-01'), to_time=pd.Timestamp('2017-01-02'))

    # If username is not provided, the client will default to your ASML username
    # If password is not provided, the client will ask you for it.

"""
import os
import requests
import getpass
import configparser
import urllib.request, urllib.error, urllib.parse
import simplejson as json
import pandas as pd

from urllib3.exceptions import InsecureRequestWarning
from influxdb.exceptions import InfluxDBClientError

from pyeuv.EUVDashboard import common
from pyeuv.Shared.cache import SignalCache

from . import shared

if common.has_etl_environment():
    import shared as etl_shared
else:
    from ._InfluxUrlClient import DataFrameUrlClient

# Disable insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


test_credential_file = "~/.pyeuv/test_credentials.conf"

def get_euvdb_test_credentials():
    """
    Read the credential file and return username, password and api_key. The
    credential file is pointed to by the credential_file variable of this
    module. The text file must contain at least the following config section:

    ::

        [EUVDB]
        username=<username>
        password=<password>

    Also, see the Unit testing section of the Pyeuv Manual.

    :returns: username, password
    :rtype: tuple<str>
    """
    if os.path.exists(os.path.expanduser(test_credential_file)):
        config = configparser.ConfigParser()
        with open(os.path.expanduser(test_credential_file), 'r') as f:
            config.read_file(f)

        username = config['EUVDB']['username']
        password = config['EUVDB']['password']
    else:
        raise FileNotFoundError("Missing test credential file: {0}\n"
                                "Please refer to the testing section of the manual."
                                "".format(os.path.expanduser(test_credential_file)))

    return username, password


class UserLANClient:
    _host = 'euv-dashboard.asml.com'
    _baseurl = 'https://euv-dashboard.asml.com/data/'

    def __init__(self, username=None, password=None, cache_dir='~/.pyeuv/cache'):
        """
        EUV Dashboard client. Instantiate this to obtain interfaces to InfluxDB  
        
        :param username: ASML Username, used to login to the EUV Dashboard.
        :type username: str
        :param password: Password, will be requested by getpass if set to None
        :type password: str
        :param cache_dir: Location to store cached data for get_signals_cached()
        :type cache_dir: str
        """

        if not common.has_etl_environment():
            if username is None:
                username = getpass.getuser()

            if password is None:
                password = getpass.getpass("Enter password of user {0} for "
                                       "euv-dashboard.asml.com: ".format(username))

        if common.has_etl_environment():
            self.client = etl_shared.get_influx_dataframe_client('admin')
        else:
            self.client = DataFrameUrlClient(
                host=self._host,
                baseurl=self._baseurl,
                username=username,
                password=password,
                ssl=True,
                verify_ssl=False
            )

        # Check if our login is successful
        try:
            self.client.query("SHOW DATABASES")
        except InfluxDBClientError:
            raise InfluxDBClientError("User {0} not authorized. "
                                      "Check your credentials."
                                      "".format(username))

        # Initialize cache for get_signal_cached()
        self.cache = SignalCache(cache_dir=os.path.expanduser(cache_dir))

    def chunk_signal(self, signal, from_time=None, to_time=None, chunksize=shared.CHUNK_SIZE, verify_tags=True,
                     verbose=False):
        """
        Generator, yields data for a signal in chunks. Timestamps are returned in UTC.

        Signals must be specified according to the following pattern
        ::

            <source_nr>.<signal_type>.<signal_name>[field]{tag}.<aggregate_time>.<aggregate_func>

        *Examples*

        ::

            s62440.ScannerLog.de_err{code=DW-3411}.1d.max
            s62179.DWMD.MCDWMD_EXPOSURE_MODE_PARAMS_EXPOSURE_MODE_DATA_MINI_BURST_MODE_PARAMETERS_BURST_DUTY_CYCLE_TAG[value01]
            s62240.LUER.image.1h.last
            s62240.LUER.transmission.1h.mean
            s62240.LUER.transmission

        :param signal: Signal using the following format:
        :type signal: str
        :param from_time: Epoch timestamp [ns] or pd.Timestamp(tz=UTC), default is 0
        :type from_time: pandas.Timestamp
        :param to_time:   Epoch timestamp [ns] or pd.Timestamp(tz=UTC), default is now
        :type to_time: pandas.Timestamp
        :param chunksize: Approximate number of records to return per iteration (default 50000)
        :type chunksize: int
        :param verify_tags: Verify that given tag keys and values are available for the given signal.
                            Will raise an error if they don't exist. Has a small performance penalty
                            because it needs to send some extra queries to influx. This may become
                            noticeable in rare cases where the list of signals is very long. So it can
                            be disabled with this option.
        :type verify_tags: bool (Default=True)

        :param verbose: Print chunk sizes if True
        :type verbose: bool
        """

        return shared.chunk_signal(
            signal,
            None,
            from_time=from_time,
            to_time=to_time,
            chunksize=chunksize,
            dbclient=self.client,
            verify_tags=verify_tags,
            verbose=verbose
        )

    def get_signals(self, signals, from_time=None, to_time=None,
                    chunksize=shared.CHUNK_SIZE, defaults=None,
                    last_value=False, verbose=False, verify_tags=True):
        """
        Get signals from the database between from_time and to_time. Uses chunk_signal() to send multiple
        small queries to the database that will return at most CHUNK_SIZE points. Returned points are
        concatenated in a single dataframe.

        Each signal in the list should follow the following format:
            <source_nr>.<signal_type>.<signal_name>[field]{tag}.<aggregate_time>.<aggregate_func>

            *Examples:*

        ::

            # Standard
            s62240.LUER.transmission
            # Rolling mean 1h
            s62240.LUER.transmission.1h.mean
            # Specify field
            s62179.DWMD.MCDWMD_EXPOSURE_MODE_PARAMS_EXPOSURE_MODE_DATA_MINI_BURST_MODE_PARAMETERS_BURST_DUTY_CYCLE_TAG[value01]
            # Last of the hour
            s62240.LUER.image.1h.last
            # Single tag filter
            s62440.ScannerLog.de_err{code=DW-3411}.1d.max
            # Multi tag filter
            s62265.RT23.TFMmajorAxis{subroutine=MP}{in_spec=True}


        :param signals: Signal or list of signals
        :type signals: list<str> or str
        :param from_time: Lower time limit
        :type from_time: pandas.Timestamp
        :param to_time: Upper time limit
        :type to_time: pandas.Timestamp
        :param chunksize: The maximum number of points requested per query
        :type chunksize: int
        :param verify_tags: Verify that given tag keys and values are available for the given signal.
                            Will raise an error if they don't exist. Has a small performance penalty
                            because it needs to send some extra queries to influx. This may become
                            noticeable in rare cases where the list of signals is very long. So it can
                            be disabled with this option.
        :type verify_tags: bool (Default=True)

        :param verbose: Print the name of the signal that's currently being
                    downloaded. Default is False
        :type verbose: bool
        :rtype: Dataframe
        """

        return shared.get_signals(
            signals,
            None,
            from_time=from_time,
            to_time=to_time,
            chunksize=chunksize,
            dbclient=self.client,
            last_value=last_value,
            defaults=defaults,
            verify_tags=verify_tags,
            verbose=verbose
        )

    def get_signals_cached(self, signals, from_time=None, to_time=None, chunksize=shared.CHUNK_SIZE,
                           verbose=False, verify_tags=True, cache_only=False, cache_limit=pd.Timedelta(0)):
        """
        Similar to get_signals, but builds up a disk cache of the retrieved data. This function offers a substantial
        performance improvement for data that is requested more than once. The cache will persist after the program
        has stopped.

        For more information see the documentation of get_signals. Note that the defaults and last_value options
        are not supported by this version.

        :param signals: Signal or list of signals
        :type signals: list<str> or str
        :param from_time: Lower time limit
        :type from_time: pandas.Timestamp
        :param to_time: Upper time limit
        :type to_time: pandas.Timestamp
        :param chunksize: The maximum number of points requested per query
        :type chunksize: int
        :param verify_tags: Verify tag avialability before running the query. See the documentation
                            of get_signals for more information.
        :type verify_tags: bool (Default=True)
        :param cache_only: Don't query Influx, only return results from cache
        :type cache_only: bool
        :param verbose: Print the name of the signal that's currently being
                    downloaded. Default is False
        :type verbose: bool
        :rtype: Dataframe
        :param cache_limit: Time in days for which the cached data has to be refreshed
        :type cache_limit: pandas.Timedelta
        """
        # Make sure to only cache UTC timestamps
        tstart = from_time
        tstop = to_time
        if not isinstance(tstart, pd.Timestamp):
            tstart = pd.to_datetime(from_time).tz_localize('UTC')
        if not isinstance(tstart, pd.Timestamp):
            tstop = pd.to_datetime(to_time).tz_localize('UTC')

        # Force UTC
        if tstart.tz is None:
            tstart = tstart.tz_localize('UTC')
        else:
            tstart = tstart.tz_convert('UTC')
        if tstop.tz is None:
            tstop = tstop.tz_localize('UTC')
        else:
            tstop = tstop.tz_convert('UTC')

        df_out = pd.DataFrame()
        for s in signals:
            try:
                df_cache, wr, wl = self.cache.get_signal(s, tstart, tstop, cache_limit)
            except KeyError:
                df_cache = pd.DataFrame()
                wr = None
                wl = None
            if cache_only:
                df_out = df_out.join(df_cache, how='outer').sort_index()
                continue

            df_new = pd.DataFrame()
            if df_cache.empty:
                # No cached data, get everything fresh
                df_new = self.get_signals(
                    [s], from_time=tstart, to_time=tstop, chunksize=chunksize,
                    defaults=None, last_value=False, verbose=verbose,
                    verify_tags=verify_tags)
            else:
                # Partially cached data, request missing data
                if wl is not None:  # Partially cached, get missing points on the left
                    df_new_left = self.get_signals(
                        [s], from_time=wl[0], to_time=wl[1],
                        chunksize=chunksize, defaults=None, last_value=False,
                        verbose=verbose, verify_tags=verify_tags)

                    df_new = pd.concat([df_new_left, df_new])
                if wr is not None:
                    # Partially cached, get missing points on the right
                    df_new_right = self.get_signals(
                        [s], from_time=wr[0], to_time=wr[1],
                        chunksize=chunksize, defaults=None, last_value=False,
                        verbose=verbose, verify_tags=verify_tags)

                    df_new = pd.concat([df_new, df_new_right])

            if not df_new.empty:
                df_result = self.cache.cache_signal(s, df_new, return_updated=True)
            else:
                df_result = df_cache

            df_out = df_out.join(df_result, how='outer').sort_index()

        return df_out

    def get_signals_dict(self, signals_dict, source_id, from_time=None, to_time=None,
                        chunksize=shared.CHUNK_SIZE, last_value=False, defaults=None, create_columns=False):
        """
        Returns a dataframe with signals from influx. The column names have been renamed 
        to more human readable names, as provided in the signal_dict
        
        :param signal_dict: dictionary for signals to be retrieved and their human readable representation (as key)
        :type signals_dict: dict
        :param source_id: the source_id for which the signals have to be retrieved
        :type source_id: string
        :param from_time: Lower time limit
        :type from_time: pandas.Timestamp
        :param to_time: Upper time limit
        :type to_time: pandas.Timestamp
        :param chunksize: The maximum number of points requested per query
        :type chunksize: int
        :param defaults: List of defaults if the requested signals yield no data.
                         {'signalA': defaultA, 'signalB': defaultB, ...}
        :type defaults: dict
        :param last_value: If there's no data available for the given time
                           window, return the last known value instead.
    
                           If used in combination with the defaults option the
                           last value will take precedence over the default.
        :type last_value: bool
        :param create_columns: if for a signal, no data is available, create the column containing NaNs (default: False)
        :type last_value: bool
        :rtype: Dataframe
        """
    
        return shared.get_signals_dict(
            signals_dict,
            source_id, 
            None,
            from_time=from_time,
            to_time=to_time,
            chunksize=chunksize,
            dbclient=self.client,
            last_value=last_value,
            defaults=defaults,
            create_columns=create_columns
        )


    def get_aggregated_dataframe(self, report_date, signals, machines, max_retention=0):
        """
        Obtain aggregated values for the given day. Use only for KPI.DayAggregates._ signals.

        *This function makes the following assumptions for the signal*
          * The aggregated value for a given day is written with a timestamp 00:00:00 (start of the day)
            a tolerance of +/- 1s is used.
          * There is only one aggregated value in this range

        :param report_date: Date for which to get the aggregated (KPI) data
        :type report_date: datetime.datetime
        :param signals: list of signal names to extract. (Uses value column)
        :type signals: list or str
        :param machines: list of machines to include.
        :type machines: list

        :param max_retention: integer number of days, default is 0. Allow the this function to return older aggregated
                              values if no values are available for the given day. Values will not be older than [max_retention] days.
                              If set to 0 no older values will be used.

        :type max_retention: int

        :return: Dataframe with the results
        """

        return shared.get_aggregated_dataframe(
            self.client,
            report_date,
            signals,
            machines,
            clear_cache=False,
            max_retention=max_retention
        )

    def get_last_value_before(self, signal, timestamp, default=None):
        """
        Returns the last value of the given signal before the given timestamp.

        :param signal: The full name of the signal in influxdb
        :type signal: str

        :param timestamp: Maximum age of value to look for
        :type timestamp: pandas.Timestamp

        *Optional*

        :param default: Value to return if no result

        :rtype: Dataframe
        """

        return shared.last_value_before(
            signal,
            timestamp,
            default=default,
            dbclient=self.client
        )

    def get_first_value_after(self, signal, timestamp, default=None):
        """
        Returns the first value of the given signal after the given timestamp.

        :param signal: The full name of the signal in influxdb
        :type signal: str

        :param timestamp: Minimum age of value to look for
        :type timestamp: pandas.Timestamp

        *Optional*

        :param default: Value to return if no result

        :rtype: Dataframe
        """

        return shared.first_value_after(
            signal,
            timestamp,
            default=default,
            dbclient=self.client
        )

    def _get_http(self, list_url, verify_ssl=False):
        """
        Helper function to download html content

        :param list_url: url pointing to http(s) content
        :param verify_ssl: switch for ssl verification, turned off for unix
        :rtype: str
        """

        if common.has_unix_environment():
            # on unix (hpc, centos hosts, etc.) ssl verification fails.
            # turn it off, since it is within the asml network anyway.
            verify_ssl = False

        passman = urllib.request.HTTPPasswordMgrWithDefaultRealm()
        passman.add_password(None, list_url, self.client._username,
                             self.client._password)
        authhandler = urllib.request.HTTPBasicAuthHandler(passman)
        opener = urllib.request.build_opener(authhandler)
        urllib.request.install_opener(opener)

        if not verify_ssl:
            import ssl
            ssl._create_default_https_context = ssl._create_unverified_context

        return urllib.request.urlopen(list_url).read()


    def get_machine_list(self, return_type='list', verify_ssl=True):
        """
        Returns a list (default) or a dataframe containing all available
        machines in grafana.

        :param custom_sll: on the HPC this needs to be set to True
        :param return_type: Set to 'list' to return a list, or 'dataframe' to
                            return a dataframe.
        :type return_type: str

        :return: List or dataframe
        """
        url = 'https://euv-dashboard.asml.com/service/machines.json'
        response = self._get_http(url, verify_ssl=verify_ssl)

        if return_type == 'dataframe':
            machines = pd.read_json(response)
        else:
            machines = json.loads(response)

        return machines

    def get_signal_list(self, machine, return_type='list', verify_ssl=True):
        """
        Return the list of available measurements (signals) for the given
        machine.

        :param machine: Machine to get the signal list for. Provide a machine
                        number, source number or a machine dict. e.g. s38911
                        or m6224.

        :type machine: dict or str
        :param return_type: Set to 'list' to return a list, or 'dataframe' to
                            return a dataframe.
        :rtype: List or dataframe
        """
        if return_type not in ['list', 'dataframe']:
            raise ValueError(
                "Unknown return type, expected 'dataframe' or 'list'")

        if type(machine) == dict:
            source_nr = 's' + machine['source_nr']
        elif machine[0]in ['m', 's']:
            source_nr = machine
        else:
            raise ValueError("Machine number must start with 'm' or 's'")

        url = 'https://euv-dashboard.asml.com/service/signals'
        url += "?machine={0}".format(source_nr)

        response = json.loads(self._get_http(url, verify_ssl=verify_ssl))

        signal_list = []
        for measurement in response:
            signal_list.append(
                measurement['type'] + '.' + measurement['signal']
            )

        if return_type == 'dataframe':
            return pd.DataFrame(signal_list)
        else:
            return signal_list

    def get_tag_keys(self, signal_name):
        """
        Returns available tag keys for the given signal. Will return an empty
        list if there are none.

        :param signal_name: Signal name e.g. s66224.RT23.TFMdebrisArea
        :type signal_name: str
        :rtype: list of strings
        """
        return shared.get_tag_keys(signal_name, self.client)

    def get_tag_values(self, signal_name, tag_key):
        """
        Returns available tag values for the given tag key. Will return
        an empty list if there are none.

        :param signal_name: Signal name e.g. s66224.RT23.TFMdebrisArea
        :type signal_name: str
        :param tag_key: Tag name e.g. 'root_cause'
        :type tag_key: str

        :rtype: list of strings
        """
        return shared.get_tag_values(signal_name, tag_key, self.client)
