"""
shared.py
Authors: RLBL, PKVB
Date:  2019-09-25

Modified version of ETL/shared.py for distribution with pyeuv.

*Avoid using this module directly, use clients.UserLANClient instead.*
"""
import time

import datetime
import numpy as np  # matrix manipulation
import pandas as pd
import regex as re  # better regular expressions
from collections import defaultdict
from influxdb.exceptions import InfluxDBClientError, InfluxDBServerError


#################################################################################
# DATABASE READING
#################################################################################

CHUNK_SIZE = 50000


def get_signals(signals, user, from_time=None, to_time=None,
                chunksize=CHUNK_SIZE, defaults=None, last_value=False,
                dbclient=None, verify_tags=True, verbose=False):
    """
    Get signals from the database between from_time and to_time. Uses chunk_signal() to send multiple
    small queries to the database that will return at most CHUNK_SIZE points. Returned points are
    cocatenated in a single dataframe. Returned timestamps are in UTC.

    :param signals: Signal or list of signals
                    This parameter can contain modifiers to manupulate the signal. See chunk_signal() for details.
    :type signals: list<str> or str
    :param user: The InfluxDB user account name
    :param from_time: Lower time limit
    :type from_time: pandas.Timestamp
    :param to_time: Upper time limit
    :type to_time: pandas.Timestamp
    :param chunksize: The maximum number of points requested per query
    :type chunksize: int
    :param defaults: Dict with defaults if the requested signals yield no data.
                     {'signalA': defaultA, 'signalB': defaultB, ...}
    :type defaults: dict
    :param last_value: If there's no data available for the given time
                           window, return the last known value instead.

                           If used in combination with the defaults option the
                           last value will take precedence over the default.
    :type last_value: bool

    :param dbclient: Use the provided DataframeClient instead of automatically
                     determining the client based on hostname.
    :param verify_tags: Verify that given tag keys and values are available for the given signal.
                        Will raise an error if they don't exist. Has a small performance penalty
                        because it needs to send some extra queries to influx. This may become
                        noticeable in rare cases where the list of signals is very long. So it can
                        be disabled with this option.
    :type verify_tags: bool (Default=True)
    :param verbose: Print the name of the signal that's currently being
      downloaded as well as the chunk sizes. Default is False
    :type verbose: bool
    :rtype pandas.DataFrame:
    """

    df_result = pd.DataFrame()
    if type(signals) == str:
        signals = [signals]

    for s in signals:
        if verbose:
            print("Donwloading: {0}".format(s))
        df_signal = pd.DataFrame()
        for chunk in chunk_signal(s, user, from_time, to_time, chunksize,
                                  dbclient=dbclient, verbose=verbose, verify_tags=verify_tags):
            if pd.__version__ < '0.23.0':
                # pandas version 0.19.2 on EUV-DB does not have the sort parameter
                df_signal = pd.concat([df_signal, chunk], axis=0)
            else:
                df_signal = pd.concat([df_signal, chunk], axis=0, sort=False)

        # Stack signals horizontally
        df_signal = df_signal[~df_signal.index.duplicated(keep='first')]
        df_result = df_result.join(df_signal, how='outer')
    
    # Add the last value for signals that didn't return a result. Return
    # defaults if there's no last value available.
    if last_value:
        for signal in signals:
            if signal not in df_result.columns:
                if defaults is not None:
                    default = defaults.get(signal, None)
                else:
                    default = None
                df_result = pd.concat([
                    df_result,
                    last_value_before(
                        signal=signal,
                        to_time=from_time,
                        default=default,
                        dbclient=dbclient)
                    ])
    else:
        # Return defaults where needed
        if defaults:
            for signal in signals:
                if signal in defaults and signal not in df_result.columns:
                    df_result = pd.concat([
                        df_result,
                        pd.DataFrame(
                            data=defaults[signal],
                            index=[pd.to_datetime(0, utc=True)],
                            columns=[signal])
                        ])

    df_result.sort_index(inplace=True)
    return df_result


def get_signals_dict(signals_dict, source_id, user, from_time=None, to_time=None,
                     chunksize=CHUNK_SIZE, defaults=None, last_value=False, create_columns=False,
                     dbclient=None):
    """
    Returns a dataframe with signals from influx. The column names have been renamed 
    to more human readable names, as provided in the signal_dict
    
    :param signal_dict: dictionary for signals to be retrieved and their human readable representation (as key)
    :type signals_dict: dict
    :param source_id: the source_id for which the signals have to be retrieved
    :type source_id: string
    :param from_time: Lower time limit
    :type from_time: pandas.Timestamp
    :param to_time: Upper time limit
    :type to_time: pandas.Timestamp
    :param chunksize: The maximum number of points requested per query
    :type chunksize: int
    :param defaults: List of defaults if the requested signals yield no data.
                     {'signalA': defaultA, 'signalB': defaultB, ...}
    :type defaults: dict
    :param last_value: If there's no data available for the given time
                       window, return the last known value instead.

                       If used in combination with the defaults option the
                       last value will take precedence over the default.
    :type last_value: bool
    :param create_columns: if for a signal, no data is available, create the column containing NaNs (default: False)
    :type last_value: bool
    :rtype: Dataframe
    """
     
    signals_dict_reversed = dict((source_id+'.'+v, k) for k,v in signals_dict.items())
    df = get_signals(list(signals_dict_reversed.keys()), user, 
                     from_time=from_time,
                     to_time=to_time,
                     chunksize=chunksize,
                     dbclient=dbclient,
                     last_value=last_value,
                     defaults=defaults
                    )
    if create_columns:
        for current_column_name, new_column_name in signals_dict_reversed.items():
            if current_column_name in df.columns:
                df.rename(columns={current_column_name: new_column_name}, inplace=True)
            else:
                df[new_column_name] = np.NaN
    else:
        df.rename(columns=signals_dict_reversed, inplace=True)

    return df


def _split_signal_name(signal_name, signal_parts):
    """
    Split signal name, reserved for use with generate_influxdb_query.

    :param signal_name: Fully qualified signal name
        <source_nr>.<signal_type>.<signal_name>[field]{tag}.<aggregate_time>.<aggregate_func>
    :type signal_name: str
    :param signal_parts: Signal parts dictionary, see chunk_signal
    :type signal_parts: dict
    :returns: Splitted signal, mathstr_pre, mathstr_post
    :rtype: list<str>, str, str
    """
    re_math = re.compile(r"(?P<operator>multiply|divide|add|substract|inverse)\((?P<value>(?:\d+|\d+\.\d+))\)")

    # Split of any math functions
    math_match = re_math.search(signal_name)
    mathstr_pre = ''
    mathstr_post = ''
    if math_match:
        split_sig = signal_name[0:math_match.start()-1].split('.')
        groupdict = math_match.groupdict()
        if groupdict['operator'] == 'add':
            mathstr_pre = "{0}+".format(groupdict['value'])
        # Influx is not consistent here. It will not accept 'mean(field) - 10'
        # but it does accept '-10 + mean(field)'
        elif groupdict['operator'] == 'substract':
            mathstr_pre = "-{0}+".format(groupdict['value'])
        elif groupdict['operator'] == 'multiply':
            mathstr_post = "*{0}".format(groupdict['value'])
        elif groupdict['operator'] == 'divide':
            mathstr_post = "/{0}".format(groupdict['value'])
        elif groupdict['operator'] == 'inverse':
            mathstr_pre = "{0}/".format(groupdict['value'])
    else:
        split_sig = signal_name.split('.')   # interpret the signal

    signal_parts['mathstr_pre'] = mathstr_pre
    signal_parts['mathstr_post'] = mathstr_post

    return split_sig


def _parse_aggfun_parts(split_sig, signal_parts):
    """
    Detect aggregation functions and measurement name, then adjust signal parts
    accordingly.

    :param split_sig: Split signal from _split_signal_name()
    :type split_sig: list<str>
    :param signal_parts:
    :type signal_parts: dict

    :return: None
    """
    # Aggregation functions supported by InfluxDB.
    agg_functions = ['count', 'min', 'max', 'mean', 'median', 'mode',
                     'distinct', 'sum', 'stddev', 'first', 'last', 'percentile']
    agg_fun = split_sig[-1].lower()  # last part of the signal

    if agg_fun in agg_functions:
        signal_parts['measurement'] = '.'.join(split_sig[1:-2])  # last part of the signal
        signal_parts['groupby'] = split_sig[-2].lower()  # e.g. 1h, 1d, 0.5s, etc
        signal_parts['aggfun'] = agg_fun  # e.g. mean, std, etc.

        # Select query template (with or without aggfunction argument)
        if agg_fun == 'percentile':
            try:
                signal_parts['aggfun_arg'] = int(agg_fun[10:])
            except ValueError as e:
                raise "Percentile function not specified correctly. It needs to end with an integer. " \
                      "E.g.: m3322.RT5.BDenergy1Mean.1m.percentile95. Message: " + str(e)
    else:
        signal_parts['measurement'] = '.'.join(split_sig[1:])


def _check_tag_availability(database, measurement, tag_matches, dbclient):
    """
    Check if the found tag key-value combinations exist for the signal
    Raises error if a key or value is missing.

    :param database: InfluxDB database name. Usually a source nr.
    :type database: str
    :param measurement: Measurement name in InfluxDB.
    :type measurement: str
    :param tag_matches: results from the tag_regex applied to the sigal in generate_influx_db.
    :type tag_matches: list<tuple>
    :type dbclient: InfluxDB Client used to check tag key/value availability
    :param dbclient: InfluxDBClient
    """

    base_signal_name = database + '.' + measurement
    keys_avail = get_tag_keys(base_signal_name, dbclient)
    for t in tag_matches:
        if t[0] not in keys_avail:
            raise KeyError("Tag key doesn't exist: {0}".format(t[0]))

    vals_avail = {}
    for t in tag_matches:
        vals_avail[t[0]] = get_tag_values(base_signal_name, t[0], dbclient)

    for t in tag_matches:
        if t[2] not in vals_avail[t[0]]:
            raise ValueError("Tag value {0} doesn't exist for key {1}".format(t[0], t[2]))


def _parse_tags_and_fields(signal_parts, dbclient, verify_tags=True):
    """
    Parse tags from the signal name and put them in signal_parts.

    :param signal_parts: Parts of the signal, see generate_influxdb_query
    :type signal_parts: dict
    :param dbclient: InfluxDB client used to lookup tag keys/values
    :type dbclient: InfluxDBClient
    :param verify_tags: If true, check if the tag keys/values exist for this signal. Raises KeyError/ValueError if
                        the a tag key/value is missing for the given signal.
    :type verify_tags: bool
    :return None
    """
    measurement_regex = re.compile(r"^(?P<name>^\S+?(?=\{|\[|$))")
    tag_regex = re.compile(r"\{(?P<tag_name>\w+)(?P<tag_op>!=|=)(?P<tag_val>[^\}]+)\}")
    field_regex = re.compile(r"^(?P<measurement>\S+)\[(?P<field>\S+)\]\S*")

    measurement_name = measurement_regex.match(signal_parts['measurement']).captures()[0]

    # Parse tag elements if any
    tag_matches = tag_regex.findall(signal_parts['measurement'])

    if len(tag_matches) > 0 and verify_tags:
        _check_tag_availability(signal_parts['database'], measurement_name, tag_matches, dbclient)

    if len(tag_matches) > 0:
        signal_parts['tagcondition'] = ''
        for m in tag_matches:  # m = (tag_key, tag_operator, tag_value)
            signal_parts['tagcondition'] += "\"{0}\"{1}'{2}' AND ".format(*m)

    # Match field elements if any
    match = field_regex.match(signal_parts['measurement'])
    if match:
        d = match.groupdict()
        if d['field'] == '*':
            signal_parts['field'] = d['field']
        else:
            signal_parts['field'] = [d['field']][0]

    # Remove field and tag brackets from the measurement name
    signal_parts['measurement'] = measurement_name


def generate_influxdb_query(signal_name, from_time, to_time, limit, dbclient, verify_tags=True, order_by_desc=False,
                            adjust_groupby_boundaries=True):
    """
    Generate InfluxQL query from signal name. If group by is used will also
    suggest a new from_time for the next chunk. Otherwise the third return
    value will be None.

    :param signal_name:
    :type signal_name: str
    :param from_time: From time
    :type from_time: Unix timestamp in [ns] as int64
    :param to_time: To time
    :type to_time: Unix timestamp in [ns] as int64
    :param limit: Max number of points to be returned by this query
    :type limit: int
    :param dbclient: Influx client used to lookup meta information
    :type dbclient: InfluxClient
    :param verify_tags: Verify that given tag keys and values are available for the given signal.
                        Will raise an error if they don't exist. Has a small performance penalty
                        because it needs to send some extra queries to influx. This may become
                        noticeable in rare cases where the list of signals is very long. So it can
                        be disabled with this option.
    :type verify_tags: bool (Default=True)
    :param order_by_desc: Return results in reverse order if true.
    :param adjust_groupby_boundaries: When groupby is used, adjusts the boundaries of the query such that groups
                                      aren't broken up as this would otherwise cause inconsistent aggregates.
    :type adjust_groupby_boundaries: bool
    :type order_by_desc: bool
    :return: database name and InfluxQL Query
    :rtype: (str, str, pd.Timestamp/None)
    """
    signal_parts = {
        'signal_name': signal_name,
        'database': None,
        'measurement': None,
        'aggfun': None,
        'aggfun_arg': None,
        'field': 'value',
        'tagcondition': '',
        'groupby': None,
        'mathstr_pre': '',
        'mathstr_post': '',
        'from': from_time,
        'to': to_time,
        'limit': limit
    }

    if order_by_desc:
        signal_parts['order_by'] = 'DESC'
    else:
        signal_parts['order_by'] = 'ASC'

    # Split signal into components
    split_sig = _split_signal_name(signal_name, signal_parts)

    # Derive database name for the first element of the signal name
    database = split_sig[0]
    # Convention: Machine numbers 'm' or 's' must be lower case.
    signal_parts['database'] = database[0].lower() + database[1:]

    _parse_aggfun_parts(split_sig, signal_parts)
    _parse_tags_and_fields(signal_parts, dbclient, verify_tags=verify_tags)

    # Select query template
    if signal_parts['aggfun'] is not None and signal_parts['aggfun_arg'] is not None:
        query_template = 'SELECT {mathstr_pre}percentile("{field}", {aggfun_arg}){mathstr_post} ' \
                         'AS "{signal_name}" ' \
                         'FROM "{measurement}" ' \
                         'WHERE {tagcondition} time>{from} AND time<{to} ' \
                         'GROUP BY time({groupby}) ' \
                         'FILL(none) ' \
                         'ORDER BY {order_by} ' \
                         'LIMIT {limit}'
    elif signal_parts['aggfun'] is not None:
        query_template = 'SELECT {mathstr_pre}{aggfun}("{field}"){mathstr_post} ' \
                         'AS "{signal_name}" ' \
                         'FROM "{measurement}" ' \
                         'WHERE {tagcondition} time>{from} AND time<{to} ' \
                         'GROUP BY time({groupby}) ' \
                         'FILL(none) ' \
                         'ORDER BY {order_by} ' \
                         'LIMIT {limit}'
    else:
        query_template = 'SELECT {mathstr_pre}"{field}"{mathstr_post} ' \
                         'AS "{signal_name}" ' \
                         'FROM "{measurement}" ' \
                         'WHERE {tagcondition} time>{from} AND time<{to} ' \
                         'ORDER BY {order_by} ' \
                         'LIMIT {limit}'

    # If there is a groupby statement, determine the last left boundary to
    # ensure we don't stop a chunk in the middle of a group.
    last_left_group_boundary = None
    if signal_parts['groupby'] is not None and adjust_groupby_boundaries:
        last_left_group_boundary = _get_last_left_group_boundary(signal_parts)
        last_left_group_boundary += 1000  # InfluxDB offset
        signal_parts['to'] = last_left_group_boundary

    query = query_template.format(**signal_parts)
    query = query.replace('"*"', '*')  # Unquote field asterisks

    return database, query, last_left_group_boundary


def _get_last_left_group_boundary(signal_parts):
    """
    Returns the from time for the next iteration such that groups will not
    be broken up when chunking data.

    Example:

    group size: 3
    agg method: last
    t :  0  1  2  3  4  5  6  7  8  9  10
    x :  0  1  2  3  4  5  6  7  8  9  10
    tg:  0        3        6        9
    xg:  2        5        8        10
                                    ^
                                    group is based on only 2 points i.s.o 3
                                    adjust tstop for this chunk and tstart
                                    for the next chunk to 9.

    In case of the example this function will return 9 as the suggested time.

    :param signal_parts: Signal parts, requires 'groupby' field
    :type signal_parts: dict

    :return: Last left boundary (9 in the example)
    :rtype: pd.Timestamp
    """
    match = re.match(r"(?P<value>\d+)(?P<unit>\w+)", signal_parts['groupby'])
    if not match:
        raise ValueError("signal_parts['groupby'] contains invalid syntax")
    cap_groups = match.groupdict()
    time_value = int(cap_groups['value'])
    unit = str(cap_groups['unit'])

    # Pandas uses the T symbol for minutes
    if unit == 'm':
        unit = 'T'

    tstart = pd.Timestamp(int(signal_parts['from']))
    step = pd.Timedelta(time_value, unit=unit)
    tstop = tstart + int(signal_parts['limit']) * step

    chunk_end_time = tstop.floor(str(time_value) + unit)

    return min(chunk_end_time.value, signal_parts['to'])


def chunk_signal(signal, user, from_time=None, to_time=None, chunksize=CHUNK_SIZE, dbclient=None, verbose=False,
                 verify_tags=True):
    """
    Returns the data of a list of signals in chunks.
    The signal are aligned in time and are converted to the local time of the machine.

    :param signal: Signal to get

    ::

        Each signal in the list should follow the following format:
            <source_nr>.<signal_type>.<signal_name>[field]{tag}.<aggregate_time>.<aggregate_func>
                Examples:
                    Standard          --> s62240.LUER.transmission
                    Rolling mean 1h   --> s62240.LUER.transmission.1h.mean
                    Specify field     --> s62179.DWMD.MCDWMD_EXPOSURE_MODE_PARAMS_EXPOSURE_MODE_DATA_MINI_BURST_MODE_PARAMETERS_BURST_DUTY_CYCLE_TAG[value01]
                    Last of the hour  --> s62240.LUER.image.1h.last
                    Single tag filter --> s62440.ScannerLog.de_err{code=DW-3411}.1d.max
                    Multi tag filter  --> s62265.RT23.TFMmajorAxis{subroutine=MP}{in_spec=True}

    :type signal: str
    :param user:               name of the user that is requesting the data (will be used for authorisation)
    :type user: str

    :param from_time:          epoch timestamp [ns] or pd.Timestamp(tz=UTC), default is 0
    :type from_time:           epoch or pd.Timestamp
    :param to_time:            epoch timestamp [ns] or pd.Timestamp(tz=UTC), default is now
    :type to_time:             epoch or pd.Timestamp
    :param chunksize:          Approximate number of records to return per iteration (default 5000)
    :type chunksize:           int
    :param dbclient:           Use the provided DataframeClient instead of automatically determinine the client based on
    :type dbclient:            DataFrameClient
    :param verify_tags: Verify that given tag keys and values are available for the given signal.
                        Will raise an error if they don't exist. Has a small performance penalty
                        because it needs to send some extra queries to influx. This may become
                        noticeable in rare cases where the list of signals is very long. So it can
                        be disabled with this option.
    :type verify_tags: bool (Default=True)

    :param verbose: Prints chunk sizes if True
    :type verbose: bool
    """
    if dbclient is None:
        raise ValueError("DB client required when running from userlan!")

    # Convert from_time to pandas.Timestamp if needed
    if isinstance(from_time, pd.Timestamp) and from_time.tzname() == 'UTC':
        from_time = from_time.value
    else:
        from_time = pd.to_datetime(from_time).tz_localize('UTC').value if from_time else 0  # ns timestamp

    if not to_time:
        to_time = np.datetime64('now')

    # Convert to_time to pandas.Timestamp if needed
    if isinstance(to_time, pd.Timestamp) and to_time.tzname() == 'UTC':
        to_time = to_time.value
    else:
        to_time = pd.to_datetime(to_time).tz_localize('UTC').value

    # Initial guess of the last timestamp of the chunk
    chunk_end_time = to_time

    # Chunking loop
    while True:
        # Use suggested from time for queries with a groupby statement
        database, qry, sugg_from_time = generate_influxdb_query(signal, from_time, to_time, chunksize, dbclient,
                                                                verify_tags=verify_tags)

        if verbose:
            print("Chunk {0} - {1}".format(
                pd.Timestamp(from_time).strftime('%Y-%m-%d %H:%M:%S'),
                pd.Timestamp(to_time).strftime('%Y-%m-%d %H:%M:%S')))

        result_dict = query_with_retry(qry, database, user, dbclient, 3)

        # Get the first dataframe out of the result dict. There will never
        # be more than 1 dataframe because we query them one at a time.
        if type(result_dict) in [dict, defaultdict] and len(result_dict) > 0:
            df = list(result_dict.values())[0]
        else:
            df = pd.DataFrame()

        if not df.empty:
            df = df.reset_index().drop_duplicates(subset='index', keep='last')
            df.rename(columns={'index': 'time'}, inplace=True)
            df = df.set_index('time').sort_index()

            # Calculate starting time of the next chunk
            chunk_end_time = df.index[-1].value

        if sugg_from_time is not None:
            if sugg_from_time >= to_time:
                yield df
                break
        elif df.empty:
            yield df  # return this chunk
            break

        # Calculate time interval for the next chunk, +1 should be OK but is
        # not robust because of DB resolution
        if sugg_from_time is None:
            from_time = chunk_end_time + 1000
        else:
            from_time = sugg_from_time

        # Reset chunk_end_time
        chunk_end_time = to_time
        yield df


def last_value_before(signal, to_time, default=None, dbclient=None):
    """
    Return the last value of a signal before the given timestamp
    """

    # Convert from_time to pandas.Timestamp if needed
    if isinstance(to_time, pd.Timestamp) and to_time.tzname() == 'UTC':
        to_time = to_time.value
    else:
        to_time = pd.to_datetime(to_time).tz_localize('UTC').value if to_time else 0  # ns timestamp

    # Disable groupby boundaries because our left boundary is always 0.
    db, qry, _ = generate_influxdb_query(signal, 0, to_time, 1, order_by_desc=True, dbclient=dbclient,
                                         adjust_groupby_boundaries=False)

    result_dict = query_with_retry(qry, db, None, dbclient, 3)

    # Get the first dataframe out of the result dict. There will never
    # be more than 1 dataframe because we query them one at a time.
    if type(result_dict) in [dict, defaultdict] and len(result_dict) > 0:
        df = list(result_dict.values())[0]
    elif default is not None:
        df = pd.DataFrame(data=[default], index=[pd.to_datetime(0,utc=True)], columns=[signal])
    else:
        df = pd.DataFrame()

    return df


def first_value_after(signal, from_time, default=None, dbclient=None):
    """
    Return the last value of a signal after the given timestamp
    """

    # Convert from_time to pandas.Timestamp if needed
    if isinstance(from_time, pd.Timestamp) and from_time.tzname() == 'UTC':
        from_time = from_time.value - 100  # Set from_time to 100ns before to ensure inclusion of from_time
    else:
        from_time = pd.to_datetime(from_time).tz_localize('UTC').value - 100 if from_time else 0  # ns timestamp

    # Disable groupby boundaries because our left boundary is always 0.
    ts_max = 2147483647000000000  # Max unix timestamp
    db, qry, _ = generate_influxdb_query(signal, from_time, ts_max, 1, order_by_desc=False, dbclient=dbclient,
                                         adjust_groupby_boundaries=False)

    result_dict = query_with_retry(qry, db, None, dbclient, 3)

    # Get the first dataframe out of the result dict. There will never
    # be more than 1 dataframe because we query them one at a time.
    if type(result_dict) in [dict, defaultdict] and len(result_dict) > 0:
        df = list(result_dict.values())[0]
    elif default is not None:
        df = pd.DataFrame(data=[default], index=[pd.to_datetime(0,utc=True)], columns=[signal])
    else:
        df = pd.DataFrame()

    return df



def results_to_dataframe(resultset):
    """
    Converts results from the InfluxClient to dataframes. This is a workaround
    for the 'broken' DataFrameClient where it doesn't support execution of multiple
    queries.

    Borrowed from influxdb.DataFrameClient._to_dataframe.
    Modified to return one dataframe per resultset.
    """
    results = {}
    for key, data in list(resultset.items()):
        name, tags = key
        if tags is None:
            key = name
        else:
            key = (name, tuple(sorted(tags.items())))
        df = pd.DataFrame(data)
        df.time = pd.to_datetime(df.time)
        df.set_index('time', inplace=True)
        df.index = df.index.tz_localize('utc')
        df.index.name = None
        results[key] = df

    return results


def get_aggregated_dataframe(client, report_date, signals, machines, clear_cache=False, max_retention=0):
    """
    Obtain aggregated values for the given day. Use only for KPI.DayAggregates._ signals.

    :param client: Influx client to use
    :param report_date: datetime.datetime.
    :param signals: list of signal names to extract. (Uses value column)
    :param machines: list of machines to include.

    :param clear_cache: Set to true to clear the query cache
    :param max_retention: integer number of days, default is 0. Allow the this function to return older aggregated values
      if no values are available for the given day. Values will not be older than [max_retention] days. If set to 0
      no older values will be used.

    *This function makes the following assumptions for the signal*

    * The aggregated value for a given day is written with a timestamp 00:00:00 (start of the day)
        a tolerance of +/- 1s is used.
    * There is only one aggregated value in this range

    Returns: pandas.DataFrame
    """
    #
    dt_start_str = (report_date - datetime.timedelta(seconds=1, days=max_retention)).strftime('%Y-%m-%d %H:%M:%S')
    dt_stop_str = (report_date + datetime.timedelta(seconds=1)).strftime('%Y-%m-%d %H:%M:%S')
    where_clause = "WHERE time > '{0}' and time < '{1}'".format(dt_start_str, dt_stop_str)
    qry_tpl = r'SELECT value from "s{0}".."{1}" ' + where_clause  # Note: '..' will get the default retention policy
    super_qry = ''

    # Switch to the first allowed DB so we have the right to run queries
    client.switch_database('s{0}'.format(machines[0]['source_nr']))

    # Build one big query for increased performance
    resultlist = []
    for m in machines:
        # Build one big query per machine for increased performance
        for s in signals:
            resultlist.append([m['machine_nr'], s])
            qry = qry_tpl.format(m['source_nr'], s)
            super_qry += qry + ';'

    result = client.query(super_qry)

    # If only a single aggregate is requested, the query will return a dict instead of a list of dicts
    if type(result) == dict:
        result = [result]

    # The number of returned results must match the number of prepared items in the resultlist (equals nr queryies).
    if len(resultlist) != len(result):
        raise IndexError("Unexpected number of results returned. Got {0}, expected {1}".format(len(result), len(resultlist)))

    # Convert results to dataframes and link them to the result list
    for i, rs in enumerate(resultlist):
        results = results_to_dataframe(result[i])
        if len(results) > 0:
            df = results[list(results.keys())[0]]  # We expect at most 1 result.
        else:
            df = None
        try:
            resultlist[i].append(df['value'][0])
        except TypeError:
            resultlist[i].append(np.nan)

    resultdict = defaultdict(dict)
    for r in resultlist:
        resultdict[r[0]][r[1]] = r[2]

    df_result = pd.DataFrame.from_dict(resultdict, orient='index')

    return df_result


def get_tag_keys(signal_name, dbclient):
    """
    Returns available tag keys for the given signal. Will return an empty
    list if there are none.

    :param signal_name: Signal name e.g. s66224.RT23.TFMdebrisArea
    :type signal_name: str
    :param dbclient: Influx client to use
    :type dbclient: InfluxDB client

    :rtype: list of strings
    """
    database = signal_name.split('.')[0]
    measurement_name = '.'.join(signal_name.split('.')[1:])
    results = dbclient.query(
        "SHOW TAG KEYS FROM \"{0}\"".format(measurement_name),
        database=database)

    tag_keys = []
    for r in results:
        for item in r:
            tag_keys.append(item['tagKey'])

    return tag_keys


def get_tag_values(signal_name, tag_key, dbclient):
    """
    Returns available tag values for the given tag key. Will return
    an empty list if there are none.

    :param signal_name: Signal name e.g. s66224.RT23.TFMdebrisArea
    :type signal_name: str
    :param tag_key: Tag name e.g. 'root_cause'
    :type tag_key: str
    :param dbclient: Influx client to use
    :type dbclient: InfluxDB client

    :rtype: list of strings
    """
    database = signal_name.split('.')[0]
    measurement_name = '.'.join(signal_name.split('.')[1:])
    results = dbclient.query(
        "SHOW TAG VALUES FROM \"{0}\" WITH KEY=\"{1}\""
        "".format(measurement_name, tag_key),
        database=database)

    tag_values = []
    for r in results:
        for item in r:
            tag_values.append(item['value'])

    return tag_values

################################################################################
# DATABASE MANAGEMENT
#################################################################################


def query_with_retry(query, database, user, dbclient, n_retry=4):
    """
    Run the query and retry if it fails.

    :param query: InfluxQL query
    :type query: str
    :param database: Database (source_nr) to query on
    :type database: str
    :param dbclient: Influx client to use
    :type dbclient: influx.DataFrameClient
    :param n_retry: Max number of retries
    :type n_retry: int

    :return: Query result
    :rtype: dict
    """
    # Retry loop in case we (temporarily) lose connection to InfluxDB
    for i in range(n_retry):
        try:
            result_dict = dbclient.query(query, database=database)
            break  # Success break out of the retry loop
        except InfluxDBClientError as e:  # call to db failed
            if e.code == 401:  # Not authorized
                # Not authorized stop retrying
                raise InfluxDBClientError("User {0} not authorized. "
                                          "Check your credentials"
                                          "".format(user))
            elif e.code == 403:
                raise InfluxDBClientError("User {0} not authorized to "
                                          "run this query or the "
                                          "requested signal doesn't "
                                          "exist. Check your query."
                                          "".format(user))
            elif e.code == None:
                raise InfluxDBClientError(e)
            elif e.code >= 500:
                # Retry server errors
                time.sleep(2 ** i)  # Internal server error (>=500), wait and retry
                continue
            else:
                raise e  # Give up on all other client errors
        except InfluxDBServerError:
            time.sleep(2**i)  # wait and retry
            continue
    else:
        raise IOError('Could not get signal')  # tried 4 times --> stop

    return result_dict


