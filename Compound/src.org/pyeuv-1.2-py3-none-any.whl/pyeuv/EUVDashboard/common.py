import socket
import os
import sys


def has_etl_environment():
    """
    Checks if pyeuv is running as part of the ETL environment.

    :returns True/False
    """
    # We're on the ETL environment if crawler and shared can be imported
    if socket.gethostname().upper().startswith('ICS106019'):
        return_value = True
    else:
        # If these files exist we're running as part of the ETL code
        if os.path.exists('crawler.py'):
            return_value = True
        else:
            return_value = False

    return return_value


def has_unix_environment():
    """

    :return:
    """
    if has_hpc_environment() & has_sf18_environment():
        return_value = True
    else:
        return_value = False

    return return_value


def has_hpc_environment():
    """
    Checks if pyeuv is running on the HPC.

    :returns True/False
    """
    if len([sp for sp in sys.path if '/hpc/' in sp]) > 0:
        return_value = True
    else:
        return_value = False

    return return_value


def has_sf18_environment():
    """
    Checks if pyeuv is running on the SF18 host machine.

    :returns True/False
    """
    if 'sf18' in socket.gethostname():
        return_value = True
    else:
        return_value = False

    return return_value
