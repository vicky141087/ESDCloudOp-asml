"""
ocrm_io.py
Authors: DANT
Date:  2020-09-08

Ownership: SF-18 (FC-079, FC-086)

The Optical Column Reflectivity Metric (OCRM) is calculating on tool (scanner) the relative reflectivity of the optical
column modules (collector, ILLUMO, POB).
This code handles all the data retrieval for icrm.py


Change History:
Date       | AUTH | Branch
-----------+------+-------------------------------------------------------------------------------------
2020-09-08 | DANT | feature/SSPT-601-create-icrm_corrected-signal-in-influxdb-to-support-replace-slie-dt

"""

from inspect import currentframe
import pandas as pd

from pyeuv.Do_It import do_it_library as do_it


def get_collector_name_names(verbose=False):
    """
    Function that returns a dictionary with required collector_name signals:
        'Collector.Swap'

    Until Collector install CPD is not available the 'Collector.Swap' signal is the only signal indicating
    when a collector swap was done.

    :param verbose: switches debug mode (default=False)
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    :type: dict
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
        u'Collector_Name': u'Collector.Swap'
    }
    return signal_names_mapping


def get_icrm_signal_names(verbose=False):
    """
    Function that returns a dictionary with required ICRM (collector) signals like reflectivity and pulse count:
            'Scanner.OCRM_CollectorLifetimeRelativeReflectivity',
            'Scanner.OCRM_CollectorLifetimePulseCounter'

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    :type: dict
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
        u'icrm': u'Scanner.OCRM_CollectorLifetimeRelativeReflectivity',
        u'icrm_pulse_count': 'Scanner.OCRM_CollectorLifetimePulseCounter'
    }

    return signal_names_mapping


def get_icrm_filter_signal_names(verbose=False):
    """
    Function that returns a dictionary with required filter signals related to ICRM:
            'Filter._ICRM_AutoCorrection',                  <<= ICRM auto correct signal as calculated in icrm.py
            'Filter._ICRM_ManualCorrection',                <<= manual uploaded signal to InfluxDB for the manual correction
            'Filter._ManualBlockICRM',                      <<= manual uploaded signal to InfluxDB to block
                                                                icrm_corrected data
            'PXPBV2.MCPXPBV2_MEMBRANE_TRANSMISSION_TAG',    <<= DGLm transmission MC
            'Scanner.DW_SS_cf_non_leading'

    :param verbose: to switch internal debug info
    :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
    :type: dict
    """

    do_it.do_it_verbose(currentframe(), verbose)

    signal_names_mapping = {
            u'icrm_auto_correct': u'Filter._ICRM_AutoCorrection',
            u'icrm_manual_correct': u'Filter._ICRM_ManualCorrection',
            u'manual_block_icrm': u'Filter._ManualBlockICRM',
            u'ocrm_dglm_transmission': u'PXPBV2.MCPXPBV2_MEMBRANE_TRANSMISSION_TAG',
            u'ocrm_sscf_non_leading': u'Scanner.DW_SS_cf_non_leading'
            }
    return signal_names_mapping


def get_icrm_data(client, source_id, from_time, to_time, verbose=False):
    """
    obtain all the required ICRM related data from InfluxDB.

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :param verbose: to switch internal debug info
    :return: dictionary with data frames per signal group
    :type: dict
    """

    do_it.do_it_verbose(currentframe(), verbose)

    time_start = pd.Timestamp(u'now')
    signals = dict()

    try:
        df = client.get_signals_dict(get_collector_name_names(),
                                     source_id, from_time, to_time, create_columns=True)
        if df.empty:
            signals[u'collector'] = pd.DataFrame(columns=get_collector_name_names().keys())
        else:
            signals[u'collector'] = df

        df = client.get_signals_dict(get_icrm_filter_signal_names(),
                                     source_id, from_time, to_time, create_columns=True)
        if df.empty:
            signals[u'filter'] = pd.DataFrame(columns=get_icrm_filter_signal_names().keys())
        else:
            signals[u'filter'] = df

        df = client.get_signals_dict(get_icrm_signal_names(),
                                     source_id, from_time, to_time, create_columns=True)
        if df.empty:
            signals[u'scanner'] = pd.DataFrame(columns=get_icrm_signal_names().keys())
        else:
            signals[u'scanner'] = df


    except Exception as e:
        print (u'Error:', e)
        signals[u'collector'] = pd.DataFrame(columns=get_collector_name_names().keys())
        signals[u'filter'] = pd.DataFrame(columns=get_icrm_filter_signal_names().keys())
        signals[u'scanner'] = pd.DataFrame(columns=get_icrm_signal_names().keys())

    if verbose:
        duration = pd.Timestamp(u'now') - time_start
        print(u'\ndata loaded in {:.2f} seconds\n'.format(duration.seconds + duration.microseconds * 1e-6))

    return signals
