"""
icrm.py
Authors: DANT
Date:  2020-09-08

Ownership: SF-18 (FC-079, FC-086)

The Inline Collctor Reflectivity Metric (ICRM) is calculating on tool (scanner) by using the normalized ratio of
"Corrected Open UN SLIP"/"Source Internal Power".
As this signal is calculated on tool and the "Corrected Open UN SLIP" is subjective to "external" influences e.g.:
 - DGLm transmission changes
 - SSCF_NL updates
These are currently not being included/accounted for by the ICRM signal.
This code will correct the ICRM signal (available in InfluxDB) for these contributors and store it as a
new signal 'Scanner._ICRM_corrected'.
Also the ICRM_corrected will include manual uploaded corrections for e.g. pedestal tuning.
And the last option is to block incorrect ICRM_corrected data points

Additionally the degradation rates can be calculated for the ICRM and ICRM_corrected signals.


Change History:
Date       | AUTH | Branch
-----------+------+-------------------------------------------------------------------------------------
2020-09-08 | DANT | feature/SSPT-601-create-icrm_corrected-signal-in-influxdb-to-support-replace-slie-dt

"""

from inspect import currentframe
import pandas as pd
import numpy as np

from pyeuv.OpticalColumnReflectivityMonitoring.ocrm_io import get_icrm_data
from pyeuv.Do_It import do_it_library as do_it


def prepare_icrm_filter(icrm_data, verbose=False):
    """
    Function to prepare the ICRM filter data. It uses the default values in case filter data is unavailable.

    :param icrm_data: signals from the filter signal group
    :type: dataframe
    :param verbose: to switch internal debug info
    :return: dataframe
    :type: dataframe
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # default icrm filter state in case data is missing
    default_icrm_filter_values = dict([('icrm_auto_correct', 1.0),
                                       ('icrm_manual_correct', 1.0),
                                       ('manual_block_icrm', 0)])

    icrm_filter = icrm_data['filter'].copy()
    icrm_filter = icrm_filter.join(icrm_data['scanner'], how='outer')

    # in case data is missing at all, fill with default value
    for key in default_icrm_filter_values:
        if key not in icrm_filter.keys():
            icrm_filter[key] = default_icrm_filter_values[key]

    # in case first datapoint is nan, fill it with the default value
    if not icrm_filter.empty:
        for signal in icrm_filter.keys():
            if np.isnan(icrm_filter.loc[icrm_filter.index[0], signal]) & (signal in default_icrm_filter_values.keys()):
                icrm_filter.loc[icrm_filter.index[0], signal] = default_icrm_filter_values[signal]

    # define columns for which ffill should be applied
    cols = ['ocrm_dglm_transmission', 'ocrm_sscf_non_leading', 'icrm_auto_correct', 'icrm_manual_correct',
            'manual_block_icrm']
    icrm_filter[cols] = icrm_filter[cols].fillna(method='ffill')
    icrm_filter.dropna(inplace=True)

    # enabled when manual_block_icrm is not active
    icrm_filter['block_icrm_filter'] = False
    icrm_filter.loc[(icrm_filter['manual_block_icrm'] != 1), 'block_icrm_filter'] = True

    return icrm_filter


def create_relative_correction_factor(df, key, verbose=False):
    """
    Function to calculate the relative correction factor with respect to the 1st data points for a given signal.

    :param df: input dataframe containing the column of the key for which the relative correction factor
               is to be calculated
    :type df: dataframe
    :param key: name of the column for which the relative correction factor is calculated
    :param verbose: to switch internal debug info
    :return: dataframe containing the relative correction factor of the key
    :type: dataframe
    """
    result = 1.0 - ((df[key] - df[key].iloc[0]) / df[key].iloc[0])

    return result


def apply_icrm_correction_filters(icrm_filter, use_dglm_transmission=True, use_sscf_nl_correction=True, verbose=False):
    """
    Function to apply the icrm (auto, manual and block) correction factors on the icrm signal. The corrected signal
    will then be 'icrm_corrected'.
    In the future when ICRM itself is corrected for DGLm transmission, SSCF_NL changesand other contributors than
    the ICRM_corrected signal would not be needed anymore.
    Then the 'use_dglm_transmission' and 'use_sscf_nl_correction' will by default be False. For now we would like
    to have a new signal 'ICRM_corrected' including all corrections and therefore they are enabled by default.

    :param use_dglm_transmission: correct the ICRM signal for the DGLm transmission (default = True)
    :param use_sscf_nl_correction: correct the ICRM signal for the SSCF_NL changes (default = True)
    :param icrm_filter: signals from the filter signal group
    :type: dataframe
    :param verbose: to switch internal debug info
    :return: dataframe with 'Scanner._ICRM_corrected'
    :type: dataframe
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # calculate the icrm_auto_correct data
    # the 'icrm_auto_correct' is by default 1 for the 1st icrm measurement. For the next it can change
    # depending on the values of the other signals i.e. DGLM trans and SSCF. Therefore 'icrm_auto_correct'
    # needs to be calculated from the 2nd and onward icrm measurement

    if use_dglm_transmission and not use_sscf_nl_correction:
        icrm_filter['icrm_auto_correct'] = create_relative_correction_factor(icrm_filter, ['ocrm_dglm_transmission'],
                                                                             verbose=verbose)

    if use_sscf_nl_correction and not use_dglm_transmission:
        icrm_filter['icrm_auto_correct'] = create_relative_correction_factor(icrm_filter, ['ocrm_sscf_non_leading'],
                                                                             verbose=verbose)

    if use_dglm_transmission and use_sscf_nl_correction:
        icrm_filter['icrm_auto_correct'] = \
            create_relative_correction_factor(icrm_filter, ['ocrm_dglm_transmission'], verbose=verbose).iloc[:, 0] * \
            create_relative_correction_factor(icrm_filter, ['ocrm_sscf_non_leading'], verbose=verbose).iloc[:, 0]

    # apply correction to icrm and create the new signal icrm_corrected
    icrm_filter['icrm_corrected'] = icrm_filter['icrm'] * icrm_filter['icrm_auto_correct'] * icrm_filter[
        'icrm_manual_correct']

    # apply the manual block icrm filter
    icrm_filter['icrm_corrected'] = icrm_filter['icrm_corrected'] * icrm_filter['block_icrm_filter']
    # make all null values Nan
    icrm_filter.loc[(icrm_filter['icrm_corrected'] == 0), 'icrm_corrected'] = np.NaN

    result = pd.DataFrame(icrm_filter['icrm_corrected'])
    # result = icrm_filter.dropna()

    return result


def calculate_icrm_degradation_rate(df, key, windows=[1.0, 5.0, 20.0], post_fix='',
                                    advanced_analysis=False, verbose=False):
    """
    Calculates the (degradation) rate and confidence interval for different pulse count windows of a given signal.
    A window of x has at least a range of x pulsecounts, so the data point in that window is at least x (max - min >= x)

    :param df: input dataframe containing a column 'icrm_pulse_count' (in Gp) and key
    :type: dataframe
    :param key: key of the signal for which the rate is calculated
    :param windows: list of pulse count windows (in Gp) to be calculated (default: [1.0, 5.0, 20.0])
    :param post_fix: in case one needs to add a postfix to the created degradation rate signals,
        for instance '_nonSG', one can use this post_fix (default: '')
    :param advanced_analysis: when true calculate linear fit including the confidence interval and adjusted R squared.
        Otherwise only calculate the linear fit slope (faster calculation)
    :param verbose: to switch internal debug info
    :return: dataframe containing the original signals and degradation rates.
    :type: dataframe
    """

    from pyeuv.Shared.signal_processing import calculate_linear_fit

    do_it.do_it_verbose(currentframe(), verbose)

    # Get the name of column containing the pulse count data
    pc_column = df.loc[:, df.columns.str.contains("pulse_count")]
    pc = pc_column.columns[0]   # name of the column containing the pulse count data
    if verbose:
        print('Pulse count column name used is:', pc)

    result = df.dropna()

    # create helper columns, to easily select the rows including the first row that is >= x Gp from the current row
    # without, this, the 5 Gp window would in fact be <5 Gp, where the functional requirement is a fit of at least 5 Gp.

    result[pc + '_up'] = result[pc].shift(-1)
    result[pc + '_down'] = result[pc].shift(1)

    for i, row in result.iterrows():
        for window in windows:
            # filter data for previous x Gp window
            tmp = result[(result[pc] <= row[pc]) & (result['{}_up'.format(pc)] >= (row[pc] - window))]

            if tmp[pc].max() - tmp[pc].min() > window:
                linear_fit = calculate_linear_fit(tmp[pc], tmp[key], round_to_significant_digit=False,
                                                  advanced_analysis=advanced_analysis)
                slope, offset, confidence_interval, adjusted_r_squared = linear_fit
                result.loc[i, '{}_degradation_rate_previous_{}Gp{}'.format(key, window, post_fix)] = slope
                # only create the confidence interval column when advance analysis is enabled as by default it is not
                # being calculated
                if advanced_analysis:
                    result.loc[i, '{}_degradation_rate_previous_{}Gp_confidence_interval{}'.format(
                        key, window, post_fix)] = confidence_interval

    # remove the helper columns
    result.drop(columns=['{}_up'.format(pc), '{}_down'.format(pc)], inplace=True)

    return result


def cleanup_icrm_auto_correct(icrm_filter, verbose=False):
    """
    Cleanup the icrm_auto_correct signal to keep only the 1st value of the duplicate values and remove the others.
    This will result in only having the change point values. This cleaned-up signal can then be used to be
    stored in InfluxDB.

    :param icrm_filter: dataframe containing all icrm filter data
    :type: dataframe
    :param verbose: to switch internal debug info
    :return: dataframe containing only the icrm_auto_correct change points.
    :type: dataframe
    """

    do_it.do_it_verbose(currentframe(), verbose)

    # copy only the icrm_auto_correct data to new dataframe
    result = icrm_filter[['icrm_auto_correct']].copy()

    # keep only the 1st value of the duplicates and remove the duplicates
    result = result.drop_duplicates(subset='icrm_auto_correct', keep='first',inplace=False)

    return result
