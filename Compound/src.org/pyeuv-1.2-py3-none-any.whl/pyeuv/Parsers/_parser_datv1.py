"""
Stripped down datv1 parser from SEAT
Original author: Han Claas [ASML]
Modified version: Rob de Laat [ASML]
"""

import os, csv, logging
from struct import unpack
from numpy import frombuffer
from ._datv1_translator import translator
from ..helpers import epoch2num


class parser_datv1(object):
    def __init__(self, fid, FullFileName, metadatafile=None):
        self.FullFileName = FullFileName
        self.dtype_memmap, self.order = '<u4', 'C'
        self.fid = fid
        self.parse_header(self.fid)

        if metadatafile is None:  # Try to find the file ourselves
            base_path = os.path.dirname(FullFileName)
            search_strings = ['StreamingMetaData.txt', 'MetaData.csv', 'MetaData.dat']
            for s in search_strings:
                metadatafile = os.path.join(base_path, s)
                if os.path.isfile(metadatafile):
                    break
            else:
                raise IOError("DATv1 Requires a StreamingMetaData.txt file, but none could be found.")

        metadata = self.parse_metadata_file(metadatafile)
        self.create_metadata(metadata)

    def parse_metadata_file(self, MetaFileName):
        metadata = {}
        with open(MetaFileName, 'r') as fid:
            csvr = csv.reader(fid, delimiter=',', skipinitialspace=True)
            for line in csvr:
                if line[0].isdigit():
                    metadata[int(line[0])] = [line[1], line[2], int(line[3]), int(line[4])]
                elif line[0] in ['StreamingDataMetaDataVersion', 'Records']:
                    metadata[line[0]] = int(line[1])
                elif line[0] == 'FieldID':
                    metadata['headers'] = line
                else:
                    logging.info(' not parsed: %s\n' %line)

        return metadata

    def parse_header(self, fid):
        fid.read(4)  # Skip LCHD bytes, file has already been verified to be LHCD
        version, fields= unpack('II', fid.read(8))
        self.fieldIDs = unpack('I'*fields, fid.read(fields * 4))
        preamble, = unpack('I', fid.read(4))
        if preamble != 1437257522:
            self.dtype = '<u4' # big endian

        fid.seek(0,2)
        filesize = fid.tell()
        columns = fields + 7
        self.offset = 4 + 4 + 4 + fields * 4
        rows = (filesize - self.offset) / (4 * columns)
        self.shape = (rows, columns)
        self.leftover = (filesize - self.offset) % (4 * columns)

        if os.path.splitext(self.FullFileName)[-1] in  ['.dat'] and self.leftover != 0:
            logging.info('WARNING %i leftover bytes present\n' %self.leftover)

    def create_metadata(self, metadata):
        column = 0
        DataTypes = {4: 'u4', 5: 'i4', 6: 'f4'}
        init_columns = [('Preamble', 'none'), ('MetaVersion', 'none'), ('Sequence', 'none'), ('time', 's'), ('fractionalTime', 'ns'), ('RecordType', 'none'), ('Columns', 'none')]
        self.dtype = [('Preamble', 'u4'), ('MetaVersion', 'u4'), ('Sequence', 'u4'), ('TIMESTAMP', 'M8[ns]'), ('RecordType', 'u4'), ('Columns', 'u4')]
        self.dtype = [('Preamble', 'u4'), ('MetaVersion', 'u4'), ('Sequence', 'u4'), ('TIMESTAMP', 'f8'), ('RecordType', 'u4'), ('Columns', 'u4')]
        self.actual_metadata = {}
        for FieldName, Units in init_columns:
            self.actual_metadata[FieldName] = {}
            self.actual_metadata[FieldName]['Column'] = column
            self.actual_metadata[FieldName]['Units'] = Units
            self.actual_metadata[FieldName]['DataType'] = DataTypes[4]
            column += 1
        for id in self.fieldIDs:
            if id in metadata:
                FieldName = metadata[id][0]
                self.actual_metadata[FieldName] = {}
                self.actual_metadata[FieldName]['FieldID'] = id
                self.actual_metadata[FieldName]['Units'] = metadata[id][1]
                self.actual_metadata[FieldName]['DataType'] = DataTypes[metadata[id][2]]
                self.actual_metadata[FieldName]['RecordType'] = metadata[id][3]
                self.actual_metadata[FieldName]['Column'] = column
                self.dtype += [ (FieldName, DataTypes[metadata[id][2]])]
            column += 1        

    def create(self):
        return

    def contains(self):
        return [name for name, dtype in self.dtype]

    def metadata(self):	
        return self.actual_metadata

    def get(self, FieldName = None):
            return self.get_basic(self.fid, FieldName)
    
    def get_basic(self, fid, FieldName = None):
        fid.read(self.offset)
        if self.order == 'C':
            # rows = len(s) / npdtype(self.dtype).itemsize
            if self.leftover > 0 and os.path.splitext(self.FullFileName)[-1] in  ['.datx', '.dat']:
                data = frombuffer(fid.read()[:-self.leftover], dtype=self.dtype)
            else:
                data = frombuffer(fid.read(), dtype=self.dtype)
        else:
            data = frombuffer(fid.read(), dtype='u4')
            columns = 1 + len(self.dtype)
            rows = data.size/columns
            # rows = len(s) / npdtype(self.dtype).itemsize
            data = frombuffer(data.reshape((columns, rows)).tostring('F'), dtype=self.dtype)
        # ...
        if type(FieldName) == type(''):
            FieldName = [FieldName]

        data = data[FieldName].copy()
        for fld in FieldName:
            fld_dtype = [d for d in self.dtype if d[0] == fld][0]
            if fld in translator and 'DisplayScale' in translator[fld]:
                if fld_dtype == translator[fld]['DataType']:
                    data[fld] = translator[fld]['DisplayScale'] * data[fld].view(fld_dtype)
                else:
                    data[fld] = translator[fld]['DisplayScale'] * data[fld].astype(translator[fld]['DataType'])

        if self.dtype[3][1] == 'M8[ns]':
            data['TIMESTAMP'] = (data['TIMESTAMP'].astype('u8') & 2**32-1).astype('datetime64[s]') + (data['TIMESTAMP'].astype('u8') >> 32).astype('timedelta64[ns]')
        elif self.dtype[3][1] == 'f8':
            data['TIMESTAMP'] = epoch2num((data['TIMESTAMP'].view('u8') & 2**32-1).astype('f8') + (data['TIMESTAMP'].view('u8') >> 32).astype('f8') * 1e-9)
        return data
    
