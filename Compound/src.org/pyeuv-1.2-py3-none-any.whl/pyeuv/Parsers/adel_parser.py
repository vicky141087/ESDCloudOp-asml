import pandas as pd
from lxml import etree
from ..helpers import LoadFile


def parse_adel(f, verbose=False):
    """
    Parses input adel files into a pandas dataframe.

    :param fn: File name of file handle
    :type fn: str or File object
    :param verbose: Print filenames being parsed
    :type verbose: bool

    :return: dict with pandas.Series
    """
    # Got a file name, open it and decompress if needed.
    if type(f) == str:
        if verbose:
            print("Loading {0}".format(f))
        with LoadFile(f) as fh:
            tree = etree.parse(fh)
    else:
        tree = etree.parse(f)

    # Determine report type
    try:
        adel_title = tree.xpath('//Header/Title')[0].text
    except KeyError:
        raise KeyError("Could not determine ADEL type")

    if adel_title == 'Parameter History Report':
        adel_type = 'scn'
    elif adel_title == 'KPI report':
        adel_type = 'src'
    else:
        raise TypeError("Unsupported ADEL type: {0}".format(adel_title))

    values = []
    times = []
    data = dict()

    if adel_type == 'scn':
        signal = tree.find('//ParameterHistoryList/elt/ParameterName').text

        for node in tree.xpath('//ValueList/elt'):
            times.append(pd.Timestamp(node[0].text).tz_convert('utc'))
            values.append(float(node[1].text))

        data[signal] = pd.Series(values, index=times)
        return data
    else:
        signals = []
        signal_list = tree.find('//KpiList')
        for elt in signal_list:
            for kpi_name in elt:
                signals.append(kpi_name.text)

        for s in signals:
            if verbose:
                print("Reading: {0}".format(s))
            for node in tree.xpath('//{0}/HistoryList/elt'.format(s)):
                times.append(pd.Timestamp(node[0].text).tz_convert('utc'))
                values.append(float(node[1].text))
            data[s] = pd.Series(values, index=times)

        return data
