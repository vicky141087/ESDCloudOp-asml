translator = {
    'ECtFireActual':
        {'DisplayName': 'tFire', 'DisplayUnit': 'us', 'DataType': 'f4', 'DisplayScale': 1e-3},
    'SUBS_VAL_FL_FOC_TFF_CORR_X__OT_SUBS_VAL_FL_OUT':
        {'DisplayName': 'FFA-X', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'SI_FC_RBD_CAM__OT_SI_CAM_RBD_MSG_RSLT_INTENS_OUT':
        {'DisplayName': 'RBD Intensity', 'DisplayUnit': '-', 'DataType': 'f4', 'DisplayScale': 1.0},
    'SUBS_VAL_FL_FOC_TFF_CORR_Y__OT_SUBS_VAL_FL_OUT':
        {'DisplayName': 'FFA-Y', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'SUBS_VAL_FL_FOC_TFF_CORR_Z__OT_SUBS_VAL_FL_OUT':
        {'DisplayName': 'FFA-Z', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'SUBS_FL_FC_SLOW_FOC_Y__OT_SUBS_FL_OUT':
        {'DisplayName': 'L2D-Y slow', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'SUBS_FL_FC_FOC_Z__OT_SUBS_FL_OUT':
        {'DisplayName': 'L2D-Z', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'SUBS_FL_FC_FAST_FOC_Y__OT_SUBS_FL_OUT':
        {'DisplayName': 'L2D-Y fast', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'ECfcem1MpEnergy':
        {'DisplayName': 'PA3 MP', 'DisplayUnit': 'mJ', 'DataType': 'f4', 'DisplayScale': 1.0},
    'ECfcem1PpEnergy':
        {'DisplayName': 'PA3 PP', 'DisplayUnit': 'mJ', 'DataType': 'f4', 'DisplayScale': 1.0},
    'ECbwdPpEnergy':
        {'DisplayName': 'bwd PP', 'DisplayUnit': 'mJ', 'DataType': 'f4', 'DisplayScale': 1.0},
    'MS_FC_WAVEFR_CAM__OT_MAT_2X2_FLT_OUT2':
        {'DisplayName': 'WFS PP Foc', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_WAVEFR_CAM__OT_MAT_2X2_FLT_OUT1':
        {'DisplayName': 'WFS MP Foc', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_FBD_MP_NF_CAM__OT_MAT_2X2_FLT_OUT1':
        {'DisplayName': 'FBD MP NF Y', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 7100.0},
    'MS_FC_FBD_MP_NF_CAM__OT_MAT_2X2_FLT_OUT2':
        {'DisplayName': 'FBD MP NF X', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 7100.0},
    'MS_FC_FBD_MP_FF_CAM__OT_MAT_2X2_FLT_OUT1':
        {'DisplayName': 'FBD MP FF X', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_FBD_MP_FF_CAM__OT_MAT_2X2_FLT_OUT2':
        {'DisplayName': 'FBD MP FF Y', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT1':
        {'DisplayName': 'FBD PP FF X', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT2':
        {'DisplayName': 'FBD PP FF Y', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'DLPA3_PB_TASC_WINDOW_TEMP':
        {'DisplayName': 'PA3 output', 'DisplayUnit': 'W', 'DataType': 'f4', 'DisplayScale': 1.0},
    'DLPA0_PB_TASC_WINDOW_TEMP':
        {'DisplayName': 'PA0 input', 'DisplayUnit': 'W', 'DataType': 'f4', 'DisplayScale': 1.0},
    'DLSDL_PM4001_PWR':
        {'DisplayName': 'Leakage PWR', 'DisplayUnit': 'W', 'DataType': 'f4', 'DisplayScale': 1.0},
    'DLSDL_PM4002_PWR':
        {'DisplayName': 'Rejected PWR', 'DisplayUnit': 'W', 'DataType': 'f4', 'DisplayScale': 1.0},
    'ECeuvValue':
        {'DisplayName': 'EUV', 'DisplayUnit': 'mJ', 'DataType': 'f4', 'DisplayScale': 1.0},
    'ECcrossingInterval':
        {'DisplayName': 'CrossingInterval', 'DisplayUnit': 'us', 'DataType': 'f4', 'DisplayScale': 1.0},
    'MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT1':
        {'DisplayName': 'RBD X', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT2':
        {'DisplayName': 'RBD Y', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT3':
        {'DisplayName': 'RBD Focus Z', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_WAVEFR_CAM__OT_MAT_2X2_FLT_OUT1':
        {'DisplayName': 'WFS MP Focus', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'MS_FC_WAVEFR_CAM__OT_MAT_2X2_FLT_OUT2':
        {'DisplayName': 'WFS PP Focus', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'OAinputX':
        {'DisplayName': 'OASIS-X', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'OAinputY':
        {'DisplayName': 'OASIS-Y', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'OAinputZ':
        {'DisplayName': 'OASIS-Z', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'DDDG_DPC6501_ACTUAL_Y_CAMERA':
        {'DisplayName': 'FDCS-Y', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
    'DDDG_DPC6501_ACTUAL_Z_CAMERA':
        {'DisplayName': 'FDCS-Z', 'DisplayUnit': 'um', 'DataType': 'f4', 'DisplayScale': 1e6},
}
