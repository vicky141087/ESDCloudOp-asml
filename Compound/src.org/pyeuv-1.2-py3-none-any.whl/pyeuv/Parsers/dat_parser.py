import os
from struct import unpack
import pandas as pd
from multiprocessing import Pool
from functools import partial
import glob
import tkinter as tk
from tkinter import filedialog

from ._parser_datv1 import parser_datv1
from ._parser_datv2 import parser_datv2, datv2
from ..helpers import LoadFile, num2ts


def _parse_dat(fn, signal_list, datv1_metadatafile=None, verbose=False):
    if verbose:
        print(fn)

    with LoadFile(fn) as fh:
        if fh.read(4) != b"LCHD":
            raise TypeError("Not a datv1 or datv2 file.")

        version, = unpack('<L', fh.read(4))

        if version == 1:
            fh.seek(0)
            parser = parser_datv1(fh, fn, metadatafile=datv1_metadatafile)
            parser.create()

            # Always include timestamp
            if 'TIMESTAMP' not in signal_list:
                signal_list.insert(0, 'TIMESTAMP')

            fh.seek(0)
            df = pd.DataFrame(parser.get(signal_list)).set_index('TIMESTAMP')
            df.index = num2ts(df.index)

        elif version == 2:
            fh.read(4)  # Skip column count

            df = pd.DataFrame()
            for data in datv2(fh, signal_list, None):
                df = pd.concat([df, data])

        else:
            raise TypeError("Dat v{0} is not supported!".format(version))

        return df


def parse_dat(filenames, signal_list, datv1_metadatfile=None, verbose=False):
    """
    Processes input dat files into pandas dataframes.

    :param filenames: List of files (full path) to process
    :param signal_list: List of signals to extract For example: BDeuvEnergyAvgOn from RT5
    :param datv1_metadatafile: Path to metadatafile, for DATv1. Will try to autodetect if set to None (default)
    :param verbose: If true, prints filenames being parsed

    :return: pandas.DataFrame: Dataframe
    """
    if type(filenames) == str:
        filenames = [filenames]

    df_result = None
    for fn in filenames:
        if verbose:
            print("Reading " + fn)

        df = _parse_dat(fn, signal_list, datv1_metadatafile=datv1_metadatfile)
        df_result = pd.concat([df_result, df], axis=0)

    return df_result

def parse_dat_parallel(filenames, signal_list, datv1_metadatafile=None,
                       verbose=False, pool_size=5):
    """
    Update a cached signal with new data Process input dat files into pandas
    dataframes. Processes multiple files in parallel

    :param filenames: List of files (full path) to process
    :param signal_list: List of signals to extract For example: BDeuvEnergyAvgOn from RT5
    :param datv1_metadatafile: Path to metadatafile, for DATv1. Will autodetect if set to None (default)
    :param verbose: (bool) If true, prints filenames being parsed
    :param pool_size: (int) Number of processes

    :return: pandas.DataFrame: Dataframe
    """

    if isinstance(filenames, str):
        filenames = [filenames]
    
    pfunc = partial(_parse_dat, signal_list=signal_list, verbose=verbose, datv1_metadatafile=datv1_metadatafile)
    p = Pool(pool_size)
    chunks = p.map(pfunc, filenames)

    if verbose:
        print("Linking chunks")
    result = pd.concat(chunks)

    return result


def ls_dat(fn, datv1_metadatafile=None, verbose=False):
    """Lists signals available in the given dat file.

    :param fn: Full path to the dat file
    :type fn: str
    :param datv1_metadatafile: Required only when parsing datv1 data.
    :type datv1_metadatafile: str
    :param verbose: Print messages from the parser module
    :type verbose: bool

    """
    if verbose:
        print(fn)

    with LoadFile(fn) as fh:
        if fh.read(4) != b"LCHD":
            raise TypeError("Not a datv1 or datv2 file.")

        version, = unpack('<L', fh.read(4))

        if version == 1:
            fh.seek(0)
            parser = parser_datv1(fh, fn, metadatafile=datv1_metadatafile)
            parser.create()

            return parser.contains()

        elif version == 2:
            fh.read(4)  # Skip column count

            p = parser_datv2(fh, None)

            return p.contains()

        else:
            raise TypeError("Dat v{0} is not supported!".format(version))


def parse_dat_directory_gui(rt_type, signal_list=None):
    """
    Parse RT files of the given in the directory selected by the user. Upon
    calling this function a tk file selection diaglog is opened. 
    Unless a signal_list is provided it will parse all available signals in
    the RT file. Can only process one type of RT data at the same time.

    :param rt_type: Type of RT to parse. (RT05, RT05 etc...)
    :type rt_type: str
    :param signal_list: Signals in the RT file to parse.
    :type signal_list: list<str>, optional
    :returns: parsed data, or None if the directory is empty
    :rtype: pandas.DataFrame or None
    """
    # Use tkinter to get a file dialog
    tk_root = tk.Tk()
    tk_root.withdraw()
    directory = tk.filedialog.askdirectory(parent=tk_root, title='Select folder with RT data')

    if directory is not None:
        return parse_dat_directory(directory, rt_type, signal_list)
    else:
        return


def parse_dat_directory(directory, rt_type, signal_list=None):
    """
    Parse RT files of the given type in this directory. Unless a signal_list
    is provided it will parse all available signals in the RT file. Can only
    process one type of RT data at the same time.

    :param directory: Directory containing the RT files
    :type directory: str
    :param rt_type: Type of RT to parse. (RT05, RT05 etc...)
    :type rt_type: str
    :param signal_list: Signals in the RT file to parse.
    :type signal_list: list<str>, optional
    :returns: parsed data, or None if the directory is empty
    :rtype: pandas.DataFrame or None
    """

    allowed_extensions = ['.dat', '.xz', '.gz']

    file_pattern = '*{0}*'.format(rt_type)
    filez = glob.glob(os.path.join(directory, file_pattern))
    filez = [f for f in filez if rt_type.lower() in f.lower()
             and os.path.splitext(f)[-1] in allowed_extensions]
    
    if len(filez) == 0:
        return None

    # Get the signal list from the first file
    if signal_list is None:
        signal_list = ls_dat(filez[0])

    # Create empty object in which to store the result of parsed data
    df_result = None
    for f in filez:
        df = parse_dat(f, signal_list)
        df_result = pd.concat([df_result, df], axis=0)

    return df_result


if __name__ == '__main__':
    df = parse_dat_directory_gui('RT02')
    print(df)