import pandas as pd

from struct import unpack
from numpy import fromstring
from xml.etree.ElementTree import fromstring as xml_fromstring

from ..helpers import epoch2num

class ColumnType(object):
    '''ColumnType enumeration.
    
    See "StreamingDataReader.py".
    '''
    Ignore         = 1
    SequenceNumber = 2
    Time           = 3
    FractionalTime = 4
    SignalValue    = 5

class DataType(object):
    '''datv2 data type enumeration.
    
    See "StreamingDataReader.py".
    '''
    Undefined               = 1
    FourByteInteger         = 2
    EightByteInteger        = 3
    FourByteUnsignedInteger = 4
    Float                   = 5
    FixedSizeString         = 6

class SignalInfo(object):
    '''Generic DAT file signal information structure.

    See "StreamingDataReader.py".
    '''
    def __init__(self):
        '''Constructor.
        
        Initializes the class attributes.
        '''
        # Data from the file header as described by the datv2 format
        # description (TCE document D00220427) made available to the user.
        self.id        = 0                 # datv2 Id element
        self.name      = ''                 # datv2 Name element
        self.unit      = ''                 # datv2 Unit element
        self.type      = ''                 # datv2 DataType element
        self.data_type = DataType.Undefined # "DataType"

class ColumnDescription(object):
    '''Generic DAT file column description structure.
    
    Data needed for parsing, hidden to the user.  See "StreamingDataReader.py".
    '''

    def __init__(self):
        '''Constructor.
        
        Initializes the class attributes
        '''
        # Column description data needed for parsing (includes the
        # ColumnDescriptionList data as described by the datv2 format
        # description (TCE document D00220427).
        self.column_id     = [] # datv2 ColumnId element
        self.column_type   = [] # datv2 ColumnType (see "ColumnType.py")
        self.column_size   = [] # datv2 ColumnSize element
        self.column_offset = [] # Offsets from start of record in bytes
                                # (start of data for column-major order)
        self.column_name   = [] # Signal names
        self.column_data   = [] # Signal data types (see "DataType.py")

class HeaderInfo(object):
    '''Generic DAT file header structure.
    
    The properties are to be made available as getter methods.
    See "StreamingDataReader.py".
    '''
    def __init__(self):
        '''Constructor.

        Initializes the class attributes
        '''
        # Data from the file header as described by the datv2 format
        # description (TCE document D00220427) made available to the user.
        self.category_list           = []   # datv2 CategoryList element
        self.comment                 = []   # datv2 Comment element
        self.create_time             = ''   # datv2 CreateTime element
        self.created_by              = ''   # datv2 CreatedBy element
        self.document_id             = ''   # datv2 DocumentId element
        self.document_type           = ''   # datv2 DocumentType element
        self.document_type_version   = ''   # datv2 DocumentTypeVersion element
        self.machine_customer_name   = ''   # datv2 CustomerName element
        self.machine_host_delta_time = 0   # datv2 MachineHostDeltaTime element
        self.machine_id              = ''   # datv2 MachineId element
        self.machine_type            = ''   # datv2 MachineType element
        self.signals                 = {}   # datv2 Signal element (see also
                                            # D000259300)
        self.software_release        = ''   # datv2 SoftwareRelease element
        self.title                   = ''   # datv2 Title element
        self.type                    = ''   # datv2 Type element

        # Additional data to be made available to the user
        self.filename    = ''       # Input file name (without the .gz 
                                    # extension)
        self.metafile    = ''       # DATv1 metadata name used to parse the
                                    # input file
        self.metaversion = 0       # DATv1 metadata version used to parse the
                                    # input file
        self.start_time  = [0, 0] # Timestamp (s, ns) of the first sample
        self.end_time    = [0, 0] # Timestamp (s, ns) of the last sample

class ParseInfo(ColumnDescription):
    '''Generic DAT file parse information structure.
    
    Data needed for parsing, hidden to the user.
    See "StreamingDataReader.py".
    '''

    def __init__(self):
        '''Constructor.
        
        Initializes the class attributes
        '''
        ColumnDescription.__init__(self)

        # Data from the file header as described by the datv2 format
        # description (TCE document D00220427) needed for parsing.
        self.byte_order              = ''   # Either '<' for little or '>' for 
                                                # big endian
        self.binary_block_order      = ''   # 'column-major' or 'row-major'
        self.time_stamps_provided    = True # 'True' if provided, else 'False'
        self.initial_time            = 0   # datv2 InitialTime
        self.initial_fractional_time = 0   # datv2 InitialFractionalTime
        self.delta_time              = 0   # datv2 DeltaTime
        self.delta_fractional_time   = 0   # datv2 DeltaFractionalTime

class FileInfo(HeaderInfo, ParseInfo):
    '''Generic DAT file information structure.
    
    Combined "HeaderInfo" and "ParseInfo" structure.
    See "StreamingDataReader.py".
    '''
    def __init__(self):
        '''Constructor.
        
        Initializes the class attributes
        '''
        HeaderInfo.__init__(self)
        ParseInfo.__init__(self)

        # Additional derived attributes useful for parsing
        self.aggregate_delta_time = 0      # Aggregate delta time in ns
        self.aggregate_end_time   = 0      # Aggregate end time in ns
        self.aggregate_start_time = 0      # Aggregate start time in ns
        self.data_offset          = 0      # First record file offset in bytes
        self.file                 = None    # File object
        self.file_size            = 0      # File size in bytes
        self.n_records            = 0      # Number of records in the file
        self.record_size          = 0      # Record size in bytes
        self.sequence_start       = 0      # Starting sequence number (if no timestamps)
        self.temporary            = False   # Flag indicating if file needs to
                                            # be deleted during destruction

class parser_datv2(object):
    def __init__(self, file_handler, logger):
        self.fid = file_handler
        self.logger = logger
        self.order = 'C'
        self.DataTypes = {2: 'i4', 4: 'u4', 5: 'f4', 6:'|S'}
        self.contains_text = False
        self.parse_header()

    def parse_header(self):
        fid = self.fid      # open(self.FullFileName, 'rb')
        # LCHD = fid.read(4)
        # version = unpack('LL', fid.read(8))
        headersize, = unpack('<L', fid.read(4))
        self.offset = 4 + 8 + 4 + headersize
        adel_string = fid.read(headersize)
        root = xml_fromstring(adel_string)
        
        header = root.findall('Header')[0]
        description = root.findall('DataSectionDescription')[0]
        info = self.parse_header_elements(header)
        info.signals = {}
        info = self.parse_descr_elements(info, description)
        if info.binary_block_order == 'column-major':
                self.order = 'F'
            # raise ValueError('Only dat v2 files in column major order are supported')
        self.dtype = [('Sequence', 'u4'), ('TIMESTAMP', 'M8[ns]')]
        cols = len(info.column_name)
        rows = info.n_records
        self.shape = (rows, cols)
        init_columns = [('Sequence', 'none'), ('time', 's'), ('fractionalTime', 'ns')]
        self.actual_metadata = {}
        column = 0
        for FieldName, Units in init_columns:
            self.actual_metadata[FieldName] = {}
            self.actual_metadata[FieldName]['Column'] = column
            self.actual_metadata[FieldName]['Units'] = Units
            self.actual_metadata[FieldName]['DataType'] = 'u4'
            column += 1
        for i, id in enumerate(info.column_id):
            # if id != 0: # newest forward
            FieldName = info.column_name[i]
            if FieldName == '': continue # first  starting columns
            if info.column_data[i] == 6:
                DataType = 'S' + str(info.column_size[i])
                self.contains_text = True
            else:
                DataType = self.DataTypes[info.column_data[i]]
            self.actual_metadata[FieldName] = {}
            self.actual_metadata[FieldName]['FieldID'] = info.signals[FieldName][0]
            self.actual_metadata[FieldName]['Units'] = info.signals[FieldName][1]
            self.actual_metadata[FieldName]['DataType'] = DataType
            self.actual_metadata[FieldName]['RecordType'] = ''
            self.actual_metadata[FieldName]['Column'] = column
            self.dtype += [(FieldName, DataType)]
            column += 1

    def parse_header_elements(self, header):
        class info(): pass
        
        elements = list(header)
        for element in elements:
            name = element.tag
            if name == 'MachineHostDeltaTime':
                time = self._get_node_text(element)
                try:
                    info.machine_host_delta_time = int(time)
                except Exception:
                    info.machine_host_delta_time = 0
            elif name == 'Comment':
                children = element.findall('elt')
                info.comment = [''] * len(children)
                for i in range(len(children)):
                    info.comment[i] = self._get_node_text(children[i])
            elif name == 'CategoryList':
                children = element.findall('elt')
                info.category_list = [''] * len(children)
                for i in range(len(children)):
                    info.category_list[i] = self._get_node_text(children[i])
            else:
                setattr(info, name, self._get_node_text(element)) 
        return info

    def parse_descr_elements(self, info, node):
        '''Parses the datv2 "DataSectionDescription"
        
        Returns an instance of the "FileInfo" class
        
        Keyword arguments:
        info -- Instance of the "FileInfo" class
        node -- XML node (xml.etree.ElementTree.Element)
        
        Postconditions:
        - "FileInfo" "byte_order", "binary_block_order", "n_records", (for
          column-major order files), "signals", "type", and 
          "time_stamps_provided" are defined (either explicit or the default
          values)
        - Endianness is correct, if present
        - Postconditions of PARSE_COLUMN_DESCRIPTION_LIST
        - Postconditions of PARSE_TIME_STAMP_INFORMATION
        '''
        elements = list(node)

        for element in elements:
            name = element.tag
            if name == 'ByteOrder':
                byte_order = self._get_node_text(element)
                if byte_order == 'Big endian':
                    info.byte_order = '>'
                elif byte_order == 'Little endian':
                    info.byte_order = '<'
                else:
                    raise ValueError('Invalid endianness')
            elif name == 'BinaryBlockOrder':
                binary_block_order = self._get_node_text(element)
                if binary_block_order == 'Row major order':
                    info.binary_block_order = 'row-major'
                elif binary_block_order == 'Column major order':
                    info.binary_block_order = 'column-major'
                else:
                    raise ValueError('Invalid binary block order')
            elif name == 'NumberOfSamples':
                n_samples = self._get_node_text(element)
                try:
                    info.n_records = int(n_samples)
                except Exception:
                    info.n_records = 0
            elif name == 'Type':
                info.type = self._get_node_text(element)
            elif name == 'SampleTimeStampsProvided':
                time_stamps_provided = self._get_node_text(element)
                if time_stamps_provided == 'Timestamps provided':
                    info.time_stamps_provided = True
                elif time_stamps_provided == 'Timestamps not provided':
                    info.time_stamps_provided = False
                else:
                    raise ValueError(
                        'Invalid value for "SampleTimeStampsProvided": %s' %
                        time_stamps_provided)
            elif name == 'TimeStampInformation':
                info = self._parse_time_stamp_information(info, element)
            elif name == 'ColumnDescriptionList':
                info = self._parse_column_description_list(info, element)
            else:
                self.logger.warning('Unsupported header tag "%s" is ignored' % name)

        return info

    def _parse_column_type(self, text):
        '''Parse the column type from text.
        
        Returns the "ColumnType"
        
        Keyword arguments:
        text -- String from the XML node
        '''
        column_type = ColumnType.Ignore

        if text == 'Ignore':
            column_type = ColumnType.Ignore
        elif text == 'Sequence number':
            column_type = ColumnType.SequenceNumber
        elif text == 'Time':
            column_type = ColumnType.Time
        elif text == 'FractionalTime':
            column_type = ColumnType.FractionalTime
        elif text == 'SignalValue':
            column_type = ColumnType.SignalValue
        else:
            self.logger.warning('Unsupported "ColumnType" tag "%s" is ignored' % text)

        return column_type

        
    def _parse_column_description_list(self, info, node):
        '''Parse the datv2 "ColumnDescriptionList"
        
        Returns an instance of the "FileInfo" class
        
        Keyword arguments:
        info -- Instance of the "FileInfo" class
        node -- XML node (xml.etree.ElementTree.Element)
        
        Postconditions:
        - All "ColumnDescription" data is defined
        - "FileInfo" "signals" is defined
        - Column sizes are integer multiples of 4 bytes
        '''
        elements = node.findall('elt')
        
        # Fill the column structure
        n_columns = len(elements)
        info.column_id = [0] * (n_columns)
        info.column_type = [ColumnType.Ignore] * (n_columns)
        info.column_size = [0] * (n_columns)
        info.column_offset = [0] * (n_columns)
        info.column_name = [''] * (n_columns)
        info.column_data = [DataType.Undefined] * (n_columns)
        
        # Loop over all nodes
        for i in range(n_columns):
            column_number = n_columns;
            column_type = ColumnType.Ignore
            column_size = 0
            signal = SignalInfo()

            element = elements[i]
            children = list(element)
            # Loop over all column descriptors
            for child in children:
                name = child.tag
                if name == 'ColumnNumber':
                    number = self._get_node_text(child)
                    try:
                        column_number = int(number)
                    except Exception:
                        column_number = 0
                elif name == 'ColumnType':
                    text = self._get_node_text(child)
                    column_type = self._parse_column_type(text)
                elif name == 'ColumnSize':
                    text = self._get_node_text(child)
                    try:
                        column_size = int(text)
                    except Exception:
                        column_size = 0
                    if column_size % 4 != 0:
                        raise ValueError(
                            'Column size should be a multiple of 4 bytes')
                elif name == 'Signal':
                    signal = self._parse_signal(child, signal)
                else:
                    self.logger.warning('Unsupported header tag "%s" is ignored' % name)

            # Update the "ColumnDescription" data
            if not column_number in range(n_columns):
                raise ValueError(
                    '"ColumnNumber" %d exceeds number of columns %d' %
                    (column_number, n_columns - 1))

            info = self._update_column_description_list(info,
                column_number, column_type, column_size, signal)

        # Calculate offsets
        for i in range(n_columns)[1:]:
            info.column_offset[i] = \
                info.column_offset[i - 1] + info.column_size[i - 1]

        return info

    def _parse_signal(self, node, signal):
        '''Parses a datv2 "Signal" descriptor.
        
        Returns an instance of the "SignalInfo" class
        
        Keyword arguments:
        node   -- XML node (xml.etree.ElementTree.Element)
        signal -- Instance of the "SignalInfo" class
        '''
        elements = list(node)
        for element in elements:
            name = element.tag            
            if name == 'Id':
                text = self._get_node_text(element)
                try:
                    signal.id = int(text)
                except Exception:
                    signal.id = 0
            elif name == 'Name':
                signal.name = self._get_node_text(element)
                # logging.info(signal.name + signal.id)
            elif name == 'Unit':
                signal.unit = self._get_node_text(element)
            elif name == 'DataType':
                signal.type = self._get_node_text(element)
                if signal.type == '4 byte integer':
                    signal.data_type = DataType.FourByteInteger
                elif signal.type == '8 byte integer':
                    signal.data_type = DataType.EightByteInteger
                elif signal.type == '4 byte unsigned integer':
                    signal.data_type = DataType.FourByteUnsignedInteger
                elif signal.type == 'Float':
                    signal.data_type = DataType.Float
                elif signal.type == 'Fixed size string':
                    signal.data_type = DataType.FixedSizeString
                else:
                    self.logger.warning('Unsupported data type is ignored: %s' % signal.type)
            else:
                self.logger.warning('Unsupported header tag "%s" is ignored' % name)

        return signal
        
        
    def _get_node_text(self, node):
        '''Get the text data from an XML text node.
        
        Returns the text contained by the node (string), or empty string
        
        Keyword arguments:
        node -- XML node (xml.etree.ElementTree.Element)
        '''
        text = ''
        if len(list(node)) == 0:
            text = node.text
        else:
            raise ValueError('XML node "%s" should not have child nodes' %
                node.tag)
        if text == None:
            text = ''

        return text

    def contains(self):
        return [name for name, dtype in self.dtype]

    def metadata(self):
        return self.actual_metadata

    def get(self, FieldName = None):
        return self.get_basic(FieldName)

    def get_basic(self, FieldName = None):
        fid = self.fid # self.fidGet() #for zip? fid.seek(0)  # added by PKVB
        NotEpoch = True
        if self.order == 'C':
            data = fromstring(fid.read(), dtype=self.dtype)
        elif self.order == 'F' and not self.contains_text:
            data = fromstring(fid.read(), dtype='u4')
            columns = self.shape[1] # 1 + len(self.dtype)
            rows = self.shape[0] # data.size/columns
            data = fromstring(data.reshape((columns, rows)).tostring('F'), dtype=self.dtype)
        else:
            data = {}
            rows = self.shape[0] # data.size/columns
            for name, dtype_ in self.dtype:
                if name == 'TIMESTAMP': # in seconds past epoch
                    # data[name] = fromstring(fid.read(4*rows), dtype='u4', count=rows).astype('f8') + 1e-9 * fromstring(fid.read(4*rows), dtype='u4', count=rows)
                    # data[name] = num2epoch(fromstring(fid.read(4 * rows), dtype='u4', count=rows).astype('f8') + 1e-9 * fromstring(
                    #         fid.read(4 * rows), dtype='u4', count=rows))
                    data['TIMESTAMP'] = fromstring(fid.read(4 * rows), dtype='u4', count=rows).astype('datetime64[s]') + \
                                        fromstring(fid.read(4 * rows), dtype='u4', count=rows).astype('timedelta64[ns]')
                    NotEpoch = False
                # elif not FieldName or name in FieldName:
                elif dtype_.startswith('S'):
                    nr_bytes = int(dtype_[1:])
                    if nr_bytes>0:
                        data[name] = fromstring(fid.read(nr_bytes * rows), dtype=dtype_, count=rows)
                else:
                    data[name] = fromstring(fid.read(4*rows), dtype=dtype_, count=rows)

        # # convert TIMESTAMP
        if dict(self.dtype)['TIMESTAMP'] == 'M8[ns]' and NotEpoch:
            data['TIMESTAMP'] = (data['TIMESTAMP'].astype('u8') & 2 ** 32 - 1).astype('datetime64[s]') + (
            data['TIMESTAMP'].astype('u8') >> 32).astype('timedelta64[ns]')
        elif dict(self.dtype)['TIMESTAMP'] == 'f8' and NotEpoch:
            data['TIMESTAMP'] = epoch2num((data['TIMESTAMP'].view('u8') & 2 ** 32 - 1).astype('f8') + (
            data['TIMESTAMP'].view('u8') >> 32).astype('f8') * 1e-9)
        return data

    def _update_column_description_list(
        self, info, column_number, column_type, column_size, signal):
        '''Update column description list.
        
        Returns an instance of the "FileInfo" class
        
        Keyword arguments:
        info          -- Instance of the "FileInfo" class
        column_number -- datv2 ColumnNumber element
        column_type   -- datv2 ColumnType element
        column_size   -- datv2 ColumnSize element
        signal        -- Instance of the "SignalInfo" class
        '''
        # Update the "signals" structure
        if column_type == ColumnType.SignalValue:
            if signal.data_type != DataType.Undefined:
                if signal.name == '':
                    raise ValueError('Signal has no name')
                info.signals[signal.name] = \
                    [signal.id, signal.unit, signal.type]

        # Update the "ColumnDescription" class
        if not info.column_name[column_number] == '':
            raise ValueError('Duplicate assignment for "ColumnNumber" %d' %
                column_number)

        info.column_id[column_number] = signal.id
        info.column_type[column_number] = column_type
        info.column_size[column_number] = column_size
        info.column_name[column_number] = signal.name
        info.column_data[column_number] = signal.data_type

        return info


def isstr(name):
    return isinstance(name, str) or isinstance(name, str)


def datv2(file_handle, signal_list, logger):
    p = parser_datv2(file_handle, logger)
    data = pd.DataFrame(p.get())
    data.set_index(['TIMESTAMP'],inplace=True)
    if signal_list:
        signals = [signal for signal in data.columns if signal in signal_list]
        data = data[signals]
    yield data

