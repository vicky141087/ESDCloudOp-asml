# This Python file uses encoding: utf-8

import os.path
import ast


def _check_boolean(x: str):
    """
    Return whether a string is True or False, since bool('False') normally returns True irrespective of the string
    contents.

    Since bool('False') will return True (non-empty string), use ast.literal_eval
    However since ast.literal_eval('false') will raise an exception, use 'false'.title()

    :param x: Input string
    :type x: string
    :return: Boolean based on x
    :rtype: boolean
    """
    return ast.literal_eval(x.title())


FORMATTERS = {'INT': int, 'DOUBLE': float, 'TEXT': str, 'BOOL': _check_boolean}
ALLOW_ERRORS_IN_TGS = True  # Will continue even if some errors in the TGS structure are present


def format_tag(return_type: str, value):
    """
    Format TGS tags as the type defined in the TGS. If ALLOW_ERRORS_IN_TGS==True then if the type does not fit the
    data no Exception is raised.

    :param return_type: Define the return type for the formatting
    :type return_type: str
    :param value: Value to be formatted
    :return: Formatted value with specified type
    """
    try:
        return FORMATTERS[return_type](value)
    except ValueError:
        print(f'ValueError raised for converting "{value}" to type "{return_type}"' +
              ", will return unformatted value" if ALLOW_ERRORS_IN_TGS else "")
        if ALLOW_ERRORS_IN_TGS:
            # print('Will return unformatted value')
            return value
        else:
            return FORMATTERS[return_type](value)


def parse_TGS_file(filename: str, sep: str='|', value_if_empty=None):
    """
    Parses a single TGS file and returns the contents as a dictionary. Since TGS files contain many tags that have
    wildly different structures/sizes, returning a dataframe is not preferred.

    Tag types supported: TEXT, BOOL, DOUBLE, INT
    All tags with the prefix 'COL_' are also supported, and parse as a column of values

    If the types are defined wrong in the TGS, this will not be fixed. However if the global variable
    ALLOW_ERRORS_IN_TGS is set to True (default setting), for some errors the script will continue.

    :param filename: Filename of TGS
    :type filename: str
    :param sep: Seperator, defaults to '|'
    :type sep: str
    :param value_if_empty: Value to return is tag is empty, defaults to None
    :return: dictionary with tags/data as key:value. Values are either direct (text/booleans) or in a dictionary with
        keys 'unit' and 'value'.
    :rtype: dictionary
    """
    [folder, fname] = os.path.split(filename)
    contents = {'folder': folder, 'filename': fname}
    file_version = '0.0.0'  # init value

    with open(filename, 'r') as f:
        for i, line_as_str in enumerate(f):
            line = line_as_str.split(sep)
            key = line[0]
            valuetype = line[1]

            # Always strip leading whitespace and newline characters
            line[-1] = line[-1].strip(' \n')

            # If valuetyple starts with "COL_" then the order is always the same, including unit
            if 'COL_' in valuetype:
                values_specified = int(line[2])
                values_found = len(line[4:])

                if values_found != values_specified:
                    # Put a dummy unit for COL_TEXT and file_version 0.0.1 and higher and continue
                    if valuetype == 'COL_TEXT' and file_version > '0.0.0' and values_found - values_specified == 1:
                        line.insert(3, '')
                    else:  # Warning, but do not raise an error in other cases
                        print(f'Warning for line #{i} - "{key}",',
                              f'specified length of line does not match number of values found',
                              f'({values_found} / {values_specified}):\n{line_as_str}')

                values = [format_tag(valuetype.replace('COL_', ''), x) if x else value_if_empty for x in line[4:]]
                contents[key] = {'unit': line[3], 'value': values}

            # TEXT and BOOL do not have unit on the third position
            elif valuetype in ['TEXT', 'BOOL']:
                contents[key] = format_tag(valuetype, line[2]) if line[2] else value_if_empty

            # INT and DOUBLE do have unit on the third position
            elif valuetype in ['INT', 'DOUBLE'] and len(line) == 4:
                contents[key] = {'unit': line[2], 'value': format_tag(
                    valuetype, line[3]) if line[3] else value_if_empty}
            elif ALLOW_ERRORS_IN_TGS and valuetype in ['INT', 'DOUBLE'] and len(line) == 3:
                print(f'Warning for line #{i} - "{line_as_str}", expected 4 items: [tag, type, unit, value],',
                      f'only 3 found, will assume unit is missing')
                contents[key] = {'unit': None, 'value': format_tag(valuetype, line[2]) if line[2] else value_if_empty}

            # Other tags not recognized, give error
            else:
                raise ValueError(f'Tag value not recognized, please extend the parse_TGS_file function.',
                                 f'Error from line #{i + 1}: {line_as_str}')

            if 'FILE_VERSION' in key:  # Typically this is the second value of a TGS file
                file_version = '.'.join(str(x) for x in values)

    return contents
