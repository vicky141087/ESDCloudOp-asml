# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: Rob Wieggers (RWKL)
@ownership: FC-071

Based on code from CDL EUVDB
"""

from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.RT_Processing.simple_rt import SimpleRT


class RT25(SimpleRT):
    def __init__(self):
        self.name = 'RT25'
        super(RT25, self).__init__(self.name)

    @staticmethod
    def process_signals(df, verbose=False):
        """
        Calculate KPI Rejected / Leakage Ratio's (for TGOQ). Also see post_process_LSP

        :param df: input dataframe containing raw RT22 data
        :param verbose: switches debug mode (default=False)
        :return: dataframe df, including additional columns of derived data
        """

        do_it.do_it_verbose(currentframe(), verbose)

        try:
            df['_MPRejectedLeakageRatioPEM'] = df.BDrejectedMpEnergyMeanOn / df.BDleakageMpEnergyMeanOn
            df['_PPRejectedLeakageRatioPEM'] = df.BDrejectedPpEnergyMeanOn / df.BDleakagePpEnergyMeanOn
            df['_PPMPLeakageRatioPEM'] = df.BDleakagePpEnergyMeanOn / df.BDleakageMpEnergyMeanOn
            df['_PPMPRejectedRatioPEM'] = df.BDrejectedPpEnergyMeanOn / df.BDrejectedMpEnergyMeanOn
        except Exception as e:
            print('Warning: processing RT25 failed:', e)

        return df
