# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: Rob Wieggers (RWKL)
@ownership: FC-078

Based on code from CDL EUVDB

*Example usage*
::

    import pandas as pd
    import pyeuv.RT_Processing.rt05 as rt05
    from pyeuv.EUVDashboard.clients import UserLANClient

    client = UserLANClient()
    source_id = 's62265'

    RT = rt05.RT05()
    rt_config = RT.get_signal_config()
    input_signals = rt_config['SCHEMA_PROCESSING_SIGNALS']
    output_signals = rt_config['SCHEMA_PROCESSED_SIGNALS']

    # get data from influx
    signals_dict = dict()
    for signal in input_signals.keys():
        signals_dict[signal] = '{}.{}'.format(RT.signal_group, signal)
    df = client.get_signals_dict(signals_dict, source_id, pd.Timestamp(2019,12,2,10,0,0), pd.Timestamp(2019,12,2,11,0,0))

    # process data
    df_cleaned = RT.clean_signals(df, rt_config)
    df_out = RT.process_signals(df_cleaned)
    df_out = df_out[output_signals]

"""

import numpy as np
import pandas as pd


from pyeuv.Shared import pandas_helpers
from pyeuv.RT_Processing.simple_rt import SimpleRT
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it


class RT05(SimpleRT):
    def __init__(self):
        self.name = 'RT05'
        super(RT05, self).__init__(self.name)

    @staticmethod
    def process_signals(df, verbose=False):
        """
        Calculate derived data for rt05

        :param df: input dataframe containing raw RT05 data
        :param verbose: switches debug mode (default=False)
        :return: dataframe df, including additional columns of derived data
        """

        do_it.do_it_verbose(currentframe(), verbose)

        try:
            end_time = pd.to_timedelta(df['BDbeginTime'].index.tz_localize(None).to_series()).\
                apply(lambda x: x.total_seconds())
            start_time = df['BDbeginTime'] + 1.0e-9 * df['BDbeginNSecs']
            duration = end_time - start_time
            df['_BurstDuration'] = duration

            df['_ExposureGateEUV_On'] = np.where(df.BDenergyAvg > .2, True, False)
            df['_ExposureGateEUV_Off'] = np.where(df.BDenergyAvg > .2, False, True)
            df['_EUVBurstEnergy'] = 1.0e-3 * df.BDenergyAvg * df.BDpulseCount
            df['_DoseMargin'] = 100.0 * (1 - (df.BDenergyAvg / df.BDenergyAvgOn))
            df['_EnergyCalibrationCheck'] = df.BDenergyAvgOn / df.BDenergyInternalAvgOn
            df['_DutyCycle'] = 100.0 * df.BDpulseCount / df.BDrepRateAvgMean / df._BurstDuration
            df['_OldEUVPower'] = 1.0e-3 * df.BDenergyAvg * df.BDpulseCount / df._BurstDuration
            df['_EUVPower'] = 5.0 * df.BDenergyTargetAvg * df._DutyCycle / 100.0
            df['_EffectiveEUVDutyCycle'] = df._DutyCycle * (1.0 - (df._DoseMargin / 100.0)) * (
                    df.BDburstLength / (df.BDburstLength + df.BDinterBurstInterval))
            df['_EUVPowerIncludingBurstIdleTimes'] = df._EUVPower * df._BurstDuration / (
                    df.BDinterBurstInterval + df._BurstDuration)
        except Exception as e:
            print('Warning: processing RT05 failed:', e)

        return df


    @staticmethod
    def aggregate_signals(pdf, timestamp):
        """
        Calculate aggregated signals.
        The signals are:
        - 'EUVEnergy_SourceInternal',
        - 'EUVPower_SourceInternal',
        - 'CrossingInterval_3sigma'

        :param pdf: dataframe including processed/derived signals
        :param timestamp: timestamp for which aggregation is calculated
        :return: dataframe with aggregated data
        """
        aggregation_signals = ['EUVEnergy_SourceInternal', 'EUVPower_SourceInternal', 'CrossingInterval_3sigma']
        df_aggregate = pd.DataFrame(columns=aggregation_signals, index=[timestamp])

        # BDenergyAvgOn
        signal = "BDenergyAvgOn"
        aggregation_name = "EUVEnergy_SourceInternal"
        df_aggregate[aggregation_name] = pandas_helpers.max_hist(
            pdf[signal][(pdf[signal] > 0) & (pdf[signal] < 20)])

        # _EUVPower
        signal = "_EUVPower"
        aggregation_name = "EUVPower_SourceInternal"
        df_aggregate[aggregation_name] = pandas_helpers.max_hist(
            pdf[signal][(pdf[signal] > 0) & (pdf[signal] < 1000)])

        # BDcrossingIntervalStdOn
        signal = "BDcrossingIntervalStdOn"
        aggregation_name = "CrossingInterval_3sigma"
        df_aggregate[aggregation_name] = 3 * pandas_helpers.max_hist(
            pdf[signal][(pdf[signal] >= 0) & (pdf[signal] < 10)])

        return df_aggregate

