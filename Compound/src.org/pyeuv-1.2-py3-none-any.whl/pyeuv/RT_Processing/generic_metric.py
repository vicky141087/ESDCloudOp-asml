import json
import os
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it


class GenericMetric:
    def __init__(self, name):
        """
        Initialize the metric.
        The common items to initialize for each metric are:
        - the name
        - the configuration (input/output signals, signal group of the output signal

        :param name: the name of the metric
        """

        self.name = name

    def load_configuration(self, filename,
                           base_config_path,
                           verbose=False):
        """
        Loads the configuration file. The configuration file is a json file.

        :param base_config_path: base path for config file
        :param filename: filename of the configuration file
        :param verbose: switches debug mode (default=False)
        :return: json data
        """

        do_it.do_it_verbose(currentframe(), verbose)

        json_file = os.path.join(base_config_path, 'config', filename)
        try:
            with open(json_file, 'r') as fp:
                try:
                    json_data = json.load(fp)
                except Exception as e:
                    raise e
        except Exception as e:
            raise Exception(e)

        return json_data
