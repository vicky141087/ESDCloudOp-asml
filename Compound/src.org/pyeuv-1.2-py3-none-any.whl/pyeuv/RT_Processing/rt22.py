# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: Rob Wieggers (RWKL)
@ownership: FC-072

Based on code from CDL EUVDB
"""


import numpy as np
import pandas as pd

from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.RT_Processing.simple_rt import SimpleRT


class RT22(SimpleRT):
    def __init__(self):
        self.name = 'RT22'
        super(RT22, self).__init__(self.name)

    @staticmethod
    def process_signals(df, apply_resampling=True, verbose=False):
        """
        Calculate KPI Rejected / Leakage Ratio's (for TGOQ). Also see post_process_LSP
        By default it resamples the data to 1Hz, as used for influx. In this case it calculates the
        mean for all the columns.

        :param df: input dataframe containing raw RT22 data
        :param apply_resampling: switches resampling to 1 Hz on or off (default=True)
        :param verbose: switches debug mode (default=False)
        :return: dataframe df, including additional columns of derived data
        """

        do_it.do_it_verbose(currentframe(), verbose)

        # Filter on validity of PP FF
        msk = "FFA_LD_SI_FC_FBD_PP_FF_CAM__OT_SI_CAM_FBD_PP_FF_VALID_OUT"
        try:
            df["FFA_LD_MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT1"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT2"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Filter on validity of RBD
        msk = "FFA_LD_SI_FC_RBD_CAM__OT_SI_CAM_RBD_VALID_OUT"
        try:
            df["FFA_LD_MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT1"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT2"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT3"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Filter on validity of PP WFS
        msk = "FFA_LD_SI_FC_WF_PP_CAM__OT_SI_CAM_WF_PP_VALID_OUT"
        try:
            df["FFA_LD_MS_FC_WAVEFR_CAM__OT_MAT_2X2_FLT_OUT2"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_5_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_6_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_7_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_8_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_9_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_10_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_11_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_12_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_13_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_14_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_15_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_16_PP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_PP_CAM__OT_SI_CAM_WF_PP_OUT_X"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_PP_CAM__OT_SI_CAM_WF_PP_OUT_Y"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Filter on validity of MP WFS
        msk = "FFA_LD_SI_FC_WF_MP_CAM__OT_SI_CAM_WF_MP_VALID_OUT"
        try:
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_5_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_6_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_7_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_8_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_9_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_10_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_11_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_12_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_13_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_14_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_15_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_16_MP"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_MP_CAM__OT_SI_CAM_WF_MP_OUT_X"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_WF_MP_CAM__OT_SI_CAM_WF_MP_OUT_Y"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Filter on validity of MP FF
        msk = "FFA_LD_SI_FC_FBD_MP_FF_CAM__OT_SI_CAM_FBD_MP_FF_VALID_OUT"
        try:
            df["FFA_LD_MS_FC_FBD_MP_FF_CAM__OT_MAT_2X2_FLT_OUT1"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_FC_FBD_MP_FF_CAM__OT_MAT_2X2_FLT_OUT2"][df[msk] == 0] = np.NaN
            df['_MP2PP_dx'] = df["FFA_LD_MS_FC_FBD_MP_FF_CAM__OT_MAT_2X2_FLT_OUT1"] - df[
                "FFA_LD_MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT1"]
            df['_MP2PP_dy'] = df["FFA_LD_MS_FC_FBD_MP_FF_CAM__OT_MAT_2X2_FLT_OUT2"] - df[
                "FFA_LD_MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT2"]
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Filter on validity of MP NF
        msk = "FFA_LD_SI_FC_FBD_MP_NF_CAM__OT_SI_CAM_FBD_MP_NF_VALID_OUT"
        try:
            df["FFA_LD_SI_FC_FBD_MP_NF_CAM__OT_SI_CAM_FBD_MP_NF_OUT_X"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_FBD_MP_NF_CAM__OT_SI_CAM_FBD_MP_NF_OUT_Y"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_FBD_CAM_BUF__OT_SI_CAM_FBD_BUF_MSG_RSLT1_DIAMETER"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_FBD_CAM_BUF__OT_SI_CAM_FBD_BUF_MSG_RSLT1_D4S_LONG"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_FBD_CAM_BUF__OT_SI_CAM_FBD_BUF_MSG_RSLT1_D4S_SHORT"][df[msk] == 0] = np.NaN
            df["FFA_LD_SI_FC_FBD_CAM_BUF__OT_SI_CAM_FBD_BUF_MSG_RSLT1_D4S_ANGLE"][df[msk] == 0] = np.NaN
            df["_MPNF_ellipticity"] = df["FFA_LD_SI_FC_FBD_CAM_BUF__OT_SI_CAM_FBD_BUF_MSG_RSLT1_D4S_SHORT"] / df[
                "FFA_LD_SI_FC_FBD_CAM_BUF__OT_SI_CAM_FBD_BUF_MSG_RSLT1_D4S_LONG"]
            df["_MPNF_ellipticity"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Filter on validity of MP diameter measured on the WFS
        msk = "FFA_LD_SI_FC_WF_MP_CAM__OT_SI_CAM_WF_MP_VALID_OUT"
        try:
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_BEAM_DIAMETER_MP"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Filter on validity of PP diameter measured on the WFS
        msk = "FFA_LD_SI_FC_WF_PP_CAM__OT_SI_CAM_WF_PP_VALID_OUT"
        try:
            df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_BEAM_DIAMETER_PP"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        # Calc signals
        msk = "FFA_LD_SI_FC_RBD_CAM__OT_SI_CAM_RBD_VALID_OUT"
        try:
            df['_L2D_x'] = df["FFA_LD_MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT1"] - df[
                "FFA_LD_MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT1"]
            df['_L2D_y'] = df["FFA_LD_MS_FC_FBD_PP_FF_CAM__OT_MAT_2X2_FLT_OUT2"] - df[
                "FFA_LD_MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT2"]
            df["_L2D_x"][df[msk] == 0] = np.NaN
            df["_L2D_y"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        msk = "FFA_LD_SI_FC_RBD_CAM__OT_SI_CAM_RBD_VALID_OUT"
        try:
            df['_L2D_z'] = df["FFA_LD_MS_FC_WAVEFR_CAM__OT_MAT_2X2_FLT_OUT2"] - df[
                "FFA_LD_MS_FC_RBD_CAM__OT_MAT_3X3_FLT_OUT3"]
            df["_L2D_z"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT22 on mask {}.".format(msk), e)

        try:
            fu_diameter, k = 45e-3, 1.4  # 45mm aperture for FU (RBD port size) and mask size factor of 1.4
            df["_ZERNIKE_5_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_5_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_6_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_6_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_7_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_7_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_8_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_8_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_9_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_9_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_10_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_10_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_11_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_11_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_12_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_12_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_13_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_13_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_14_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_14_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_15_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_15_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
            df["_ZERNIKE_16_MP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_16_MP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]) ** 2))
                
            df["_ZERNIKE_5_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_5_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_6_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_6_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_7_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_7_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_8_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_8_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_9_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_9_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_10_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_10_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_11_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_11_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_12_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_12_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_13_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_13_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_14_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_14_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_15_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_15_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
            df["_ZERNIKE_16_PP_RELATIVE_45mm"] = \
                df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_16_PP"] * \
                ((fu_diameter ** 2) / ((k * df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]) ** 2))
                
            del df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_MP"]
            del df["FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_D4SLONGAXIS_PP"]

            if apply_resampling:
                # Re-sample selected signals
                resampled = [key for key in df.keys()
                            if (key.startswith("FFA_LD_SI_FC_FBD_CAM_BUF__OT_SI_CAM_FBD_BUF_MSG_")
                                or key.startswith("FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_ZERNIKE_")
                                or key.startswith("FFA_LD_SI_FC_WF_CAM_BUF__OT_SI_CAM_WF_BUF_MSG_BEAM_DIAMETER_")
                                or key.startswith("_ZERNIKE"))]
                df_resampled = df[resampled]
                df_resampled = df_resampled.resample('1S', how='mean').add_suffix('_mean')

                df = df.drop(resampled, axis=1)
                df = pd.merge(df, df_resampled, how='outer', on='Timestamp')
        except Exception as e:
            if verbose:
                print("Failed processing RT22.", e)

        return df
