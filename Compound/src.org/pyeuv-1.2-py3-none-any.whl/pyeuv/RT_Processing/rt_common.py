import numpy as np


def on_drop_mask(rt2, gate_lag=2):
    """
    Return a mask that can be used to find the on droplet events for CO2 and EUV measurements

    :param rt2:         rt2 dataframe
    :type rt2:          pandas.DataFrame
    :param gate_lag:    lagging of EUV/CO2 measurements on the gate edges
    :type gate_lag:     int

    :return:            bool numpy array that can be used as filter to only select on droplet events
    """

    ondrop = np.roll((rt2['ECmiscellaneousStatus'].values >> 21) & 1, gate_lag).astype('bool')  # bit 21 contains on drop info
    if 'ECshotID' in rt2.columns:
        shotId = rt2['ECshotID'].values
        shotId = shotId - shotId[0]
    else:
        shotId = []
    if len(shotId) > 1:
        if any(np.diff(shotId) > 1):
            EUV_full = np.zeros(shotId[-1] +1)
            EUV_full[:] = np.NaN
            EUV_full[shotId] = rt2['ECeuvValue'].values
            ondrop = ((rt2['ECmiscellaneousStatus'].values >> 21) & 1)
            ondrop_full = -1*np.ones(shotId[-1]+1, dtype=np.int32)
            ondrop_full[shotId] = ondrop
            ondrop_full = np.roll(ondrop_full, gate_lag)

            good_idx = np.where(ondrop_full < 0)[0]
            bad_idx = np.where(np.isnan(EUV_full))[0]

            for i in range(len(good_idx)):
                j = good_idx[i]
                if np.isfinite(EUV_full[j]):
                    if EUV_full[j] > 0.05:
                        ondrop_full[j] = 1
                    else:
                        ondrop_full[j] = 0

                ondrop_full[bad_idx] = -1
            mask = ondrop_full > -1
            ondrop = ondrop_full[mask].astype('bool')

    return ondrop
