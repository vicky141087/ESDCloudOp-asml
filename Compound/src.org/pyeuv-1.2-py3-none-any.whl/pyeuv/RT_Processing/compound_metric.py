import os
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.RT_Processing.generic_metric import GenericMetric


def static_var(varname, value):
    def decorate(func):
        setattr(func, varname, value)
        return func
    return decorate


class CompoundMetric(GenericMetric):
    def __init__(self, name, base_config_path=os.path.dirname(os.path.realpath(__file__))):
        """
        Initialize the metric.
        The common items to initialize for each metric are:
        - the name
        - the configuration (input/output signals, signal group of the output signal

        :param name: the name of the metric
        """
        super(CompoundMetric, self).__init__(name)

        self.configuration = self.get_configuration(base_config_path)
        self.input_signals = self.get_input_signals()
        self.output_signals = self.get_output_signals()
        self.signal_group = self.get_signal_group()

    def get_configuration(self, base_config_path, verbose=False):
        """
        Function that returns a dictionary with required signals per signal group for processing compound metrics

        :param verbose: switches debug mode (default=False)
        :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
        """

        do_it.do_it_verbose(currentframe(), verbose)

        # load full configuration
        try:
            json_data = self.load_configuration('compound_metrics.json', base_config_path)
        except Exception as e:
            print('Failed to read compound metrics configuration:', e)

        signal_config_dict = json_data[self.name]

        return signal_config_dict

    def get_input_signals(self, verbose=False):
        """
        Function that returns a dictionary with required signals per signal group for processing compound metrics

        :param verbose: switches debug mode (default=False)
        :return: dictionary with signal groups as key, and a dictionary with signal names as key and type as value.
        """

        do_it.do_it_verbose(currentframe(), verbose)

        if 'INPUT_GROUPS' in self.configuration:
            input_signals_dict = self.configuration['INPUT_GROUPS']
        else:
            input_signals_dict = dict()
            if verbose:
                print('No input signals in configuration found')

        return input_signals_dict

    def get_output_signals(self, verbose=False):
        """
        Function that returns a list of output signals of a compound metrics

        :param verbose: switches debug mode (default=False)
        :return: dictionary of signal names as key and their type as value
        """

        do_it.do_it_verbose(currentframe(), verbose)

        if 'SCHEMA_PROCESSED_SIGNALS' in self.configuration:
            output_signals_dict = self.configuration['SCHEMA_PROCESSED_SIGNALS']
        else:
            output_signals_dict = dict()
            if verbose:
                print('No input signals in configuration found')

        return output_signals_dict

    def get_signal_group(self, verbose=False):
        """
        This function returns the function group name for this specific compound metric.

        :param verbose: switches debug mode (default=False)
        :return: signal group (string)
        """
        do_it.do_it_verbose(currentframe(), verbose)

        if "SIGNAL_GROUP" in self.configuration:
            signal_group = self.configuration["SIGNAL_GROUP"]
        else:
            if verbose:
                print("No signal group information found in the configuration. Returning empty string")
            signal_group = ""

        return signal_group

    def get_data(self, client, source_id, from_time, to_time, verbose=False):
        """
        Function to get the data required for this metric.
        Based on the configuration, it loads the correct signals from influx (client).
        A dictionary with dataframes of data per signal group is returned

        :param client: connection to data source (influx)
        :param source_id: the source_id for which the signals have to be retrieved
        :param from_time: Lower time limit
        :param to_time: Upper time limit
        :param verbose: switches debug mode (default=False)
        :return: dictionary of dataframes of input data for this metric
        """

        do_it.do_it_verbose(currentframe(), verbose)

        data = dict()
        for signal_group, signals in self.input_signals.items():
            signals_dict = dict()
            for signal in signals:
                signals_dict[signal] = '{}.{}'.format(signal_group, signal)
            data[signal_group] = client.get_signals_dict(signals_dict, source_id, from_time, to_time,
                                                         create_columns=True)
        return data

