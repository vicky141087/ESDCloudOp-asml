import json
import os
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.RT_Processing.generic_metric import GenericMetric
from pyeuv.Shared.pandas_helpers import remove_zeros, clean_transient, clean_convert_numeric, clean_convert_list, \
    clean_convert_list2, clean_convert_boolean, clean_convert_tec_state


class SimpleRT(GenericMetric):
    def __init__(self, name,
                 base_config_path=os.path.dirname(os.path.realpath(__file__)),
                 apply_resampling=False):
        """
        Initialize the metric.
        The common items to initialize for each metric are:
        - the name
        - the configuration (input/output signals, signal group of the output signal

        :param name: the name of the metric
        :param apply_resampling: switch to turn on resampling (which is an option for a few RT groups (default=False).
        """
        super(SimpleRT, self).__init__(name)
        self.apply_resampling = apply_resampling

        self.configuration = self.get_configuration(base_config_path)
        self.input_signals = self.get_input_signals()
        self.output_signals = self.get_output_signals()
        self.signal_group = self.name

    def get_configuration(self, base_config_path, verbose=False):
        """
        Function that returns a dictionary with required RT signals configuration for processing derived data

        This configuration provides information per RT group on:
        - which input signals are required to process the derived metrics
        - which derived metrics are calculated
        - which aggregated derived metrics can be calculated. For instance 1 Hz aggregation, used for influx
        - which signals need some kind of cleaning / interpretation

        :param verbose: switches debug mode (default=False)
        :return: dictionary containing keys used as column names in the data frames, and influx signal names as value.
        """

        do_it.do_it_verbose(currentframe(), verbose)

        # load full configuration
        try:
            json_data = self.load_configuration('signal_groups.json', base_config_path)
        except Exception as e:
            print('Failed to read compound metrics configuration:', e)
        if self.name in json_data:
            signal_config_dict = json_data[self.name]
        else:
            signal_config_dict = dict()

        return signal_config_dict

    def get_input_signals(self, verbose=False):
        """
        This function returns a list of input signals used to process a specific RT group.

        :param rt_config: configuration for a specific RT group
        :param verbose: switches debug mode (default=False)
        :return: dictionary with signal groups as key, and a dictionary with signal names as key and type as value.
        """

        if 'SCHEMA_PROCESSING_SIGNALS' in self.configuration:
            input_signals_dict = dict()
            input_signals_dict[self.name] = self.configuration['SCHEMA_PROCESSING_SIGNALS']
        else:
            input_signals_dict = dict()
            if verbose:
                print("No input signals information found in the configuration. Returning empty list")

        return input_signals_dict

    def get_output_signals(self, verbose=False):
        """
        This function returns a list of output signals expected after process a specific RT group.

        :param rt_config: configuration for a specific RT group
        :param apply_resampling: switch to indicate resampling is used (default=True)
        :param verbose: switches debug mode (default=False)
        :return: dictionary of signal names as key and their type as value
        """

        if self.apply_resampling and 'SCHEMA_RESAMPLED_SIGNALS' in self.configuration:
            output_signals_dict = self.configuration['SCHEMA_RESAMPLED_SIGNALS']
        elif not self.apply_resampling and 'SCHEMA_PROCESSED_SIGNALS' in self.configuration:
            output_signals_dict = self.configuration['SCHEMA_PROCESSED_SIGNALS']
        else:
            output_signals_dict = dict()
            if verbose:
                print("No output signals information found in the configuration. Returning empty list")

        return output_signals_dict

    @staticmethod
    def clean_signals(pdf, config):
        """

        :param pdf:
        :param config:
        :return:
        """
        if 'CLEAN_ZERO_SIGNALS' in config:
            pdf = remove_zeros(pdf, config['CLEAN_ZERO_SIGNALS'])
        if 'CLEAN_TRANSIENT_SIGNALS' in config:
            pdf = clean_transient(pdf, config['CLEAN_TRANSIENT_SIGNALS'])
        if 'CLEAN_CONVERT_NUMERIC' in config:
            pdf = clean_convert_numeric(pdf, config['CLEAN_CONVERT_NUMERIC'])
        if 'CLEAN_CONVERT_LIST' in config:
            pdf = clean_convert_list(pdf, config['CLEAN_CONVERT_LIST'])
        if 'CLEAN_CONVERT_LIST2' in config:
            pdf = clean_convert_list2(pdf, config['CLEAN_CONVERT_LIST2'])
        if 'CLEAN_CONVERT_BOOLEAN' in config:
            pdf = clean_convert_boolean(pdf, config['CLEAN_CONVERT_BOOLEAN'])
        if 'CLEAN_CONVERT_TEC_STATE' in config:
            pdf = clean_convert_tec_state(pdf, config['CLEAN_CONVERT_TEC_STATE'])
        return pdf
