# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: Rob Wieggers (RWKL)
@ownership: FC-078

Based on code from CDL EUVDB
"""


import numpy as np
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.RT_Processing.simple_rt import SimpleRT


class RT35(SimpleRT):
    def __init__(self):
        self.name = 'RT35'
        super(RT35, self).__init__(self.name)

    @staticmethod
    def process_signals(df, verbose=False):
        """
        Calculate derived data for rt35

        :param df: input dataframe containing raw RT35 data
        :param verbose: switches debug mode (default=False)
        :return: dataframe df, including additional columns of derived data
        """

        do_it.do_it_verbose(currentframe(), verbose)


        try:
            df['_BiX'] = float('nan')
            df['_BiY'] = float('nan')
            available_sensors = [1, 2, 4, 5]
            euvp98_max = 0

            # check sensor data is above threshold
            for s_id in available_sensors:
                p = np.percentile(df['BDenergy{0}MeanOn'.format(s_id)], 98)
                if p > euvp98_max:
                    euvp98_max = p

            if euvp98_max < 0.2:
                # data is below threshold, nothing to process
                return df

            # finding active sensors
            active_sensors = set()
            condition = 0.35 * euvp98_max
            for s_id in available_sensors:
                if np.mean(df['BDenergy{0}MeanOn'.format(s_id)]) > condition:
                    active_sensors.add(s_id)

            # create temporary list and parameters for calculation
            ax = [0] * 6
            ay = [0] * 6
            b = [0] * 6

            if active_sensors == {1, 2, 4, 5}:
                ax[1], ax[2], ax[4], ax[5] = -0.266, -0.266, 0.266, 0.266
                ay[1], ay[2], ay[4], ay[5] = 0.731, -0.731, -0.731, 0.731
                b[1], b[2], b[4], b[5] = 0.25, 0.25, 0.25, 0.25

            elif active_sensors == {2, 4, 5}:
                ax[1], ax[2], ax[4], ax[5] = 0, -0.5321, 0.5321, 0
                ay[1], ay[2], ay[4], ay[5] = 0, 0, -1.4619, 1.4619
                b[1], b[2], b[4], b[5] = 0, 0.5, 0, 0.5

            elif active_sensors == {1, 4, 5}:
                ax[1], ax[2], ax[4], ax[5] = -0.5321, 0, 0, 0.5321
                ay[1], ay[2], ay[4], ay[5] = 0, 0, -1.4619, 1.4619
                b[1], b[2], b[4], b[5] = 0.5, 0, 0.5, 0

            elif active_sensors == {1, 2, 5}:
                ax[1], ax[2], ax[4], ax[5] = -0.5321, 0, 0, 0.5321
                ay[1], ay[2], ay[4], ay[5] = 1.4619, -1.4619, 0, 0
                b[1], b[2], b[4], b[5] = 0, 0.5, 0, 0.5

            elif active_sensors == {1, 2, 4}:
                ax[1], ax[2], ax[4], ax[5] = 0, -0.5321, 0.5321, 0
                ay[1], ay[2], ay[4], ay[5] = 1.4619, -1.4619, 0, 0
                b[1], b[2], b[4], b[5] = 0.5, 0, 0.5, 0
            else:
                print("Active sensor {0} not supported by BiY/BiX calculation".format(active_sensors))
                return df

            dx = ax[1] * df['BDenergy1MeanOn'] + ax[2] * df['BDenergy2MeanOn'] + \
                 ax[4] * df['BDenergy4MeanOn'] + ax[5] * df['BDenergy5MeanOn']

            dy = ay[1] * df['BDenergy1MeanOn'] + ay[2] * df['BDenergy2MeanOn'] + \
                 ay[4] * df['BDenergy4MeanOn'] + ay[5] * df['BDenergy5MeanOn']

            bsum = b[1] * df['BDenergy1MeanOn'] + b[2] * df['BDenergy2MeanOn'] + \
                   b[4] * df['BDenergy4MeanOn'] + b[5] * df['BDenergy5MeanOn']

            df['_BiX'] = dx / bsum
            df['_BiY'] = dy / bsum

        except Exception as e:
            print('Warning: processing RT35 failed:', e)

        return df
