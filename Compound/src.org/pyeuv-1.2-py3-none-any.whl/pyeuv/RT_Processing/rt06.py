# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: Rob Wieggers (RWKL)
@ownership: FC-074

Based on code from CDL EUVDB
"""

import pandas as pd
from pyeuv.RT_Processing.simple_rt import SimpleRT
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it


class RT06(SimpleRT):
    def __init__(self):
        self.name = 'RT06'
        super(RT06, self).__init__(self.name)

    @staticmethod
    def process_signals(df, apply_resampling=True, verbose=False):
        """
        Calculate derived data for rt06.
        By default it resamples the data to 1Hz, as used for influx. In this case it calculates the
        min, mean, max, and std for all the columns.
        By setting apply_resampling to False, as used in some data pipelines by ADA4EUV,
        no resampling is applyd (neither are the aggregation functions min, mean, max, std).

        :param df: input dataframe containing raw RT22 data
        :param apply_resampling: switches resampling to 1 Hz on or off (default=True)
        :param verbose: switches debug mode (default=False)
        :return: dataframe df, including additional columns of derived data
        """

        do_it.do_it_verbose(currentframe(), verbose)

        series_list = []
        columns = list(df.columns)
        first_columns = [column for column in columns if column in 'DSmoveStatus']
        try:
            for column in first_columns:
                series_list.append(df[column].resample('1S').first().rename(column + '_first'))
            if 'DSdgssStatus' in columns:
                columns.remove('DSdgssStatus')
                if apply_resampling:
                    df_value = df['DSdgssStatus'].resample('1S').first()
                else:
                    df_value = df['DSdgssStatus']
                droplet_on_fdsc = []
                droplet_on_cdsc = []
                use_fdsc = []
                droplet_detected = []
                droplet_within_limits = []
                soft_encoder = []
                encoder_mode = []
                camera_mode = []
                df_value = df_value.dropna()
                idx = df_value.index
                for index, value in df_value.items():
                    bit_value = bin(int(value))[2:]
                    bit24_value = bit_value.rjust(25, '0')
                    droplet_on_fdsc.append(bit24_value[15])
                    droplet_on_cdsc.append(bit24_value[14])
                    use_fdsc.append(bit24_value[13])
                    droplet_detected.append(bit24_value[11])
                    droplet_within_limits.append(bit24_value[10])
                    soft_encoder.append(bit24_value[9])
                    encoder_mode.append(bit24_value[8])
                    camera_mode.append(bit24_value[7])
                droplet_on_fdsc_series = pd.Series(droplet_on_fdsc)
                droplet_on_fdsc_series.index = idx
                droplet_on_cdsc_series = pd.Series(droplet_on_cdsc)
                droplet_on_cdsc_series.index = idx
                use_fdsc_series = pd.Series(use_fdsc)
                use_fdsc_series.index = idx
                droplet_detected_series = pd.Series(droplet_detected)
                droplet_detected_series.index = idx
                droplet_within_limits_series = pd.Series(droplet_within_limits)
                droplet_within_limits_series.index = idx
                soft_encoder_series = pd.Series(soft_encoder)
                soft_encoder_series.index = idx
                encoder_mode_series = pd.Series(encoder_mode)
                encoder_mode_series.index = idx
                camera_mode_series = pd.Series(camera_mode)
                camera_mode_series.index = idx
                series_list = series_list + [droplet_on_fdsc_series.rename('DROPLET_ON_FDSC'),
                                             droplet_on_cdsc_series.rename('DROPLET_ON_CDSC'),
                                             use_fdsc_series.rename('USE_FDSC'),
                                             droplet_detected_series.rename('DROPLET_DETECTED'),
                                             droplet_within_limits_series.rename('DROPLET_WITHIN_LIMITS'),
                                             soft_encoder_series.rename('SOFT_ENCODER'),
                                             encoder_mode_series.rename('ENCODER_MODE'),
                                             camera_mode_series.rename('CAMERA_MODE')]
                df = pd.concat(series_list, axis=1)
            if apply_resampling:
                df = df[columns]
                resampled_df = df.resample('1S').mean().add_suffix('_mean')
                series_list.append(resampled_df)
                resampled_df = df.resample('1S').min().add_suffix('_min')
                series_list.append(resampled_df)
                resampled_df = df.resample('1S').max().add_suffix('_max')
                series_list.append(resampled_df)
                resampled_df = df.resample('1S').std().add_suffix('_std')
                series_list.append(resampled_df)
                df = pd.concat(series_list, axis=1)
        except Exception as e:
            print("Failed processing RT06.", e)

        return df
