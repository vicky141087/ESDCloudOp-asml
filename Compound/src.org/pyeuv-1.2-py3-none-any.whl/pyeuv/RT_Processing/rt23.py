# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: Rob Wieggers (RWKL)
@ownership: FC-076

Based on code from CDL EUVDB
"""


import numpy as np
import pandas as pd

from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.RT_Processing.simple_rt import SimpleRT


class RT23(SimpleRT):
    def __init__(self):
        self.name = 'RT23'
        super(RT23, self).__init__(self.name)

    @staticmethod
    def process_signals(df, mv_flag, verbose=False):
        """
        Calculate derived data for rt23

        :param df: input dataframe containing raw RT23 data
        :param mv_flag: true is MV source, false if GWE
        :param verbose: switches debug mode (default=False)
        :return: dataframe df, including additional columns of derived data
        """
        # TODO: auto get machine flag from machines_json, add function to shared.shared

        do_it.do_it_verbose(currentframe(), verbose)

        out = pd.DataFrame()

        try:
            status_idx = ~df['TFMimageStatus'].apply(np.isnan).values
            time_idx = df['TFMrt2timestampSeconds'].values != 0 & ~df['TFMrt2timestampSeconds'].apply(
                np.isnan).values
            time_idx2 = ~df['TFMrt2timestampFractionalSecs'].apply(np.isnan).values
            rt2_ok = ~((df['TFMrt2timestampSeconds'] - df[
                'TFMrt2timestampSeconds'].mean()).abs() > 2419200)  # Filter where TFMrt2timestampSeconds = 15. 2419200 seconds in a month.
            if mv_flag:
                status_idxDFC1 = ~(df['TFMimageStatusDFC1'].apply(np.isnan).values)  # New for MV
                status_idxDFC2 = ~(df['TFMimageStatusDFC2'].apply(np.isnan).values)  # New for MV
                ok_idx = status_idx & time_idx & time_idx2 & rt2_ok & status_idxDFC1 & status_idxDFC2
            else:
                ok_idx = status_idx & time_idx & time_idx2 & rt2_ok
            if ~np.any(ok_idx):
                print("No Data Passed Initial Validity Filtering")
                return pd.DataFrame()
            df = df[ok_idx]

            # Constants
            subid = df['TFMsubroutineId'].values  # Subroutine Values

            # Output Signal List
            if mv_flag:
                sigs = ['' for _ in range(56)]
                sigs[0] = 'TFMpositionX'
                sigs[1] = 'TFMpositionZ'
                sigs[2] = 'TFMrotationY'
                sigs[3] = 'TFMminorAxis'
                sigs[4] = 'TFMmajorAxis'
                sigs[5] = 'TFMdebrisArea'
                sigs[6] = 'TFMimageMean'
                sigs[7] = 'TFMimageStandardDeviation'
                sigs[8] = '_ProcessingTime'
                sigs[9] = 'TFMdelaySinceDropletDetect'
                sigs[10] = 'TFMdelaySincePp'
                sigs[11] = 'TFMplasmaIntensity'
                sigs[12] = 'TFMellipseDeviation'
                sigs[13] = 'TFMimageStatus'
                sigs[14] = 'TFMreferencePointX'  # MV
                sigs[15] = 'TFMreferencePointY'  # MV
                sigs[16] = 'TFMreferencePointZ'  # MV
                sigs[17] = 'TFMrotationX'  # MV
                sigs[18] = 'TFMpositionY'  # MV

                sigs[19] = 'TFMdebrisAreaDFC1'  # MV and TFMimageStatusDFC1
                sigs[20] = 'TFMellipseDeviationDFC1'  # MV and TFMimageStatusDFC1
                sigs[21] = 'TFMImageBlockIdDFC1'  # MV and TFMimageStatusDFC1
                sigs[22] = 'TFMimageMeanDFC1'  # MV and TFMimageStatusDFC1
                sigs[23] = 'TFMimageStandardDeviationDFC1'  # MV and TFMimageStatusDFC1
                sigs[24] = 'TFMimageStatusDFC1'  # MV and TFMimageStatusDFC1
                sigs[25] = 'TFMmajorAxisDFC1'  # MV and TFMimageStatusDFC1
                sigs[26] = 'TFMminorAxisDFC1'  # MV and TFMimageStatusDFC1
                sigs[27] = 'TFMplasmaIntensityDFC1'  # MV and TFMimageStatusDFC1
                sigs[28] = 'TFMpositionHorDFC1'  # MV and TFMimageStatusDFC1
                sigs[29] = 'TFMpositionVerDFC1'  # MV and TFMimageStatusDFC1
                sigs[30] = 'TFMreferenceHorDFC1'  # MV and TFMimageStatusDFC1
                sigs[31] = 'TFMreferenceVerDFC1'  # MV and TFMimageStatusDFC1
                sigs[32] = 'TFMrotationOpticalAxisDFC1'  # MV and TFMimageStatusDFC1

                sigs[33] = 'TFMdebrisAreaDFC2'  # MV and TFMimageStatusDFC2
                sigs[34] = 'TFMellipseDeviationDFC2'  # MV and TFMimageStatusDFC2
                sigs[35] = 'TFMImageBlockIdDFC2'  # MV and TFMimageStatusDFC2
                sigs[36] = 'TFMimageMeanDFC2'  # MV and TFMimageStatusDFC2
                sigs[37] = 'TFMimageStandardDeviationDFC2'  # MV and TFMimageStatusDFC2
                sigs[38] = 'TFMimageStatusDFC2'  # MV and TFMimageStatusDFC2
                sigs[39] = 'TFMmajorAxisDFC2'  # MV and TFMimageStatusDFC2
                sigs[40] = 'TFMminorAxisDFC2'  # MV and TFMimageStatusDFC2
                sigs[41] = 'TFMplasmaIntensityDFC2'  # MV and TFMimageStatusDFC2
                sigs[42] = 'TFMpositionHorDFC2'  # MV and TFMimageStatusDFC2
                sigs[43] = 'TFMpositionVerDFC2'  # MV and TFMimageStatusDFC2
                sigs[44] = 'TFMreferenceHorDFC2'  # MV and TFMimageStatusDFC2
                sigs[45] = 'TFMreferenceVerDFC2'  # MV and TFMimageStatusDFC2
                sigs[46] = 'TFMrotationOpticalAxisDFC2'  # MV and TFMimageStatusDFC2

                # Convenience Signals with Single Subroutines
                sigs[47] = '_TFMdropletMpIntersectionX'  # MV and imageStatusDFC (subroutine 2 MP only)
                sigs[48] = '_TFMdropletMpIntersectionY'  # MV and imageStatusDFC (subroutine 2 MP only)
                sigs[49] = '_TFMdropletMpIntersectionZ'  # MV and imageStatusDFC (subroutine 2 MP only)
                sigs[50] = '_TFMdropletPpIntersectionX'  # MV and imageStatusDFC (subroutine 1 MP only)
                sigs[51] = '_TFMdropletPpIntersectionY'  # MV and imageStatusDFC (subroutine 1 MP only)
                sigs[52] = '_TFMdropletPpIntersectionZ'  # MV and imageStatusDFC (subroutine 1 MP only)
                sigs[53] = '_TFMplasmaCentroidX'  # MV and imageStatusDFC (subroutine 11 MFL plasma only)
                sigs[54] = '_TFMplasmaCentroidY'  # MV and imageStatusDFC (subroutine 11 MFL plasma only)
                sigs[55] = '_TFMplasmaCentroidZ'  # MV and imageStatusDFC (subroutine 11 MFL plasma only)

                # Define Convenience Signals
                df['_TFMdropletMpIntersectionX'] = df['TFMpositionX']
                df['_TFMdropletMpIntersectionY'] = df['TFMpositionY']
                df['_TFMdropletMpIntersectionZ'] = df['TFMpositionZ']
                df['_TFMdropletPpIntersectionX'] = df['TFMpositionX']
                df['_TFMdropletPpIntersectionY'] = df['TFMpositionY']
                df['_TFMdropletPpIntersectionZ'] = df['TFMpositionZ']
                df['_TFMplasmaCentroidX'] = df['TFMpositionX']
                df['_TFMplasmaCentroidY'] = df['TFMpositionY']
                df['_TFMplasmaCentroidZ'] = df['TFMpositionZ']
            else:
                sigs = ['' for _ in range(14)]
                sigs[0] = 'TFMpositionX'
                sigs[1] = 'TFMpositionZ'
                sigs[2] = 'TFMrotationY'
                sigs[3] = 'TFMminorAxis'
                sigs[4] = 'TFMmajorAxis'
                sigs[5] = 'TFMdebrisArea'
                sigs[6] = 'TFMimageMean'
                sigs[7] = 'TFMimageStandardDeviation'
                sigs[8] = '_ProcessingTime'
                sigs[9] = 'TFMdelaySinceDropletDetect'
                sigs[10] = 'TFMdelaySincePp'
                sigs[11] = 'TFMplasmaIntensity'
                sigs[12] = 'TFMellipseDeviation'
                sigs[13] = 'TFMimageStatus'

            # Get Bits and invert for positive filtering
            tstatus = df['TFMimageStatus'].values.astype(int)
            if mv_flag:
                # Redefine bits for TFMimageStatusDFC1
                tstatus_dfc1 = df['TFMimageStatusDFC1'].values.astype(int)
                # Redefine bits for TFMimageStatusDFC2
                tstatus_dfc2 = df['TFMimageStatusDFC2'].values.astype(int)
                tstatus_array = [tstatus_dfc1, tstatus_dfc2]
            else:
                tstatus_array = [tstatus]

            for tstatus_signals in tstatus_array:
                bits = dict()
                bits[0] = {"name": 'b00_Acquisition_err',
                        "val": np.invert(((tstatus_signals >> 0) & 1).astype(bool))}  # IMAGE_ACQUISITION_FAILURE
                bits[1] = {"name": 'b01_Processing_err',
                        "val": np.invert(((tstatus_signals >> 1) & 1).astype(bool))}  # IMAGE_PROCESSING_ERROR
                bits[2] = {"name": 'b02_Drop_out_of_spec',
                        "val": np.invert(((tstatus_signals >> 2) & 1).astype(bool))}  # DROPLET_NOT_IN_SPEC
                bits[3] = {"name": 'b03_Pancake_out_of_spec',
                        "val": np.invert(((tstatus_signals >> 3) & 1).astype(bool))}  # PANCAKE_NOT_IN_SPEC
                bits[4] = {"name": 'b04_Debris_persists',
                        "val": np.invert(((tstatus_signals >> 4) & 1).astype(bool))}  # DEBRIS_PERSISTS_AFTER_MP_HIT
                bits[5] = {"name": 'b05_BGimage_old',
                        "val": np.invert(((tstatus_signals >> 5) & 1).astype(bool))}  # BACKGROUND_IMAGE_OUT_OF_DATE
                bits[6] = {"name": 'b06_Gain_high',
                        "val": np.invert(((tstatus_signals >> 6) & 1).astype(bool))}  # GAIN_TOO_HIGH_ON_OBJECT
                bits[7] = {"name": 'b07_No_drop_or_pancake',
                        "val": np.invert(((tstatus_signals >> 7) & 1).astype(bool))}  # NO_DROPLET_OR_PANCAKE_DETECTED
                bits[8] = {"name": 'b08_Offdrop', "val": np.invert(((tstatus_signals >> 8) & 1).astype(bool))}  # OFF_DROPLET_EVENT
                bits[9] = {"name": 'b09_Satellites', "val": np.invert(((tstatus_signals >> 9) & 1).astype(bool))}  # SATELLITES_DETECTED
                bits[10] = {"name": 'b10_BGimage_not_uniform',
                            "val": np.invert(((tstatus_signals >> 10) & 1).astype(bool))}  # IMAGE_BACKGROUND_NOT_UNIFORM
                bits[11] = {"name": 'b11_BGimage_dark',
                            "val": np.invert(((tstatus_signals >> 11) & 1).astype(bool))}  # IMAGE_BACKGROUND_TOO_DARK
                bits[12] = {"name": 'b12_BGimage_bright',
                            "val": np.invert(((tstatus_signals >> 12) & 1).astype(bool))}  # IMAGE_BACKGROUND_TOO_BRIGHT
                bits[13] = {"name": 'b13_Plasma_flash_bright',
                            "val": np.invert(((tstatus_signals >> 13) & 1).astype(bool))}  # PLASMA_FLASH_TOO_BRIGHT
                bits[14] = {"name": 'b14_Cam_out_of_focus',
                            "val": np.invert(((tstatus_signals >> 14) & 1).astype(bool))}  # CAMERA_OUT_OF_FOCUS
                bits[15] = {"name": 'b15_Elipse_fit_poor',
                            "val": np.invert(((tstatus_signals >> 15) & 1).astype(bool))}  # ELLIPSE_FIT_QUALITY_POOR
                if mv_flag:
                    bits[16] = {"name": 'b16_DFC_image_sync_lost',
                                "val": np.invert(
                                    ((tstatus_signals >> 16) & 1).astype(bool))}  # DFC_CAPTURE_IMAGE_SYNC_LOST added for MV

            # Define Subroutine Rules
            subrout = dict()
            if mv_flag:
                subrout[1] = {"name": 'PP', "valid": [0, 1, 7], "quality": [5, 6, 14], "in_spec": [2, 9],
                              "sigs": [0, 1, 2, 3, 4, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 24, 25, 26, 28, 29,
                                       30, 31,
                                       32, 34, 35, 38, 39, 40, 42, 43, 44, 45, 46, 50, 51, 52]}
                subrout[2] = {"name": 'MP', "valid": [0, 1, 7, 8], "quality": [5, 6, 14], "in_spec": [3],
                              "sigs": [0, 1, 2, 3, 4, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 24, 25, 26, 28, 29,
                                       30, 31,
                                       32, 34, 35, 38, 39, 40, 42, 43, 44, 45, 46, 47, 48, 49]}
                subrout[3] = {"name": 'Debris', "valid": [0, 1, 8], "quality": [5, 6, 14], "in_spec": [4],
                              "sigs": [5, 8, 9, 10, 13, 14, 15, 16, 19, 21, 24, 30, 31, 33, 35, 38, 44, 45]}
                subrout[4] = {"name": 'Plasma', "valid": [0, 1], "quality": [5, 14], "in_spec": [13],
                              "sigs": [8, 9, 10, 11, 13, 14, 15, 16, 21, 24, 27, 30, 31, 35, 38, 41, 44, 45]}
                subrout[5] = {"name": 'Satellites', "valid": [0, 1, 7], "quality": [5, 14], "in_spec": [9],
                              "sigs": [8, 9, 10, 13, 14, 15, 16, 21, 24, 30, 31, 35, 38, 44, 45]}
                subrout[6] = {"name": 'Uniformity', "valid": [0, 1], "quality": [5, 14], "in_spec": [10, 11, 12],
                              "sigs": [6, 7, 8, 9, 10, 13, 14, 15, 16, 21, 22, 23, 24, 30, 31, 35, 36, 37, 38, 44, 45]}
                subrout[7] = {"name": 'External', "valid": [], "quality": [], "in_spec": [],
                              "sigs": [9, 10, 13, 14, 15, 16, 21, 24, 30, 31, 35, 38, 44,
                                       45]}  # See comment above above removal of range(len(sigs))
                subrout[8] = {"name": 'Startup', "valid": [0, 1], "quality": [5, 10, 11, 12, 14], "in_spec": [],
                              "sigs": [9, 10, 13, 14, 15, 16, 21, 22, 23, 24, 30, 31, 35, 36, 37, 38, 44, 45]}
                subrout[9] = {"name": 'ROI Monitor', "valid": [0, 1, 7], "quality": [5, 6, 14, 16], "in_spec": [],
                              "sigs": [0, 1, 2, 3, 4, 9, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 24, 25, 26, 28, 29, 30,
                                       31, 32,
                                       34, 35, 38, 39, 40, 42, 43, 44, 45, 46]}
                subrout[10] = {"name": 'ROI Recovery', "valid": [0, 1, 7], "quality": [5, 6, 14, 15, 16],
                               "in_spec": [2, 9],
                               "sigs": [0, 1, 2, 3, 4, 9, 10, 12, 13, 14, 15, 16, 17, 18, 20, 21, 24, 25, 26, 28, 29,
                                        30, 31,
                                        32, 34, 35, 38, 39, 40, 42, 43, 44, 45, 46]}
                subrout[11] = {"name": 'PlasmaImage', "valid": [0, 1, 7, 11], "quality": [5, 14, 16], "in_spec": [],
                               "sigs": [0, 1, 4, 9, 10, 11, 13, 14, 15, 16, 18, 21, 24, 27, 28, 29, 30, 31, 35, 38, 41,
                                        42, 43,
                                        44, 45, 53, 54, 55]}
            else:
                subrout[1] = {"name": 'PP', "valid": [0, 1, 7], "quality": [5, 6, 14], "in_spec": [2, 9],
                              "sigs": [0, 1, 2, 3, 4, 8, 9, 10, 12, 13]}
                subrout[2] = {"name": 'MP', "valid": [0, 1, 7, 8], "quality": [5, 6, 14], "in_spec": [3],
                              "sigs": [0, 1, 2, 3, 4, 8, 9, 10, 12, 13]}
                subrout[3] = {"name": 'Debris', "valid": [0, 1, 8], "quality": [5, 6, 14], "in_spec": [4],
                              "sigs": [5, 8, 9, 10, 13]}
                subrout[4] = {"name": 'Plasma', "valid": [0, 1], "quality": [5, 14], "in_spec": [13],
                              "sigs": [8, 10, 11, 13]}
                subrout[5] = {"name": 'Satellites', "valid": [0, 1, 7], "quality": [5, 14], "in_spec": [9],
                              "sigs": [8, 9, 13]}
                subrout[6] = {"name": 'Uniformity', "valid": [0, 1], "quality": [5, 14], "in_spec": [10, 11, 12],
                              "sigs": [6, 7, 8, 9, 13]}
                subrout[7] = {"name": 'External', "valid": [], "quality": [], "in_spec": [],
                              "sigs": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]}

            # Create New Timestamp out of seconds and fraction
            tf_mrt2timestamp = df['TFMrt2timestampSeconds'] + (1e-9 * df['TFMrt2timestampFractionalSecs'])

            # Create New Signal for Time Delta between RT2 and RT23 Timestamps
            end_time = (tf_mrt2timestamp.index.to_series() - pd.to_datetime('1970-01-01 00:00:00.000')).dt.total_seconds()
            df['_ProcessingTime'] = end_time - tf_mrt2timestamp

            # Apply RT2 timestamp to signals
            tf_mrt2index = pd.to_datetime((tf_mrt2timestamp.values * 1e9), unit='ns')
            df.index = tf_mrt2index  # Apply RT2 Timestamp

            if mv_flag:
                # Create fields for each TFMimagestatus  bit
                bit_names = []
                for x in range(17):
                    bit_names.append(bits[x]['name'])
                    df[bits[x]['name']] = np.invert(bits[x]['val']).astype(int)

                # Separate signals by subroutine and apply rules
                for x in range(1, 12):
                    sub_idx = subid == x  # Index of Subroutine
                    valid_idx = np.array([True for _ in subid])  # Valid index for main signals
                    for oi in subrout[x]['valid']:
                        valid_idx = valid_idx & bits[oi]['val']
                    qual_idx = np.array([True for _ in subid])  # Get index of Good Quality signals
                    for oi in subrout[x]['quality']:
                        qual_idx = qual_idx & bits[oi]['val']
                    inspec_idx = np.array([True for _ in subid])  # Get index of In Spec signals
                    for oi in subrout[x]['in_spec']:
                        inspec_idx = inspec_idx & bits[oi]['val']

                    df['valid'] = valid_idx
                    df['quality'] = np.where(qual_idx, 'Good', 'Poor')
                    df['in_spec'] = inspec_idx

                    df_subrout = df[sub_idx]
                    valid_signals = [sigs[si] for si in subrout[x]['sigs']]
                    columns = [sigs[si] for si in subrout[x]['sigs']] + bit_names + ['valid', 'quality', 'in_spec'] + ['TFMsubroutineId']
                    df_subrout = df_subrout[columns]
                    valid_signals.remove('TFMimageStatus')
                    df_subrout.loc[df_subrout.valid == False, valid_signals] = float('nan')

                    df_subrout['subroutine'] = subrout[x]['name']
                    out = pd.concat([out, df_subrout])
            else:
                # Create fields for each TFMimagestatus  bit
                bit_names = []
                for x in range(16):
                    bit_names.append(bits[x]['name'])
                    df[bits[x]['name']] = np.invert(bits[x]['val']).astype(int)

                # Separate signals by subroutine and apply rules
                for x in range(1, 8):
                    sub_idx = subid == x  # Index of Subroutine
                    valid_idx = np.array([True for _ in subid])  # Valid index for main signals
                    for oi in subrout[x]['valid']:
                        valid_idx = valid_idx & bits[oi]['val']
                    qual_idx = np.array([True for _ in subid])  # Get index of Good Quality signals
                    for oi in subrout[x]['quality']:
                        qual_idx = qual_idx & bits[oi]['val']
                    inspec_idx = np.array([True for _ in subid])  # Get index of In Spec signals
                    for oi in subrout[x]['in_spec']:
                        inspec_idx = inspec_idx & bits[oi]['val']

                    df['valid'] = valid_idx
                    df['quality'] = np.where(qual_idx, 'Good', 'Poor')
                    df['in_spec'] = inspec_idx

                    df_subrout = df[sub_idx]
                    valid_signals = [sigs[si] for si in subrout[x]['sigs']]
                    columns = [sigs[si] for si in subrout[x]['sigs']] + bit_names + ['valid', 'quality', 'in_spec']
                    df_subrout = df_subrout[columns]
                    valid_signals.remove('TFMimageStatus')
                    df_subrout.loc[df_subrout.valid == False, valid_signals] = float('nan')

                    df_subrout['subroutine'] = subrout[x]['name']
                    out = pd.concat([out, df_subrout])
            out.sort_index(inplace=True)
        except Exception as e:
            print('Warning: processing RT23 failed:', e)

        return out
