# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: Rob Wieggers (RWKL)
@ownership: FC-072

Based on code from CDL EUVDB
"""


import numpy as np
import pandas as pd
from inspect import currentframe
from pyeuv.Do_It import do_it_library as do_it
from pyeuv.RT_Processing.simple_rt import SimpleRT


class RT32(SimpleRT):
    def __init__(self):
        self.name = 'RT32'
        super(RT32, self).__init__(self.name)

    @staticmethod
    def process_signals(df, apply_resampling=True, verbose=False):
        """
        Calculate derived data for rt32.
        By default it resamples the data to 1Hz, as used for influx. In this case it calculates the
        min, mean, max, and std for all the columns.
        By setting apply_resampling to False, as used in some data pipelines by ADA4EUV,
        no resampling is applyd (neither are the aggregation functions min, mean, max, std).

        :param df: input dataframe containing raw RT32 data
        :param apply_resampling: switches resampling to 1 Hz on or off (default=True)
        :param verbose: switches debug mode (default=False)
        :return: dataframe new_df, including aggregated signals
        """

        do_it.do_it_verbose(currentframe(), verbose)

        df_calculated = RT32.calculate_signals(df, verbose)
        if apply_resampling:
            new_df = RT32.resample_signals(df_calculated, verbose)
            new_df = RT32.calculate_laser_to_droplet(new_df)
        else:
            new_df = df_calculated

        return new_df

    @staticmethod
    def calculate_signals(df, verbose=False):
        """
        Calculate derived data for rt32

        :param df: input dataframe containing raw RT32 data
        :param verbose: switches debug mode (default=False)
        :return: dataframe df, including additional calculated signals
        """

        do_it.do_it_verbose(currentframe(), verbose)

        # Filter on validity of L2D Y
        msk = "FFA_LD_SELECT_MEAS_SYSTEM_FC_Y__OT_SELECT_MEAS_SYSTEM_VALID_OUT"
        try:
            df["FFA_LD_SELECT_MEAS_SYSTEM_FC_Y__OT_SELECT_MEAS_SYSTEM_OUT"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT32 on mask {}.".format(msk), e)

        # Filter on validity of L2D Z
        msk = "FFA_LD_SELECT_MEAS_SYSTEM_FC_Z__OT_SELECT_MEAS_SYSTEM_VALID_OUT"
        try:
            df["FFA_LD_SELECT_MEAS_SYSTEM_FC_Z__OT_SELECT_MEAS_SYSTEM_OUT"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT32 on mask {}.".format(msk), e)

        # Calc signals
        msk = "FFA_LD_SI_FC_QUAD_CELL_FBD__OT_SI_QUADCELL_SUM_OUT_VALID"
        try:
            df["FFA_LD_MS_FC_QUAD_CELL_FBD__OT_MAT_2X2_FLT_OUT1"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_FC_QUAD_CELL_FBD__OT_MAT_2X2_FLT_OUT2"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT32 on mask {}.".format(msk), e)

        msk = "FFA_LD_SI_FC_QUAD_CELL_RBD__OT_SI_QUADCELL_SUM_OUT_VALID"
        try:
            df["FFA_LD_MS_FC_QUAD_CELL_RBD__OT_MAT_2X2_FLT_OUT1"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_FC_QUAD_CELL_RBD__OT_MAT_2X2_FLT_OUT2"][df[msk] == 0] = np.NaN
            df['_FFA_LD_SI_M150_ENC_M1__OT_SI_INC_FLOAT_OUT'] = \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT1"] * 19906.0 + \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT2"] * 1660.1
            df['_FFA_LD_SI_M150_ENC_M2__OT_SI_INC_FLOAT_OUT'] = \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT1"] * 19906.0 + \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT2"] * -1723.8 + \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT3"] * 1692.0
            df['_FFA_LD_SI_M150_ENC_M3__OT_SI_INC_FLOAT_OUT'] = \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT1"] * 19906.0 + \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT2"] * -1723.8 + \
                df["FFA_LD_MS_3X3_M150_MENC_2_MIR__OT_MS_3X3_OUT3"] * -1692.0
            df['_M150_ENCODER_DELTA_AX1'] = df["FFA_LD_SI_M150_MIRR_ENC_M1__OT_SI_INC_FLOAT_OUT"] - df[
                "_FFA_LD_SI_M150_ENC_M1__OT_SI_INC_FLOAT_OUT"]
            df['_M150_ENCODER_DELTA_AX2'] = df["FFA_LD_SI_M150_MIRR_ENC_M2__OT_SI_INC_FLOAT_OUT"] - df[
                "_FFA_LD_SI_M150_ENC_M2__OT_SI_INC_FLOAT_OUT"]
            df['_M150_ENCODER_DELTA_AX3'] = df["FFA_LD_SI_M150_MIRR_ENC_M3__OT_SI_INC_FLOAT_OUT"] - df[
                "_FFA_LD_SI_M150_ENC_M3__OT_SI_INC_FLOAT_OUT"]
        except Exception as e:
            if verbose:
                print("Failed processing RT32 on mask {}.".format(msk), e)

        msk = "FFA_LD_SELECT_MEAS_SYSTEM_FC_Z__OT_SELECT_MEAS_SYSTEM_VALID_OUT"
        try:
            df['_M150_CONTROL_ERROR_AX1_EUV'] = df["FFA_LD_CO_M150_M1__OT_CO_CTL_ERR"]
            df['_M150_CONTROL_ERROR_AX2_EUV'] = df["FFA_LD_CO_M150_M2__OT_CO_CTL_ERR"]
            df['_M150_CONTROL_ERROR_AX3_EUV'] = df["FFA_LD_CO_M150_M3__OT_CO_CTL_ERR"]

            df["_M150_CONTROL_ERROR_AX1_EUV"][df[msk] == 0] = np.NaN
            df["_M150_CONTROL_ERROR_AX2_EUV"][df[msk] == 0] = np.NaN
            df["_M150_CONTROL_ERROR_AX3_EUV"][df[msk] == 0] = np.NaN

        except Exception as e:
            if verbose:
                print("Failed processing RT32 on mask {}.".format(msk), e)

        # Calc signals for quad cell
        df = RT32.calculate_laser_to_droplet(df, post_fix="", verbose=verbose)

        # Filter mirror actuation signals on validity of FBD QC validity
        msk = "FFA_LD_SI_FC_QUAD_CELL_FBD__OT_SI_QUADCELL_SUM_OUT_VALID"
        try:
            df["FFA_LD_MS_3X3_M90_MENC_2_MIR__OT_MS_3X3_OUT1"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_3X3_M90_MENC_2_MIR__OT_MS_3X3_OUT2"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_3X3_M120_PHYS2LOG__OT_MS_3X3_OUT1"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_3X3_M120_PHYS2LOG__OT_MS_3X3_OUT2"][df[msk] == 0] = np.NaN
            df["FFA_LD_MS_3X3_M120_PHYS2LOG__OT_MS_3X3_OUT3"][df[msk] == 0] = np.NaN
        except Exception as e:
            if verbose:
                print("Failed processing RT32 on mask {}.".format(msk), e)

        return df

    @staticmethod
    def resample_signals(df, verbose=False):
        """
        Resample the signals to 1 second buckets

        :param df: input dataframe containing raw RT32 data
        :param verbose: switches debug mode (default=False)
        :return: dataframe new_df, including aggregated signals
        """

        do_it.do_it_verbose(currentframe(), verbose)

        # Re-sample selected signals
        try:
            new_df = pd.DataFrame()
            for key in df.columns:
                new_df[key + '_mean'] = df[key].resample('1S', how='mean')
                new_df[key + '_min'] = df[key].resample('1S', how='min')
                new_df[key + '_max'] = df[key].resample('1S', how='max')
                new_df[key + '_std'] = df[key].resample('1S', how='std')

        except Exception as e:
            if verbose:
                print("Failed processing RT32 re-sampling", e)
        return new_df

    @staticmethod
    def calculate_laser_to_droplet(df, post_fix="_mean", verbose=False):
        """
        Calculate laser to droplet. By default it uses the 1 second mean values to calculate this.
        When one needs L2D_x and L2D_y on the raw data, the optional post_fix should be set to "".

        :param df: input dataframe containing raw and calculated RT32 data
        :param post_fix: option to change (or remove) the postfix, which by default is '_mean'
        :param verbose: switches debug mode (default=False)
        :return: dataframe df including laser to droplet data
        """

        do_it.do_it_verbose(currentframe(), verbose)
        try:

            # Calc signals (legacy naming)
            df['_QUAD_L2D_x'] = df["FFA_LD_MS_FC_QUAD_CELL_FBD__OT_MAT_2X2_FLT_OUT1{}".format(post_fix)] - df[
                "FFA_LD_MS_FC_QUAD_CELL_RBD__OT_MAT_2X2_FLT_OUT1{}".format(post_fix)]
            df['_QUAD_L2D_y'] = df["FFA_LD_MS_FC_QUAD_CELL_FBD__OT_MAT_2X2_FLT_OUT2{}".format(post_fix)] - df[
                "FFA_LD_MS_FC_QUAD_CELL_RBD__OT_MAT_2X2_FLT_OUT2{}".format(post_fix)]
        except Exception as e:
            if verbose:
                print("Failed processing RT32 QUAD_L2D X and Y", e)
        return df
