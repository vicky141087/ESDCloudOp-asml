# -*- coding: utf-8 -*-
"""
Created on Wed Feb 17 9:22 2021

@author: Iris Clerx (ICLE)
@ownership: D&E Source Performance
"""

import numpy as np
import pandas as pd
from scipy import interpolate
from datetime import datetime


class ContextFilterObject:
    def __init__(self, times=np.array([]), booleans=np.array([]), name='', matlab=False):
        """
        Constructor of the context filter object.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param booleans: array containing boolean values
        :type booleans: np.ndarray
        :param name: name of context filter object
        :type name: str
        :param matlab: indicates whether the function is called from matlab
        :type matlab: bool
        """
        self.times = []
        self.name = name
        self.edges = []
        self.edge_type = '[)'
        self.include_edges = []
        self.times_assert = []
        self.times_deassert = []

        if matlab:
            times = self.convert_mat_times(times)
            booleans = np.array(booleans)

        if len(booleans):
            if np.isin([1, -1], booleans).all():
                self.times = times
                self.name = name
                self.edges = booleans
                self.include_edge_points()
                self.times_assert = self.times[::2]
                self.times_deassert = self.times[1::2]
            else:
                self.add_context(times, booleans)
        elif len(times):
            self.add_context(times, booleans)


    def add_context(self, times, booleans):
        """
        Add context to the context filter object.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param booleans: array containing boolean values
        :type booleans: np.ndarray
        """
        if not len(booleans) and (len(times) % 2 == 0):
            edges = np.ones(len(times))
            edges[1::2] = -1
            self.add_ctxt_edge_method(times, edges)
            return

        if not len(booleans) or not len(times):
            print('No context information added to arguments.')
            return

        booleans = np.nan_to_num(booleans)
        if booleans[-1]:
            booleans = np.append(booleans, 0)
            times = np.append(times, np.datetime64(datetime.max))

        if len(self.times):
            self = self or ContextFilterObject(times, booleans)
            return

        ida = np.append(booleans[0], (np.diff(booleans) > 0.5))
        idd = np.append(0, (np.diff(booleans) < -0.5))
        edges = ida - idd
        idx = np.where(edges != 0)
        self.edges = edges[idx]
        self.times = times[idx]

        self.include_edge_points()
        self.times_assert = self.times[::2]
        self.times_deassert = self.times[1::2]


    def add_ctxt_edge_method(self, times, edges, matlab=False, edge_fix='remove',
                             timedelta_assert=-1, timedelta_deassert=1, unit='m'):
        """
        Generate a sane context filter object.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param edges: array containing edge values
        :type edges: np.ndarray
        :param matlab: indicates whether the function is called from matlab
        :type matlab: bool
        :param edge_fix: 'remove' (default) removes repeated edges \
            'add' adds extra edges
        :type edge_fix: str
        :param timedelta_assert: time to add rising edges before \
            repeating falling edges (default -1)
        :type timedelta_assert: int
        :param timedelta_deassert: time to add falling edges after \
            repeating rising edges (default 1)
        :type timedelta_deassert: int
        :param unit: date/time unit (default 'm')
        :type unit: str
        """
        if matlab:
            times = self.convert_mat_times(times)
            edges = np.array(edges)

        if not len(edges):
            edges = np.ones(len(times))
            edges[1::2] = -1

        idx = times.argsort()
        times = times[idx]
        edges = edges[idx]

        tda = np.timedelta64(-abs(int(timedelta_assert)), unit)
        tdd = np.timedelta64(abs(int(timedelta_deassert)), unit)

        adj_idx = self.find_adjacent_edges(times, edges)
        adj_inv = np.invert(adj_idx)

        xtra_idx = self.find_extra_edges(edges)
        xtra_inv = np.invert(xtra_idx)

        if edge_fix == 'remove':
            times = times[adj_idx]
            edges = edges[adj_idx]
            self.times, self.edges = self.check_start_edge(times, edges)
            self.times, self.edges = self.check_end_edge(times, edges)

        elif edge_fix == 'add':
            cfo = ContextFilterObject()
            cfo.times = times[adj_idx]
            cfo.edges = edges[adj_idx]
            cfo_c = self or cfo

            if tda != 0:
                if edges[0] == -1:
                    cfo_c.times = np.append((cfo_c.times[0] + tda), cfo_c.times)
                    cfo_c.edges = np.append(1, cfo_c.edges)
                cfo = ContextFilterObject()
                cfo.edges = np.array([1, -1])
                idx = np.where(adj_inv & (edges == -1))
                for i in idx:
                    cfo.times = times[i] + np.array([tda, 0])
                    cfo_c = cfo_c or cfo
            else:
                cfo_c.times, cfo_c.edges = self.check_start_edge(times, edges)

            if tdd != 0:
                if edges[-1] == 1:
                    cfo_c.times = np.append(cfo_c.times, (cfo_c.times[-1] + tdd))
                    cfo_c.edges = np.append(cfo_c.edges, -1)
                cfo = ContextFilterObject()
                cfo.edges = np.array([1, -1])
                idx = np.where(adj_inv & (edges == 1))
                for i in idx:
                    cfo.times =  times[i] + np.array([0, tdd])
                    cfo_c = cfo_c or cfo
            else:
                cfo_c.times, cfo_c.edges = self.check_end_edge(times, edges)

            self.times = cfo_c.times
            self.edges = cfo_c.edges

        else:
            times = times[xtra_inv]
            edges = edges[xtra_inv]
            self.times, self.edges = self.check_start_edge(times, edges)
            self.times, self.edges = self.check_end_edge(times, edges)

        self.include_edge_points()
        self.times_assert = self.times[::2]
        self.times_deassert = self.times[1::2]


    def convert_mat_times(self, times):
        """
        Convert MATLAB datetime array to numpy datetime array.

        :param times: MATLAB array containing datetime values
        :type times: np.ndarray
        :returns: numpy array containing datetime values
        :rtype: np.ndarray
        """
        times = np.array(times)
        if len(times):
            if times[0] == '-Inf':
                if times[-1] == 'Inf':
                    times_dt = pd.to_datetime(times[1:-1], format='%Y-%m-%d %H:%M:%S.%f')
                    times_dt = np.append(np.datetime64(datetime.min), times_dt)
                    times_dt = np.append(times_dt, np.datetime64(datetime.max))
                else:
                    times_dt = pd.to_datetime(times[1:], format='%Y-%m-%d %H:%M:%S.%f')
                    times_dt = np.append(np.datetime64(datetime.min), times_dt)
            elif times[-1] == 'Inf':
                times_dt = pd.to_datetime(times[:-1], format='%Y-%m-%d %H:%M:%S.%f')
                times_dt = np.append(times_dt, np.datetime64(datetime.max))
            else:
                times_dt = pd.to_datetime(times, format='%Y-%m-%d %H:%M:%S.%f')
        else:
            times_dt = times
        return np.array(times_dt, dtype=np.datetime64)


    def find_adjacent_edges(self, times, edges):
        """
        Keep 1,-1 pairs spaced a non-zero amount of time.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param edges: array containing edge values
        :type edges: np.ndarray
        :returns: indices to be kept
        :rtype: np.ndarray
        """
        edge_idx = (edges == 1) & (np.append(edges[1:], 0) == -1)
        edge_idx = edge_idx | np.append(False, edge_idx[:-1])
        time_idx = np.append(True, (np.diff(times).astype('float64') != 0)) \
            & np.append((np.diff(times).astype('float64') != 0), True)
        return (edge_idx & time_idx)


    def find_extra_edges(self, edges):
        """
        Keep first value of redundant edges.

        :param edges: array containing edge values
        :type edges: np.ndarray
        :returns: indices to be removed
        :rtype: np.ndarray
        """
        edge_diff = np.diff(edges)
        edge_diff = (edge_diff == 0)
        return np.append(False, edge_diff)


    def check_start_edge(self, times, edges):
        """
        Ensure that the first edge is rising.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param edges: array containing edge values
        :type edges: np.ndarray
        :returns: arrays containing datetime values and edge values
        :rtype: np.ndarray
        """
        if edges[0] == -1:
            times = times[1:]
            edges = edges[1:]
        return times, edges


    def check_end_edge(self, times, edges):
        """
        Ensure that the last edge is falling.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param edges: array containing edge values
        :type edges: np.ndarray
        :returns: arrays containing datetime values and edge values
        :rtype: np.ndarray
        """
        if edges[-1] == 1:
            times = times[:-1]
            edges = edges[:-1]
        return times, edges


    def include_edge_points(self):
        """
        Determine what to do with boundary points.
        """
        if self.edge_type[0] == '[':
            self.include_edges = self.edges == 1
        elif self.edge_type[1] == ']':
            self.include_edges = self.edges == -1


    def deglitch_inter_gates(self, timedelta_diff, inter=False, unit='m'):
        """
        Remove (inter)gates shorter than a certain duration.

        :param timedelta_diff: minimum duration of (inter)gates
        :type timedelta_diff: int
        :param inter: indicates whether to remove intermediate gates or gates
        :type inter: bool
        :param unit: date/time unit ('Y'|'M'|'W'|'D'|'h'|'m'|'s'|'ms'|'us')
        :type unit: str
        """
        tdd = np.timedelta64(abs(int(timedelta_diff)), unit)

        idx = []
        if not inter:
            for i, times in enumerate(zip(self.times_assert, self.times_deassert)):
                if ((times[1] - times[0]) < tdd):
                    idx.extend([i*2, i*2+1])
        else:
            j = 1
            for i, times in enumerate(zip(self.times_assert[1:], self.times_deassert[:-1])):
                if ((times[0] - times[1]) < tdd):
                    idx.extend([i+j, i+j+1])
                j += 1
        self.times = np.delete(self.times, idx)
        self.edges = np.delete(self.edges, idx)

        self.include_edge_points()
        self.times_assert = self.times[::2]
        self.times_deassert = self.times[1::2]


    def shift_edge_points(self, timedelta_assert=1, timedelta_deassert=-1, unit='m'):
        """
        Move (de)assertion edges over time.

        :param timedelta_assert: time to move assertion edges
        :type timedelta_assert: int
        :param timedelta_deassert: time to move deassertion edges
        :type timedelta_deassert: int
        :param unit: date/time unit
        :type unit: str
        """
        tda = np.timedelta64(int(timedelta_assert), unit)
        tdd = np.timedelta64(int(timedelta_deassert), unit)

        self.times = np.sort(np.concatenate(((self.times_deassert + tdd),
                                             (self.times_assert + tda)), axis=None))
        self.include_edge_points()
        self.times_assert = self.times[::2]
        self.times_deassert = self.times[1::2]


    def not_ctxt_filters(self):
        """
        Generate inverse of context filter object.

        :returns: inverted context filter object
        :rtype: object
        """
        if not len(self.times):
            times = np.array([np.datetime64(datetime.min), np.datetime64(datetime.max)])
            cfo = ContextFilterObject(times)
            return cfo

        cfo = ContextFilterObject()
        cfo.name = self.name
        cfo.times = self.times
        cfo.edges = self.edges * -1
        cfo.include_edges = np.invert(self.include_edges)

        if cfo.times[0] == np.datetime64(datetime.min):
            cfo.times = cfo.times[1:]
            cfo.edges = cfo.edges[1:]
            cfo.include_edges = cfo.include_edges[1:]
        else:
            cfo.times = np.append(np.datetime64(datetime.min), cfo.times)
            cfo.edges = np.append(1, cfo.edges)
            cfo.include_edges = np.append(False, cfo.include_edges)

        if cfo.times[-1] == np.datetime64(datetime.max):
            cfo.times = cfo.times[:-1]
            cfo.edges = cfo.edges[:-1]
            cfo.include_edges = cfo.include_edges[:-1]
        else:
            cfo.times = np.append(cfo.times, np.datetime64(datetime.max))
            cfo.edges = np.append(cfo.edges, -1)
            cfo.include_edges = np.append(cfo.include_edges, False)

        cfo.include_edge_points()
        cfo.times_assert = cfo.times[::2]
        cfo.times_deassert = cfo.times[1::2]
        return cfo


    def limit_gate_freq(self, timedelta_diff, unit='m', from_end=False):
        """
        Remove gates that start within a certain duration from the start|end \
            of the previous gate.

        :param timedelta_diff: minimum duration of (inter)gates/time to move deassertion edges
        :type timedelta_diff: int
        :param unit: date/time unit ('Y'|'M'|'W'|'D'|'h'|'m'|'s'|'ms'|'us')
        :type unit: str
        :param from_end: indicates whether to calculate duration from the start or \
            the end of the previous gate
        :type from_end: bool
        """
        tdd = np.timedelta64(abs(int(timedelta_diff)), unit)

        idx = 1
        if not from_end:
            for i in range(1, len(self.times_assert)):
                if (self.times_assert[idx] - self.times_assert[idx-1]) < tdd:
                    self.times = np.delete(self.times, [idx*2, idx*2+1])
                    self.edges = np.delete(self.edges, [idx*2, idx*2+1])
                    self.times_assert = self.times[::2]
                    self.times_deassert = self.times[1::2]
                    idx = 1
                else:
                    idx += 1
        else:
            for i in range(1, len(self.times_assert)):
                if (self.times_assert[idx] - self.times_deassert[idx-1]) < tdd:
                    self.times = np.delete(self.times, [idx*2, idx*2+1])
                    self.edges = np.delete(self.edges, [idx*2, idx*2+1])
                    self.times_assert = self.times[::2]
                    self.times_deassert = self.times[1::2]
                    idx = 1
                else:
                    idx += 1

        self.include_edge_points()


    def combine_ctxt_filters(self, cfo2, logic='and'):
        """
        Combine two context filter objects by using a logical operator.

        :param cfo2: second context filter object
        :type cfo2: object
        :param logic: logical operator 'and', 'or' or 'xor'
        :type logic: str
        :returns: combined context filter object
        :rtype: object
        """
        idx = np.sort(np.append(np.array(self.times, dtype=np.datetime64),
                                np.array(cfo2.times, dtype=np.datetime64)))
        booleans1 = self.apply_ctxt_filter(idx)
        booleans2 = cfo2.apply_ctxt_filter(idx)
        if logic == 'and':
            booleans = [booleans1[i] and booleans2[i] for i in range(len(booleans1))]
        elif logic == 'or':
            booleans = [booleans1[i] or booleans2[i] for i in range(len(booleans1))]
        elif logic == 'xor':
            booleans = [float(bool(booleans1[i]) ^ bool(booleans2[i])) for i in range(len(booleans1))]
        return ContextFilterObject(pd.DataFrame(index=idx).index.values, np.array(booleans))


    def apply_ctxt_filter(self, times, matlab=False):
        """
        Apply context filtering to time series data within each gate.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param matlab: indicates whether the function is called from matlab
        :type matlab: bool
        :returns: array containing estimated boolean values
        :rtype: np.ndarray
        """
        if matlab:
            times = self.convert_mat_times(times)

        if not len(self.edges):
            booleans = np.zeros(len(times))
        else:
            if len(self.times) == 1:
                booleans = np.ones(len(times))
                return booleans

            time_delta = np.timedelta64(1, 'us')

            time_diff = self.times_deassert - self.times_assert
            idx = np.where(time_diff.astype(int) != 0)[0] * 2
            times_est = self.times[np.sort(np.append((idx + 1), idx))]
            edges_est = self.edges[np.sort(np.append((idx + 1), idx))]

            if times_est[0] == np.datetime64(datetime.min):
                times_est[0] = np.amin(times) - time_delta
            if times_est[-1] == np.datetime64(datetime.max):
                times_est[-1] = np.amax(times) + time_delta

            est_fx = interpolate.interp1d(x = [x.astype(float) for x in times_est],
                                          y = np.cumsum(edges_est), kind = 'previous',
                                          bounds_error = False)
            booleans = est_fx([x.astype(float) for x in times])
            booleans = np.nan_to_num(booleans)

            idx = np.isin(times, np.delete(self.times, self.include_edges))
            booleans[idx] = 0
            idx = np.isin(times, self.times[self.include_edges])
            booleans[idx] = 1
        return booleans


    def agg_ctxt_filter(self, times, values, matlab=False, agg_fun=lambda x: np.mean(x)):
        """
        Apply context filtering to time series data within each gate.

        :param times: array containing datetime values
        :type times: np.ndarray
        :param values: array containing values to be aggregated
        :type values: np.ndarray
        :returns: arrays containing estimated boolean values and \
            corresponding datetime values respectively
        :rtype: np.ndarray, np.ndarray
        """
        if matlab:
            times = self.convert_mat_times(times)
            values = np.array(values)

        idx = np.where(self.times == np.datetime64(datetime.max))
        edges_inf = np.delete(self.edges, idx)
        times_inf = np.delete(self.times, idx)
        gate_count = np.cumsum(edges_inf == 1)
        gate_count = pd.DataFrame({'gate_count': gate_count}, index=times_inf)
        self.include_edge_points()
        gate_count = gate_count[self.include_edges.astype('bool')].dropna()

        agg_pdf = pd.DataFrame({'values': values}, index=times)
        agg_pdf = agg_pdf.join(gate_count, how='outer').sort_index()
        agg_pdf['gate_count'] = agg_pdf['gate_count'].fillna(method='ffill')

        idx = self.apply_ctxt_filter(agg_pdf.index.values)

        agg_pdf = agg_pdf[idx.astype('bool')].dropna()
        agg_times = self.times[(agg_pdf['gate_count'].unique().astype('int') * 2 - 1)]
        agg_pdf = agg_pdf.groupby('gate_count').apply(agg_fun)
        return agg_times, agg_pdf['values'].values


    def convert_py_times(self):
        """
        Convert numpy datetime arrays to float arrays for conversion \
            in MATLAB to MATLAB datetime array.
        """
        self.times = self.times.astype('float')
        self.times_assert = self.times_assert.astype('float')
        self.times_deassert = self.times_deassert.astype('float')
