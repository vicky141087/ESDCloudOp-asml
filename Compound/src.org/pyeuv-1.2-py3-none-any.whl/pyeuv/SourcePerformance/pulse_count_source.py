import numpy as np
import pandas as pd
from math import floor

from pyeuv.RT_Processing.compound_metric import CompoundMetric


class PulseCount(CompoundMetric):
    def __init__(self):
        """
        Initialize the object.
        """
        super(PulseCount, self).__init__("PULSE_COUNT_SOURCE")

    @staticmethod
    def process_signals(df):
        """
        Make pulse count columns (total pulse counts and Gp).
        Hereto, it sums up the pulse counts of each exposure (RT5)
        Note that this has to be called for the whole machine for a total machine pulsecount
        or per collector to get a collector pulse count.
        Otherwise, it only has a relative, and no absolute meaning.

        :param df: input dataframe containing RT5 pulse count data
        :return: dataframe with pulse count information
        """

        # negative pulsecounts exist, remove them (threat them as zero pulsecount
        df = df[df['BDpulseCount'] > 0]

        df = df.sort_index()
        df['_pulse_count'] = df['BDpulseCount'].cumsum()
        df['_pulse_count_gp'] = df['_pulse_count'] * 1.e-9

        df = df.drop(columns=['BDpulseCount'])
        df = df.dropna()
        return df
