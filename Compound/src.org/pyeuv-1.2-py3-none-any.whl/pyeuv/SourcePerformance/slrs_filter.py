import numpy as np
import pandas as pd
from pyeuv.RT_Processing.compound_metric import CompoundMetric


class SLRSFilter(CompoundMetric):
    def __init__(self):
        """
        Initialize metric object
        """
        super(SLRSFilter, self).__init__("SLRS_FILTER")

    @staticmethod
    def process_signals(df):
        """
        Calculates conversion efficiency (CE)
        See D000432786 for details

        :return: dataframe with single column containing slrs_highdc_euv
        """

        # drop duplicate index because I saw them
        df = df.loc[~df.index.duplicated(keep='first')]

        ecal_indexes = df.index[~df["RT12.t"].isna()]

        max_exposure_crawl = 5
        max_timespan = pd.Timedelta("30s")
        max_dc_delta = 0.5
        df["slrs_highdc_euv"] = np.NaN
        slrs_highdc_euv_colnr = df.columns.get_loc("slrs_highdc_euv")
        measured_euv_colnr = df.columns.get_loc("RT36.BDenergyMeasuredEUVMean")

        end_time = pd.to_timedelta(df['RT05.BDbeginTime'].index.tz_localize(None).to_series()). \
            apply(lambda x: x.total_seconds())
        start_time = df['RT05.BDbeginTime'] + 1.0e-9 * df['RT05.BDbeginNSecs']
        duration = end_time - start_time
        df['_BurstDuration'] = duration
        df['_DutyCycle'] = 100.0 * df["RT05.BDpulseCount"] / df["RT05.BDrepRateAvgMean"] / df["_BurstDuration"]
        for index in ecal_indexes:
            start_index = df.index.get_loc(index)
            prev_dc = -1
            for i in range(1, max_exposure_crawl):
                if start_index - i < 0:
                    continue
                row = df.iloc[start_index - i, :]
                if ((100 - max_dc_delta) <= prev_dc <= (100 + max_dc_delta)) and \
                        (row["_DutyCycle"] <= (100 - max_dc_delta)) and \
                        ((df.index[start_index] - df.index[start_index - i]) < max_timespan):
                    # print(df.index[start_index] - df.index[start_index-i])
                    # this is the filtered euv value we are looking for
                    df.iloc[start_index - i, slrs_highdc_euv_colnr] = df.iloc[start_index - i, measured_euv_colnr]
                    break

                prev_dc = row["_DutyCycle"]

        return df

    @staticmethod
    def convert_dict_to_dataframe(input_dict, machine_version):
        """
        Merges the dataframes that are contained in the dict.

        :param input_dict: the dictionary with dataframes
        :param machine_version: valid values are 'S1', 'S2' or 'S3'. Validation depends on machine version
        :return: dataframe of merged data
        """

        if machine_version.upper() in ['S1', 'S2']:
            df = input_dict['RT05']

        else:
            rt05_df = input_dict['RT05']
            rt26_df = input_dict['RT26']

            rt05_df = rt05_df[['BDenergyAvgOn']]
            df = pd.concat([rt05_df, rt26_df], axis=1)

        return df

    @staticmethod
    def input_dict_is_valid(input_dict, machine_version, verbose=False):
        """
        Validate the input dictionary.
        It should contain the keys RT05 and RT26.
        The dataframes per key should not be empty (for S1 and S2, RT26 is not required)

        :param input_dict: the input dictionary to be validated
        :param machine_version: valid values are 'S1', 'S2' or 'S3'. Validation depends on machine version
        :return: True if input dictionary is valid
        """

        for rt in ['RT05', 'RT26']:
            if rt not in input_dict:
                if verbose:
                    print("No {} data, returning empty dataframe.".format(rt))
                return False

        if input_dict['RT05'].empty:
            if verbose:
                print("No RT05 data, returning empty dataframe.")
            return False

        if (not machine_version.upper() in ['S1', 'S2']) & input_dict['RT26'].empty:
            if verbose:
                print("No RT26 data (required from S3 onwards), returning empty dataframe.")
            return False

        return True
