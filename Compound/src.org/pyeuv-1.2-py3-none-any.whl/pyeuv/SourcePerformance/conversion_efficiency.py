import numpy as np
import pandas as pd
from pyeuv.RT_Processing.compound_metric import CompoundMetric


class ConversionEfficiency(CompoundMetric):
    def __init__(self):
        """
        Initialize metric object
        """
        super(ConversionEfficiency, self).__init__("KPI_CE")

    def process_signals(self, input_data, machine_version=None):
        """
        Calculates conversion efficiency (CE)
        See D000432786 for details

        The calculation depends on the version of the system. S1,S2 differs from S3

        :param input_data: pandas/dask dataframe or dictionary of signals per signal group
        :param machine_version: machine version (expected: 'S1'/'S2'/'S3', default=None)
        :return: dataframe with single column '_CE', containing conversion efficiency
        """

        if machine_version is None:
            print("No machine_version provided, returning empty dataframe.")
            return pd.DataFrame()

        if type(input_data) == pd.DataFrame:
            df = input_data

        elif type(input_data) == dict:

            if not ConversionEfficiency.input_dict_is_valid(input_data, machine_version):
                return pd.DataFrame()

            df = ConversionEfficiency.convert_dict_to_dataframe(input_data)

        else:
            print("Incorrect input data. Expected a dataframe or dict, got {}, returning empty dataframe.".format(
                type(input_data)))
            return pd.DataFrame()

        if machine_version.upper() in ['S1', 'S2']:
            df['_CE'] = 100 * (df['RT05.BDenergyAvgOn'] / (df['RT05.BDfcem1MpEnergyMeanOn'] * 0.221))

        else:
            # forward fill rt05 data to rt26 data
            df['RT05.BDenergyAvgOn'] = df['RT05.BDenergyAvgOn'].fillna(method='ffill', limit=1)
            df = df.dropna(subset=['RT05.BDenergyAvgOn', 'RT26.BDfcem1MpEnergyMeanOn'])
            df = df.loc[~df.index.duplicated(keep='last')]

            # Noise level 0.2 mJ
            df = df.loc[df['RT05.BDenergyAvgOn'] > 0.2]

            # T_bts_MP = 0.84
            # S3_product_factor = 1.73
            df['_CE'] = 100 * df['RT05.BDenergyAvgOn'] / (df['RT26.BDfcem1MpEnergyMeanOn'] * 0.84) * 2 * np.pi / 1.73

        df = df[['_CE']]
        df = df.dropna()

        return df

    @staticmethod
    def convert_dict_to_dataframe(input_dict):
        """
        Merges the dataframes that are contained in the dict to a single dataframe
        The signal group is added to the front of the column name to ensure unique column names

        :param input_dict: the dictionary with dataframes
        :return: dataframe of merged data
        """

        df_merged = pd.DataFrame()
        for signal_group in input_dict:
            df = input_dict[signal_group]
            for c in df.columns:
                df.rename(columns={c: '{}.{}'.format(signal_group, c)}, inplace=True)
            if df_merged.empty:
                df_merged = df.copy()
            else:
                df_merged = pd.merge(df_merged, df, how='outer',
                                     left_index=True, right_index=True)

        return df_merged

    @staticmethod
    def input_dict_is_valid(input_dict, machine_version):
        """
        Validate the input dictionary.
        It should contain the keys RT05 and RT26.
        The dataframes per key should not be empty (for S1 and S2, RT26 is not required)

        :param input_dict: the input dictionary to be validated
        :param machine_version: valid values are 'S1', 'S2' or 'S3'. Validation depends on machine version
        :return: True if input dictionary is valid
        """

        for rt in ['RT05', 'RT26']:
            if rt not in input_dict:
                print("No {} data, returning empty dataframe.".format(rt))
                return False

        if input_dict['RT05'].empty:
            print("No RT05 data, returning empty dataframe.")
            return False

        if (not machine_version.upper() in ['S1', 'S2']) & input_dict['RT26'].empty:
            print("No RT26 data (required from S3 onwards), returning empty dataframe.")
            return False

        return True
