import numpy as np
import pandas as pd
from pyeuv.RT_Processing.compound_metric import CompoundMetric


class SystemStateDecomposition(CompoundMetric):
    def __init__(self):
        """
        Initialize the object.
        """
        super(SystemStateDecomposition, self).__init__("SYSTEM_STATE_DECOMPOSITION")

    def default_config_parameters(self):
        return {"max_state_duration": 900.0}

    def process_signals(self, df, max_state_duration=900.0):
        """
        Derives the system state from both exposure and co2 data
        Ask Benny Renkens for details

        :return: dataframe with a 'level_wafer_detail', 'state_start', 'state_end' column
        """
        exposure_states = self.make_states_from_exposure_data(df, max_state_duration=max_state_duration)
        co2_states = self.make_states_from_co2_data(df)
        overall_states = pd.concat([exposure_states, co2_states])

        overall_states = overall_states.sort_index()

        # delete states that take longer than the max_state_duration
        state_duration = overall_states["state_end"] - overall_states["state_start"]
        max_duration_delta = pd.Timedelta('{}s'.format(max_state_duration))
        res = overall_states.loc[state_duration <= max_duration_delta, :]
        return res

    def make_states_from_co2_data(self, df):
        """
        Extract the system state from co2 data

        :param df: input dataframe
        :return: dataframe with system state decomposition information
        """
        df_co2_firing_state_changes = df["LSP.LSP_HPSM_PM5_1_Rejected_Power"].dropna().resample("5S",
                                                                                                 label='left').mean().to_frame()
        df_plc_firing_state_changes = df["PLCSTATUS.DLPA3_PB_TASC_WINDOW_TEMP"].dropna().resample("5S",
                                                                                                 label='left').mean().to_frame()

        df_co2_firing_state_changes = pd.merge(df_co2_firing_state_changes,
                                               df_plc_firing_state_changes,
                                               left_index=True, right_index=True, how='inner')

        mask_fire_off_target = ((df_co2_firing_state_changes["LSP.LSP_HPSM_PM5_1_Rejected_Power"] < 10.0) &
                                (df_co2_firing_state_changes["PLCSTATUS.DLPA3_PB_TASC_WINDOW_TEMP"] > 15000.0))

        df_co2_firing_state_changes = mask_fire_off_target[mask_fire_off_target.astype(np.int32).diff() != 0]

        df_co2_firing_state_changes = df_co2_firing_state_changes.to_frame(name="off_target_state")
        df_co2_firing_state_changes["state_start"] = df_co2_firing_state_changes.index

        # mark the start of on-target as the end of the previous off-target
        df_co2_firing_state_changes["state_end"] = df_co2_firing_state_changes["state_start"].shift(-1)

        # drop the ON-target state periods
        df_co2_firing_state_changes = df_co2_firing_state_changes[
            df_co2_firing_state_changes["off_target_state"] == 1]

        states = df_co2_firing_state_changes.drop(labels=['off_target_state'], axis=1)
        states["level_wafer_detail"] = 4.0
        states = states[['level_wafer_detail', 'state_start', 'state_end']]
        new_columns = ['level_wafer_detail', 'state_start', 'state_end']
        states = states.rename(columns=dict(zip(states.columns, new_columns)))

        return states

    def make_states_from_exposure_data(self, df, max_state_duration=900.0):
        """
        Extract the system state from exposure data

        :param df: input dataframe
        :param max_state_duration: optional parameter indicating the maximum duration in seconds of the state
        :return:  dataframe with system state decomposition information
        """
        # get coarse ecal based states
        wafer_states = self.create_ecal_based_states(df, max_state_duration)
        df_states = self.create_rt05_based_states(df)

        df_states = pd.merge(df_states, wafer_states, how='outer',
                             left_index=True, right_index=True, indicator=True)

        df_states["ecal_flag"] = np.NaN
        df_states["ecal_flag"] = df_states["ecal_flag"].mask(df_states["_merge"] == 'right_only', other=1)

        # ignore bits which are not "state transitions" and can come in the middle of a sequence of exposures
        mask_empty_values = df_states["RT05.BDmiscellaneousStatus"].isna()
        df_states["RT05.BDmiscellaneousStatus"] = df_states["RT05.BDmiscellaneousStatus"].fillna(0).astype(
            np.uint32) & np.uint32(~(1 << 2))  # bit 3 is queue flushed, no relation with state change
        df_states["RT05.BDmiscellaneousStatus"] = df_states["RT05.BDmiscellaneousStatus"].astype(np.float32)
        df_states["RT05.BDmiscellaneousStatus"] = df_states["RT05.BDmiscellaneousStatus"].mask(mask_empty_values,
                                                                                               other=np.NaN)

        # now we save exposures which are:
        # 1) the first ones in a new state according to BDmiscellaneousStatus
        # 2) the last ones in a state according to BDmiscellaneousStatus
        # 3) the first ones in a new period (overlaps largely with 1)
        # 4) the last ones in a period (overlaps largely with 2)
        df_states = df_states[(df_states["RT05.BDmiscellaneousStatus"].diff() != 0) |
                              (df_states["RT05.BDmiscellaneousStatus"].diff().shift(-1) != 0) |
                              (df_states["ecal_flag"].shift(-1) == 1) |
                              (df_states["ecal_flag"].shift(1) == 1)]

        df_states["fast_euv_gate_flag"] = (
                df_states["RT05.BDmiscellaneousStatus"].fillna(0).astype(np.uint32) & (1 << 24) != 0).astype(np.int32)
        df_states["die_repair_flag"] = (
                df_states["RT05.BDmiscellaneousStatus"].fillna(0).astype(np.uint32) & (1 << 29) != 0).astype(np.int32)

        # the production part of the wafer starts when the flag goes from 0 to 1 or when it's the first
        # exposure after the ecal with the flag up (but there was no different state indicated by
        # BDmiscellaneousStatus)
        mask_wafer_start = ((df_states["fast_euv_gate_flag"].diff() == 1) |
                            ((df_states["_merge"] == 'right_only').shift(1) == 1) &
                            (df_states["fast_euv_gate_flag"] == 1))

        # for die repair we can simply check the transition of the profile bit
        mask_die_repair_start = df_states["die_repair_flag"].diff() == 1

        # wafer prep start is the first exposure which happens after an ecal with the fast euv gate low
        mask_wafer_prep_start = (((df_states["_merge"] == 'right_only').shift(1) == 1) &
                                 (df_states["fast_euv_gate_flag"] == 0))

        # by default we say, every state transition now is an unknown state, except the ones we defined in the
        # previous lines
        mask_unkown_state_start = df_states["RT05.BDmiscellaneousStatus"].fillna(method='ffill').diff().fillna(0).astype(np.uint32) != 0
        mask_unkown_state_start = mask_unkown_state_start.mask(mask_wafer_start, other=False)
        mask_unkown_state_start = mask_unkown_state_start.mask(mask_die_repair_start, other=False)
        mask_unkown_state_start = mask_unkown_state_start.mask(mask_wafer_prep_start, other=False)

        # filling the states for each exposure
        df_states_level_ecal_period = df_states.index.to_series()
        # drop duplicate index because I saw them
        df_states_level_ecal_period = df_states_level_ecal_period[
            ~df_states_level_ecal_period.index.to_series().duplicated()].astype(np.int64)
        df_states_merge = (df_states["_merge"] == 'right_only')
        df_states['level_ecal_period'] = df_states_level_ecal_period.where(df_states_merge, other=np.nan)
        df_states['level_wafer_detail'] = np.NaN
        df_states['level_wafer_detail'] = df_states['level_wafer_detail'].mask(mask_unkown_state_start, other=-1)
        df_states['level_wafer_detail'] = df_states['level_wafer_detail'].mask(mask_wafer_start, other=1.0)
        df_states['level_wafer_detail'] = df_states['level_wafer_detail'].mask(mask_wafer_prep_start, other=2.0)
        df_states['level_wafer_detail'] = df_states['level_wafer_detail'].mask(mask_die_repair_start, other=3.0)

        df_states['level_wafer_detail'].fillna(method='ffill', inplace=True)

        # now apply some corrections, like the ecal moments itself. they can still be located with the merge column
        df_states['level_wafer_detail'] = df_states['level_wafer_detail'].mask(df_states['_merge'] == 'right_only',
                                                                               other=np.NaN)

        # determine the start and end-time of each state
        df_states['unique_state_id'] = (df_states.level_wafer_detail != df_states.level_wafer_detail.shift()).fillna(
            1).cumsum()
        df_states = df_states[df_states['level_wafer_detail'] >= 0.0]

        df_states = df_states.groupby('unique_state_id').agg({'level_wafer_detail': ['first'],
                                                              '_StartTime': ['first'],
                                                              '_EndTime': ['last']})
        df_states.columns = df_states.columns.droplevel(1)
        df_states = df_states.set_index("_StartTime", drop=False)

        new_columns = ['level_wafer_detail', 'state_start', 'state_end']
        df_states = df_states.rename(columns=dict(zip(df_states.columns, new_columns)))
        return df_states

    def create_ecal_based_states(self, states, max_state_duration=900.0):
        """
        Use ecal data to get basic wafer state information
        Too long states are filtered based on max_state_duration

        :param states:
        :param max_state_duration: optional parameter indicating the maximum duration in seconds of the state
        :return: dataframe with the states (start, end)
        """

        states = states[['RT12.t']].dropna()
        states['ecal'] = states['RT12.t'].index
        states["next_ecal"] = states['ecal'].shift(-1)
        states = states.dropna()  # drops the last row because of the shift
        states["duration"] = (states["next_ecal"] - states["ecal"]).dt.seconds

        # first we determine the correct endings for the periods which take too long
        states["period_end"] = states["next_ecal"]
        states["period_start"] = states["ecal"]
        states["period_end"] = states["period_end"].where(
            states["duration"] <= max_state_duration,
            other=states["ecal"] + pd.Timedelta('{}s'.format(max_state_duration))
        )

        # drop the columns we don't need anymore
        states = states.drop(labels=['ecal', 'next_ecal', 'duration'], axis=1)

        return states

    def create_rt05_based_states(self, df):
        """
        Calculates the start and end of an exposure

        :param df: input dataframe
        :return: dataframe with stat and end time of the exposure
        """
        signals = ['RT05.{}'.format(s) for s in self.configuration['INPUT_GROUPS']['RT05']]
        df = df[signals]
        df = df.dropna(how='all')

        start_time = df['RT05.BDbeginTime'] + 1.0e-9 * df['RT05.BDbeginNSecs']
        df['_StartTime'] = pd.to_datetime(start_time, unit='s')
        df['_EndTime'] = df.index.to_series()

        df = df.drop(columns=['RT05.BDbeginTime', 'RT05.BDbeginNSecs'])

        return df
