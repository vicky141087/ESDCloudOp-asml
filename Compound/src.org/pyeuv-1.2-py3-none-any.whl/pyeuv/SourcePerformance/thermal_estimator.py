import numpy as np
import pandas as pd
import datetime

from pyeuv.RT_Processing.compound_metric import CompoundMetric, static_var


class ThermalEstimator(CompoundMetric):
    def __init__(self):
        """
        Initialize metric.
        Besides the generic initialization, it also initializes the previous states of the drive laser and EUV
        :param prev_euv_state: previous thermal state of EUV
        :param prev_dl_state: previous thermal state of drive laser
        """
        super(ThermalEstimator, self).__init__("KPI_THERMAL_STATE")

    @staticmethod
    def process_signals(input_data, time_constants=None, sample_rate=10,
                        dl_on_threshold=5000, euv_on_threshold=0.25):
        """
        Determine the thermal state of the system, based on drive laser and EUV.
        The thermal state is a value between 0 and 1.

        The algorithm follows these steps:
        - create a timeline based on the sample rate
        - create a binary signal from the input signals (on/off), using the threshold values.
        - merge the binary state data to the timeline
        - loop over the timeline and exponentially adjust the thermal state: ts_now = ts_prev + k * (state * ts_prev),
        where k is the time constant

        :param input_data: pandas/dask dataframe or dictionary of signals per signal group
        :param time_constants: list of time constant, expressed in hours. For example [0.25, 0.5, 1, 2, 4, 8]
        :param sample_rate: rate of signal calculation, expressed in seconds
        :param dl_on_threshold: threshold above which it is assumed the drive laser is on
        :param euv_on_threshold: threshold above which it is assumed EUV is made
        :return: dataframe with thermal estimator data
        """

        if type(input_data) == pd.DataFrame:
            df = input_data
        elif type(input_data) == dict:
            df = ThermalEstimator.convert_dict_to_dataframe(input_data)
        else:
            print("Incorrect input data. Expected a dataframe or dict, got {}, returning empty dataframe.".format(
                type(input_data)))
            return pd.DataFrame()

        if not isinstance(time_constants, list):
            if np.isfinite(time_constants):
                time_constants = [time_constants]

        output_names = ["thermal_est_{}hr".format(time_const.replace('.','_dot_') for time_const in time_constants]
        alpha = [ThermalEstimator.lifetime(time_const, sample_rate) for time_const in time_constants]

        if df.empty:
            return pd.DataFrame()

        # create binary signals
        df_euv = df[["PLCSTATUS.DLPA3_PB_TASC_WINDOW_TEMP"]].dropna()
        df_euv["DL_ON"] = df_euv["PLCSTATUS.DLPA3_PB_TASC_WINDOW_TEMP"] > dl_on_threshold
        df_euv["DL_ON"] = df_euv["DL_ON"].astype(np.int64)

        df_dl = df[["RT05.BDenergyAvgOn"]].dropna()
        df_dl["EUV_ON"] = df_dl["RT05.BDenergyAvgOn"] > euv_on_threshold
        df_dl["EUV_ON"] = df_dl["EUV_ON"].astype(np.int64)

        # determine the start and end of the generated signal
        min_time = min([df_dl.index.min(), df_euv.index.min()])
        max_time = max([df_dl.index.max(), df_euv.index.max()])
        # generate a timeline
        time_line = pd.date_range(min_time, max_time, freq='{}s'.format(sample_rate))

        # merge the drive laser on/off info into the timeline
        df = pd.merge_asof(time_line.to_frame(), df_dl[["EUV_ON"]], left_index=True, right_index=True,
                           direction='nearest',
                           tolerance=pd.Timedelta('{}s'.format(sample_rate)))

        # merge the euv on/off info into the timeline
        df = pd.merge_asof(df, df_euv[["DL_ON"]], left_index=True, right_index=True,
                           direction='nearest',
                           tolerance=pd.Timedelta('{}s'.format(sample_rate)))

        # there are only RT5 Samples when the system is making light, so we have to assume the nans are EUV OFF
        df["EUV_ON"].fillna(value=0, inplace=True)

        # only keep the 2 columns we want
        df = df[["EUV_ON", "DL_ON"]]

        ThermalEstimator.estimate_thermal_state.prev_state = None
        df_dl_thermal = df["DL_ON"].apply(ThermalEstimator.estimate_thermal_state, alpha=alpha)
        df_dl_thermal = pd.DataFrame(df_dl_thermal.tolist(), columns=["DL_{}".format(col) for col in output_names],
                                     index=df.index)

        ThermalEstimator.estimate_thermal_state.prev_state = None
        df_euv_thermal = df["EUV_ON"].apply(ThermalEstimator.estimate_thermal_state, alpha=alpha)
        df_euv_thermal = pd.DataFrame(df_euv_thermal.tolist(), columns=["EUV_{}".format(col) for col in output_names],
                                      index=df.index)

        # make one big dataframe
        df_thermal = pd.merge(df_dl_thermal, df_euv_thermal, left_index=True, right_index=True, how='inner')

        return df_thermal

    @staticmethod
    def lifetime(hours, sample_rate):
        return 1 / (hours * 60 * 60 / sample_rate)

    @static_var("prev_state", None)
    @staticmethod
    def estimate_thermal_state(x, alpha, th=1, t0=0, verbose=False):
        """
        Estimate the thermal state based on the previous state, the thermal constant and current value

        :param x: current value (0 or 1)
        :param alpha: list of thermal constants. In case it is no list, it will be converted.
        :param th: upper threshold of estimator
        :param t0: lower threshold for estimator
        :param verbose: switches debug mode (default: False)
        :return: list of current thermal states, same length as alpha
        """
        if not isinstance(alpha, list):
            if np.isfinite(alpha):
                alpha = [alpha]

        # initialize the first cycle
        if ThermalEstimator.estimate_thermal_state.prev_state is None:
            ThermalEstimator.estimate_thermal_state.prev_state = np.zeros(len(alpha))

        # only do something with numeric values
        if np.isfinite(x):
            if x == 1:
                # system is heating up
                target = th
            elif x == 0:
                # system is cooling down
                target = t0
            else:
                target = t0
                if verbose:
                    print("unkown thermal indicator. expected 0/1, but got %d", x)

            for i in range(len(alpha)):
                # perform the calculation
                val = ThermalEstimator.estimate_thermal_state.prev_state[i] + alpha[i] * \
                      (target - ThermalEstimator.estimate_thermal_state.prev_state[i])

                # save the current result as previous
                ThermalEstimator.estimate_thermal_state.prev_state[i] = val

            res = ThermalEstimator.estimate_thermal_state.prev_state.tolist()
        else:
            res = len(alpha) * [np.nan]

        return res

    @staticmethod
    def convert_dict_to_dataframe(input_dict):
        """
        Merges the dataframes that are contained in the dict.

        :param input_dict: the dictionary with dataframes
        :return: dataframe of merged data
        """

        df = pd.DataFrame()
        for signal_group, df_group in input_dict.items():
            df = pd.concat([df, df_group], axis=1)

        return df
