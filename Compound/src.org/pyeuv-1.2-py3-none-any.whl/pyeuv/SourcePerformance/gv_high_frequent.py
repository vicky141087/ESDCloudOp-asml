import pandas as pd

from pyeuv.RT_Processing.compound_metric import CompoundMetric


class GVHighFrequent(CompoundMetric):
    def __init__(self):
        """
        Initialize the object.
        """
        super(GVHighFrequent, self).__init__("GV_HIGH_FREQUENT")

    @staticmethod
    def process_signals(df, max_pressure=1000):
        """
        Calculate high frequent vessel delta pressure
        Based on euvdb
        https://apps-bbdc-prd.asml.com/projects/EUVDB/repos/euvdb/browse/worker.py

        :param df: input dataframe containing RT5 pulse count data
        :param max_pressure in Pascal (default=1000).
        :return: dataframe with pulse count information
        """

        # calculate delta pressure
        if ('GV_VAC_VES_PRS2_ABS' in list(df.keys())) & ('GV_VAC_VES_PRS1_ABS' in list(df.keys())):
            # Only calculate for pressures (smaller than 10mBar )
            msk = df['GV_VAC_VES_PRS2_ABS'] < max_pressure

            df['_PRS2minusPRS1'] = df['GV_VAC_VES_PRS2_ABS'][msk] - df['GV_VAC_VES_PRS1_ABS'][msk]
            df = df[['_PRS2minusPRS1']]
            df = df.dropna()
        else:
            df = pd.DataFrame(columns=['_PRS2minusPRS1'])
        return df
