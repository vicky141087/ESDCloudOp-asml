import numpy as np
import pandas as pd
from pyeuv.RT_Processing.compound_metric import CompoundMetric
from pyeuv.TinManagement.vanes import extract_thermal_cycles, extract_vane_spitting_area
from pyeuv.TinManagement.vanes import calc_vanes_top_bot_min_mean_max


class ThermalCyclingGWE(CompoundMetric):
    """
    Class for thermal cycling metrics for GWE systems

    :param CompoundMetric (Class): inherits from the basic CompoundMetric class
    """

    def __init__(self):
        """
        Initialize metric object
        """
        super(ThermalCyclingGWE, self).__init__("THERMAL_CYCLING_GWE")

    @staticmethod
    def process_signals(df, pc):
        """
        Run the calculations

        :param df: dataframe containing correct columns
        :param pc: pulsecount dataframe

        :return: dataframe with thermal cycling metrics
        """

        if len(pc) == 0:
            print('No pulsecount data')
            return pd.DataFrame()

        df.rename(columns={
            'Vanes_Bottom_Temperature.MEAN': 'vanes_bottom',
            'Vanes_Bottom_Temperature.MIN': 'vanes_bottom_min',
            'Vanes_Bottom_Temperature.MAX': 'vanes_bottom_max',
            'Vanes_Top_Temperature.MEAN': 'vanes_top',
            'Vanes_Top_Temperature.MIN': 'vanes_top_min',
            'Vanes_Top_Temperature.MAX': 'vanes_top_max',
            "KPI_Vanes.Vanes_BottomVane02_Temperature": "S02B",
            "KPI_Vanes.Vanes_TopVane03_Temperature": "S03T",
            "KPI_Vanes.Vanes_BottomVane07_Temperature": "S07B",
            "KPI_Vanes.Vanes_TopVane08_Temperature": "S08T",
            "KPI_Vanes.Vanes_BottomVane12_Temperature": "S12B",
            "KPI_Vanes.Vanes_TopVane13_Temperature": "S13T",
            "KPI_Vanes.Vanes_BottomVane17_Temperature": "S17B",
            "KPI_Vanes.Vanes_TopVane18_Temperature": "S18T",
            "KPI_Vanes.Vanes_BottomVane22_Temperature": "S22B",
            "KPI_Vanes.Vanes_TopVane23_Temperature": "S23T",
            "KPI_Vanes.Vanes_BottomVane27_Temperature": "S27B",
            "KPI_Vanes.Vanes_TopVane28_Temperature": "S28T",
            "KPI_Vanes.Vanes_BottomVane32_Temperature": "S32B",
            "KPI_Vanes.Vanes_TopVane33_Temperature": "S33T",
            "KPI_Vanes.Vanes_BottomVane37_Temperature": "S37B",
            "KPI_Vanes.Vanes_TopVane38_Temperature": "S38T",
            "KPI_Vanes.Vanes_BottomVane42_Temperature": "S42B",
            "KPI_Vanes.Vanes_TopVane43_Temperature": "S43T",
            "KPI_Vanes.Vanes_BottomVane47_Temperature": "S47B",
            "KPI_Vanes.Vanes_TopVane48_Temperature": "S48T",
            "KPI_Vanes.Vanes_BottomVane52_Temperature": "S52B",
            "KPI_Vanes.Vanes_TopVane53_Temperature": "S53T",
            "KPI_Vanes.Vanes_BottomVane57_Temperature": "S57B",
            "KPI_Vanes.Vanes_TopVane58_Temperature": "S58T"
            }, inplace=True)
        for c in df.columns:
            df[c] = df[c] - 273.15
            if 'vanes_' not in c:
                # Filter out-of-bounds sensor data
                df[c][(df[c] < 0.0) | (df[c] > 400.0)] = np.NaN

        thermal_cycles_columns = ['vanes_bottom', 'vanes_bottom_min', 'vanes_bottom_max',
                                  'vanes_top', 'vanes_top_min', 'vanes_top_max']

        vane_spitting_columns = ['S02B', 'S03T', 'S07B', 'S08T', 'S12B', 'S13T',
                                 'S17B', 'S18T', 'S22B', 'S23T', 'S27B', 'S28T',
                                 'S32B', 'S33T', 'S37B', 'S38T', 'S42B', 'S43T',
                                 'S47B', 'S48T', 'S52B', 'S53T', 'S57B', 'S58T']

        df_tc = df[thermal_cycles_columns].dropna(how='all')
        df_tc = df_tc.join(pc[['_pulse_count']], how='outer')
        df_tc.rename(columns={'_pulse_count': 'pulse_count'}, inplace=True)
        df_tc['pulse_count'].interpolate(inplace=True)

        # convert pulse_count to Gp
        df_tc['pulse_count'] *= 1e-9

        # drop rows where pulse_count is nan
        df_tc.dropna(subset=['pulse_count'], inplace=True)

        # drop rows where thermal cycling columns are nan
        df_tc.dropna(subset=thermal_cycles_columns, how='all', inplace=True)

        # extract phases
        df_vs = df[vane_spitting_columns].dropna(how='all')
        phases = extract_thermal_cycles(df_tc, df_vs)
        df = extract_vane_spitting_area(df_vs)

        df = build_df_from_phases(df, phases)

        if 'spitting_area' in df.columns:
            df_spitting_filter = (df['spitting_area'] == 0) & (df['phases_hot_start'].isna()) & (df['phases_warm_start'].isna())
            df.loc[df_spitting_filter, 'spitting_area'] = np.nan
            df.dropna(subset=['spitting_area'], inplace=True)
        return df


class ThermalCyclingMV(CompoundMetric):
    """
    Class for thermal cycling metrics for MV systems

    :param CompoundMetric (Class): inherits from the basic CompoundMetric class
    """

    def __init__(self):
        """
        Initialize metric object
        """
        super(ThermalCyclingMV, self).__init__("THERMAL_CYCLING_MV")

    @staticmethod
    def process_signals(df, pc):
        """
        Run the calculations

        :param df: dataframe containing correct columns
        :param pc: pulsecount dataframe

        :return: dataframe with thermal cycling metrics
        """

        if len(pc) == 0:
            print('No pulsecount data')
            return pd.DataFrame()

        for c in df.columns:
            df[c] = df[c] - 273.15
            # Filter out-of-bounds sensor data
            df[c][(df[c] < 0.0) | (df[c] > 400.0)] = np.NaN

        df = calc_vanes_top_bot_min_mean_max(df)

        df.rename(columns={
            "KPI_FV.FV_Group01Top_Temperature_Vane03": "S03T",
            "KPI_FV.FV_Group01Bottom_Temperature_Vane04": "S04B",
            "KPI_FV.FV_Group02Top_Temperature_Vane09": "S09T",
            "KPI_FV.FV_Group02Bottom_Temperature_Vane11": "S11B",
            "KPI_FV.FV_Group03Top_Temperature_Vane15": "S15T",
            "KPI_FV.FV_Group03Bottom_Temperature_Vane17": "S17B",
            "KPI_FV.FV_Group04Top_Temperature_Vane21": "S21T",
            "KPI_FV.FV_Group04Bottom_Temperature_Vane23": "S23B",
            "KPI_FV.FV_Group05Top_Temperature_Vane28": "S28T",
            "KPI_FV.FV_Group05Bottom_Temperature_Vane29": "S29B",
            "KPI_FV.FV_Group06Top_Temperature_Vane33": "S33T",
            "KPI_FV.FV_Group06Bottom_Temperature_Vane34": "S34B",
            "KPI_FV.FV_Group07Top_Temperature_Vane39": "S39T",
            "KPI_FV.FV_Group07Bottom_Temperature_Vane41": "S41B",
            "KPI_FV.FV_Group08Top_Temperature_Vane45": "S45T",
            "KPI_FV.FV_Group08Bottom_Temperature_Vane47": "S47B",
            "KPI_FV.FV_Group09Top_Temperature_Vane51": "S51T",
            "KPI_FV.FV_Group09Bottom_Temperature_Vane53": "S53B",
            "KPI_FV.FV_Group10Top_Temperature_Vane58": "S58T",
            "KPI_FV.FV_Group10Bottom_Temperature_Vane59": "S59B",
            "KPI_FVG.FVG_DGSideDoor_Temperature": "FVG_DGSideDoor_Temperature",
            "KPI_FVG.FVG_DGSideScanner_Temperature": "FVG_DGSideScanner_Temperature",
            "KPI_FVG.FVG_SDM_Temperature": "FVG_SDM_Temperature",
            "KPI_FVG.FVG_TCSideDoor_Temperature": "FVG_TCSideDoor_Temperature",
            "KPI_FVG.FVG_TCSideScanner_Temperature": "FVG_TCSideScanner_Temperature"
            }, inplace=True)

        thermal_cycles_columns = ['vanes_bottom', 'vanes_bottom_min', 'vanes_bottom_max',
                                  'vanes_top', 'vanes_top_min', 'vanes_top_max']

        vane_spitting_columns = ['S03T', 'S04B', 'S09T', 'S11B', 'S15T', 'S17B',
                                 'S21T', 'S23B', 'S28T', 'S29B', 'S33T', 'S34B',
                                 'S39T', 'S41B', 'S45T', 'S47B', 'S51T', 'S53B',
                                 'S58T', 'S59B',
                                 "FVG_DGSideDoor_Temperature",
                                 "FVG_DGSideScanner_Temperature",
                                 "FVG_SDM_Temperature",
                                 "FVG_TCSideDoor_Temperature",
                                 "FVG_TCSideScanner_Temperature"]

        df_tc = df[thermal_cycles_columns].dropna(how='all')
        df_tc = df_tc.join(pc[['_pulse_count']], how='outer')
        df_tc.rename(columns={'_pulse_count': 'pulse_count'}, inplace=True)
        df_tc['pulse_count'].interpolate(inplace=True)

        # convert pulse_count to Gp
        df_tc['pulse_count'] *= 1e-9

        # drop rows where pulse_count is nan
        df_tc.dropna(subset=['pulse_count'], inplace=True)

        # drop rows where thermal cycling columns are nan
        df_tc.dropna(subset=thermal_cycles_columns, how='all', inplace=True)

        # extract phases
        df_vs = df[vane_spitting_columns].dropna(how='all')        
        phases = extract_thermal_cycles(df_tc, df_vs)
        df = extract_vane_spitting_area(df_vs, cooling_config='MV')

        df = build_df_from_phases(df, phases)
        
        if 'spitting_area' in df.columns:
            df_spitting_filter = (df['spitting_area'] == 0) & (df['phases_hot_start'].isna()) & (df['phases_warm_start'].isna())
            df.loc[df_spitting_filter, 'spitting_area'] = np.nan
            df.dropna(subset=['spitting_area'], inplace=True)
        return df


def build_df_from_phases(df, phases):
    """
    Builds a dataframe containing the warm and hot phase data of thermal cycling
    
    :param df: input dataframe with vane metrics
    :param phases: dictionary of warm and hot phases
    :return: dataframe with phases information
    """

    if phases:
        # add the phases data to the output df
        phases_hot = phases['hot']
        [phases_hot.rename(columns={c: 'phases_hot_' + c}, inplace=True) for c in phases_hot.columns]
        phases_warm = phases['warm']
        [phases_warm.rename(columns={c: 'phases_warm_' + c}, inplace=True) for c in phases_warm.columns]
        df = pd.merge(df, phases_hot, left_index=True, right_index=True, how='outer')
        df = pd.merge(df, phases_warm, left_index=True, right_index=True, how='outer')

        # dropping rows before and after we have thermal cycling data
        phases_index = df.dropna(subset=['phases_hot_start', 'phases_warm_start'], how='all').index
        df = df[(df.index >= phases_index.min()) & (df.index <= phases_index.max())]
    else:
        print('No phases detected')
        df = pd.DataFrame()
    return df
