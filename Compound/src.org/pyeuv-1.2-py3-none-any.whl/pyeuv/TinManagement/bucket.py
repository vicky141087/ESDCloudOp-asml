# -*- coding: utf-8 -*-
"""
bucket.py
Authors: RWKL
Date: 2018-10-17

Derive KPIs related to the tin bucket and clogging of it
"""

def get_drip_pin_clogging_signal_names():
    '''
    Returns a dictionary with influx signal names as values and human readable 
    names as keys. The dictionary includes all the mean temperature signals of the vanes.

    :return: dictionary with signal names for drip pin clogging.
    '''
    signal_names_mapping = {
            'bucket_fill_level' : 'VDR_BUCKET.Fill_level',
            'bucket_fill_level2' : 'VDR_BUCKET.FillLevel2', 
            'bucket_fill_rate_5gp' : 'VDR_BUCKET._FillRate_5Gp',
            'bucket_fill_rate_10gp' : 'VDR_BUCKET._FillRate_10Gp',
            'bucket_fill_rate_20gp' : 'VDR_BUCKET._FillRate_20Gp',
            }
    return signal_names_mapping

def get_pulse_count_signal_names():
    '''
    Returns a dictionary with influx signal names as values and human readable 
    names as keys. The dictionary contains the collector pulse count.

    :return: dictionary with signal name for collector pulse count.
    '''
    signal_names_mapping = {
            'pulse_count' : 'Collector._PulseCount',            
            }
    return signal_names_mapping

def get_data_drip_pin_clogging(client, source_id, from_time, to_time):
    '''
    Retreives all the data required for drip pin clogging analysis from influx.
    Merges the dataframes from different sources

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :return: dataframe containing bucket fill level, rate and pulse count
    '''
    
    data = client.get_signals_dict(get_drip_pin_clogging_signal_names(), 
                                   source_id, from_time, to_time)
    
    pulse_count = client.get_signals_dict(get_pulse_count_signal_names(), 
                                          source_id, from_time, to_time)
    
    data = data.join(pulse_count, how='outer')
    data.pulse_count.interpolate(inplace = True)
    
    # remove rows where we only have pulse count data
    data = data.dropna(subset=get_drip_pin_clogging_signal_names(), how='all')

    # convert pulse_count to Gp
    data.pulse_count *= 1e-9
    
    return data

