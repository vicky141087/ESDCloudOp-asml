# -*- coding: utf-8 -*-
"""
vanes.py
Authors: RWKL
Date: 2018-10-16

Derive KPIs related to thermal cycling
"""

import numpy as np
import pandas as pd


def get_specifications():
    """
    Function to return the specifications for thermal cycles
    """

    specification = {
        'config': ['REV3 TVB+', 'REV4 (MK2)'],
        'description': ['', 'improved cooling'],
        'temperature_hot_threshold': [250, 250],
        'temperature_warm_threshold': [232, 232],
        'hot_duration_min': [10 * 60, 30 * 60],
        'hot_duration_max': [600 * 60, 150 * 60],
        'first_hot_duration_min': [10 * 60, 30 * 60],
        'first_hot_duration_max': [600 * 60, 150 * 60],
        'hot_CO2_assistance': [False, True],
        'warm_duration_min': [0, 0],
        'warm_duration_max': [48 * 60, 48 * 60],
        'warm_CO2_assistance': [False, True],
        'sensors_continuously_hot': [[], ['02', '03']]
    }
    return pd.DataFrame(specification)


def get_vanes_temperature_signal_names_KPI():
    """
    Returns a dictionary with influx signal names as values and human readable
    names as keys. The dictionary includes all the mean temperature signals of the vanes.

    :return: dictionary with signal names for vanes thermal data.
    """

    aggregation = '.5m.mean'

    signal_names_mapping = {
        'S02B': 'KPI.Vanes_BottomVane02_Temperature_VALUE',
        'S03T': 'KPI.Vanes_TopVane03_Temperature_VALUE',
        'S07B': 'KPI.Vanes_BottomVane07_Temperature_VALUE',
        'S08T': 'KPI.Vanes_TopVane08_Temperature_VALUE',
        'S12B': 'KPI.Vanes_BottomVane12_Temperature_VALUE',
        'S13T': 'KPI.Vanes_TopVane13_Temperature_VALUE',
        'S17B': 'KPI.Vanes_BottomVane17_Temperature_VALUE',
        'S18T': 'KPI.Vanes_TopVane18_Temperature_VALUE',
        'S22B': 'KPI.Vanes_BottomVane22_Temperature_VALUE',
        'S23T': 'KPI.Vanes_TopVane23_Temperature_VALUE',
        'S27B': 'KPI.Vanes_BottomVane27_Temperature_VALUE',
        'S28T': 'KPI.Vanes_TopVane28_Temperature_VALUE',
        'S32B': 'KPI.Vanes_BottomVane32_Temperature_VALUE',
        'S33T': 'KPI.Vanes_TopVane33_Temperature_VALUE',
        'S37B': 'KPI.Vanes_BottomVane37_Temperature_VALUE',
        'S38T': 'KPI.Vanes_TopVane38_Temperature_VALUE',
        'S42B': 'KPI.Vanes_BottomVane42_Temperature_VALUE',
        'S43T': 'KPI.Vanes_TopVane43_Temperature_VALUE',
        'S47B': 'KPI.Vanes_BottomVane47_Temperature_VALUE',
        'S48T': 'KPI.Vanes_TopVane48_Temperature_VALUE',
        'S52B': 'KPI.Vanes_BottomVane52_Temperature_VALUE',
        'S53T': 'KPI.Vanes_TopVane53_Temperature_VALUE',
        'S57B': 'KPI.Vanes_BottomVane57_Temperature_VALUE',
        'S58T': 'KPI.Vanes_TopVane58_Temperature_VALUE',
    }

    for key in signal_names_mapping:
        signal_names_mapping[key] += aggregation

    return signal_names_mapping


def get_vanes_temperature_signal_names_KPI_FV():
    """
    Returns a dictionary with influx signal names as values and human readable
    names as keys. The dictionary includes all the mean temperature signals of the vanes.

    :return: dictionary with signal names for vanes thermal data.
    """

    aggregation = '.5m.mean'

    signal_names_mapping = {
        'S03T': 'KPI.FV_Group01Top_Temperature_Vane03_VALUE',
        'S04B': 'KPI.FV_Group01Bottom_Temperature_Vane04_VALUE',
        'S09T': 'KPI.FV_Group02Top_Temperature_Vane09_VALUE',
        'S11B': 'KPI.FV_Group02Bottom_Temperature_Vane11_VALUE',
        'S15T': 'KPI.FV_Group03Top_Temperature_Vane15_VALUE',
        'S17B': 'KPI.FV_Group03Bottom_Temperature_Vane17_VALUE',
        'S21T': 'KPI.FV_Group04Top_Temperature_Vane21_VALUE',
        'S23B': 'KPI.FV_Group04Bottom_Temperature_Vane23_VALUE',
        'S28T': 'KPI.FV_Group05Top_Temperature_Vane28_VALUE',
        'S29B': 'KPI.FV_Group05Bottom_Temperature_Vane29_VALUE',
        'S33T': 'KPI.FV_Group06Top_Temperature_Vane33_VALUE',
        'S34B': 'KPI.FV_Group06Bottom_Temperature_Vane34_VALUE',
        'S39T': 'KPI.FV_Group07Top_Temperature_Vane39_VALUE',
        'S41B': 'KPI.FV_Group07Bottom_Temperature_Vane41_VALUE',
        'S45T': 'KPI.FV_Group08Top_Temperature_Vane45_VALUE',
        'S47B': 'KPI.FV_Group08Bottom_Temperature_Vane47_VALUE',
        'S51T': 'KPI.FV_Group09Top_Temperature_Vane51_VALUE',
        'S53B': 'KPI.FV_Group09Bottom_Temperature_Vane53_VALUE',
        'S58T': 'KPI.FV_Group10Top_Temperature_Vane58_VALUE',
        'S59B': 'KPI.FV_Group10Bottom_Temperature_Vane59_VALUE',
        'FVG_DGSideDoor_Temperature': 'KPI.FVG_DGSideDoor_Temperature_VALUE',
        'FVG_DGSideScanner_Temperature': 'KPI.FVG_DGSideScanner_Temperature_VALUE',
        'FVG_SDM_Temperature': 'KPI.FVG_SDM_Temperature_VALUE',
        'FVG_TCSideDoor_Temperature': 'KPI.FVG_TCSideDoor_Temperature_VALUE',
        'FVG_TCSideScanner_Temperature': 'KPI.FVG_TCSideScanner_Temperature_VALUE'
    }

    for key in signal_names_mapping:
        signal_names_mapping[key] += aggregation

    return signal_names_mapping


def get_aggregated_vanes_temperature_signal_names():
    """
    Returns a dictionary with influx signal names as values and human readable
    names as keys. The dictionary includes all the mean temperature signals of the vanes.

    :return: dictionary with signal names for vanes thermal data.
    """
    signal_names_mapping = {
        'vanes_bottom': 'KPI.Vanes_Bottom_Temperature_MEAN',
        'vanes_top': 'KPI.Vanes_Top_Temperature_MEAN',
        'vanes_bottom_min': 'KPI.Vanes_Bottom_Temperature_MIN',
        'vanes_bottom_max': 'KPI.Vanes_Bottom_Temperature_MAX',
        'vanes_top_min': 'KPI.Vanes_Top_Temperature_MIN',
        'vanes_top_max': 'KPI.Vanes_Top_Temperature_MAX',
    }
    return signal_names_mapping


def get_vanes_temperature_signal_names_TinVanesStatus():
    """
    Returns a dictionary with influx signal names as values and human readable
    names as keys. The dictionary includes all the mean temperature signals of the vanes.

    :return: dictionary with signal names for vanes thermal data.
    """

    aggregation = '.5m.mean'

    signal_names_mapping = {
        'S02B': 'TinVanesStatus.VHCC_VANE02_BOT_TMP',
        'S03T': 'TinVanesStatus.VHCC_VANE03_TOP_TMP',
        'S07B': 'TinVanesStatus.VHCC_VANE07_BOT_TMP',
        'S08T': 'TinVanesStatus.VHCC_VANE08_TOP_TMP',
        'S12B': 'TinVanesStatus.VHCC_VANE12_BOT_TMP',
        'S13T': 'TinVanesStatus.VHCC_VANE13_TOP_TMP',
        'S17B': 'TinVanesStatus.VHCC_VANE17_BOT_TMP',
        'S18T': 'TinVanesStatus.VHCC_VANE18_TOP_TMP',
        'S22B': 'TinVanesStatus.VHCC_VANE22_BOT_TMP',
        'S23T': 'TinVanesStatus.VHCC_VANE23_TOP_TMP',
        'S27B': 'TinVanesStatus.VHCC_VANE27_BOT_TMP',
        'S28T': 'TinVanesStatus.VHCC_VANE28_TOP_TMP',
        'S32B': 'TinVanesStatus.VHCC_VANE32_BOT_TMP',
        'S33T': 'TinVanesStatus.VHCC_VANE33_TOP_TMP',
        'S37B': 'TinVanesStatus.VHCC_VANE37_BOT_TMP',
        'S38T': 'TinVanesStatus.VHCC_VANE38_TOP_TMP',
        'S42B': 'TinVanesStatus.VHCC_VANE42_BOT_TMP',
        'S43T': 'TinVanesStatus.VHCC_VANE43_TOP_TMP',
        'S47B': 'TinVanesStatus.VHCC_VANE47_BOT_TMP',
        'S48T': 'TinVanesStatus.VHCC_VANE48_TOP_TMP',
        'S52B': 'TinVanesStatus.VHCC_VANE52_BOT_TMP',
        'S53T': 'TinVanesStatus.VHCC_VANE53_TOP_TMP',
        'S57B': 'TinVanesStatus.VHCC_VANE57_BOT_TMP',
        'S58T': 'TinVanesStatus.VHCC_VANE58_TOP_TMP'
    }

    for key in signal_names_mapping:
        signal_names_mapping[key] += aggregation

    return signal_names_mapping


def get_vanes_temperature_signal_names_VDC_VANES_SENSORS():
    """
    Returns a dictionary with influx signal names as values and human readable
    names as keys. The dictionary includes all the mean temperature signals of the vanes.

    :return: dictionary with signal names for vanes thermal data.
    """

    aggregation = '.5m.mean'

    signal_names_mapping = {
        'S02B': 'VDC_VANES_SENSORS.VHCC_VANE02_BOT_TMP',
        'S03T': 'VDC_VANES_SENSORS.VHCC_VANE03_TOP_TMP',
        'S07B': 'VDC_VANES_SENSORS.VHCC_VANE07_BOT_TMP',
        'S08T': 'VDC_VANES_SENSORS.VHCC_VANE08_TOP_TMP',
        'S12B': 'VDC_VANES_SENSORS.VHCC_VANE12_BOT_TMP',
        'S13T': 'VDC_VANES_SENSORS.VHCC_VANE13_TOP_TMP',
        'S17B': 'VDC_VANES_SENSORS.VHCC_VANE17_BOT_TMP',
        'S18T': 'VDC_VANES_SENSORS.VHCC_VANE18_TOP_TMP',
        'S22B': 'VDC_VANES_SENSORS.VHCC_VANE22_BOT_TMP',
        'S23T': 'VDC_VANES_SENSORS.VHCC_VANE23_TOP_TMP',
        'S27B': 'VDC_VANES_SENSORS.VHCC_VANE27_BOT_TMP',
        'S28T': 'VDC_VANES_SENSORS.VHCC_VANE28_TOP_TMP',
        'S32B': 'VDC_VANES_SENSORS.VHCC_VANE32_BOT_TMP',
        'S33T': 'VDC_VANES_SENSORS.VHCC_VANE33_TOP_TMP',
        'S37B': 'VDC_VANES_SENSORS.VHCC_VANE37_BOT_TMP',
        'S38T': 'VDC_VANES_SENSORS.VHCC_VANE38_TOP_TMP',
        'S42B': 'VDC_VANES_SENSORS.VHCC_VANE42_BOT_TMP',
        'S43T': 'VDC_VANES_SENSORS.VHCC_VANE43_TOP_TMP',
        'S47B': 'VDC_VANES_SENSORS.VHCC_VANE47_BOT_TMP',
        'S48T': 'VDC_VANES_SENSORS.VHCC_VANE48_TOP_TMP',
        'S52B': 'VDC_VANES_SENSORS.VHCC_VANE52_BOT_TMP',
        'S53T': 'VDC_VANES_SENSORS.VHCC_VANE53_TOP_TMP',
        'S57B': 'VDC_VANES_SENSORS.VHCC_VANE57_BOT_TMP',
        'S58T': 'VDC_VANES_SENSORS.VHCC_VANE58_TOP_TMP'
    }

    for key in signal_names_mapping:
        signal_names_mapping[key] += aggregation

    return signal_names_mapping


def get_pulse_count_signal_names():
    """
    Returns a dictionary with influx signal names as values and human readable
    names as keys. The dictionary contains the collector pulse count.

    :return: dictionary with signal name for collector pulse count.
    """

    signal_names_mapping = {
        'pulse_count': 'Collector._PulseCount',
    }
    return signal_names_mapping


def get_data_vane_spitting(client, source_id, from_time, to_time, mv_flag):
    """
    Retreives all the data required for vane spitting analysis from influx.
    Merges the dataframes from different sources

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :type source_id: string
    :param from_time: start time of the window of data to be retrieved
    :type from_time: pd.Timestamp
    :param to_time: start time of the window of data to be retrieved
    :type to_time: pd.Timestamp
    :param mv_flag: mv machine or not
    :type to_time: boolean
    :return: dataframe containing vanes temperatures and pulse_count
    """

    if mv_flag:
        data = client.get_signals_dict(get_vanes_temperature_signal_names_KPI_FV(),
                                       source_id, from_time, to_time)

        for signal in list(get_vanes_temperature_signal_names_KPI_FV()):
            if signal not in data.columns:
                data[signal] = np.NaN

            # convert to Celcius
            data[signal] -= 273.15
    else:
        data = client.get_signals_dict(get_vanes_temperature_signal_names_KPI(),
                                       source_id, from_time, to_time)

        for signal in list(get_vanes_temperature_signal_names_KPI()):
            if signal not in data.columns:
                data[signal] = np.NaN

            # convert to Celcius
            data[signal] -= 273.15

        if data.empty:
            data = client.get_signals_dict(get_vanes_temperature_signal_names_VDC_VANES_SENSORS(),
                                           source_id, from_time, to_time)

            for signal in list(get_vanes_temperature_signal_names_VDC_VANES_SENSORS()):
                if signal not in data.columns:
                    data[signal] = np.NaN

                # convert to Celcius
                data[signal] -= 273.15

        if data.empty:
            data = client.get_signals_dict(get_vanes_temperature_signal_names_TinVanesStatus(),
                                           source_id, from_time, to_time)

            for signal in list(get_vanes_temperature_signal_names_TinVanesStatus()):
                if signal not in data.columns:
                    data[signal] = np.NaN

    # Filter out-of-bounds sensor data
    data[(data < 0.0) | (data > 400.0)] = np.NaN

    return data


def extract_vane_spitting_area(data, cooling_config='TVB+MK2',
                               threshold_temperature=232.0):
    """
    Determine total percent vane area above spitting temperature (threshold)

    :param data: The dataframe with vanes temperature data
    :param cooling_config: the cooling config of the system, options TVB, TVB+, TVB+MK2, MV
    :param threshold_temperature: identical to melting temperature in ideal world,
                                  possible offset due to sensor locations
    :return: Dictionary with series of total vane area above spitting temperature
    """

    # Define a dictionary to contain sensor to group mapping information
    sensor_map_dict = {}

    # Sensor to group mapping for the TVB configuration
    sensor_map_dict['TVB'] = np.array([[['S02B'], ['S03T']],
                                       [['S07B'], ['S08T']],
                                       [['S12B'], ['S13T']],
                                       [['S17B'], ['S18T']],
                                       [['S22B'], ['S23T']],
                                       [['S27B'], ['S28T']],
                                       [['S32B'], ['S33T']],
                                       [['S37B'], ['S38T']],
                                       [['S42B'], ['S43T']],
                                       [['S47B'], ['S48T']],
                                       [['S52B'], ['S53T']],
                                       [['S57B'], ['S58T']]])

    # Sensor to group mapping for the TVB+ configuration
    sensor_map_dict['TVB+'] = np.array([[['S02B'], ['S03T']],
                                        [['S07B', 'S12B'], ['S08T']],
                                        [['S17B'], ['S13T', 'S18T']],
                                        [['S22B'], ['S23T']],
                                        [['S27B'], ['S28T']],
                                        [['S32B'], ['S33T']],
                                        [['S37B', 'S42B'], ['S38T']],
                                        [['S47B'], ['S43T', 'S48T']],
                                        [['S52B'], ['S53T']],
                                        [['S57B'], ['S58T']]])

    sensor_map_dict['MV'] = np.array([[['S04B'], ['S03T']],
                                      [['S11B'], ['S09T']],
                                      [['S17B'], ['S15T']],
                                      [['S23B'], ['S21T']],
                                      [['S29B'], ['S28T']],
                                      [['S34B'], ['S33T']],
                                      [['S41B'], ['S39T']],
                                      [['S47B'], ['S45T']],
                                      [['S53B'], ['S51T']],
                                      [['S59B'], ['S58T']]])

    # Sensor to group mapping for the TVB+MK2 configuration
    # Sensors moved between vanes but not between groups
    sensor_map_dict['TVB+MK2'] = sensor_map_dict['TVB+']

    # Obtain the correct map. The cooling config is stored as the PVP item
    # Source_PVP.TIN_VANES_HW_CONFIG.
    sensor_map = sensor_map_dict[cooling_config]

    # Obtain the number of vane groups (either 10 or 12)
    N_vanegroups = len(sensor_map)

    # Use the sensor map to obtain vane group top and bottom temperatures
    bottom_temps = np.flipud(
        np.rot90(np.array([np.nanmean(data[group[0]].values, axis=1) for group in sensor_map])))
    top_temps = np.flipud(np.rot90(np.array([np.nanmean(data[group[1]].values,
                                                        axis=1) for group in sensor_map])))

    # Interpolate NaN temperature values with adjacent groups;
    # NaN propagates if adjacent groups are also NaN
    def interpolate_nans(temps):
        interpolated_temps = temps
        for t in np.arange(len(data)):
            for g in np.arange(N_vanegroups):
                if np.isnan(temps[t, g]):
                    interpolated_temps[t, g] = np.mean([temps[t, g - 1],
                                                        temps[t, (g + 1) % N_vanegroups]])
        return interpolated_temps

    # Apply the interpolations
    bottom_temps = interpolate_nans(bottom_temps)
    top_temps = interpolate_nans(top_temps)

    # Add correct group temperatures to the dataframe
    for g in np.arange(N_vanegroups):
        data['G%02d' % g] = list(zip(bottom_temps[:, g], top_temps[:, g]))

    # remove the keys; for all data sources (KPI, VDC_VANES_SENSORS, TinVanesStatus),
    # these are the same.
    if cooling_config == 'MV':
        data = data.drop(get_vanes_temperature_signal_names_KPI_FV().keys(), axis=1)
    else:
        data = data.drop(get_vanes_temperature_signal_names_KPI().keys(), axis=1)

    vanegroup_signal_names = ['G%02d' % g for g in np.arange(N_vanegroups)]

    data['spitting_area'] = np.NaN

    # Function to calculate the percentage area above spitting temperature
    # for a given group [top temp, bottom temp]
    def calc_spitting_area_group(temps):
        if temps[0] == temps[1]:
            return 100 * int(temps[0] >= threshold_temperature)
        return 100 * np.clip((np.max(temps) - threshold_temperature) / (np.abs(temps[0] - temps[1])), 0, 1)

    # For each timestamp obtain the total percentage area above spitting temperature
    for index in data.index:
        data.loc[index, 'spitting_area'] = np.mean(
            [calc_spitting_area_group(data.loc[index, vanegroup_signal]) for vanegroup_signal in
             vanegroup_signal_names])

    # Remove vane temperature and utilization columns
    data = data.drop(vanegroup_signal_names, axis=1)
    return data


def get_data_thermal_cycling(client, source_id, from_time, to_time, mv_flag=False):
    """
    Retreives all the data required for thermal cycling analysis from influx.
    Merges the dataframes from different sources

    :param mv_flag: get data for a MV system or not
    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: start time of the window of data to be retrieved
    :return: dataframe containing vanes temperatures and pulse_count
    """

    if mv_flag:
        data = client.get_signals_dict(get_vanes_temperature_signal_names_KPI_FV(),
                                       source_id, from_time, to_time)
        columns_mv = data.columns
        data = calc_vanes_top_bot_min_mean_max(data, bot_str='B', top_str='T')
        data = data.drop(columns=columns_mv)
    else:
        data = client.get_signals_dict(get_aggregated_vanes_temperature_signal_names(),
                                       source_id, from_time, to_time)

    for signal in list(get_aggregated_vanes_temperature_signal_names()):
        if signal not in data.columns:
            data[signal] = np.NaN

    pulse_count = client.get_signals_dict(get_pulse_count_signal_names(),
                                          source_id, from_time, to_time)

    data = data.join(pulse_count, how='outer')
    data.pulse_count.interpolate(inplace=True)

    # remove rows where we only have pulse count data
    # data = data.dropna(subset=list(get_mean_vanes_temperature_signal_names()))

    # convert temperatures from Kelvin to Celsius
    for vane_signal in get_aggregated_vanes_temperature_signal_names():
        data[vane_signal] = data[vane_signal] - 273.15

    # convert pulse_count to Gp
    data.pulse_count *= 1e-9

    return data


def extract_thermal_cycles(data_bot_top, data_vanes_seperate=None, threshold_temperature=232.0):
    """
    Determine hot and warm phases and extract metrics.
    Per hot/warm phase, determine start, end and duration in both the time and gp domain
    Adds metadata per phase.

    :param data_bot_top: The dataframe with mean vanes temperature data
    :param data_vanes_seperate: The dataframe with seperate vanes temperature data
    :param threshold_temperature: optional parameter to indicate the threshold of hot versus warm phases
    :return: Dictionary with dataframes of kpi's for both the hot and warm phases
    """

    orig_columns = data_bot_top.columns.drop('pulse_count')

    # look for hot phases
    above_threshold = data_bot_top.vanes_bottom > threshold_temperature
    data_bot_top['hot_phase'] = above_threshold * 1
    data_bot_top['switch_phase'] = data_bot_top['hot_phase'].diff()

    # get start of all hot and warm phases
    phase_hot = pd.DataFrame(data_bot_top[data_bot_top.switch_phase > 0])
    phase_warm = pd.DataFrame(data_bot_top[data_bot_top.switch_phase < 0])

    phase_hot['start'] = phase_hot.index
    phase_warm['start'] = phase_warm.index

    if phase_hot.empty or phase_warm.empty:
        return None

    if phase_warm.start[0] > phase_hot.start[0]:
        phase_hot.loc[0:len(phase_warm), 'end'] = phase_warm.start.values
        phase_warm.loc[0:len(phase_warm), 'end'] = phase_hot.shift(-1).start.values[0:len(phase_warm)]
        phase_hot.loc[0:len(phase_warm), 'pulse_count_end'] = phase_warm.pulse_count.values
        phase_warm.loc[0:len(phase_warm),
        'pulse_count_end'] = phase_hot.shift(-1).pulse_count.values[0:len(phase_warm)]

    else:
        phase_hot.loc[0:len(phase_hot), 'end'] = phase_warm.shift(-1).start.values[0:len(phase_hot)]
        phase_warm.loc[0:len(phase_hot), 'end'] = phase_hot.start.values
        phase_hot.loc[0:len(phase_hot),
        'pulse_count_end'] = phase_warm.shift(-1).pulse_count.values[0:len(phase_hot)]
        phase_warm.loc[0:len(phase_hot), 'pulse_count_end'] = phase_hot.pulse_count.values

    # Add duration in hours and Gp
    phase_hot = calculate_duration(phase_hot)
    phase_warm = calculate_duration(phase_warm)

    # Add extreme vanes temperatures during phase
    phase_hot = calculate_extreme_temperatures(phase_hot, data_bot_top, data_vanes_seperate)
    phase_warm = calculate_extreme_temperatures(phase_warm, data_bot_top, data_vanes_seperate)

    # filter out warm phases without pulse count. This is considered maintenance
    phase_warm = phase_warm[phase_warm.pulse_count_delta > 0]

    # remove columns we do not need
    signals_to_remove = ['switch_phase', 'hot_phase']
    phase_hot.drop(columns=signals_to_remove, inplace=True)
    phase_warm.drop(columns=signals_to_remove, inplace=True)

    phase_hot.drop(columns=orig_columns, inplace=True)
    phase_warm.drop(columns=orig_columns, inplace=True)

    phases = {'hot': phase_hot,
              'warm': phase_warm,
              }
    return phases


def calculate_duration(phases):
    """
    Adds duration of the phases in time (hours) and pulses (Gp)

    :param phases: The hot or warm phases
    :return: phases including columns for duration
    """

    phases['start'] = phases['start'].dt.tz_localize(None)
    phases['end'] = phases['end'].dt.tz_localize(None)

    phases_start_values = phases.start.values
    phases_pulse_count_values = phases.pulse_count.values
    phases['duration'] = (phases.end.values - phases_start_values) / np.timedelta64(1, 's') / 3600.0
    phases['duration_phase'] = np.append(np.diff(phases_start_values) / np.timedelta64(1, 's') / 3600.0, np.nan)
    phases['pulse_count_delta'] = phases.pulse_count_end.values - phases_pulse_count_values
    phases['pulse_count_delta_phase'] = np.append(np.diff(phases_pulse_count_values), np.nan)
    return phases


def calculate_extreme_temperatures(phases, data_bot_top, data_vanes_seperate):
    """
    Adds minimum and maximum vane temperature during the cycle

    :param phases: The hot or warm phases
    :param data_bot_top: mean vanes temperature data
    :param data_vanes_seperate: seperate vanes temperature data
    :return: phases including columns for extreme temperatures
    """

    data_bot_top.index = data_bot_top.index.tz_localize(None)
    phases['start'] = phases['start'].dt.tz_localize(None)
    phases['end'] = phases['end'].dt.tz_localize(None)

    phases['temperature_bottom_min'] = np.nan
    phases['temperature_bottom_max'] = np.nan
    phases['temperature_top_min'] = np.nan
    phases['temperature_top_max'] = np.nan
    for i, phase in phases.iterrows():
        mask = (data_bot_top.index >= phase.start) & (data_bot_top.index <= phase.end)
        phases.loc[i, 'temperature_bottom_min'] = data_bot_top.loc[mask, 'vanes_bottom_min'].min()
        phases.loc[i, 'temperature_bottom_max'] = data_bot_top.loc[mask, 'vanes_bottom_max'].max()
        phases.loc[i, 'temperature_top_min'] = data_bot_top.loc[mask, 'vanes_top_min'].min()
        phases.loc[i, 'temperature_top_max'] = data_bot_top.loc[mask, 'vanes_top_max'].max()

    if data_vanes_seperate is None:
        data_vanes_seperate = pd.DataFrame()
    if len(data_vanes_seperate) > 0:
        data_vanes_seperate.index = data_vanes_seperate.index.tz_localize(None)
        for c in data_vanes_seperate.columns:
            phases[c + '_min'] = np.nan
            phases[c + '_max'] = np.nan
        for i, phase in phases.iterrows():
            mask = (data_vanes_seperate.index >= phase.start) & (data_vanes_seperate.index <= phase.end)
            for c in data_vanes_seperate.columns:
                phases.loc[i, c + '_min'] = data_vanes_seperate.loc[mask, c].min()
                phases.loc[i, c + '_max'] = data_vanes_seperate.loc[mask, c].max()

    return phases


def qualify_phases(phases, config):
    """
    Adds qualification of the phases

    :param phases: The hot or warm phases
    :param config: vessel configuration of the system
    :return: phases including columns for qualification
    """

    specifications = get_specifications()
    if config not in specifications.config:
        raise Exception('configuration {} unknown'.format(config))
    specs = specifications[specifications.config == config]

    for phase in phases['hot']:
        if phase.duration < specs.hot_duration_min:
            phase['qualification'] = 'Failed: minimum duration not achieved'
        elif phase.duration > specs.hot_duration_max:
            phase['qualification'] = 'Failed: maximum duration exceeded'
        elif phase.temperature_bottom_min < specs.temperature_hot_threshold:
            phase['qualification'] = 'Failed: too low minimum bottom vanes temperature'
        elif phase.temperature_top_min < specs.temperature_hot_threshold:
            phase['qualification'] = 'Failed: too low minimum top vanes temperature'
        else:
            phase['qualification'] = 'Passed'

    for phase in phases['warm']:
        if phase.duration < specs.warm_duration_min:
            phase['qualification'] = 'Failed: minimum duration not achieved'
        elif phase.duration > specs.warm_duration_max:
            phase['qualification'] = 'Failed: maximum duration exceeded'
        elif phase.temperature_bottom_max > specs.temperature_warm_threshold:
            phase['qualification'] = 'Failed: too high max bottom vanes temperature'
        elif phase.temperature_top_max > specs.temperature_warm_threshold:
            phase['qualification'] = 'Failed: too high max top vanes temperature'
        else:
            phase['qualification'] = 'Passed'

    return phases


def calc_vanes_top_bot_min_mean_max(df, bot_str='Bottom_Temperature_Vane', top_str='Top_Temperature_Vane'):
    """
    Caculate the min mean and max for the bottom and top vanes

    Args:
        :param df: return the original columns + calculated columns
        :type df: pandas DataFrame
        :param bot_str: unique identifier for bottom vanes
        :type bot_str: string
        :param top_str: unique identifier for top vanes
        :type top_str: string
    """
    bottom_vanes = [c for c in df.columns if bot_str in c]
    top_vanes = [c for c in df.columns if top_str in c]

    df['vanes_bottom'] = df[bottom_vanes].mean(axis=1)
    df['vanes_bottom_min'] = df[bottom_vanes].min(axis=1)
    df['vanes_bottom_max'] = df[bottom_vanes].max(axis=1)
    df['vanes_top'] = df[top_vanes].mean(axis=1)
    df['vanes_top_min'] = df[top_vanes].min(axis=1)
    df['vanes_top_max'] = df[top_vanes].max(axis=1)
    return df
