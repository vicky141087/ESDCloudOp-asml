# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 14:32 2019

@author: rwiegger

Based on pandas_helpers.py from CDL EUVDB
"""

import re
import numpy as np


def float_convert(val):
    """
    Try to convert a string to a number

    :param val: value to be converted
    :return: float value, or None in case conversion failed
    """

    try:
        val = float(val)
    except (ValueError, TypeError):
        val = None
    return val


def clean_convert_numeric(df, cols):
    """

    :param df:
    :param cols:
    :return:
    """
    numre = re.compile("([-+]?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?)")
    for clm in cols:
        if clm not in df.columns:
            continue
        df[clm] = df[clm].apply(lambda x: float_convert(numre.search(x).group()) if x == x else None)
    return df


def clean_convert_list(df, cols):
    for clm in cols:
        if clm not in df.columns:
            continue
        if not isinstance(df[clm].iloc[0], str):
            continue  # not a string or nan
        new_cols = df[clm].str.split(',', expand=True)
        for new_clm in new_cols:
            df['{col}{suf}'.format(col=clm, suf=new_clm)] = new_cols[new_clm].apply(float_convert)
    return df


def clean_convert_list2(df, cols):
    """
    Split a column containing a comma string of numbers into a series of new columns
    As opposed to clean_convert_list this function will always make the column a string
    and create new columns for the numeric values

    :param df: input dataframe
    :param cols: columns in dataframe on which removal has to be performed
    :return: cleaned dataframe
    """
    for clm in cols:
        if clm not in df.columns:
            continue
        df.loc[df[clm].notnull(), clm] = df.loc[df[clm].notnull(), clm].astype(str)
        new_cols = df[clm].str.split(',', expand=True)
        for new_clm in new_cols:
            df['{col}{suf}'.format(col=clm, suf=new_clm)] = new_cols[new_clm].apply(float_convert)
    return df


def clean_transient(df, cols):
    """
    :param df: input dataframe
    :param cols: columns in dataframe on which removal has to be performed
    :return: cleaned dataframe
    """
    for clm in cols:
        if clm not in df.columns:
            continue
        df.loc[(df[clm] == df[clm].shift(-1)) & (df[clm] == df[clm].shift(1)), clm] = None
    return df


def remove_zeros(df, cols):
    """
    Remove all zeros in the specified columns of the dataframe

    :param df: input dataframe
    :param cols: columns in dataframe on which removal has to be performed
    :return: cleaned dataframe
    """

    for clm in cols:
        if clm not in df.columns:
            continue
        df[clm].where(df[clm] != 0, None, inplace=True)
    return df


def clean_convert_boolean(df, cols):
    """
    Convert a boolean or boolean string to a 0 or 1

    :param df: input dataframe
    :param cols: columns in dataframe on which conversion has to be made
    :return: converted dataframe
    """
    for clm in cols:
        if clm not in df.columns:
            continue
        if df[clm].dtype in (bool, np.int64, np.uint64, np.int32, np.uint32, int):
            df[clm] = df[clm].apply(lambda x: 1 if x else 0)
        elif df[clm].dtype == object:
            df[clm] = df[clm].apply(convert_bool)
    return df


def convert_bool(x):
    """
    Special strings supported:
    Exposure mode (PBSS):
    'NORMAL_MODE' = 1  ('MDC_MODE' = 0)
    Cutoff mode (PBSS.PBSS_MB_CUTOFF_MODE_TAG):
    'MINI_BURST_MODE_WITH_CUTOFF' = 1  ('MINI_BURST_MODE_WITHOUT_CUTOFF' = 0)
    Energy source mode:
    EXTERNAL = 1   (INTERNAL =0)
    Timing control state:
    CLOSED_LOOP = 1 (OPEN_LOOP=0)
    Timing algo mode
    NORMAL = 1  (other =0)

    :param x: input string
    :return: boolean value, or None in case x is no string
    """

    true_list = (
        'true', '1', 'on', 'normal_mode', 'mini_burst_mode_with_cutoff', 'external', 'closed_loop', 'normal')
    if isinstance(x, str):
        return int(x.lower() in true_list)
    else:
        return None


def clean_convert_tec_state(df, cols):
    """
    Convert a LC DAS state string into an integer
    Timing mode (LC DAS):
    'FREE_RUN' = 0
    'DROPLET_DETECT' = 1
    'IDLE' = 2
    'SAFE' = 3
    If the mode already is an integer it will be used

    :param df: input dataframe
    :param cols: columns in dataframe on which conversion has to be made
    :return: converted dataframe
    """

    state = {'free_run': 0, 'droplet_detect': 1, 'idle': 2, 'safe': 3, 'safe_state': 3}
    for clm in cols:
        if clm not in df.columns:
            continue
        df[clm].replace('', np.nan, inplace=True)  # remove empty strings
        df[clm].dropna(inplace=True)
        df[clm] = df[clm].apply(lambda x: x if (type(x) == int or type(x) == np.int64 or
                                                type(x) == float) else state[x.lower()])
    return df


def max_hist(x, res=200):
    x = np.array(x)
    x = x.reshape(-1)
    if x.size == 0 or np.isnan(x).all():
        return float('nan')
    elif np.nanmin(x) == np.nanmax(x):
        return np.nanmin(x)
    else:
        bins = np.linspace(np.nanmin(x), np.nanmax(x), res)
        hist, bin_edges = np.histogram(x, bins)
        idx_max = np.argmax(hist)
        return bins[idx_max]
