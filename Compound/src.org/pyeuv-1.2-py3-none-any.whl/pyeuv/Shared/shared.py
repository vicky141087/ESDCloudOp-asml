import pandas as pd
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions


def get_machines(client, exclude_non_scanner=True, exclude_old=True, verbose=False):
    """
    Obtain the machine_list from influx.
    It does some filtering / sanity checking for missing data, such that the selection buttons work stable.

    :param client: connection to influx
    :param exclude_non_scanner: option to include or exclude sources without full scanner (default: True)
    :param exclude_old: option to (default: True)
    :param verbose: switches debug mode (default=False)
    :returns: a dataframe containing the machine list
    """

    do_it.do_it_verbose(currentframe(), verbose)

    machine_list = client.get_machine_list(return_type='dataframe')

    if exclude_old:
        machine_list = machine_list[(machine_list.replacement_vessel == "") | (machine_list.replacement_vessel.isnull())]

    if exclude_non_scanner:
        machine_list = machine_list[machine_list.hardware!='']

    # sanity checking the machine list. Drop rows that do not have essential info
    machine_list.dropna(subset=['customer', 'displayname', 'machine_nr', 'source_nr', 'hardware', 'vessel', 'timezone'], 
                        inplace=True)

    return machine_list


def get_collectors(client, source_id, verbose=False):
    """
    Obtain all collectors of the given source.
    Determines the start_time end end_time of each collector. 
    The end_time of the current celloctor is defined as pd.Timestamp('now')

    :param client: connection to influx
    :param source_id: the source_id ('s12345') for the source the collector swaps have to be retrieved
    :param verbose: switches debug mode (default=False)
    :returns: a dataframe containing the collector swaps, including start and end time.
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        collectors = client.get_signals(['{0}.Collector.Swap'.format(source_id)])
        if collectors.empty:
            raise Exception('No collectors retrieved from influx')
        collectors.columns = ['swap']
        collectors['start'] = collectors.index
        collectors['end'] = collectors['start'].shift(-1)
        collectors.loc[collectors.index[-1], 'end'] = pd.Timestamp('now').tz_localize('UTC')

    except Exception as e:
        raise Exception(e)

    return collectors


def get_current_collector(client, source_id, timestamp=pd.Timestamp('now').tz_localize('UTC'), verbose=False):
    """
    Obtain the current collector of the given source and timestanp

    :param client: connection to influx
    :param source_id: the source_id ('s12345') for the source the collector has to be retrieved
    :param verbose: switches debug mode (default=False)
    :returns: a pandas series containing the collector, including 'swap' (name), 'start' and 'end' time.
    :raises Exception: data retreival from influx fails
    :raises Exception: current collector not found
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        collectors = get_collectors(client, source_id, verbose=verbose)
    except Exception as e:
        raise Exception(e)

    current_collector = collectors[(collectors.start <= timestamp) &
                                   (collectors.end >= timestamp)]

    if len(current_collector) == 0:
        raise Exception('Current collector not found.')

    if len(current_collector) > 1:
        raise Exception('Multiple collectors found.')

    return current_collector.squeeze()


def get_machine_from_machine_id(client, machine_id, verbose=False):
    """
    Obtain the machine (1 item machine_list json), represented as a series.

    :param client: connection to influx
    :param machine_id: the machine_id ('m1234')
    :param verbose: switches debug mode (default=False)
    :returns: a series containing the machine properties
    :raises Exception: data retrieval from influx fails
    :raises Exception: machine_id does not exist
    :raises Exception: machine_id does exist multiple times
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        machine_list = client.get_machine_list(return_type='dataframe')
    except Exception as e:
        print(e)

    # in the machine_list, we have machine numbers, so without the 'm' in front
    machine = machine_list[machine_list.machine_nr == machine_id[1:]]

    if machine.empty:
        raise Exception('Machine_id {} not found in machine_list'.format(machine_id))
    elif len(machine) > 1:
        raise Exception('Machine_id {} found multiple times in machine_list'.format(machine_id))

    return machine.squeeze()


def get_source_id_from_machine_id(client, machine_id, verbose=False):
    """
    Obtain the source_id belonging to a machine_id

    :param client: connection to influx
    :param machine_id: the machine_id ('m1234')
    :param verbose: switches debug mode (default=False)
    :returns: a string containing the source_id('s12345')
    :raises Exception: data retrieval from influx fails
    :raises Exception: machine_id does not exist
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        machine_list = client.get_machine_list(return_type='dataframe')
    except Exception as e:
        print(e)

    # in the machine_list, we have machine numbers, so without the 'm' in front
    machine = machine_list[machine_list.machine_nr == machine_id[1:]]
    if len(machine) == 1:
        source_id = 's{}'.format(machine.squeeze().source_nr)

    else:
        if machine.empty:
            raise Exception('Machine_id {} not found in machine_list'.format(machine_id))
        else:
            raise Exception('Machine_id {} found multiple times in machine_list'.format(machine_id))

    return source_id


def get_timezone_from_machine_id(client, machine_id, verbose=False):
    """
    Obtain the timezone belonging to a machine_id

    :param client: connection to influx
    :param machine_id: the machine_id ('m1234')
    :param verbose: switches debug mode (default=False)
    :returns: a string containing the timezone (e.g. 'Asia/Taipei')
    :raises Exception: data retrieval from influx fails
    :raises Exception: machine_id does not exist
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        machine_list = client.get_machine_list(return_type='dataframe')
    except Exception as e:
        raise Exception(e)

    # in the machine_list, we have machine numbers, so without the 'm' in front
    machine = machine_list[machine_list.machine_nr == machine_id[1:]]
    if len(machine) == 1:
        timezone = machine.squeeze().timezone

    else:
        if machine.empty:
            raise Exception('Machine_id {} not found in machine_list'.format(machine_id))
        else:
            raise Exception('Machine_id {} found multiple times in machine_list'.format(machine_id))

    return timezone


def get_system_generation(client, source_id, verbose=False):
    """
    Obtain the generation (3300, 3400 etc) belonging to a source_id

    :param client: connection to influx
    :param source_id: the source_id ('s12345')
    :param verbose: switches debug mode (default=False)
    :returns: a string containing the source_generation ('3400')
    :raises Exception: data retrieval from influx fails
    :raises Exception: source_id does not exist
    """

    do_it.do_it_verbose(currentframe(), verbose)

    try:
        machine_list = client.get_machine_list(return_type='dataframe')
    except Exception as e:
        print(e)

    # in the machine_list, we have machine numbers, so without the 'm' in front
    machine = machine_list[machine_list.source_nr == int(source_id[1:])]
    if len(machine) == 1:
        generation = machine.squeeze().hardware

    else:
        if machine.empty:
            raise Exception('Source_id {} not found in machine_list'.format(source_id))
        else:
            raise Exception('Source_id {} found multiple times in machine_list'.format(source_id))

    return generation


def get_specific_source_source_ids(machines_dict, version_spec=None, hardware_version_spec=None):
    """
    Obtain the source_ids belonging to a certain version (S2/S3) or hardware version (S3-420/S3-521)
    If all S3-5xx version need to be obtained you can specify S3-5,

    :param machines_dict: dictionary of machine information taken from machines_json
    :param version_spec: the version for which you want to retreive source_ids (s3, default=None)
    :param hardware_version_spec: the hardware_version_spec for which you want to retreive source_ids (default=None)
    :returns: a list of source_ids belonging to the set spec
    :raises Exception: if no version_spec and hardware_version_spec is provided
    """

    if version_spec is not None:
        source_ids = [machine['source_nr'] for machine in machines_dict if str(version_spec).upper() in machine['version'].upper()]
    elif hardware_version_spec is not None:
        source_ids = [machine['source_nr'] for machine in machines_dict if str(hardware_version_spec).upper() in machine['hardware_version'].upper()]
    else:
        raise Exception('Please specify either a version_spec or hardware_version_spec')
    return source_ids
