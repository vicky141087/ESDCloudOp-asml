"""
signal_processing.py
Authors: RWKL, MGGV
Date: 2019-04-29

Contains generic signal processing functionality
"""
import math
import numpy as np
import statsmodels.api as sm
from scipy.signal import butter, filtfilt, freqz
from scipy.fftpack import fft, fftfreq, fftshift
import pyeuv.Do_It.do_it_library as do_it  # generic library functions
from inspect import currentframe  # internal tooling functions
import scipy


def calculate_linear_fit(x, y, confidence_level=0.95, round_to_significant_digit=True, advanced_analysis=True):
    """
    Calculates the linear fit of two series of data. It returns the fitted line,
    confidence interval and adjusted r-squared (measure for predictibility of y by x).
    It uses the statsmodels library

    :param x: data on x-axis
    :param y: data on y-axis
    :param confidence_level: confidence level for confidence interval (default 95%)
    :param round_to_significant_digit: switch to round the slope to the significant digit (default True)
    :param advanced_analysis: When false calculate the linear fit only and skip the advanced analysis e.g. confidence
        interval and adjusted R squared.
        NOTE: results of slope and offset are different w/ and w/o advance analysis
    :return: a tuple containing slope, offset, confidence interval, and adjusted r-squared
    """

    if advanced_analysis:
        fit_result = sm.OLS(y, sm.add_constant(x)).fit()
        offset = fit_result.params[0]
        slope = fit_result.params[1]
        confidence_interval = slope - fit_result.conf_int(1.0 - confidence_level)[0][1]

        if round_to_significant_digit:
            if np.isnan(confidence_interval):
                slope = np.NaN
                confidence_interval = np.NaN
                offset = np.NaN
            else:
                significant_digit = -int(np.floor(np.log10(np.abs(confidence_interval))))
                slope = np.round(slope, significant_digit)
                confidence_interval = np.round(confidence_interval, significant_digit)
                offset = np.round(offset, significant_digit)
        adjusted_r_squared = np.round(fit_result.rsquared_adj, 2)
    else:
        fit_result = scipy.stats.linregress(x, y)
        slope = fit_result.slope
        offset = fit_result.intercept
        confidence_interval = np.NaN
        adjusted_r_squared = np.NaN

    return slope, offset, confidence_interval, adjusted_r_squared


def calculate_rolling_median(data, key, window = 31):
    """
    Adds a column with the rolling median of slie_dt
    
    :param data: dataframe with input data
    :param key: the key if the signal within the dataframe to be used
    :param window: number of datapoints used for the rolling median, typically an odd number (default=31)
    :return: dataframe with an additional column for the rolling median of the slie/dt
    """
    
    data['{}_median'.format(key)] = data[key].rolling(window=window, min_periods=1, center=True).median()
    return data


def calculate_relative_variance(data, window = 31, verbose=False):
    """
    Calculates the relative variance, using a rolling window.
    The signal is divided by the rolling median. 
    Then the standard deviation over the same window is taken.
    
    :param data: input data (series)
    :param verbose: to switch internal debug info
    :param window: number of datapoints used for the rolling median, typically an odd number (default=31)
    :return: relative variance
    """

    do_it.do_it_verbose(currentframe(), verbose)

    rolling_median = data.rolling(window = window, min_periods = 1, center = True).median()
    variance = (data / rolling_median).rolling(window = window, min_periods = 1, center = True).std() * 100
    
    return variance


def make_monotonically_increasing(data):
    """
    Makes an array monotonically increasing. In case there is a drop, the drop will be set to zero (increasing all data after the drop by the magnitude of the drop
    Example:
    [1, 2, 5, 7, 9, 2, 4, 6, 9] will become [1, 2, 5, 7, 9, 9, 11, 13, 16]
    :param data: numpy array of integers or floats
    :return: numpy array with monotonically increasing values
    """

    diff = np.append(data[0], np.diff(data))
    diff[diff < 0] = 0
    data_monotonic = np.cumsum(diff)

    return data_monotonic


# %% Main change point detection function
def calculate_changepoints(x, y, Ts=0.1, Tc=5, order=6, cp_mag=0.2, limits=[-0.6, -0.3, 0]):
    """
    Automated change point detection by smoothing with butterworth (lowpass) filter and calculating inflection points (d2y/dx = max)
    above some threshold  (d2y/dx > cp_mag). Last step is basically to compensate for noisy data or all small inflection points due
    the noise are detected as inflection points.

    :param x: array with pulsecount (or any other)
    :param y: array with SLIEDT or reflectivity loss (or any other) with same length as x
    :param Ts: (optional) Sample period signal
    :param Tc: (optional) Cutoff period smoothing filter
    :param order: (optional) butterworth order (not recommended to change)
    :param cp_mag: (optional) sensitivity threshold; to make sure not all inflection points due to noisyness data are selected
    :param limits: (optional) to classify sections between inflection points in 4 different classes (in spec, just out of spec, out of spec & jumps)
    :return: inflection point coordinate x, inflection point coordinate y, avg slope in section, slopes error in section
    """

    # %% Resample uniformly
    x_r = np.arange(x[0], x[-1], Ts)  # resample x with new samplerate Ts
    y_r = np.interp(x_r, x, y)  # resample y with interpolation with new samplerate
    
    # Filter SLIE/DT
    w_cutoff = 2 * Ts / Tc  # cut off frequency
    b, a = butter(order, w_cutoff)  # butterworth filter
    y_f = filtfilt(b, a, y_r)  # filter to get smoothed data
    w, h = freqz(b, a)

    # %% Calculate change points
    # Calculate derivatives; np.diff calculates difference in y divided by uniform step size
    dydx = np.diff(y_f) / Ts
    d2ydx = np.diff(dydx) / Ts
    d3ydx = np.diff(d2ydx) / Ts

    # Identify sections using inflection points
    idx_d_zero = np.insert(np.diff(np.sign(dydx)) != 0, 0, False)
    idx_d_zero = np.append(idx_d_zero, False)
    idx_d3_zero = np.insert(np.diff(np.sign(d3ydx)) != 0, 0, False)
    idx_d3_zero = np.append(idx_d3_zero, False)  # boolean with indices of d3ydx=0
    idx_d2_include = np.abs(d2ydx) > cp_mag  # boolean with d2ydx > cp_mag [%/Gp^2]
    idx_d3_zero_flt = idx_d3_zero & idx_d2_include  # Both need to be true
    idx_d3_zero_flt = np.insert(idx_d3_zero_flt, 0, 2 * [False])

    # x and y coordinates of the inflection points!
    x_inflection = x_r[idx_d3_zero_flt]
    y_inflection = y_f[idx_d3_zero_flt]
    
    # Indices of inflection points
    idxx = np.nonzero(idx_d3_zero_flt)  
    idxx = np.insert(idxx, 0, 0)  # ADded the first and last one
    idxx = np.insert(idxx, len(idxx), len(y_r) - 1)
    
    # preallocate
    infmean = np.zeros((len(x_inflection) + 1))  # mean of slope between inflection points
    b_fit = np.zeros((len(x_inflection) + 1))  # y intersect of linear fit with forced slope (y=ax+b)
    
    # booleans to classify sections to the limits in the graph red, orange, green, blue!
    idx_trend_oot = np.zeros(len(x_r), dtype=bool)
    idx_trend_oos = np.zeros(len(x_r), dtype=bool)
    idx_trend_good = np.zeros(len(x_r), dtype=bool)
    idx_trend_rec = np.zeros(len(x_r), dtype=bool)
    
    # For loop to calculate the average dy/dx and y intersect in all the sections defined by the inflection points (+2)
    for j in range(len(idxx) - 1):
        infmean[j] = np.mean(dydx[idxx[j]:idxx[j + 1]])
        b_fit[j] = np.mean(y_f[idxx[j]:idxx[j + 1]] - infmean[j] * x_r[idxx[j]:idxx[j + 1]])
        if np.mean(limits) <= 0:
            
            # Classify to the different limits number
            idx_trend_oot[idxx[j]:idxx[j + 1]] = infmean[j] <= limits[0]  # -1 Worst, RED [%/Gp]
            idx_trend_oos[idxx[j]:idxx[j + 1]] = (infmean[j] <= limits[1]) & (
                        infmean[j] > limits[0])  # -0.5 Bad, ORANGE [%/Gp]
            idx_trend_good[idxx[j]:idxx[j + 1]] = (infmean[j] <= limits[2]) & (
                        infmean[j] > limits[1])  # Okay, GREEN [%/Gp]
            idx_trend_rec[idxx[j]:idxx[j + 1]] = (infmean[j] > limits[2])  # Growth, BLUE, jump
        elif np.mean(limits) > 0:
            idx_trend_oot[idxx[j]:idxx[j + 1]] = infmean[j] >= limits[0]  # m > 1 Worst, RED [%/Gp]
            idx_trend_oos[idxx[j]:idxx[j + 1]] = (infmean[j] >= limits[1]) & (
                        infmean[j] < limits[0])  # 0.5 <m <1 Bad, ORANGE [%/Gp]
            idx_trend_good[idxx[j]:idxx[j + 1]] = (infmean[j] >= limits[2]) & (
                        infmean[j] < limits[1])  # 0 < m < 0.5 Okay, GREEN [%/Gp]
            idx_trend_rec[idxx[j]:idxx[j + 1]] = (infmean[j] < limits[2])  # Growth, BLUE, jump

    # %% Calculate uncertainties in the fitting
    def find_nearest(array, value):  # Function to find closest value value of real data x to the inflection point
        array = np.asarray(array)
        idx = (np.abs(array - value)).argmin()
        return idx

    # Pre allocate indexes, residuals ydif, inflection point error infmean_e and middle of section infmean_x
    idx = np.zeros(len(idxx))
    ydif = np.zeros(len(infmean))
    infmean_e = np.zeros(len(infmean))
    infmean_x = np.zeros(len(infmean))
    idx[0] = 0
    idx[len(idxx) - 1] = len(x) - 1
    # Find closest value of real data (x) to inflection point
    for i in range(len(x_inflection)):
        idx[i + 1] = find_nearest(x, x_inflection[i])
    idx = idx.astype('int64')
    
    # FOr each section calculate the residuals ydif, inflection point error infmean_e and middle of section
    for j in range(len(idxx) - 1):
        ydif[j] = math.sqrt(
            sum((infmean[j] * x[idx[j]:idx[j + 1]] + b_fit[j] - y[idx[j]:idx[j + 1]]) ** 2) / (idx[j + 1] - idx[j]))
        infmean_e[j] = ydif[j] * math.sqrt((idx[j + 1] - idx[j]) / (
                    (idx[j + 1] - idx[j]) * sum(x[idx[j]:idx[j + 1]] ** 2) - sum(x[idx[j]:idx[j + 1]]) ** 2))
        infmean_x[j] = (x[idx[j]] + x[idx[j + 1]]) / 2


    settings = [Ts, Tc, order, cp_mag, limits]
    data_cpd = [x_inflection, y_inflection, infmean_x, infmean, infmean_e, x, y, x_r, y_f, h, w, settings, idx_trend_oot, idx_trend_oos, idx_trend_good, idx_trend_rec, dydx]

    return data_cpd


def plot_changepoints(data_cpd):
    """
    This function is to plot the processed change point detection data from the function calculate_changepoints.
    Two kinds of plots are given: 
    PART 1: Shows the plots corresponding to the change point detection algoritm
    PART 2: Shows frequency plot + bodediagram for diagnostics purposes of the data processing (interpolation + smoothing)
    """
    # We don't want matplotlib to be a requirement for this module, so we import on demand.
    import matplotlib.pyplot as plt

    # First load the data
    x_inflection = data_cpd[0]          # Coordinates of inflection points
    y_inflection = data_cpd[1]          # Coordinate of inflection points
    infmean_x = data_cpd[2]             # Halfway point of a section to display there the uncertainty in the slope
    infmean = data_cpd[3]               # Average slope of a section
    infmean_e = data_cpd[4]             # Error in the average slope; measurement for how well the data was smoothed
    x = data_cpd[5]                     # raw datapoints x
    y = data_cpd[6]                     # raw datapoints y
    x_r = data_cpd[7]                   # resampled r
    y_f = data_cpd[8]                   # Smoothed y
    h = data_cpd[9]                     # Parameter generated for response plot
    w = data_cpd[10]                    # Parameter generated for response plot
    Ts = data_cpd[11][0]                # Sample period signal
    Tc = data_cpd[11][1]                # Cutoff period smoothing filter
    order = data_cpd[11][2]             # butterworth order (not recommended to change)
    cp_mag = data_cpd[11][3]            # sensitivity threshold; to make sure not all inflection points due to noisyness data are selected
    limits = data_cpd[11][4]            # limits for the below mentioned classifications
    idx_trend_oot = data_cpd[12]        # mask for classification (OoS drop)
    idx_trend_oos = data_cpd[13]        # mask for classification (OoS just) of sections
    idx_trend_good = data_cpd[14]       # mask for classification (good) of sections
    idx_trend_rec = data_cpd[15]        # mask for classification (recovery) of sections
    dydx = data_cpd[16]                 # derivative np.diff of y(x)
    y_r = np.interp(x_r, x, y)          # interpolated y with new samplerate Ts

    ## --- PART 1 ---  Make plots y x with inflection points, dy/dx with average slope & standard deviation
    plt.figure(figsize=[12, 6])
    plt.subplot(211)
    plt.plot(x, y, '.', markersize=1, color='gray', label='SLIE/DT Norm')
    # plt.plot(p_trend, y_f_trend, '-b', linewidth=0.5, markersize=0.5)
    plt.plot(x_r[idx_trend_oot], y_f[idx_trend_oot], '.r', markersize=3, label="$\\leq${0:.1f} %/Gp".format(limits[0]))
    plt.plot(x_r[idx_trend_oos], y_f[idx_trend_oos], '.', markersize=3, color='orange',
             label="({0:.1f}, {1:.1f}] %/Gp".format(limits[0], limits[1]))
    plt.plot(x_r[idx_trend_good], y_f[idx_trend_good], '.', markersize=3, color='#00CC00',
             label="({0:.1f}, {1:.1f}] %/Gp".format(limits[1], limits[2]))
    plt.plot(x_r[idx_trend_rec], y_f[idx_trend_rec], '.', markersize=3, color='#00AAFF',
             label="> {0:.1f} %/Gp".format(limits[2]))
    plt.plot(x_inflection, y_inflection, '.k', markersize=6, label='change point')
    # check fit
    # plt.plot(x,infmean[j]*x+b_fit[j])
    plt.grid(True)
    plt.legend()
    # plt.title("SLIE/DT Long term ({0}-{1})".format(ds['name'], ds['collector_sn']))
    plt.title("SLIEDT vs pulsecount ")
    plt.xlabel("Pulsecount [Gp]")
    plt.ylabel("SLIEDT  [%]")

    plt.subplot(212)
    plt.grid(True)
    plt.title("Derivative d(SLIEDT)/d(Pulsecount)")
    plt.xlabel("Pulsecount [Gp]")
    plt.ylabel("d(ROI loss)/dP [%/Gp]")
    plt.plot(x_r[1:], dydx, '-', markersize=0.5)
    plt.errorbar(infmean_x, infmean, yerr=infmean_e, fmt='ro', markersize=1, color='red')
    plt.plot([x_r[0], x_r[-1]], 2 * [limits[0]], '--r')
    plt.plot([x_r[1], x_r[-1]], 2 * [limits[1]], '--', color='orange')
    plt.plot([x_r[2], x_r[-1]], 2 * [limits[2]], '--', color='#00CC00')
    plt.tight_layout()

    ## ---- PART  II ---- Make plots to troubleshoot/adjust show signal processing
    N = len(y_r)
    S = fft(y_r)
    S_flt = fft(y_f)
    f = fftfreq(N, Ts)
    f_plot = fftshift(f)
    S_plot = fftshift(np.abs(S))
    S_plot_flt = fftshift(np.abs(S_flt))

    plt.figure(figsize=[12, 6])
    plt.subplot(211)
    plt.plot(x, y, '.', color='black', markersize=1)
    plt.plot(x_r, y_f, '-b')
    plt.grid(which='both')
    plt.xlabel('Pulsecount [Gp]')
    plt.ylabel('Radon ROI')

    plt.subplot(212)
    plt.semilogy(f_plot, S_plot, '-k')
    plt.semilogy(f_plot, S_plot_flt, '-r')
    plt.grid()
    plt.xlabel('Frequency [1/p]')
    plt.ylabel('Spectrum')

    # Response plot
    #w, h = freqz(b, a)
    t_bode = w / np.pi * 2 * Ts
    phase = -np.arctan2(np.imag(h), np.real(h))

    plt.figure(figsize=[12, 6])
    plt.subplot(211)
    plt.plot(t_bode, 20*np.log10(np.abs(h)), '-r')
    plt.xlabel('Frequency [')
    plt.grid(True)

    plt.subplot(212)
    plt.plot(t_bode, phase/np.pi, '-r')
    plt.xlabel('Period')
    plt.ylabel('Phase [pi rad]')
    plt.grid(True)
