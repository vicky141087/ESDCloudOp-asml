"""
filters.py
Authors: DAAU
Date: 2020-12-15

Contains filters for Open Loop and Tru-Coax Refill events

"""

import pandas as pd
import numpy as np
from pyeuv.EUVDashboard.clients import UserLANClient
from pyeuv.Shared.shared import get_machines


def agg_first_xsec(type, timeforward):
    """
    Aggregate first X time; make sure that duration is not longer than diff between last and first timestmap.

    :param type: aggregator type, e.g. mean
    :param timeforward: select amount of time forward from the first datapoint
    :return: aggregtor object
    """
    agg = aliased_aggr(lambda x: x.loc[x.index < (x.index.min() + pd.Timedelta(timeforward))].agg(type)
                       if (x.index.min() + pd.Timedelta(timeforward)) < x.index.max()
                       else x.agg(type), type+'_first_'+timeforward)
    return agg


def agg_last_xsec(type, timeback):
    """
    Aggregate last X time; make sure that duration is not longer than diff between last and first timestmap.

    :param type: aggregator type, e.g. mean
    :param timeback: select amount of time back from the last datapoint
    :return: aggregtor object
    """

    agg = aliased_aggr(lambda x: x.loc[x.index > (x.index.max() - pd.Timedelta(timeback))].agg(type)
                       if (x.index.max() - pd.Timedelta(timeback)) > x.index.min()
                       else x.agg(type), type+'_last_'+timeback)
    return agg


def aliased_aggr(aggr, name):
    """
    Function that aggregates based on a specific column. To be used in combination with groupby, e.g.
    # df = df_data.groupby('something').agg({
    #     'time': ['max', aliased_aggr(lambda x: x.iloc[1:].mean(), 'time_max_after_first'),
    #                   })

    :param aggr: aggregator object
    :param name: aggregation columns
    :return: aggregator object
    """
    if isinstance(aggr, str):
        def f(data):
            return data.agg(aggr)
    else:
        def f(data):
            return aggr(data)
    f.__name__ = name
    return f


def create_openloop_filter(client, source_id, ts_start, ts_stop):
    """
    Create a dlgc1 and open-loop filter based on duty cycle and dlgc around 100%, and at least 3 mJ EUV.
    The time duration of a several dlgc1 exposures should be at least 5 s.

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: end time of the window of data to be retrieved
    :return:
        df_dlgc1_signal: 0/1 signal for cases with DLGC>100%, DC>100%, EUV>3mJ
        df_ol_signal: 0/1 signal for cases with DLGC>100%, DC>100%, EUV energy>3 mJ, DT>70 mJ
        df_ol_windows: aggregated signals within the OL signal

    """

    dlgc_column = 's{0}.RT36.BDdriveLaserGainCommandMean'.format(source_id)
    dc_column = 's{0}.RT05._DutyCycle'.format(source_id)
    euv_column = 's{0}.RT05.BDenergyInternalAvgOn'.format(source_id)
    dt_column = 's{0}.RT05.BDenergyTargetAvg'.format(source_id)

    try:
        df_dlgc = client.get_signals([dlgc_column], from_time=ts_start, to_time=ts_stop)
        if df_dlgc.empty:
            print("create_openloop_filter(): No dlgc data")
            return
    except:
        print("create_openloop_filter(): RT36.BDdriveLaserGainCommandMean does not exist.")
        return

    df_rt5 = client.get_signals([dc_column, euv_column, dt_column], from_time=ts_start, to_time=ts_stop)
    if df_rt5.empty:
        print("create_openloop_filter(): No duty cycle / euv energy data")
        return
    else:
        if dc_column not in df_rt5.columns:
            print("create_openloop_filter(): No duty cycle data")
            return
        if euv_column not in df_rt5.columns:
            print("create_openloop_filter(): No euv energy data")
            return
        if dt_column not in df_rt5.columns:
            print("create_openloop_filter(): No energy target data")
            return

    df_dlgc.columns = ['dlgc']
    df_rt5.columns = ['duty_cycle', 'euv_energy', 'energy_target']

    if pd.__version__ > '0.20.0':
        # Robust merging requires pandas > 0.20
        # Merge with 200ms tolerance
        df = pd.merge_asof(df_dlgc, df_rt5, left_index=True, right_index=True, tolerance=pd.Timedelta('40ms'))
        df = df.dropna()
    else:
        # Use less robust solution
        df = pd.concat([df_dlgc, df_rt5], axis=1)
        df['duty_cycle'] = df['duty_cycle'].fillna(method='ffill', limit=1)
        df['euv_energy'] = df['euv_energy'].fillna(method='ffill', limit=1)
        df['energy_target'] = df['energy_target'].fillna(method='ffill', limit=1)
        df = df.dropna()

    # create filtered signals
    df_dlgc1_filtered = df.loc[(df.dlgc > 0.995) & (df.dlgc < 1.005) &
                               (df.duty_cycle > 99.5) & (df.duty_cycle < 100.5) &
                               (df.euv_energy > 3) & (df.euv_energy < 10)
                               ]  # for filtering energy target, add: (df.energy_target > 99) & (df.energy_target < 101)

    if df_dlgc1_filtered.empty:
        print("create_openloop_filter(): No dlgc-1 data after filter")
        return

    df_dlgc1_windows = detect_chunks_of_data(df_dlgc1_filtered, min_time_between_chunks=2.5, min_time_duration=5)

    if df_dlgc1_windows.empty:
        print("create_openloop_filter(): No dlgc-1 windows")
        return

    # create filter signal
    df_dlgc1_signal = generate_filter_signal(df_dlgc1_windows[['chunk_start', 'chunk_stop']])
    df_dlgc1_signal.rename(columns={'value': 'dlgc1'}, inplace=True)

    # create filtered signals
    df_ol_filtered = df.loc[(df.dlgc > 0.995) & (df.dlgc < 1.005) &
                            (df.duty_cycle > 99.5) & (df.duty_cycle < 100.5) &
                            (df.euv_energy > 3) & (df.euv_energy < 10) &
                            (df.energy_target > 70)
                            ]  # for filtering energy target, add: (df.energy_target > 99) & (df.energy_target < 101)

    if df_ol_filtered.empty:
        print("create_openloop_filter(): No open-loop data after filter")
        return

    # first create an OL window signal with a small hold-off time: the narrow windows of the OL data
    df_ol_windows_narrow = detect_chunks_of_data(df_ol_filtered, min_time_between_chunks=2.5, min_time_duration=25)

    if df_ol_windows_narrow.empty:
        print("create_openloop_filter(): No narrow open-loop windows")
        return

    # create filter signal
    df_ol_signal = generate_filter_signal(df_ol_windows_narrow[['chunk_start', 'chunk_stop']])
    df_ol_signal.rename(columns={'value': 'OpenLoop'}, inplace=True)
    # create a counter for the narrow ol windows
    df_ol_signal.loc[df_ol_signal.OpenLoop == 1, 'narrow_chunk_count'] = \
        np.arange(0, len(df_ol_signal) / 2) + 1

    # Download and process other signals
    signal_dict = {'euv_energy_external': 'RT35.BDenergyExternalMeanOn',
                   'euv_energy_raw': 'RT35.BDenergyRawExternalMeanOn',
                   'MP_power': 'DL_AMPLIFIER_SENSORS.DLPA3_ACTL_MP_PW',
                   'PP_power': 'DL_AMPLIFIER_SENSORS.DLPA3_ACTL_PP_PW',
                   'target_size': 'RT23.TFMmajorAxis',
                   'target_size_minor': 'RT23.TFMminorAxis',
                   'target_angle_Rx': 'RT23.TFMrotationY',
                   'target_angle_Ry': 'RT23.TFMrotationX',
                   'pedestal_energy': 'RT26.BDpa3MpPedestalEnergyMeanOn'}
    signals_dict_reversed = dict(('s' + str(source_id) + '.' + v, k) for k, v in signal_dict.items())

    # Obtain the data in time intervals of df_ol_windows_narrow
    df_extra_data = pd.DataFrame()
    for index, row in df_ol_windows_narrow.iterrows():
        df_extra_data_range = client.get_signals(list(signals_dict_reversed.keys()), from_time=row['chunk_start'],
                                                 to_time=row['chunk_stop'])
        df_extra_data = df_extra_data.append(df_extra_data_range)

    df_extra_data.rename(columns=signals_dict_reversed, inplace=True)

    if df_extra_data.empty:
        print("create_openloop_filter(): No extra_data")
        return

    # filter the raw data with the narrow ol windows
    df_ol_filtered_narrow = pd.concat([df_ol_filtered, df_extra_data, df_ol_signal], axis=1)
    df_ol_signal = df_ol_signal.loc[:, df_ol_signal.columns != 'narrow_chunk_count'].copy()
    df_ol_filtered_narrow.index.name = 'time'
    df_ol_filtered_narrow.OpenLoop = df_ol_filtered_narrow.OpenLoop.fillna(method='ffill')
    df_ol_filtered_narrow.narrow_chunk_count = df_ol_filtered_narrow.narrow_chunk_count.fillna(method='ffill')
    # only filter the data which is contained within the narrow ol windows + include only actual data (check dlgc1)
    df_ol_filtered_narrow = df_ol_filtered_narrow.loc[(df_ol_filtered_narrow.OpenLoop == 1),
        df_ol_filtered_narrow.columns != 'OpenLoop']

    # calculate the ol windows with a larger hold-off time in order to aggregate many shorter ol events; only the last
    # 60s is of importance.
    df_ol_windows = detect_chunks_of_data(df_ol_filtered_narrow, min_time_between_chunks = 60, min_time_duration = 90,
                                           custom_columns = df_ol_filtered_narrow.columns,
                                           custom_agg=['max','min',
                                                       agg_first_xsec('mean','1s'),
                                                       agg_last_xsec('mean','60s')])

    if df_ol_windows.empty:
        print("create_openloop_filter(): No open-loop windows")
        return

    # calculate the number of narrow ol counts, the windows which are used in the df_ol_signal
    df_ol_windows['ol_counts'] = df_ol_windows['narrow_chunk_count_max'] - df_ol_windows['narrow_chunk_count_min'] + 1

    # remove extra columns which are not necessary
    df_ol_windows = df_ol_windows.loc[:, ~df_ol_windows.columns.str.contains('diff_time|narrow_chunk_count|max|min')]

    # Prepare the data for InfluxDB
    df_ol_windows['chunk_start'] = (pd.to_numeric(df_ol_windows['chunk_start']) / 1e9)
    df_ol_windows['chunk_stop'] = (pd.to_numeric(df_ol_windows['chunk_stop']) / 1e9)
    selected_columns = df_ol_windows.columns.isin(['chunk_start', 'chunk_stop', 'n_counts'])
    df_ol_windows.loc[:, selected_columns] = df_ol_windows.loc[:, selected_columns].astype(np.int64).copy()
    df_ol_windows.loc[:, ~selected_columns] = df_ol_windows.loc[:, ~selected_columns].astype(np.float64).copy()

    return df_dlgc1_signal, df_ol_signal, df_ol_windows


def calculate_trucoax_refill_filter(client, source_id, from_time, to_time):
    """
    Create a TruCoax refill filter based on dips in the trucoax gas pressure.

    :param client: connection to influx
    :param source_id: the source_id for which the signals have to be retrieved
    :param from_time: start time of the window of data to be retrieved
    :param to_time: end time of the window of data to be retrieved
    :return: 1/0 signal with TruCaox refill start and end
    """
    df = client.get_signals(['s{0}.PLCStatus.DLPRE_PB_TASC_GAS_PRESSURE'.format(source_id)], from_time=from_time,
                            to_time=to_time)

    if df.empty:
        print('create_trucoax_refill_filter(): No gas pressure data')
        return

    df.columns = ['gas_pressure']

    # create filtered signals
    df_filtered = df.reset_index()
    df_filtered = df_filtered.loc[(df_filtered.gas_pressure < 50) & (df_filtered.gas_pressure >= 5)]

    if df_filtered.empty:
        print('create_trucoax_refill_filter(): No data after filtering')
        return

    df_chunk_windows = detect_chunks_of_data_based_on_index(df_filtered, max_time_duration=120, min_time_duration=10)

    if df_chunk_windows.empty:
        print('create_trucoax_refill_filter(): No trucoax refill data')
        return

    df_filter_signal = generate_filter_signal(df_chunk_windows[['chunk_start', 'chunk_stop']]).astype('int64')
    df_filter_signal.rename(columns={'value': 'TruCoaxRefill'}, inplace=True)

    return df_filter_signal


def generate_filter_signal(df_time_window):
    """
    Generate a zero-one signal from time window data

    :param df_time_window: dataframe with start and end timestamps
    :return: 0/1 signal of start (1) and end (0) times
    """
    zero_one_signal = {'dn': [], 'value': []}
    for index, row in df_time_window.iterrows():
        zero_one_signal['dn'].extend([row[0], row[1]])
        zero_one_signal['value'].extend([1, 0])
    if len(df_time_window) > 0:
        df_filter_signal = pd.DataFrame(zero_one_signal['value'], index=zero_one_signal['dn'], columns=['value'])
    else:
        df_filter_signal = pd.DataFrame(zero_one_signal['value'], index=zero_one_signal['dn'])
        df_filter_signal['value'] = []

    return df_filter_signal


def detect_chunks_of_data_based_on_index(df, max_time_duration=None, min_time_duration=None,
                                         min_time_between=None):
    """
    Detect chuncks of data using the index difference between the exposures.
    The filtered data with a index delta <= 1 between exposures, are considered a
    chunk. Moreover, filtering on total duration of the chunck can be applied.

    :param df: dataframe with filtered data
    :param max_time_duration: maximum time interval of datapoints in the chuncks
    :param min_time_duration: minimum time interval of datapoints in the chuncks
    :param min_time_between: minimum time interval between chuncks
    :return: dataframe of chunk start and stop times
    """

    df.reset_index(inplace=True)
    df.loc[:, 'diff_idx'] = df['index'].diff().copy()
    df['time'] = pd.to_datetime(df['time'])
    df.loc[:, 'diff_time'] = df['time'].diff().dt.total_seconds().copy()
    # assume this the start of a lot (so there is a large delta time at the start); check below if this is true
    df.loc[0, 'diff_time'] = 1000  # arbitrary long time
    # same applies for the index difference
    df.loc[0, 'diff_idx'] = 1000

    df_times_between_chunks = df.loc[df.diff_idx > 1].copy()
    df_times_between_chunks.loc[:, 'chunck_counter'] = np.arange(len(df_times_between_chunks)) + 1
    df_times_between_chunks = df_times_between_chunks[['time', 'chunck_counter']].set_index('time')

    # filter the dose error data with the chunk start times
    df_chunk_counter = pd.concat([df.set_index('time'), df_times_between_chunks], axis=1)
    df_chunk_counter['time'] = pd.DatetimeIndex(df_chunk_counter.index)
    df_chunk_counter['chunck_counter'] = df_chunk_counter['chunck_counter'].fillna(method='ffill')

    df_chunk_windows = df_chunk_counter.groupby('chunck_counter').agg({
        'diff_time': 'max',
        'chunck_counter': 'max',
        'time': ['min', 'max', 'count']})
    df_chunk_windows.columns = ['_'.join(col) for col in df_chunk_windows.columns]
    df_chunk_windows.rename(columns={'chunck_counter_max': 'chunk_count',
                                     'time_count': 'n_counts',
                                     'time_min': 'chunk_start',
                                     'time_max': 'chunk_stop'},
                            inplace=True)

    # filter chunks above/below time duration threshold
    df_chunk_windows['duration'] = (df_chunk_windows.chunk_stop - df_chunk_windows.chunk_start).dt.total_seconds()
    if max_time_duration is not None:
        df_chunk_windows = df_chunk_windows.loc[df_chunk_windows.duration < max_time_duration]
    if min_time_duration is not None:
        df_chunk_windows = df_chunk_windows.loc[df_chunk_windows.duration > min_time_duration]

    # filter chunks below minimum time between each other
    df_chunk_windows['time_between'] = (
                df_chunk_windows.chunk_start - df_chunk_windows.chunk_stop.shift(1)).dt.total_seconds()
    if (min_time_between is not None) and (df_chunk_windows.empty is False):
        df_chunk_windows = df_chunk_windows.loc[(df_chunk_windows.time_between > min_time_between) | (
                df_chunk_windows.index.values == df_chunk_windows.index[0])]

    # remove arbitrary long time start
    if df_chunk_windows.empty is False:
        df_chunk_windows.loc[df_chunk_windows.index.values == df_chunk_windows.index[0], 'diff_time_max'] = np.nan

    return df_chunk_windows


def detect_chunks_of_data(df, min_time_between_chunks=2.5, min_time_duration=9, min_time_between=0, custom_columns=None,
                          custom_agg=None):
    """
    Detect chuncks of data using the time difference between the exposures.
    The filtered data with a sufficiently short time between exposures, are considered a
    chunk. Moreover, filtering on total duration of the chunck can be applied.

    :param df: dataframe with filtered data
    :param min_time_between_chunks: minimum time between chunks to be detect as the edge of the chunk
    :param min_time: minimum time interval of chunck
    :return: dataframe of chunk start and stop times
    """

    df = df.reset_index()
    df['time'] = pd.to_datetime(df['time'])
    df.loc[:, 'diff_time'] = df['time'].diff().dt.total_seconds().copy()
    # assume this the start of a lot (so there is a large delta time at the start); check below if this is true
    df.loc[0, 'diff_time'] = 1000  # arbitrary long time

    df_times_between_chunks = df.loc[df['diff_time'] > min_time_between_chunks].copy()
    df_times_between_chunks.loc[:, 'chunck_counter'] = np.arange(len(df_times_between_chunks)) + 1
    df_times_between_chunks = df_times_between_chunks[['time', 'chunck_counter']].set_index('time')

    # filter the dose error data with the chunk start times
    df_chunk_counter = pd.concat([df.set_index('time'), df_times_between_chunks], axis=1)
    df_chunk_counter['time'] = pd.DatetimeIndex(df_chunk_counter.index)
    df_chunk_counter['chunck_counter'] = df_chunk_counter['chunck_counter'].fillna(method='ffill')

    # define what signals need to be aggregated. Basic ones are:
    agg_dict = {
        'diff_time': ['max',
                      aliased_aggr(lambda x: x.iloc[1:].mean(), 'max_after_first'),
                      aliased_aggr(lambda x: x.iloc[1:].mean(), 'mean_after_first'),
                      aliased_aggr(lambda x: x.iloc[1:].min(), 'min_after_first'),
                      ],
        'chunck_counter': 'max',
        'time': ['min', 'max', 'count']}

    # add if defined, custom aggregated
    if custom_columns is not None:
        for column in custom_columns:
            agg_dict[column] = custom_agg

    # perform the aggregation
    df_chunk_windows = df_chunk_counter.groupby('chunck_counter').agg(agg_dict)
    df_chunk_windows.columns = ['_'.join(col) for col in df_chunk_windows.columns]
    df_chunk_windows.rename(columns={'chunck_counter_max': 'chunk_count',
                                     'time_count': 'n_counts',
                                     'time_min': 'chunk_start',
                                     'time_max': 'chunk_stop'},
                            inplace=True)

    df_chunk_windows.index = pd.DatetimeIndex(df_chunk_windows['chunk_start'])

    # extend start and end time to prevent aggregation issues
    df_chunk_windows.chunk_start -= pd.Timedelta(1e-6, 's')
    df_chunk_windows.chunk_stop += pd.Timedelta(1e-6, 's')

    # filter chunks below minimum duration
    df_chunk_windows['duration'] = (df_chunk_windows.chunk_stop - df_chunk_windows.chunk_start).dt.total_seconds()
    df_chunk_windows = df_chunk_windows.loc[df_chunk_windows.duration > min_time_duration]

    # filter chunks with hold-off time
    df_chunk_windows['time_between'] = (df_chunk_windows.chunk_start -
                                        df_chunk_windows.chunk_stop.shift(1)).dt.total_seconds()
    if not df_chunk_windows.empty:
        df_chunk_windows = df_chunk_windows.loc[(df_chunk_windows.time_between > min_time_between) |
                                                (df_chunk_windows.index == df_chunk_windows.index[0])]

    return df_chunk_windows


if __name__ == '__main__':

    client = UserLANClient()
    machine_list = get_machines(client)

    source_id = 62308
    ts_start_str = '2019-12-29 00:00'
    ts_stop_str = '2019-12-30 00:00'
    ts_start = pd.to_datetime(ts_start_str).tz_localize('UTC')
    ts_stop = pd.to_datetime(ts_stop_str).tz_localize('UTC')

    df_dlgc1_signal, df_ol_signal, df_ol_windows = create_openloop_filter(client, source_id, ts_start, ts_stop)

    df_trucoaxrefill = calculate_trucoax_refill_filter(client, source_id, ts_start, ts_stop)
