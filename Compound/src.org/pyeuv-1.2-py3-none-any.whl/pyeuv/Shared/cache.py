import os
import pickle
import pandas as pd


class DiskCache:
    """
    Stores and retrieves data on disk using pickle.

    Example:
    # Generate some random data
    df = pd.DataFrame(np.random.randn(100, 3), index=range(0, 100), columns=list("abc"))

    dc = DataCache()  # Create the store

    dc['df'] = df  # Store data with key 'df'
    df = df['df']  # Retrieve data identified by key 'df'
    c.delete('df')  # Delete data
    c.keys()        # List available keys

    """
    def __init__(self, cache_dir):
        """
        Creates a cache at the given directory.

        :param cache_dir: Path to the directory where to create/open the cache.
        :type cache_dir: str
        """
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        self._cache_dir = cache_dir

    def __getitem__(self, key):
        return self.load(key)

    def __setitem__(self, key, value):
        self.store(key, value)

    def store(self, key, obj):
        """
        Store the given object using the given key

        :param key: Key to lookup this object
        :type key: str
        :param obj: The object to store
        :type obj: Any object that can be pickled.

        :return: pandas.DataFrame
        """
        if isinstance(obj, pd.DataFrame):
            path = os.path.join(self._cache_dir, 'df_' + key + '.dat')
            obj.to_pickle(path)
        else:
            path = os.path.join(self._cache_dir, 'obj_' + key + '.dat')
            with open(path, 'w') as f:
                pickle.dump(obj, f)

    def keys(self):
        """ Returns a list of available keys """
        files = [x for x in os.listdir(self._cache_dir) if x.endswith('.dat')]
        keys = []
        for f in files:
            key = '_'.join(f.split('_')[1:])
            keys.append(key[:-4])  # Don't include .dat extension

        return keys

    def load(self, key):
        """ Returns the object at the given key """
        for fn in os.listdir(self._cache_dir):
            if key in fn:
                if fn.startswith('df_'):
                    return pd.read_pickle(os.path.join(self._cache_dir, fn))
                else:
                    with open(os.path.join(self._cache_dir, fn), 'r') as f:
                        return pickle.load(f)
        else:
            raise KeyError("Key not found: {0}".format(key))

    def delete(self, key):
        """ Deletes the object at the given key """
        for fn in os.listdir(self._cache_dir):
            filekey = '_'.join(fn.split('_')[1:])[:-4]
            if key == filekey:
                os.remove(os.path.join(self._cache_dir, fn))
                break
        else:
            raise KeyError("Key not found: {0}".format(key))

    def pop(self, key):
        """ Returns and deletes the object at the given key"""
        data = self.load(key)
        self.delete(key)
        return data

    def clear(self):
        """ Clears the cache """
        for k in self.keys():
            self.delete(k)


class SignalCache(DiskCache):
    """ Stores signals in cache """

    def get_signal(self, signal, tstart, tstop, tbuffer=pd.Timedelta(0, 'Days')):
        """
        Returns the given signal between tstart and tstop. If tstart is before
        the first datapoint in the cache a window with timestamps is returned
        to indicate the period that's not in the cache. The same applies to
        the case where tstop is later than the last datapoint. These periods
        are returned as overshoot_left and overshoot_right respectively.

        Raises KeyError if the signal doesn't exist in the cache.

        :param signal: Signal name .e.g. s39811.RT05.BDenergyAvgOn
        :type signal: str
        :param tstart: Start time of the data to include
        :type tstart: pd.Timestamp
        :param tstop: Stop time of the data to include
        :type tstop: pd.Timestamp
        :param tbuffer: Time delta for which the cached data has to be refreshed
        :type tbuffer: pandas.Timedelta
        :return: data, overshoot_left, overshoot_right
        :rtype: tuple(pd.DataFrame, list<pd.Timestamp>, list<pd.Timestamp>)
        """
        key = 'signalcache_' + signal
        df = self.load(key)

        if tstart > tstop - tbuffer:
            tbuffer = pd.Timedelta(min(tbuffer, tstop-tstart).days, 'Days')
            if tstart > tstop:
                raise ValueError("tstart must be smaller than tstop (- tbuffer)")
        if tstart > df.index[-1]:  # Requested data newer than available
            return pd.DataFrame(), None, [tstart, tstop]
        if tstop - tbuffer < df.index[0]:  # Requested data older than available
            return pd.DataFrame(), [tstart, tstop], None

        # Some or all of the data is available
        df = df.loc[(df.index >= tstart) & (df.index <= (tstop - tbuffer))]
        overshoot_left = None
        if df.index[0] > tstart:  # Missing data on the left
            overshoot_left = [tstart, df.index[0]]
        overshoot_right = None
        if df.index[-1] < tstop:  # Missing data on the right
            overshoot_right = [df.index[-1], tstop]

        return df, overshoot_left, overshoot_right

    def cache_signal(self, signal, data, return_updated=False):
        """
        Updates the cache with the given signal.

        :param signal: Signal to cache
        :type signal: str
        :param data: Data of the signal
        :type data: pd.Series or pd.DataFrame (Nx1)
        :param return_updated: Returns the updated signal that was stored in the cache
        :type return_updated: bool
        """
        if type(data) not in [pd.DataFrame, pd.Series]:
            raise TypeError("Input data must be of type pandas.Dataframe or pandas.Series.")
        if type(data) == pd.Series:
            data = pd.DataFrame(data)

        if type(data.index) != pd.DatetimeIndex:
            raise TypeError("Data index must be of type pd.DatetimeIndex.")

        key = 'signalcache_' + signal

        try:
            df_cached = self.load(key)
        except KeyError:
            df_cached = pd.DataFrame()

        df = df_cached
        df.update(data)
        df = pd.concat([df_cached, data], axis=0).sort_index()

        # Remove duplicate indices
        df.index.name = '_ts_index_'
        df.reset_index(inplace=True)
        df.drop_duplicates(subset=['_ts_index_'], inplace=True)
        df = df.set_index('_ts_index_')

        self.store(key, df)

        if return_updated:
            return df

    def cache_signal_fast(self, signal, data):
        """
        Updates the cache with the given signal.

        :param signal: Signal to cache
        :type signal: str
        :param data: Data of the signal
        :type data: pd.Series or pd.DataFrame (Nx1)
        """
        if type(data) not in [pd.DataFrame, pd.Series]:
            raise TypeError("Input data must be of type pandas.Dataframe or pandas.Series.")

        if type(data.index) != pd.DatetimeIndex:
            raise TypeError("Data index must be of type pd.DatetimeIndex.")

        key = 'signalcache_' + signal

        try:
            df_cached = self.load(key)
        except KeyError:
            df_cached = pd.DataFrame()

        df = df_cached
        df.update(data)

        df_left = data.loc[data.index < df_cached.index[0], :]
        df_right = data.loc[data.index > df_cached.index[-1], :]

        if not df_left.empty:
            df = pd.concat([df_left, df], axis=0)
        if not df_right.empty:
            df = pd.concat([df, df_right], axis=0)

        self.store(key, df.sort_index())

    def list_signals(self):
        signals = []
        for k in self.keys():
            if k.startswith('signalcache_'):
                signals.append(k.split('signalcache_')[1])

        return signals


