# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 22:04:28 2019

Author: RWKL
Date: 2019-01-21

The collector_selection provides a method of selecting a collector by clicking on buttons for customer, machine and collector.
Whenever a button is clicked, it generates or updates the configuration in which the colloctor and machine properties are stored.

*Example usage*

::

    from pyeuv.EUVDashboard.clients import UserLANClient
    from pyeuv.Shared.configuration import Configuration
    import pyeuv.Shared.collector_selection as selector
    
    client = UserLANClient()
    conf = Configuration()
    conf = selector.show(client)

"""

from .configuration import Configuration as config

import numpy as np
from ipywidgets import widgets
import pyeuv.Shared.shared as shared

def show(_client, scanners_only = True):
    """
    Shows the selection buttons to select a machine and collector.
    The shown customers and systems are based on the machine_list. The collectors from the collector.swap data from influx

    :param _client: connection to influx
    :param scanner_only: option to include or exclude sources without full scanner
    :returns: the configuration of the selected machine and collector
    """
    
    global machine_buttons, collector_buttons, machine_list, conf, client
    conf = config()
    client = _client
    machine_list = shared.get_machines(client, exclude_non_scanner=scanners_only)
    customer_list = np.unique(machine_list['customer'])
    
    customer_buttons = widgets.ToggleButtons(
        options = customer_list,
        description = 'Customer:',
    )
    machine_buttons = widgets.ToggleButtons(
        options = ['Select Customer'],
        description = 'Machine:',
        disabled = True,
    )
    collector_buttons = widgets.ToggleButtons(
        options = ['Select Machine'],
        description = 'Collector:',
        disabled = True,
    )
    #execute_all_button = widgets.Button(description="Select collector")
    customer_buttons.observe(customer_selected, 'value')#, conf)
    machine_buttons.observe(machine_selected, 'value')#, conf)
    collector_buttons.observe(collector_selected, 'value')#, conf)
    #execute_all_button.on_click(storeConfig)
    display(customer_buttons)
    display(machine_buttons)
    display(collector_buttons)
    return conf
#    display(execute_all_button)
    
    
def showMachineSelectionButtons(client, exclude_non_scanner=True):
    """
    Shows the selection buttons to select a machine
    The shown customers and systems are based on the machine_list.

    :param client: connection to influx
    :param scanner_only: option to include or exclude sources without full scanner
    """
    
    global machine_buttons, machine_list
    machine_list = shared.get_machines(client, exclude_non_scanner)
    customer_list = np.unique(machine_list['customer'])
    
    customer_buttons = widgets.ToggleButtons(
        options = customer_list,
        description = 'Customer:',
    )
    machine_buttons = widgets.ToggleButtons(
        options = ['Select Customer'],
        description = 'Machine:',
        disabled = True,
    )
    
    #execute_all_button = widgets.Button(description="Select collector")
    customer_buttons.observe(customer_selected, 'value')#, conf)
    machine_buttons.observe(machine_selected_no_collector, 'value')#, conf)
    display(customer_buttons)
    display(machine_buttons)

    
def customer_selected(v):
    """
    initializes the machine buttons after a customer has been selected. 
    It also stores information of the selected customer to the configuration 
    
    :param v: value and properties of the clicked button
    """
    
    conf.using_customer(v['new'])
    sublist = machine_list[machine_list['customer'] == v['new']]
    machine_buttons.options = {m['displayname']:{
            'machine':m['machine_nr'],
            'machine_name': m['displayname'],
            'source':m['source_nr'],
            'source_gen':m['hardware'],
            'vessel':m['vessel'],
            'tz':m['timezone']
        } for index, m in sublist.iterrows()}
    machine_buttons.tooltips = [m['displayname'] for index, m in sublist.iterrows()]
    machine_buttons.disabled = False
    machine_buttons.value = machine_buttons.options[machine_buttons.tooltips[0]]


def machine_selected(v):
    """
    initializes the collector buttons after a machine has been selected. 
    It also stores information of the selected machine to the configuration 
    
    :param v: value and properties of the clicked button
    """
    
    if v['new'] == None:
        return
    source_id = 's{}'.format(v['new']['source'])
    conf.using_machine(v['new']['machine'], v['new']['machine_name']).\
        using_source(source_id).\
        using_source_generation(v['new']['source_gen']).\
        using_vessel(v['new']['vessel']).\
        using_timezone(v['new']['tz']).\
        using_collector('')
        
    try:
        collectors = shared.get_collectors(client, source_id)
        
        collector_buttons.options = {c['swap']:{'name':c['swap'], 'start':c['start'], 'end':c['end']} for index, c in collectors.iterrows()}
        collector_buttons.value = None
        
        collector_buttons.disabled = False    
    except:
        print ('exception')
        collector_buttons.options = ['No collectors found']
        collector_buttons.disabled = True
    conf.using_collector('')    


def machine_selected_no_collector(v):
    """
    Stores information of the selected machine to the configuration 
    
    :param v: value and properties of the clicked button
    """
    
    if v['new'] == None:
        return
    conf.using_machine(v['new']['machine'], v['new']['machine_name']).\
        using_source('s' + v['new']['source']).\
        using_source_generation(v['new']['source_gen']).\
        using_vessel(v['new']['vessel']).\
        using_timezone(v['new']['tz']).\
        using_collector('')


def collector_selected(v):
    """
    Stores information of the selected collector to the configuration 
    
    :param v: value and properties of the clicked button
    """

    try:
        conf.using_collector(v['new']['name']).\
            using_start_time(v['new']['start']).\
            using_end_time(v['new']['end'])
    except:
        pass
