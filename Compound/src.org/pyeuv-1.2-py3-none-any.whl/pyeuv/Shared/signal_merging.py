u"""
signalmerging.py
Authors: DAAU
Date: 2019-01-07

Contains generic signal merging functionality
"""
import pandas as pd
import numpy as np

def prepare_concat(df, column_names, time_arr = None):
    """
    Function to prepare for a concatenation with feature to change column names and duplicate the time columns
    i.e., else after concatenation this column is gone (for the second dataframe)

    :param df: dataframe to be prepared
    :param column_names: option to rename column names
    :param time_arr: option to duplicate the time columns
    :return: prepared dataframe
    """
    df.columns = column_names
    df.index.names = ['time']
    try:
        df.index = df.index.tz_localize('UTC')
    except Exception as e:
        # timestamp already has timezone
        pass
    df = df.reset_index()
    df['time'] = pd.to_datetime(df['time'])
    if time_arr is not None:
        df[time_arr] = pd.to_datetime(df['time'])

    return df

def concat_df(df1,df2,check_size = False, match_exposure_id = True):
    """
    Concatenation function with feature to  perform same-size matching and matching based on exposure id

    :param df1: dataframe one to be matched
    :param df2: dataframe two to be matched
    :param check_size: option to perform same-size matching
    :param match_exposure_id: option to match based on exposure id
    :return: concatenated dataframe
    """
    df_concat = pd.concat([df1.set_index('time'), df2.set_index('time')], axis=1)
    if check_size:
        if len(df1) != len(df2):
            print('WARNING: dataframes not the same size')   # or add columns: ' + df1.columns[0] + ' and ' + df2.columns[0] + '
    if match_exposure_id:
        df_concat = df_concat.loc[~df_concat['exposure_id'].isnull()]
        df_concat['exposure_id'] = df_concat['exposure_id'].astype('int64')

    return df_concat