"""
wafer_lot_aggregation.py
Author: DAAU

Function for wafer or lot aggregation
"""

import numpy as np
import pandas as pd

from pyeuv.Shared.filters import generate_filter_signal, aliased_aggr
from pyeuv.Shared.signal_merging import prepare_concat, concat_df

def filter_lots_on_time_duration(df_lots):
    """
    Filters lots on a maximum time duration, after which they are removed

    :param df_lots: lot windows signal
    :return: filtered lot windows
    """
    # Filter out lots that take longer than 2 hours (expired) as they usually contain garbage.
    s_lot_duration = df_lots['stop'] - df_lots['start']
    df_lots = df_lots.loc[(s_lot_duration > pd.Timedelta(0)) & (s_lot_duration < pd.Timedelta(hours=2))]
    df_lots.index = range(0, df_lots.shape[0])

    return df_lots

def match_lot_name_and_id(lots, df_lot_name_id):
    """
    Matches lot id and name using LO_0050/51 codes.

    :param lots: dictionary of lot windows
    :param df_lot_name_id:
    :return:
        df_lots: lot-start-and-end-matched lot windows, including lot id and name
        n_match: number of lots that are matching lot start and end
        n_no_idname: number of lots which do not have a match based on lot name and id
        n_no_futuretime: number of lots without lot end
        n_multiple: number of lots which are matched multiple times
    """
    # Loop trough all LO_0050 codes and try to find a LO_0051 code with the same lot name and lot ID.
    n_match = 0
    n_no_idname = 0
    n_no_futuretime = 0
    n_multiple = 0
    if len(df_lot_name_id.loc[df_lot_name_id.code == 'LO-0051']) == 0:
        return pd.DataFrame(columns=['start', 'stop', 'lot_name', 'lot_id'], index=pd.to_datetime([], utc=True)), \
               n_match, n_no_idname, n_no_futuretime, n_multiple
    for index, row in df_lot_name_id.loc[df_lot_name_id.code == 'LO-0050'].iterrows():
        match = df_lot_name_id.loc[(df_lot_name_id.code == 'LO-0051') & (df_lot_name_id.lot_name == row.lot_name)]
        if match.empty:
            n_no_idname += 1
            continue
        if len(match) > 1:  # We found a LO_0050/LO-0051 pair so this is an actual lot
            # In rare cases (Lot aborts/crashes) we can have more LO_0050 codes for the same lot name.
            # In such cases, take the first LO_0051 with the same lot name that occurs after the LO-0050
            n_multiple += 1
            delta = match.index - index
            result = np.where(delta.total_seconds() > 0)[0]
            if result.size == 0:
                n_no_futuretime += 1
                continue  # Could not find a LO-0051 code after the current LO-0050. Log this problem and ignore the lot.
            idx = result[0]
            if idx.size >= 1:
                match = match.iloc[idx: idx + 1]
        n_match += 1
        lots['start'].append(index)
        lots['stop'].append(match.index[0])
        lots['lot_name'].append(match['lot_name'].str.cat())
        lot_id = df_lot_name_id.loc[(df_lot_name_id.index == match.iloc[0].name) & (df_lot_name_id.code == 'LO-0051'),\
            'lot_id'].drop_duplicates()

        # Workaround: In rare cases the lot_id is missing, give these lots an invalid LOT ID of -1. This way we can
        # still process these lots while keeping them separate from the others.
        if len(lot_id) == 0:
            lots['lot_id'].append(-1)
        else:
            lots['lot_id'].append(lot_id.values[0].astype(np.int64))

    df_lots = pd.DataFrame.from_dict(lots)

    return df_lots, n_match, n_no_idname, n_no_futuretime, n_multiple

def align_lots(df_lots, df_lot_windows):
    """
    Aligns lots. If the next lot starts before the current lot ends move the next lot start to the current lot end +1 sec.
    under the assumption that the range of 'df_lot_windows' is always smaller (from both edges), we don't need to take
    into account that there are no df_lot_windows not taken into account

    :param df_lots: lot-start-and-end-matched lot windows, including lot id and name
    :param df_lot_windows: lot windows identified using exposure data
    of the lot start and end time
    :return:
        df_lots: lot-start-and-end-matched lot windows that are matched with the exposure-based identification
        n_no_exposures: number of lots without lot end
    """


    # df_lots.drop(columns = ['issue','too_early'],inplace=True)
    df_lots['start_new'] = df_lots['start'].copy()
    df_lots['stop_new'] = df_lots['stop'].copy()
    df_lots['matched'] = False
    df_lots['idx_changed'] = False
    df_lots['lot_removed'] = False

    idx_current_lot_arr = []
    iii = 0  # start at 1 because need to compare to previous lot
    while iii < df_lot_windows.shape[0]:
        # check which lot is withing the LO-0050/51 (lot-start/stop) boundaries
        range_current_lot = df_lots.loc[(df_lots.stop > df_lot_windows.lot_stop.iloc[iii]) & \
                                        (df_lots.start < df_lot_windows.lot_start.iloc[iii])]
        if len(range_current_lot) > 0:
            idx_current_lot = range_current_lot.index[0]
            if idx_current_lot in df_lots.loc[df_lots.matched].index:
                # Check for another lot which can be matched if the current one is already matched
                # This is in cases where you have few parralel initialized lots (few LO-0050; lot start signals, without
                # LO-0051; lot stop signals)
                while idx_current_lot in df_lots.loc[df_lots.matched].index:
                    idx_current_lot += 1
                # Check if index is still in range
                if idx_current_lot > df_lots.index[-1]:
                    print('match_lots():align_lots(): Index out of range')
                    break
                # Check whether lot is within the LO-0050/51 (lot-start/stop) boundaries or if we're dealing with the
                # first lot of df_lots
                if (not ((df_lots.loc[idx_current_lot, 'start'] < df_lot_windows.lot_start.iloc[iii]) & \
                        (df_lots.loc[idx_current_lot, 'stop'] > df_lot_windows.lot_stop.iloc[iii]))) | \
                        (idx_current_lot-1 == df_lots.index[0]):
                    # For the first lot in df_lots, take the last lot in the time window as initial condtion estimate.
                    # If it involves a later event, the lot possibly had an auto-recovery and started again (leading to \
                    # 2 lots); also in this case take the last lot.
                    # Remove the first lot, but do add a tag
                    df_lots.loc[idx_current_lot - 1, 'lot_removed'] = True
                    # > use the following line to select the second lot
                    idx_current_lot = idx_current_lot-1
                    # > use the following two lines to select the first lot
                    # iii += 1
                    # continue
                else:
                    df_lots.loc[idx_current_lot, 'idx_changed'] = True
            df_lots.loc[idx_current_lot, 'start_new'] = df_lot_windows.lot_start.iloc[iii]
            df_lots.loc[idx_current_lot, 'stop_new'] = df_lot_windows.lot_stop.iloc[iii]
            df_lots.loc[idx_current_lot, 'matched'] = True

        iii += 1

    # remove the lots without match (since these may interfere with the matched lot windows)
    df_lots = df_lots.loc[df_lots.matched].copy()

    if not df_lots.empty:
        df_lots['start_time_delta'] = (df_lots['start_new'] - df_lots['start']).dt.total_seconds()
        df_lots['stop_time_delta'] = (df_lots['stop_new'] - df_lots['stop']).dt.total_seconds()
    else:
        df_lots['start_time_delta'] = []
        df_lots['stop_time_delta'] = []

    # remove duplicated cases (e.g. where no data was found or only SLIE measurements)
    n_no_exposures = len(df_lots.loc[df_lots.stop_new.duplicated(keep='first')])
    df_lots = df_lots.loc[~df_lots.stop_new.duplicated(keep='first')].copy()

    # temporarily columns 'start_new' and 'start_new' are used in order to debug if necessary. Let's remove them:
    # df_lots.drop(columns=['start','stop'],inplace=True)
    df_lots.rename(columns={'start_new': 'start','stop_new': 'stop','start':'start_old','stop':'stop_old'}, inplace=True)

    return df_lots, n_no_exposures

def generate_wafer_lot_windows(df_dose_data, min_dies_in_wafer_criteria, max_dies_in_wafer_criteria, min_time_between_wafers,
                               time_between_dies_criteria, typical_delta_time_slie, margin_delta_time_slie,
                               min_time_between_slie, max_time_between_slie, min_time_before_lot,is_S1S2):
    """
    This function determines when a wafer and lot start and end based on die exposure data
    First of all, it recognizes when a lot starts based on a SLIE measurement, using function identify_slie_scan, and
    it tags these exposures. Next, it checks when exposures have a large delta time "min_time_between_wafers" and tags
    these exposures as possible wafer/lot starts. It then identifies a wafer if there is at least
    "min_dies_in_wafer_criteria" die exposures between the identified wafers start times. Finally, it identifies lot
     windows if there is at least a wafer between two lot starts (=SLIE measurements) times. Some more filtering is
     applied to disregard wafers that are not expected to be part of the identified lot.

    :param df_dose_data: die exposure data
    :param min_dies_in_wafer_criteria: maximum number of die exposures for which the set of exposures is still counted as wafer
    :param max_dies_in_wafer_criteria: minimum number of die exposures for which the set of exposures is still counted as wafer
    :param min_time_between_wafers: minimum time between wafers
    :param time_between_dies_criteria: exclusion time (wafers after a long time gap are excluded)
    :param typical_delta_time_slie: typical delta time between two exposures during a slie measurements
    :param margin_delta_time_slie: margin taken from the typical_delta_time_slie value to be used for the calculation
    :param min_time_between_slie: the time which should be minimally between two SLIE measurements
    :param max_time_between_slie: the time which should be maximally between two SLIE measurements
    :param min_time_before_lot: minimal time before another lot starts
    :return:
        df_wafer_windows_export: wafer windows identified using exposure data
        df_lot_windows_ext: lot windows identified using exposure data
        lot_start_exposures: dataframe of die exposures during the lot start signature (=slie measurements)
    """

    # index die exposures in order to compute wafers by a time delta method
    df_dose_data_trunc = df_dose_data[['exposure_id']].copy()
    df_dose_data_trunc = add_diff_time(df_dose_data_trunc)

    # identify wafer start timestamps
    times_between_wafers_and_lots = df_dose_data_trunc.loc[df_dose_data_trunc['diff_time'] > min_time_between_wafers].copy()
    times_between_wafers_and_lots['diff_idx'] = times_between_wafers_and_lots['index'].diff()
    times_between_wafers_and_lots.loc[:,'start_wafer_lot'] =  np.arange(len(times_between_wafers_and_lots)) + 1

    if times_between_wafers_and_lots.empty:
        print('calculate_wafer_lot_windows():generate_wafer_lot_windows(): No wafers/lots detected')
        return

    # identify lot start timestamps (=slie measurements)
    try:
        times_start_lot, lot_start_exposures = identify_lot_start(df_dose_data_trunc, typical_delta_time_slie, \
            margin_delta_time_slie, min_time_between_slie, max_time_between_slie, min_time_before_lot)
    except:
        print('calculate_wafer_lot_windows():generate_wafer_lot_windows(): Abort calculation')
        return

    if is_S1S2:
        # For S1/S2 wafers are seperated by a single SLIE measurement (4 exposures), and a double SLIE measurement
        # (8 exposures) at the start of the wafer.
        times_start_wafer = times_start_lot.copy()
        times_start_lot = times_start_lot.loc[times_start_lot.time_count == 8].copy()

        # concatenate both dataframes to obtain one dataframe with both the start wafer and the start lots timestamps
        # (seperately indicated).
        times_between_wafers_and_lots_extended = pd.concat([\
            times_start_wafer[['time_min','diff_idx_first','diff_time_first']].rename(
                columns={'diff_idx_first': 'diff_idx','diff_time_first': 'diff_time'}).set_index('time_min'), \
            times_start_lot[['time_min','start_lot','time_count']].set_index('time_min')], axis=1)
        times_between_wafers_and_lots['start_lot'],times_between_wafers_and_lots['time_count'] = np.nan,np.nan
        # add new timestamps with a large delta time
        times_between_wafers_and_lots = times_between_wafers_and_lots.loc[~times_between_wafers_and_lots.time.isin(\
            times_between_wafers_and_lots_extended.index)]
        times_between_wafers_and_lots_extended = pd.concat([times_between_wafers_and_lots_extended,\
            times_between_wafers_and_lots[['time','start_wafer_lot','diff_idx','diff_time','start_lot',\
            'time_count']].set_index('time')],sort=True).sort_index()
        # renumber wafer and lot starts
        times_between_wafers_and_lots_extended['start_wafer_lot'] = np.arange(len(times_between_wafers_and_lots_extended)) + 1
    else:
        # concatenate both dataframes to obtain one dataframe with both the start wafer and the start lots timestamps
        # (seperately indicated).
        times_between_wafers_and_lots_extended = pd.concat([times_between_wafers_and_lots[['time','start_wafer_lot',\
            'diff_idx','diff_time']].set_index('time'), \
            times_start_lot[['time_min','start_lot','time_count']].set_index('time_min')], axis=1)

    # connect lot start to start wafer if the time delta between the slie measurement and the wafer is longer than 2.5 s
    remove_these_cases = times_between_wafers_and_lots_extended.loc[(times_between_wafers_and_lots_extended.diff_idx == \
        times_between_wafers_and_lots_extended.time_count.shift(1)) & \
        (times_between_wafers_and_lots_extended.diff_idx == 4)].copy()
    remove_these_cases = remove_these_cases.loc[remove_these_cases.start_lot.isnull()].copy()
    times_between_wafers_and_lots_extended = times_between_wafers_and_lots_extended.loc[\
        ~times_between_wafers_and_lots_extended.index.isin(remove_these_cases.index)].copy()
    times_between_wafers_and_lots_extended.drop(['diff_idx','diff_time','time_count'], axis=1, inplace=True)
    times_between_wafers_and_lots_extended.loc[:,'start_wafer_lot'] =  np.arange(len(times_between_wafers_and_lots_extended)) + 1

    # filter the dose error data with the wafer/lot start times
    filtered_data = pd.concat([df_dose_data_trunc.set_index('time'),times_between_wafers_and_lots_extended],axis=1).copy()
    filtered_data['time'] = pd.DatetimeIndex(filtered_data.index)
    filtered_data['start_lot'] = filtered_data['start_lot'].fillna(method='ffill')
    filtered_data['start_wafer_lot'] = filtered_data['start_wafer_lot'].fillna(method='ffill')
    # remove lot start exposures for calculation of statistics
    filtered_data['time_excl_slie'] = filtered_data['time'].copy()
    filtered_data.loc[filtered_data.index.isin(lot_start_exposures.index),'time_excl_slie'] = np.nan

    # generate wafers windows by aggregation
    df_wafer_windows_ext = filtered_data.groupby('start_wafer_lot').agg({
                    'diff_time': [aliased_aggr(lambda x: x.iloc[0],'first'), \
                                  aliased_aggr(lambda x: x.iloc[1:].max(), 'max_after_first'),
                                  aliased_aggr(lambda x: x.iloc[1:].median(), 'median_after_first'),
                                  aliased_aggr(lambda x: x.iloc[1:].min(), 'min_after_first')],
                    'start_lot':'max',
                    'start_wafer_lot':['max','count'],'time':['min','max'],\
                    'time_excl_slie': ['min','count']})
    df_wafer_windows_ext.columns = ['_'.join(col) for col in df_wafer_windows_ext.columns]
    df_wafer_windows_ext.rename(columns={'start_lot_max': 'start_lot',\
                                         'start_wafer_lot_max':'wafer_counter',\
                                         'start_wafer_lot_count':'n_dies_incl_lot_start',\
                                         'time_excl_slie_count':'n_dies', \
                                         'time_min': 'lot_start',
                                         'time_excl_slie_min':'wafer_start',
                                         'time_max':'wafer_stop'}, inplace=True)

    # calculate the time between two possible wafers start times
    df_wafer_windows_ext['diff_lot'] = df_wafer_windows_ext.start_lot.diff()

    ############### filter wafers ###############
    # if there are wafers very late after the main set of wafers in the lot, tag these
    df_wafer_windows_ext['remove_selector'] = np.nan
    df_wafer_windows_ext.loc[df_wafer_windows_ext.diff_lot >= 1, 'remove_selector'] = 0
    # condition for removing is that the lot start is not present (diff_lot==0) and the time is longer than the hold-off time
    df_wafer_windows_ext.loc[((df_wafer_windows_ext.diff_lot == 0) & (df_wafer_windows_ext.diff_time_first > \
        time_between_dies_criteria)),'remove_selector'] = 1
    df_wafer_windows_ext['remove_selector'] = df_wafer_windows_ext['remove_selector'].fillna(method='ffill')
    df_wafer_windows_ext.drop(['diff_lot','diff_time_first'], axis=1, inplace=True)
    # remove cases with no wafer exposures (i.e. only SLIE exposures)
    df_wafer_windows_ext = df_wafer_windows_ext.loc[~df_wafer_windows_ext.wafer_start.isnull()].copy()
    # remove wafers which are not at least a critical number of exposures; these are probably not wafers
    df_wafer_windows_ext = df_wafer_windows_ext.loc[(df_wafer_windows_ext.n_dies_incl_lot_start >= min_dies_in_wafer_criteria) & \
        (df_wafer_windows_ext.n_dies_incl_lot_start < max_dies_in_wafer_criteria)].copy()
    # calculate the new delta between wafers (after removal), i.e. different than diff_time_first due to prevoius step
    df_wafer_windows_ext['delta_time_between_wafers'] = (df_wafer_windows_ext.wafer_start - \
        df_wafer_windows_ext.wafer_stop.shift(1)).dt.total_seconds()
    # expand the wafer window slightly, not to cause issues with aggregation (always save)
    df_wafer_windows_ext.wafer_start = df_wafer_windows_ext.wafer_start - pd.Timedelta('0.000001s')
    df_wafer_windows_ext.wafer_stop = df_wafer_windows_ext.wafer_stop + pd.Timedelta('0.000001s')

    # make df to export (without excluding wafers yet that occur very long after the main set of wafers in the lot
    # (tagged with 'remove_selector')
    df_wafer_windows_export = df_wafer_windows_ext.copy()
    # now, remove these wafers to prepare for lot aggregation
    df_wafer_windows_ext = df_wafer_windows_ext.loc[~(df_wafer_windows_ext['remove_selector'] == 1)].copy()
    df_wafer_windows_ext.drop(['remove_selector'], axis=1, inplace=True)
    # calculate when a lot starts and stops
    df_lot_windows_ext = df_wafer_windows_ext.groupby('start_lot').agg(
        {'delta_time_between_wafers': [aliased_aggr(lambda x: x.iloc[0],'first'),
                                      aliased_aggr(lambda x: x.iloc[1:].max(),'max_after_first'),
                                      aliased_aggr(lambda x: x.iloc[1:].min(),'min_after_first')],
         'start_lot':'max','n_dies':['max','min','count','sum'], \
         'lot_start': 'min',
         'wafer_stop':'max'})  # for debugging add: 'time_excl_slie_min':'min',\
    df_lot_windows_ext.columns = ['_'.join(col) for col in df_lot_windows_ext.columns]
    df_lot_windows_ext.rename(columns={'lot_count_max':'start_lot',\
                                       'n_dies_count':'n_wafers',\
                                       'n_dies_sum':'total_n_dies',\
                                       'lot_start_min': 'lot_start',\
                                       'wafer_stop_max':'lot_stop',\
                                       'start_lot_max':'lot_counter'}, inplace=True)

    # expand the lot window slightly, not to cause issues with aggregation (always save)
    df_lot_windows_ext.lot_start = df_lot_windows_ext.lot_start - pd.Timedelta('0.000001s')
    df_lot_windows_ext.lot_stop = df_lot_windows_ext.lot_stop + pd.Timedelta('0.000001s')

    return df_wafer_windows_export, df_lot_windows_ext, lot_start_exposures

def detect_8exp_slie_scan(x,min_time_between_slie,max_time_between_slie,typical_delta_time_slie,margin_delta_time_slie,\
        min_time_before_lot):
    """
    Matches specific fingerprint of delta time during a slie measurements in the case it consists of 4 exposures.

    :param x: die exposures during slie to be matched
    :param min_time_between_slie: the time which should be minimally between two SLIE measurements
    :param max_time_between_slie: the time which should be maximally between two SLIE measurements
    :param typical_delta_time_slie: typical delta time between two exposures during a slie measurements
    :param margin_delta_time_slie: margin taken from the typical_delta_time_slie value to be used for the calculation
    :param min_time_before_lot: minimal time before another lot starts
    :return: Match = True/False
    """

    is_8exp_slie_scan = int(x.diff_time.iloc[0] > min_time_before_lot) & \
                       all(abs(x.diff_time.iloc[1:3] - typical_delta_time_slie) < margin_delta_time_slie) & \
                       ((x.diff_time.iloc[4] > min_time_between_slie) & (x.diff_time.iloc[4] < max_time_between_slie)) & \
                       all(abs(x.diff_time.iloc[5:7] - typical_delta_time_slie) < margin_delta_time_slie)

    return is_8exp_slie_scan

def detect_4exp_slie_scan(x,min_time_between_slie,max_time_between_slie,typical_delta_time_slie,margin_delta_time_slie, \
        min_time_before_lot):
    """
    Matches specific fingerprint of delta time during a slie measurements in the case it consists of 4 exposures.

    :param x: die exposures during slie to be matched
    :param min_time_between_slie: the time which should be minimally between two SLIE measurements
    :param max_time_between_slie: the time which should be maximally between two SLIE measurements
    :param typical_delta_time_slie: typical delta time between two exposures during a slie measurements
    :param margin_delta_time_slie: margin taken from the typical_delta_time_slie value to be used for the calculation
    :param min_time_before_lot: minimal time before another lot starts
    :return: Match = True/False
    """

    is_4exp_slie_scan = int(x.diff_time.iloc[0] > min_time_before_lot) & \
                       (abs(x.diff_time.iloc[1] - typical_delta_time_slie) < margin_delta_time_slie) & \
                       ((x.diff_time.iloc[2] > min_time_between_slie) & (x.diff_time.iloc[2] < max_time_between_slie)) & \
                       (abs(x.diff_time.iloc[3] - typical_delta_time_slie) < margin_delta_time_slie)

    return is_4exp_slie_scan

def identify_lot_start(df_dose_data_trunc, typical_delta_time_slie, margin_delta_time_slie, \
                               min_time_between_slie, max_time_between_slie, min_time_before_lot):
    """
    Identifies when a slie measurement occurs using a specific fingerprint of delta time during a slie measurements.

    :param df_dose_data_trunc: die exposure data
    :param typical_delta_time_slie: typical delta time between two exposures during a slie measurements
    :param margin_delta_time_slie: margin taken from the typical_delta_time_slie value to be used for the calculation
    :param min_time_between_slie: the time which should be minimally between two SLIE measurements
    :param max_time_between_slie: the time which should be maximally between two SLIE measurements
    :param min_time_before_lot: minimal time before another lot starts
    :return:
        times_start_lot: dataframe of timestamps when lots started
        lot_start_exposures: dataframe of die exposures during the lot start signature (=slie measurements)

    """

    for typical_delta_time_slie_select in typical_delta_time_slie:
        times_during_lots = detect_slie_scan(df_dose_data_trunc, min_time_between_slie, max_time_between_slie, \
            typical_delta_time_slie_select, margin_delta_time_slie,  min_time_before_lot)
        if not times_during_lots.empty:
            break
    if times_during_lots.empty:
        print('calculate_wafer_lot_windows():generate_wafer_lot_windows():identify_lot_start(): No SLIE measurements detected')
        return

    # identify the slie measurement, and compute info
    times_start_lot = times_during_lots.groupby('start_lot').agg(
        {'diff_idx': aliased_aggr(lambda x: x.iloc[0],'first'),
         'time': ['min', 'max', 'count'],
         'diff_time': aliased_aggr(lambda x: x.iloc[0],'first')})
    times_start_lot.columns = ['_'.join(col) for col in times_start_lot.columns]
    times_start_lot.reset_index(inplace=True)

    # create a dataframe with the lot start (=slie measurement) exposures
    lot_start_exposures = times_during_lots.loc[times_during_lots.start_lot.isin(times_start_lot.start_lot)].copy()
    lot_start_exposures.index = pd.to_datetime(lot_start_exposures.time)

    return times_start_lot, lot_start_exposures

def detect_slie_scan(df_dose_data_trunc, min_time_between_slie, max_time_between_slie,
                            typical_delta_time_slie, margin_delta_time_slie, min_time_before_lot):
    """
    Algorithm to detect SLIE measurements by specific time fingerprint.

    :param df_dose_data_trunc: data with dose errors
    :param typical_delta_time_slie: typical delta time between two exposures during a slie measurements
    :param margin_delta_time_slie: margin taken from the typical_delta_time_slie value to be used for the calculation
    :param min_time_between_slie: the time which should be minimally between two SLIE measurements
    :param max_time_between_slie: the time which should be maximally between two SLIE measurements
    :param min_time_before_lot: minimal time before another lot starts
    :return: dataframe with only slie measurements
    """

    # get rid of most normal exposures by having a exposure delta time threshold (exception for the typical inter-SLIE time)
    times_during_lots = df_dose_data_trunc.loc[
        (abs(df_dose_data_trunc.diff_time - typical_delta_time_slie) < margin_delta_time_slie) | \
        ((df_dose_data_trunc.diff_time > min_time_between_slie) & (
                    df_dose_data_trunc.diff_time < max_time_between_slie)) | \
        (df_dose_data_trunc.diff_time > min_time_before_lot)].copy()

    if times_during_lots.empty:
        print(
            'calculate_wafer_lot_windows():generate_wafer_lot_windows():detect_slie_scan(): After filtering no data to '
            'detect SLIE measurements')
        return

    # chop the times up in groups (with single index differences)
    times_during_lots.reset_index(inplace=True)
    times_during_lots.loc[:, 'diff_idx'] = -1 * times_during_lots.loc[
        times_during_lots['diff_time'] > max_time_between_slie, 'index'].diff(periods=-1)
    times_during_lots.loc[~times_during_lots['diff_idx'].isnull(), 'start_lot'] = np.arange(
        len(times_during_lots.loc[~times_during_lots['diff_idx'].isnull()])) + 1

    # check whether the start and end can be included for diff_idx and diff_time (if we don't do this, data loss will
    # occur at the start and end, i.e., in the case of diff(), there is NaN at the start, in the case of
    # diff(periods=-1) there is NaN at the end.
    idx_first = times_during_lots.index < times_during_lots.loc[~times_during_lots['diff_idx'].isnull()].index[0]
    if any(times_during_lots.loc[idx_first].diff_time < max_time_between_slie):
        times_during_lots.loc[0, 'diff_idx'] = len(times_during_lots.loc[idx_first])
        times_during_lots.loc[0, 'start_lot'] = 0
    else:
        times_during_lots = times_during_lots.loc[~idx_first]
    idx_last_diff_idx = times_during_lots.loc[times_during_lots['diff_time'] > max_time_between_slie].index[-1]
    idx_last = times_during_lots.index >= idx_last_diff_idx
    if any(times_during_lots.loc[idx_last].diff_time < max_time_between_slie):
        times_during_lots.loc[idx_last_diff_idx, 'diff_idx'] = len(times_during_lots.loc[idx_last])
        times_during_lots.loc[idx_last_diff_idx, 'start_lot'] = times_during_lots.start_lot.max() + 1
    else:
        times_during_lots = times_during_lots.loc[~idx_last]
    times_during_lots.loc[:, 'start_lot'] = times_during_lots['start_lot'].fillna(method='ffill')

    # 1) Check if the start lot is correct; it should contain at least two SLIE measurements; this means inter SLIE
    #    measurement times (~0.76 s) and intra SLIE measurement times diff (~0.7-2 s). The total number is either 4 or 8;
    #    assess each case individually.
    # 2) Check if it starts 'a while' after the events.
    # 3) Check if the sequence is without gaps in exposure id
    idx_limit_number = times_during_lots.groupby('start_lot').agg({'time': 'count'})
    times_during_lots_tmp = pd.DataFrame()
    for lot_count in idx_limit_number.index:
        x = times_during_lots.loc[times_during_lots.start_lot == lot_count]
        is_slie = False
        if len(x) >= 8:
            if detect_8exp_slie_scan(x, min_time_between_slie, max_time_between_slie, typical_delta_time_slie,
                margin_delta_time_slie, min_time_before_lot):
                x = x[:8]
                is_slie = True
        if (len(x) >= 4) & (is_slie == False):
            if detect_4exp_slie_scan(x, min_time_between_slie, max_time_between_slie, typical_delta_time_slie,
                margin_delta_time_slie, min_time_before_lot):
                x = x[:4]
                is_slie = True
        if is_slie:
            # check if exposures are sequential
            if x.exposure_id.max() - x.exposure_id.min() == len(x) - 1:
                times_during_lots_tmp = times_during_lots_tmp.append(x)

    return times_during_lots_tmp

def add_diff_time(df):
    """
    Add a time diff columns to the data based on index values

    :param df: dataframe
    :return: dataframe with time delta
    """

    df = df.reset_index()
    df['index'] = df.index
    df['time'] = pd.to_datetime(df['time'])
    df.loc[:, 'diff_time'] = df['time'].diff().dt.total_seconds().copy()
    # assume this the start of a lot (so there is a large delta time at the start); check below if this is true
    df.loc[0, 'diff_time'] = 1000

    return df

def calculate_wafer_lot_windows(df_dict, verbose=False):
    """
    Determine the raw wafer and lot windows based on the dose error data.

    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :param df_dict: dictionary containing:
        df_dose_error: dataframe with dose error values
        df_dose_id: dataframe with exposure ids
    :return:
        df_dose_data: exposures without the SLIE measurement (either 4 or 8) at the start of the lot
        df_wafer_windows: signal with wafer start and stop timestamps
        df_lot_windows: signal with lot start and stop timestamps
        lot_start_exposures: exposures of the SLIE measurement
    """

    df_dose_error = df_dict['df_dose_error']
    df_dose_id = df_dict['df_dose_id']
    machine = df_dict['machine']

    # check for sufficient data
    if df_dose_error.empty:
        print('calculate_wafer_lot_windows(): ScannerLog.de_err not available')
        return df_dict
    if df_dose_id.empty:
        print('calculate_wafer_lot_windows(): ScannerLog.exposure_handle not available')
        return df_dict
    if machine.empty:
        print('calculate_wafer_lot_windows(): machine info not available')
        return df_dict

    df_dose_error = prepare_concat(df_dose_error, ['dose_error'])
    df_dose_id = prepare_concat(df_dose_id, ['error_code', 'exposure_id'])

    # concatenate data
    df_dose_data = concat_df(df_dose_error, df_dose_id, check_size=True)

    # filter only the interesting signals
    df_dose_data = df_dose_data.loc[df_dose_data['error_code'].isin(['DW-343A', 'DW-343B', 'DW-3411', 'DW-3425'])]

    # make dw-3425 dose errors negative
    df_dose_data.loc[(df_dose_data['error_code'].isin(['DW-3425'])), 'dose_error'] = -1 * df_dose_data.loc[
        (df_dose_data['error_code'].isin(['DW-3425'])), 'dose_error']

    print('calculate_wafer_lot_windows(): Identify wafer, lot and repair windows')
    min_dies_in_wafer_criteria = 25  # this ensures that only real lot are included (some pre-lot exposures have 4 < exposures <= 20).
    max_dies_in_wafer_criteria = 3000  # this ensures that wafers of ~180 die exposures are included

    if machine['version'].upper() in ['S1', 'S2']:  # For S1/S2 systems, see worker:post_process_rt5()
        min_time_between_wafers = 50  # (s) minimal time between two wafers
        min_time_before_lot = 7  # (s) minimal time before another lot starts
        time_between_dies_criteria = 500  # (s) this ensures that if there are wafers after a set of wafers (=lot), these will be excluded
        typical_delta_time_slie = [0.742,0.764,0.864]  # (s) typical delta time between two exposures during a slie measurements
        margin_delta_time_slie = 0.02  # (s) margin taken from the typical_delta_time_slie value to be used for the calculation
        min_time_between_slie = 0.7  # (s) the value which should be minimally between two SLIE measurements
        max_time_between_slie = 2.0  # (s) the same as above, but maximum time
        is_S1S2 = True
    else:
        min_time_between_wafers = 2.0  # (s) minimal time between two wafers
        min_time_before_lot = 10  # (s) minimal time before another lot starts
        typical_delta_time_slie = [0.764]  # (s) typical delta time between two exposures during a slie measurements
        margin_delta_time_slie = 0.02  # (s) margin taken from the typical_delta_time_slie value to be used for the calculation
        min_time_between_slie = 0.9  # (s) the value which should be minimally between two SLIE measurements
        max_time_between_slie = 2.0  # (s) the same as above, but maximum time
        time_between_dies_criteria = 1000  # (s) this ensures that if there are wafers after a set of wafers (=lot), these will be excluded
        is_S1S2 = False

    try:
        df_wafer_windows_ext, df_lot_windows_ext, lot_start_exposures = generate_wafer_lot_windows(
            df_dose_data,
            min_dies_in_wafer_criteria,
            max_dies_in_wafer_criteria,
            min_time_between_wafers,
            time_between_dies_criteria,
            typical_delta_time_slie,
            margin_delta_time_slie,
            min_time_between_slie,
            max_time_between_slie,
            min_time_before_lot,
            is_S1S2)
    except:
        print('calculate_wafer_lot_windows(): Abort calculation')
        return df_dict

    # remove lot start exposures for calculation of statistics
    df_dose_data = df_dose_data.loc[~df_dose_data.index.isin(lot_start_exposures.index)].copy()

    df_wafer_windows = df_wafer_windows_ext[['wafer_start', 'wafer_stop','n_dies','delta_time_between_wafers']].copy()
    # make index the wafer start time
    df_wafer_windows.index = pd.DatetimeIndex(df_wafer_windows['wafer_start'])

    df_lot_windows = df_lot_windows_ext[['lot_start', 'lot_stop']].copy()
    # make index the wafer start time
    df_lot_windows.index = pd.DatetimeIndex(df_lot_windows['lot_start'])

    print('calculate_wafer_lot_windows(): Generate wafer signals')
    df_wafer_signal = generate_filter_signal(df_wafer_windows)

    if verbose:
        # Stats for debugging
        print("calculate_wafer_lot_windows(): ----- WAFER/LOT WINDOWS PROCESS SUMMARY -----")
        print("calculate_wafer_lot_windows(): # die exposures        :{0}".format(len(df_dose_data)))
        print("calculate_wafer_lot_windows(): # wafers               :{0}".format(len(df_wafer_windows)))
        print("calculate_wafer_lot_windows(): % dies in wafers       :{0:.1f}".format(100 * float(df_wafer_windows.n_dies.sum()) \
            / len(df_dose_data)))
        print("calculate_wafer_lot_windows(): # lots                 :{0}".format(len(df_lot_windows_ext)))
        print("calculate_wafer_lot_windows(): % dies in lots         :{0:.1f}".format(100 * float(df_lot_windows_ext.total_n_dies.sum()) \
            / len(df_dose_data)))
        print("calculate_wafer_lot_windows(): % wafers in lots       :{0:.1f}".format(100 * float(df_lot_windows_ext.n_wafers.sum()) \
            / len(df_wafer_windows)))

    df_dict['df_dose_data'] = df_dose_data
    df_dict['df_wafer_windows'] = df_wafer_windows
    df_dict['df_wafer_signal'] = df_wafer_signal
    df_dict['df_lot_windows'] = df_lot_windows

    return df_dict
