# -*- coding: utf-8 -*-
"""
Created on Mon Jan 21 22:07:04 2019

@author: rwiegger

The Configuration provides a class to facilitate storage of machine and collector properties.
It enables to build up the configuration step by step, for instance in a menu of buttons selecting the customer, machine and collector.
"""

import pandas as pd

class Configuration():
    """
    Configuration facilitates storage of machine and collector properties, and enables to update these properties through functions
    """
    
    source_id = ''
    machine_id = ''
    machine_name = ''
    collector_name = ''
    start_time = ''
    end_time = ''
    timezone = ''
    source_generation = ''
    vessel_id = ''
    customer = ''
    
    # The class "constructor" - It's actually an initializer 
    #def __init__(self):


    def using_customer(self, customer):
        """
        Set the customer
        
        :param customer: the customer
        """
        
        self.customer = customer
        return self


    def using_collector(self, collector_name):
        """
        Set the collector name
        
        :param collector_name: the collector name
        """
        
        self.collector_name = collector_name
        return self


    def using_start_time(self, start_time):
        """
        Set the timestamp the collector was put in the source
        
        :param start_time: the timestamp the collector was installed
        """
        
        self.start_time = start_time
        return self


    def using_end_time(self, end_time):
        """
        Set the timestamp the collector was extracted from the source
        
        :param end_time: the timestamp the collector was extracted from the source
        """
        
        self.end_time = end_time
        return self


    def using_timezone(self, timezone):
        """
        Set the timezone of the machine
        
        :param timezone: the timezone where the machine is located
        """
        
        self.timezone = timezone
        return self


    def using_source(self, source_id):
        """
        Set the source id
        
        :param source_id: the id of the source
        """
        
        self.source_id = source_id
        return self


    def using_machine(self, machine_id, machine_name):
        """
        Set the machine id and name
        
        :param machine_id: the id of the machine
        :param machine_name: the name of the machine
        """
        
        self.machine_id = machine_id
        self.machine_name = machine_name
        return self


    def using_vessel(self, vessel_id):
        """
        Set the vessel id
        
        :param vessel_id: the id of the vessel
        """
        
        self.vessel_id = vessel_id
        return self


    def using_source_generation(self, source_generation):
        """
        Set the source generation (3300, 3350, 3400, etc.)
        
        :param source_generation: the generation of the source
        """
        self.source_generation = source_generation
        return self


    def set_configuration(self, client, machine, collector_name=None, verbose=False):
        """
        Set the configuration of the machine, and optionally also the collector.
        Based on the machine properties and collector name, all the machine properties, and collector properties are set.
        
        :param client: connection to influx
        :param machine: object containing all kinds of properties of the machine (from the machine_list)
        :param collector_name: collector name, used to select collector properties from influx (optional, default=None)
        :param verbose: switches debug mode (default=False)
        """

        if len(machine) == 0:
            print('machine_id not found in the machine list')
            return
        self.using_source('s{}'.format(machine.source_nr))
        self.using_customer(machine.customer)
        self.using_timezone(machine.timezone)
        self.using_machine(machine.machine_nr, machine.displayname)
        self.using_vessel(machine.vessel)
        self.using_source_generation(machine.hardware)
        
        if (not collector_name == None):
            self.using_collector(collector_name)
            collectors = self.get_collectors(client, self.source_id)
            collectors['start'] = collectors.index
            collectors['end'] = collectors['start'].shift(-1)
            collectors.loc[collectors.index[-1], 'end'] = pd.Timestamp('now')
            collector = collectors[collectors['swap'] == collector_name]
            self.using_start_time(collector.start.values[0])
            self.using_end_time(collector.end.values[0])


    def get_collectors(self, client, source_id):
        """
        Retrieves all collectors that were in the specified source
        
        :param client: connection to influx
        :param source_id: the source id (S#####)
        :returns: dataframe of collector swaps
        """
        
        collector_swaps = client.get_signals(['{0}.Collector.Swap'.format(source_id)])
        if len(collector_swaps) == 0:
            return pd.DataFrame(columns=['swap'])
        collector_swaps.columns = ['swap']
        collector_swaps.drop_duplicates(inplace=True)
        return collector_swaps   
