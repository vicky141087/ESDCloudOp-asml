"""
PyEUV - Python modules for working with EUV data.

Copyright 2020, ASML HOLDING N.V. (INCLUDING AFFILIATES). ALL RIGHTS RESERVED.
"""
from pkg_resources import get_distribution
__author__ = "Rob de Laat, Rob Wieggers, Nic Geron, Wouter van Roosmalen et al."
__copyright__ = "2020, ASML HOLDING N.V. (INCLUDING AFFILIATES). ALL RIGHTS RESERVED."
__credits__ = [
    "Rob de laat (CSI)",
    "Rob Wieggers (CSI)",
    "Nic Geron (SF-18)",
    "Wouter van Roosmalen (CSI)"
    "Damien Aussems (SSPT)",
]
__version__ = "1.2"
__maintainer__ = "Rob de Laat"
__email__ = "rob.de.laat@asml.com"
