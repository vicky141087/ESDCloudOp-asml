"""
Script to calculate dose performance
Author: DAAU

Plugin for ETL3 to calculate Lot statistics from extracted scannerlog data.
"""

import numpy as np
import pandas as pd
import arrow
import datetime

from pyeuv.PowerDose.Dose.shared import cast_for_influxdb
from pyeuv.Shared.shared import get_machines
from pyeuv.EUVDashboard import clients
from pyeuv.PowerDose.Dose.dose_io import import_lot_data

pd.set_option('display.max_rows', 100)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


def get_4wk_statistics(client, source_id, from_time, to_time):
    """
    Task to aggregate the die yield statistics information over 4 weeks

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return: signal with die yield statistics information aggregated over 4 weeks
    """

    machine_list = get_machines(client)
    machine = machine_list.loc[machine_list.source_nr == int(source_id[1:])].iloc[0]

    # Go 4 wks back UTC time where the day in localtime starts.
    # ensure that the lower bound data is always taken into account
    dt_data_start = from_time.tz_convert(machine['timezone']).floor('d').tz_convert('utc')
    # the upper bound data may not always be present, hence take the start of the day as end time.
    dt_data_stop = to_time.tz_convert(machine['timezone']).floor('d').tz_convert('utc')
    delta_days = np.int(np.ceil((dt_data_stop - dt_data_start).total_seconds()/3600/24))
    dt_data_start_28days_back = dt_data_stop - pd.Timedelta(days=delta_days + 28)

    df_lot_stats = import_lot_data(client, source_id, dt_data_start_28days_back, dt_data_stop)

    df_4wks_stats = calculate_4wk_statistics(dt_data_stop, delta_days, df_lot_stats)
    df_4wks_stats = cast_for_influxdb(df_4wks_stats, key='df_4wks_stats')

    return df_4wks_stats


def calculate_4wk_statistics(dt_data_stop, delta_days, df_lot_stats, verbose=False):
    """
    Calculation for aggregating the die yield statistics information over 4 weeks

    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :param df_lot_stats: signal with die yield statistics information aggregated over a lot
    :return: dataframe with die yield statistics information aggregated over 4 weeks
    """

    # check for sufficient data
    if df_lot_stats.empty:
        print('task_lot_statistics_4wks(): df_lot_stats not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    die_stats_4wks = {
        'n_init_dies_nok_asml': [],
        'n_init_dies_nok_asml_15p': [],
        'n_init_dies_nok_sys': [],
        'n_init_dies_unrep': [],
        'n_repair_dies_ok_sys': [],
        'n_after_repair_nok_sys': [],
        'n_dies': [],
        'n_wafers': [],
        'n_lots': [],
        'n_repair_exposures': [],
        'die_loss_init_asml': [],
        'die_loss_init_asml_15p': [],
        'die_loss_init_sys': [],
        'die_loss_repair_sys': [],
        'repair_yield': [],
        'percentage_repairs': [],
        'mean_dose_error_initial': [],
        'std_dose_error_initial': [],
        'min_dose_error_initial': [],
        'max_dose_error_initial': [],
    }
    day_timestamps_4wks = []

    for days_back_count in range(delta_days):
        dt_day_start = dt_data_stop - pd.Timedelta(days=days_back_count + 28)
        dt_day_stop = dt_data_stop - pd.Timedelta(days=days_back_count)

        lots = df_lot_stats.loc[(df_lot_stats.index > dt_day_start) & (df_lot_stats.index < dt_day_stop)]

        n_init_dies_nok_asml = np.nansum(lots['n_init_dies_nok_asml'])
        n_init_dies_nok_asml_15p = np.nansum(lots['n_init_dies_nok_asml_15p'])
        n_init_dies_nok_sys = np.nansum(lots['n_init_dies_nok_sys'])
        n_repair_dies_ok_sys = np.nansum(lots['n_repair_dies_ok_sys'])
        n_repair_exposures = np.nansum(lots['n_repair_exposures'])
        n_dies = np.nansum(lots['n_dies'])
        n_lots = len(lots['n_dies'])

        if 'n_wafers' in lots.columns:
            n_wafers = np.nansum(lots['n_wafers'])
        else:
            n_wafers = np.nan

        if 'n_after_repair_nok_sys' in lots.columns:
            n_after_repair_nok_sys = np.nansum(lots['n_after_repair_nok_sys'])
        else:
            n_after_repair_nok_sys = n_init_dies_nok_sys - n_repair_dies_ok_sys  # this gives sometimes the wrong results, \
            # because in the past there were some cases where the lot window got either truncated or extended because of \
            # misalignment, leading to either too many initial exposures (from the next lot), or too few repair exposures.

        if 'n_init_dies_unrep' in lots.columns:
            n_init_dies_unrep = np.nansum(lots['n_init_dies_unrep'])
        else:
            n_init_dies_unrep = np.nan

        if n_dies > 0:
            L_initial_asml = 100 * n_init_dies_nok_asml / float(n_dies)
            L_initial_asml_15p = 100 * n_init_dies_nok_asml_15p / float(n_dies)
            L_initial_sys = 100 * n_init_dies_nok_sys / float(n_dies)
            L_repair_sys = 100 * n_after_repair_nok_sys / float(n_dies)
            percentage_repairs = 100 * n_repair_exposures / float(n_dies)

            if 'mean_dose_error_initial' in lots.columns:
                # use the weighted mean ; weights are the number of samples (=die exposures)
                mean_dose_error_initial = np.nansum(lots['n_dies'] * lots['mean_dose_error_initial']) / np.nansum(
                    lots['n_dies'])
                # use the pooled standard deviation  :  https://en.wikipedia.org/wiki/Pooled_variance
                std_dose_error_initial = np.sqrt(
                    np.nansum((lots['n_dies'] - 1) * lots['std_dose_error_initial'] ** 2 + \
                    lots['n_dies'] * (lots['mean_dose_error_initial'] - mean_dose_error_initial) ** 2) / \
                    (np.nansum(lots['n_dies']) - 1))
                min_dose_error_initial = np.min(np.nanmin(lots['min_dose_error_initial']))
                max_dose_error_initial = np.max(np.nanmax(lots['max_dose_error_initial']))
        else:
            L_initial_asml, L_initial_asml_15p, L_initial_sys, \
            L_repair_sys, percentage_repairs, mean_dose_error_initial, std_dose_error_initial, \
            min_dose_error_initial, max_dose_error_initial \
                = np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan

        if n_repair_exposures > 0:
            Y_repair = 100 * n_repair_dies_ok_sys / float(n_repair_exposures)
        else:
            Y_repair = np.nan

        day_timestamps_4wks.append(pd.Timestamp((dt_day_stop - pd.Timedelta(days=1))))
        die_stats_4wks['die_loss_init_asml'].append(L_initial_asml)
        die_stats_4wks['die_loss_init_asml_15p'].append(L_initial_asml_15p)
        die_stats_4wks['die_loss_init_sys'].append(L_initial_sys)
        die_stats_4wks['die_loss_repair_sys'].append(L_repair_sys)
        die_stats_4wks['repair_yield'].append(Y_repair)
        die_stats_4wks['n_dies'].append(n_dies)
        die_stats_4wks['n_wafers'].append(n_wafers)
        die_stats_4wks['n_lots'].append(n_lots)
        die_stats_4wks['n_repair_exposures'].append(n_repair_exposures)
        die_stats_4wks['n_init_dies_nok_asml'].append(n_init_dies_nok_asml)
        die_stats_4wks['n_init_dies_nok_asml_15p'].append(n_init_dies_nok_asml_15p)
        die_stats_4wks['n_init_dies_nok_sys'].append(n_init_dies_nok_sys)
        die_stats_4wks['n_init_dies_unrep'].append(n_init_dies_unrep)
        die_stats_4wks['n_repair_dies_ok_sys'].append(n_repair_dies_ok_sys)
        die_stats_4wks['n_after_repair_nok_sys'].append(n_after_repair_nok_sys)
        die_stats_4wks['percentage_repairs'].append(percentage_repairs)
        die_stats_4wks['mean_dose_error_initial'].append(mean_dose_error_initial)
        die_stats_4wks['std_dose_error_initial'].append(std_dose_error_initial)
        die_stats_4wks['min_dose_error_initial'].append(min_dose_error_initial)
        die_stats_4wks['max_dose_error_initial'].append(max_dose_error_initial)

    df_4wks_stats = pd.DataFrame.from_dict(die_stats_4wks)
    df_4wks_stats.index = day_timestamps_4wks

    if verbose:
        # Summary for debugging
        print("task_lot_statistics_4wks(): ----- 4 WEEK AGGREGATE SUMMARY -----")
        print("task_lot_statistics_4wks(): Processed days                   :{0}".format(delta_days))

    return df_4wks_stats

if __name__ == '__main__':

    pd.set_option('display.max_rows', 100)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    source_nr = '44481'
    days_back = 3
    to_time_tmp = pd.Timestamp(2020, 3, 20)

    # from_time = pd.to_datetime('2020-03-28 22:00:00').tz_localize('UTC')
    # to_time = pd.to_datetime('2020-03-28 23:27:20').tz_localize('UTC')

    client = clients.UserLANClient()
    machine_list = get_machines(client)

    import matplotlib.pyplot as plt

    # for source_nr in machine_list.source_nr:
    print(source_nr)
    machine = machine_list.loc[machine_list.source_nr == int(source_nr)].iloc[0]
    to_time = to_time_tmp.tz_localize(machine['timezone']).tz_convert('UTC')
    from_time = to_time - pd.Timedelta(days=days_back)
    source_id = 's' + str(source_nr)

    df_4wks_stats = get_4wk_statistics(client, source_id, from_time, to_time)
