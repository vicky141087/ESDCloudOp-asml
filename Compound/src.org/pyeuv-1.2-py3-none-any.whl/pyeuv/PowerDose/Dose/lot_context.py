"""
Script to calculate dose performance
Author: DAAU

Plugin for ETL3 to calculate Lot statistics from extracted scannerlog data.
"""

import numpy as np
import pandas as pd
import arrow
import datetime

from pyeuv.Shared.wafer_lot_aggregation import calculate_wafer_lot_windows, match_lot_name_and_id, \
    filter_lots_on_time_duration, align_lots, generate_filter_signal
from pyeuv.PowerDose.Dose.shared import check_repair_off, generate_repair_signal, cast_for_influxdb
from pyeuv.Shared.shared import get_machines
from pyeuv.Shared.signal_merging import prepare_concat, concat_df
from pyeuv.EUVDashboard import clients
from pyeuv.PowerDose.Dose.dose_io import import_dose_data, import_wafer_data

pd.set_option('display.max_rows', 100)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


def get_lot_context(client, source_id, from_time, to_time):
    """
    Makes the following analysis:
    - calculate wafer and lot windows
    - match lot context to lot windows

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return:
        lot_context: signal with lot context information
    """

    # get machine info
    machine_list = get_machines(client)
    machine = machine_list.loc[machine_list.source_nr == int(source_id[1:])].iloc[0]

    # expand start time to start of day in the timezone of the machine, to avoid issues for day aggregation (done over
    # the timezone of the machine)
    from_time = from_time.tz_convert(machine['timezone']).floor('d').tz_convert('utc')

    df_dict = import_dose_data(client,source_id, from_time, to_time)
    df_dict['df_wafer_stats'] = import_wafer_data(client,source_id, from_time, to_time)
    df_dict['machine'] = machine

    df_dict = calculate_wafer_lot_windows(df_dict)
    lot_context = match_lots(from_time, df_dict)

    # cast for influxdb
    if not lot_context.empty:
        lot_context = cast_for_influxdb(lot_context, key='df_lot_context')
    else:
        print('cast_for_influxdb(): No lot_stats data available.')

    return lot_context


def match_lots(from_time, df_dict, verbose=False):
    """
    Match using the time windows from function 'calculate_wafer_lot_windows' and use
    LOT START (LO-0050) and LOT STOP (LO-0051) signals to obtain the lot context.

    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :param df_lot_windows: signal with lot start and stop timestamps
    :param df_dict: dictionary containing:
        df_lot_name: dataframe with lot names
        df_lot_id: dataframe with lot ids
    :return:
        df_lot_context: dataframe with lot context (stop time, start time, lot name, lot id, lot signal)
    """

    try:
        df_lot_windows = df_dict['df_lot_windows']
    except:
        print('match_lots(): df_lot_windows not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    df_lot_name = df_dict['df_lot_name']
    df_lot_id = df_dict['df_lot_id']

    if df_lot_windows.empty:
        print('match_lots(): df_lot_windows not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_lot_name.empty:
        print('match_lots(): ScannerLog.lot_name not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_lot_id.empty:
        print('match_lots(): ScannerLog.lot_id not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    print('match_lots(): Match lots')
    df_lot_name = prepare_concat(df_lot_name, ['code', 'lot_name'])
    df_lot_id = prepare_concat(df_lot_id, ['lot_id'])
    df_lot_name_id = concat_df(df_lot_name, df_lot_id, check_size=True, match_exposure_id=False)
    # only select the fields we are interested in
    df_lot_name_id = df_lot_name_id.loc[df_lot_name_id.code.isin(['LO-0050', 'LO-0051'])].copy()
    # make sure that we have the full range of lots, by taking the lot start signals 2 hours before, \
    # but not the lot end signals
    df_lot_name_id = df_lot_name_id.loc[~((df_lot_name_id.code == 'LO-0051') & (df_lot_name_id.index < from_time))]

    # Generate LOT windows for non-aborted LOTs
    print("match_lots(): Generating LOT windows")
    lots = {
        'start': [],
        'stop': [],
        'lot_name': [],
        'lot_id': []
    }

    df_lots, n_match, n_no_idname, n_no_futuretime, n_multiple = \
        match_lot_name_and_id(lots, df_lot_name_id)
    if df_lots.empty:
        print('match_lots(): No lot matches found')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    not_matched_before_start_counter = len(df_lot_name_id.loc[df_lot_name_id.index < from_time]) - \
        len(df_lots.loc[df_lots.lot_name.isin(df_lot_name_id.loc[df_lot_name_id.index < from_time].lot_name)])
    df_lots = filter_lots_on_time_duration(df_lots)
    n_expired = len(lots['lot_id']) - len(df_lots)

    df_lots, n_no_exposure = align_lots(df_lots, df_lot_windows)
    # only use selection of columns
    df_lots = df_lots[['start', 'stop', 'lot_name', 'lot_id']].copy()

    print("match_lots(): Generating LOT signal")
    df_lot_signal = generate_filter_signal(df_lots[['start', 'stop']])

    if verbose:
        # Stats for debugging
        print("match_lots(): ----- LOT MATCH PROCESS SUMMARY  -----")
        print("match_lots(): Nr LO-0050 codes       :{0}".format(
            df_lot_name_id.loc[df_lot_name_id.code == 'LO-0050'].shape[0] - not_matched_before_start_counter))
        print("match_lots(): Nr LO-0051 codes       :{0}".format(
            df_lot_name_id.loc[df_lot_name_id.code == 'LO-0051'].shape[0]))
        print("match_lots(): Matched LOTs           :{0}".format(n_match))
        print("match_lots(): Unmatched LOTs         :{0}".format(
            n_no_idname - not_matched_before_start_counter))
        print("match_lots(): Multimatch LOTs        :{0}".format(n_multiple))
        print("match_lots(): No futuretime match    :{0}".format(n_no_futuretime))
        print("match_lots(): Expired                :{0}".format(n_expired))
        print("match_lots(): No exposures           :{0}".format(n_no_exposure))

    df_lots.index = pd.DatetimeIndex(df_lots['start'])
    df_lot_signal.columns = ['lot_signal']
    df_lot_context = pd.merge(df_lots, df_lot_signal, how='outer', left_index=True, right_index=True)

    return df_lot_context


if __name__ == '__main__':

    pd.set_option('display.max_rows', 100)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    source_nr = '44481'
    days_back = 3
    to_time_tmp = pd.Timestamp(2020, 3, 20)

    # from_time = pd.to_datetime('2020-03-28 22:00:00').tz_localize('UTC')
    # to_time = pd.to_datetime('2020-03-28 23:27:20').tz_localize('UTC')

    client = clients.UserLANClient()
    machine_list = get_machines(client)

    import matplotlib.pyplot as plt

    # for source_nr in machine_list.source_nr:
    print(source_nr)
    machine = machine_list.loc[machine_list.source_nr == int(source_nr)].iloc[0]
    to_time = to_time_tmp.tz_localize(machine['timezone']).tz_convert('UTC')
    from_time = to_time - pd.Timedelta(days=days_back)
    source_id = 's' + str(source_nr)

    lot_context = get_lot_context(client, source_id, from_time, to_time)

