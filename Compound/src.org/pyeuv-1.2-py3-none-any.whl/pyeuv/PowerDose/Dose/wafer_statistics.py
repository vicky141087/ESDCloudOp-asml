"""
Script to calculate dose performance
Author: DAAU

Plugin for ETL3 to calculate Lot statistics from extracted scannerlog data.
"""

import numpy as np
import pandas as pd
import arrow
import datetime

from pyeuv.Shared.wafer_lot_aggregation import calculate_wafer_lot_windows
from pyeuv.PowerDose.Dose.shared import check_repair_off, generate_repair_signal, cast_for_influxdb
from pyeuv.Shared.shared import get_machines
from pyeuv.EUVDashboard import clients
from pyeuv.PowerDose.Dose.dose_io import import_dose_data, import_lot_data

pd.set_option('display.max_rows', 100)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


def get_wafer_statistics(client, source_id, from_time, to_time):
    """
    Makes the following analysis:
    - calculate wafer and lot windows
    - calculate wafer statistics

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return:
        wafer_statistics:
    """

    # get machine info
    machine_list = get_machines(client)
    machine = machine_list.loc[machine_list.source_nr == int(source_id[1:])].iloc[0]

    # expand start time to start of day in the timezone of the machine, to avoid issues for day aggregation (done over
    # the timezone of the machine)
    from_time = from_time.tz_convert(machine['timezone']).floor('d').tz_convert('utc')

    df_dict = import_dose_data(client,source_id, from_time, to_time)
    df_dict['machine'] = machine

    df_dict = calculate_wafer_lot_windows(df_dict)
    wafer_statistics = calculate_wafer_statistics(df_dict)

    # cast for influxdb
    if not wafer_statistics.empty:
        wafer_statistics = cast_for_influxdb(wafer_statistics, key='df_wafer_stats')
    else:
        print('cast_for_influxdb(): No wafer_stats data available.')

    return wafer_statistics


def calculate_wafer_statistics(df_dict, verbose=False):
    """
    Calculate statistics for each wafer using the dose error signal
    Calculation details can be found in D000425286-03-EPS_EUV_Dashboard_Die_Yield_Calculation

    :param df_dose_data: exposures without the SLIE measurement (either 4 or 8) at the start of the lot
    :param df_wafer_windows: signal with wafer start and stop timestamps
    :param df_dict: dictionary containing:
        df_do_mode: filter signal to exclude SIM mode
        df_test_window: filter signal to exclude tests (except TwinRUNR)
    :return:
        df_wafer_stats: dataframe with die yield statistics information aggregated over a wafer
    """

    try:
        df_dose_data = df_dict['df_dose_data']
    except:
        print('calculate_wafer_statistics(): df_dose_data not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    try:
        df_wafer_windows = df_dict['df_wafer_windows']
    except:
        print('calculate_wafer_statistics(): df_wafer_windows not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    df_test_window = df_dict['df_test_window']
    df_ke_signal = df_dict['df_ke_signal']
    df_do_mode = df_dict['df_do_mode']
    df_err_lvl = df_dict['df_err_lvl']
    df_reexp_lvl = df_dict['df_reexp_lvl']

    # check for sufficient data
    if df_dose_data.empty:
        print('calculate_wafer_statistics(): df_dose_data not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_wafer_windows.empty:
        print('calculate_wafer_statistics(): df_wafer_windows not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_ke_signal.empty:
        print('calculate_wafer_statistics(): ScannerLog.occurrence not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_do_mode.empty:
        print('calculate_wafer_statistics(): THCC.THCCGroupDoSignal not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_err_lvl.empty:
        print('calculate_wafer_statistics(): df_err_lvl not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_reexp_lvl.empty:
        print('calculate_wafer_statistics(): df_reexp_lvl not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_test_window.empty:
        print('calculate_wafer_statistics(): ScannerLog._TMTestWindows not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    if df_test_window is not None:
        df_test_window.stop = pd.to_datetime(df_test_window.stop * 1e9).apply(lambda x: x.tz_localize('utc'))
        df_test_window.start = pd.to_datetime(df_test_window.start * 1e9).apply(lambda x: x.tz_localize('utc'))

    # filter only the interesting signals
    df_ke_signal = df_ke_signal.loc[df_ke_signal.code.isin(['KE-7228', 'KE-7229'])].copy()
    df_test_window = df_test_window[['start', 'stop', 'test_name']].copy()

    print('calculate_wafer_statistics(): Generate repair signals')
    df_repair_signal = generate_repair_signal(df_ke_signal)

    # Error cases to be counted
    n_tm_tests = 0
    n_twinrunr = 0
    n_ignored_due_do_mode = 0
    n_could_not_get_do_mode = 0
    n_too_few_dose_errors = 0  # less then X (=70) dose errors
    n_missing_sys_err_lvl = 0  # just a warning
    n_missing_reexp_lvl = 0  # just a warning
    n_too_many_ke_start_stop_signals = 0
    n_ke_signal_end_first = 0  # repair end time is during initial exposure
    n_wrong_loc_repair = 0  # DW-343B during initial exposure
    n_wrong_loc_norepair = 0  # DW-3425 or DW-343A during repair exposure
    n_wrong_dw3411 = 0  # cases when dose error is small (<1e-5)
    n_repair_off = 0  # cases when die repair was off

    wafer_stats = {
        'wafer_start': [],
        'wafer_stop': [],
        'die_loss_init_asml': [],
        'die_loss_init_asml_15p': [],
        'die_loss_init_sys': [],
        'die_loss_repair_sys': [],
        'repair_yield': [],
        'sys_err_lvl': [],
        'de_max_reexp_lvl': [],
        'mean_dose_error_initial': [],
        'std_dose_error_initial': [],
        'min_dose_error_initial': [],
        'max_dose_error_initial': [],
        'n_dies': [],
        'n_init_dies_nok_asml': [],
        'n_init_dies_nok_asml_15p': [],
        'n_init_dies_nok_sys': [],
        'n_init_dies_unrep': [],
        'n_repair_dies_ok_sys': [],
        'n_after_repair_nok_sys': [],
        'n_repair_exposures': [],
    }

    print('calculate_wafer_statistics(): Looping through wafers')
    min_dies_in_wafer_criteria = 25    # same number as used above, but can be adjusted
    # presume repair is off
    df_dose_data['repair_signal'] = 0
    # keep track of the skip cause
    df_wafer_windows['skip_cause'] = ''

    for index, row in df_wafer_windows.iterrows():

        ts_wafer_start = row['wafer_start']
        ts_wafer_stop = row['wafer_stop']

        # Skip lot if dose control mode is not REAL
        try:
            status_do_mode = df_do_mode.loc[df_do_mode.index < ts_wafer_start].iloc[-1].values[0]
        except IndexError:
            # DO status cannot be determined. LOT cannot be validated and is therefore ignored.
            n_could_not_get_do_mode += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'no_do_mode'
            continue
        if status_do_mode != 0:
            n_ignored_due_do_mode += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'do_mode'
            continue

        # Skip lot if a TM test is being performed. But include the LOT if the TM test is of type TwinRUNR.
        if df_test_window is not None:
            current_tm_test = df_test_window.loc[
                (df_test_window.start < ts_wafer_start) & (df_test_window.stop > ts_wafer_stop)]
            if current_tm_test.size > 0:
                if np.any(current_tm_test.test_name.str.contains('TWINRUNR')):  # Ignore lot if this is not a TwinRUNR.
                    n_twinrunr += 1
                    df_wafer_windows.loc[index, 'skip_cause'] = 'twin_runr'
                else:
                    n_tm_tests += 1
                    df_wafer_windows.loc[index, 'skip_cause'] = 'tm_test'
                    continue
        else:
            pass

        df_dose_data_wafer = df_dose_data.loc[
            (df_dose_data.index >= ts_wafer_start) & (df_dose_data.index <= ts_wafer_stop)].copy()
        # Check whether there are enough wafers
        if len(df_dose_data_wafer) <= min_dies_in_wafer_criteria:  # Error level registrations within this wafer
            n_too_few_dose_errors += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'too few die exposures'
            continue

        # Determine system error level for this wafer
        sys_err_lvl = df_err_lvl.loc[(df_err_lvl.index >= ts_wafer_start) & (df_err_lvl.index <= ts_wafer_stop)]
        if len(sys_err_lvl) > 0:  # Error level registrations within this wafer
            sys_err_lvl = np.abs(sys_err_lvl.iloc[0])[0]
        else:
            try:
                sys_err_lvl = np.abs(df_err_lvl.loc[df_err_lvl.index < ts_wafer_start].iloc[-1])[0]  # Take last known
                # level at the time of this wafer.
            except IndexError as e:
                sys_err_lvl = None
                n_missing_sys_err_lvl += 1
                # continue   # still process the wafer; assume there is not issue

        # Determine system error level for this wafer
        de_max_reexp_lvl = df_reexp_lvl.loc[
            (df_reexp_lvl.index >= ts_wafer_start) & (df_reexp_lvl.index <= ts_wafer_stop)]
        if len(de_max_reexp_lvl) > 0:  # Error level registrations within this wafer
            de_max_reexp_lvl = np.abs(de_max_reexp_lvl.iloc[0])[0]
        else:
            try:
                de_max_reexp_lvl = np.abs(df_reexp_lvl.loc[df_reexp_lvl.index < ts_wafer_start].iloc[-1])[0]  # Take last
                # known level at the time of this wafer.
            except IndexError as e:
                de_max_reexp_lvl = None
                n_missing_reexp_lvl += 1
                # continue     # still process the wafer; assume there is not issue

        # Determine repair exposures
        df_repair_signal_wafer = df_repair_signal.loc[
            (df_repair_signal.index >= ts_wafer_start) & (df_repair_signal.index <= ts_wafer_stop)]
        if df_repair_signal_wafer.empty or df_repair_signal_wafer is None:
            pass  # no repair during this wafer
        elif df_repair_signal_wafer.ke_signal.iloc[0] == 0:
            n_ke_signal_end_first += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'repair start not first'
            continue
        elif len(df_repair_signal_wafer) > 2:
            n_too_many_ke_start_stop_signals += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'too many repair start/stop signals'
            continue
        else:
            time_repair_start = df_repair_signal_wafer.loc[df_repair_signal_wafer.ke_signal == 1].index[0]
            df_dose_data_wafer.loc[(df_dose_data_wafer.index >= time_repair_start), 'repair_signal'] = 1
            df_dose_data_wafer.loc[(df_dose_data_wafer.index < time_repair_start), 'repair_signal'] = 0

        """ Filter (false) positive dose errors """
        if de_max_reexp_lvl is None or sys_err_lvl is None:
            repair_off_range = check_repair_off(df_dose_data_wafer, sys_err_lvl, de_max_reexp_lvl)
            n_repair_off_wafer = len(df_dose_data_wafer.loc[repair_off_range])
            if n_repair_off_wafer != 0:
                n_repair_off += 1
                df_wafer_windows.loc[index, 'skip_cause'] = 'repair-off positive dose errors'
                continue

        """ Create error logging for wrong cases"""
        n_wrong_loc_repair_wafer = len(df_dose_data_wafer.loc[(df_dose_data_wafer['repair_signal'] == 1) & (
            df_dose_data_wafer['error_code'].isin(['DW-3425', 'DW-343A']))])
        if n_wrong_loc_repair_wafer != 0:
            n_wrong_loc_repair += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'repair during initial exposure'
            continue

        n_wrong_loc_norepair_wafer = len(df_dose_data_wafer.loc[(df_dose_data_wafer['repair_signal'] == 0) & (
            df_dose_data_wafer['error_code'].isin(['DW-343B']))])
        if n_wrong_loc_norepair_wafer != 0:
            n_wrong_loc_norepair += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'initial exposure during repair'
            continue

        """ Filter wrong >1% DW-3411 dose errors """
        # There is a bug in Influx; 3.14*e-5 becomes 3.145; is now solved
        n_wrong_dw3411_wafer = len(df_dose_data_wafer.loc[(
                    (abs(df_dose_data_wafer['dose_error']) > 1) & (df_dose_data_wafer['error_code'] == 'DW-3411'))])
        if n_wrong_dw3411_wafer != 0:
            n_wrong_dw3411 += 1
            df_wafer_windows.loc[index, 'skip_cause'] = 'small values dose error issue'
            continue

        """ Calculate die/wafer/lot yield """
        df_dose_data_initial = df_dose_data_wafer.loc[df_dose_data_wafer['repair_signal'] == 0]
        df_dose_data_during_repair = df_dose_data_wafer.loc[df_dose_data_wafer['repair_signal'] == 1]
        df_dose_data_initial_no_repairables = df_dose_data_initial.loc[
            ~(df_dose_data_initial['error_code'] == 'DW-343A')]
        df_dose_data_after_repair = df_dose_data_initial_no_repairables.append(df_dose_data_during_repair)

        """ Calculate die stats """
        # asml specs
        n_dies = float(len(df_dose_data_initial))
        n_init_dies_nok_asml = float(len(df_dose_data_initial.loc[abs(df_dose_data_initial['dose_error']) > 1]))
        n_init_dies_nok_asml_15p = float(len(df_dose_data_initial.loc[abs(df_dose_data_initial[
            'dose_error'] > 15)]))  # > 1 not included, because already assumed these are negatives at the start)
        L_initial_asml = n_init_dies_nok_asml / n_dies
        L_initial_asml_15p = n_init_dies_nok_asml_15p / n_dies

        # system level specs (using re-expose level)
        n_dies_sys = float(len(df_dose_data_initial))
        n_init_dies_nok_sys = float(
            len(df_dose_data_initial.loc[df_dose_data_initial['error_code'].isin(['DW-3425', 'DW-343A'])]))
        n_init_dies_unrep = float(
            len(df_dose_data_initial.loc[df_dose_data_initial['error_code'].isin(['DW-3425'])]))
        n_repair_exposures = float(len(df_dose_data_during_repair))
        n_repair_dies_ok_sys = float(
            len(df_dose_data_during_repair.loc[df_dose_data_during_repair['error_code'].isin(['DW-3411'])]))
        n_after_repair_nok_sys = float(
            len(df_dose_data_after_repair.loc[df_dose_data_after_repair['error_code'].isin(['DW-3425', 'DW-343B'])]))

        L_initial_sys = n_init_dies_nok_sys / n_dies_sys
        L_repair_sys = n_after_repair_nok_sys / n_dies_sys  # should better be called 'L_after_repair_sys'
        if n_repair_exposures > 0:
            Y_repair = 100 * n_repair_dies_ok_sys / float(n_repair_exposures)
        else:
            Y_repair = np.nan

        # Compile statistics
        wafer_stats['wafer_start'].append(df_dose_data_wafer.index[0])
        wafer_stats['wafer_stop'].append(df_dose_data_wafer.index[-1])
        wafer_stats['die_loss_init_asml'].append(L_initial_asml)
        wafer_stats['die_loss_init_asml_15p'].append(L_initial_asml_15p)
        wafer_stats['die_loss_init_sys'].append(L_initial_sys)
        wafer_stats['die_loss_repair_sys'].append(L_repair_sys)
        wafer_stats['repair_yield'].append(Y_repair)
        wafer_stats['sys_err_lvl'].append(sys_err_lvl)
        wafer_stats['de_max_reexp_lvl'].append(de_max_reexp_lvl)
        wafer_stats['n_init_dies_nok_asml_15p'].append(n_init_dies_nok_asml_15p)
        wafer_stats['n_init_dies_nok_asml'].append(n_init_dies_nok_asml)
        wafer_stats['n_init_dies_nok_sys'].append(n_init_dies_nok_sys)
        wafer_stats['n_init_dies_unrep'].append(n_init_dies_unrep)
        wafer_stats['n_repair_dies_ok_sys'].append(n_repair_dies_ok_sys)
        wafer_stats['n_after_repair_nok_sys'].append(n_after_repair_nok_sys)
        wafer_stats['n_dies'].append(n_dies)
        wafer_stats['n_repair_exposures'].append(n_repair_exposures)
        wafer_stats['mean_dose_error_initial'].append(np.mean(df_dose_data_initial.dose_error))
        wafer_stats['std_dose_error_initial'].append(np.std(df_dose_data_initial.dose_error))
        wafer_stats['min_dose_error_initial'].append(np.min(df_dose_data_initial.dose_error))
        wafer_stats['max_dose_error_initial'].append(np.max(df_dose_data_initial.dose_error))

    df_wafer_stats = pd.DataFrame.from_dict(wafer_stats)
    df_wafer_stats.index = df_wafer_stats.wafer_start

    if verbose:
        # Summary for debugging
        print("calculate_wafer_statistics(): ----- WAFER STATISTICS PROCESS SUMMARY -----")
        print(
            "calculate_wafer_statistics(): Processed wafers                             :{0}".format(df_wafer_windows.shape[0]))
        print("calculate_wafer_statistics(): * FILTER ON TESTS AND DO MODE               ")
        print("calculate_wafer_statistics(): Included: TwinRUNR LOTs                      :{0}".format(n_twinrunr))
        print("calculate_wafer_statistics(): Excluded: TM-Tests                           :{0}".format(n_tm_tests))
        print("calculate_wafer_statistics(): Excluded: DO mode                            :{0}".format(n_ignored_due_do_mode))
        print("calculate_wafer_statistics(): Excluded: cannot determine DO mode           :{0}".format(n_could_not_get_do_mode))
        print("calculate_wafer_statistics(): * FILTER ON EXPOSURE CONTEXT                ")
        print("calculate_wafer_statistics(): Excluded: too few die exposures              :{0}".format(n_too_few_dose_errors))
        print("calculate_wafer_statistics(): Warming:  missing system error level         :{0}".format(n_missing_sys_err_lvl))
        print("calculate_wafer_statistics(): Warning:  missing re-expose level            :{0}".format(n_missing_reexp_lvl))
        print("calculate_wafer_statistics(): Excluded: too many repair start/stop times   :{0}".format(n_too_many_ke_start_stop_signals))
        print("calculate_wafer_statistics(): Excluded: repair start not first             :{0}".format(n_ke_signal_end_first))
        print("calculate_wafer_statistics(): Excluded: repair during initial exposure     :{0}".format(n_wrong_loc_norepair))
        print("calculate_wafer_statistics(): Excluded: initial exposure during repair     :{0}".format(n_wrong_loc_repair))
        print("calculate_wafer_statistics(): Excluded: small values dose error issue      :{0}".format(n_wrong_dw3411))
        print("calculate_wafer_statistics(): Excluded: repair-off positive dose errors    :{0}".format(n_repair_off))

    return df_wafer_stats


if __name__ == '__main__':

    pd.set_option('display.max_rows', 100)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    source_nr = '44481'
    days_back = 3
    to_time_tmp = pd.Timestamp(2020, 3, 20)

    # from_time = pd.to_datetime('2020-03-28 22:00:00').tz_localize('UTC')
    # to_time = pd.to_datetime('2020-03-28 23:27:20').tz_localize('UTC')

    client = clients.UserLANClient()
    machine_list = get_machines(client)

    import matplotlib.pyplot as plt

    # for source_nr in machine_list.source_nr:
    print(source_nr)
    machine = machine_list.loc[machine_list.source_nr == int(source_nr)].iloc[0]
    to_time = to_time_tmp.tz_localize(machine['timezone']).tz_convert('UTC')
    from_time = to_time - pd.Timedelta(days=days_back)
    source_id = 's' + str(source_nr)

    wafer_statistics = get_wafer_statistics(client, source_id, from_time, to_time)
