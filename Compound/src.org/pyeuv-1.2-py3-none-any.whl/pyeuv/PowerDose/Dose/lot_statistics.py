"""
Script to calculate dose performance
Author: DAAU

Plugin for ETL3 to calculate Lot statistics from extracted scannerlog data.
"""

import numpy as np
import pandas as pd
import arrow
import datetime

from pyeuv.Shared.wafer_lot_aggregation import calculate_wafer_lot_windows
from pyeuv.PowerDose.Dose.shared import check_repair_off, generate_repair_signal, cast_for_influxdb
from pyeuv.Shared.shared import get_machines
from pyeuv.EUVDashboard import clients
from pyeuv.PowerDose.Dose.dose_io import import_dose_data, import_lot_context, import_wafer_data

pd.set_option('display.max_rows', 100)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


def get_lot_statistics(client, source_id, from_time, to_time):
    """
    Makes the following analysis:
    - calculate wafer and lot windows
    - calculate lot statistics

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return:
        lot_statistics: signal with die yield statistics information aggregated over a lot
    """

    # get machine info
    machine_list = get_machines(client)
    machine = machine_list.loc[machine_list.source_nr == int(source_id[1:])].iloc[0]

    # expand start time to start of day in the timezone of the machine, to avoid issues for day aggregation (done over
    # the timezone of the machine)
    from_time = from_time.tz_convert(machine['timezone']).floor('d').tz_convert('utc')

    df_dict = import_dose_data(client, source_id, from_time, to_time)
    df_dict['df_lots'] = import_lot_context(client, source_id, from_time, to_time)
    df_dict['df_wafer_stats'] = import_wafer_data(client, source_id, from_time, to_time)
    df_dict['machine'] = machine

    df_dict = calculate_wafer_lot_windows(df_dict)
    lot_statistics = calculate_lot_statistics(df_dict)

    # cast for influxdb
    if not lot_statistics.empty:
        lot_statistics = cast_for_influxdb(lot_statistics, key='df_lot_stats')
    else:
        print('cast_for_influxdb(): No lot_stats data available.')

    return lot_statistics



def calculate_lot_statistics(df_dict, verbose=False):
    """
    Calculate statistics for each lot using the wafer statistics signal.
    Calculation details can be found in D000425286-03-EPS_EUV_Dashboard_Die_Yield_Calculation

    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :param df_wafer_stats: signal with die yield statistics information aggregated over a wafer
    :param df_lots: dataframe with lot context (stop time, start time, lot name, lot id)
    :param df_do_mode: filter signal to exclude SIM mode
    :param df_test_window: filter signal to exclude tests (except TwinRUNR)
    :return:
        df_lot_stats: signal with die yield statistics information aggregated over a lot
    """

    try:
        df_wafer_stats = df_dict['df_wafer_stats']
    except:
        print('calculate_lot_statistics(): df_wafer_stats not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    try:
        df_lots = df_dict['df_lots']
    except:
        print('calculate_lot_statistics(): df_lots not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    try:
        df_test_window = df_dict['df_test_window']
    except:
        print('calculate_lot_statistics(): df_test_window not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    try:
        df_do_mode = df_dict['df_do_mode']
    except:
        print('calculate_lot_statistics(): df_do_mode not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    # check for sufficient data
    if df_wafer_stats.empty:
        print('calculate_lot_statistics(): df_wafer_stats not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_lots.empty:
        print('calculate_lot_statistics(): df_lots not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_test_window.empty:
        print('calculate_lot_statistics(): df_test_window not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if df_do_mode.empty:
        print('calculate_lot_statistics(): df_do_mode not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    # Error cases to be counted
    n_tm_tests = 0
    n_twinrunr = 0
    n_ignored_due_do_mode = 0
    n_could_not_get_do_mode = 0

    lot_stats = {
        'lot_start': [],
        'lot_stop': [],
        'lot_id': [],
        'lot_name': [],
        'die_loss_init_asml': [],
        'die_loss_init_asml_15p': [],
        'die_loss_init_sys': [],
        'repair_yield': [],
        'sys_err_lvl': [],
        'de_max_reexp_lvl': [],
        'mean_dose_error_initial': [],
        'std_dose_error_initial': [],
        'min_dose_error_initial': [],
        'max_dose_error_initial': [],
        'n_dies': [],
        'n_wafers': [],
        'n_init_dies_nok_asml': [],
        'n_init_dies_nok_asml_15p': [],
        'n_init_dies_nok_sys': [],
        'n_init_dies_unrep': [],
        'n_repair_dies_ok_sys': [],
        'n_after_repair_nok_sys': [],
        'die_loss_repair_sys': [],
        'n_repair_exposures': [],
    }

    df_lots['skip_cause'] = ''
    wafers_index_array = df_wafer_stats[['wafer_start']].copy()
    wafers_index_array['included'] = False

    # do loop over lot windows
    for index, lot in df_lots.iterrows():  # Loop trough all LOTs and calculate statistics per LOT
        ts_lot_start = lot.start  # Times are in UTC
        ts_lot_stop = lot.stop

        # Skip lot if dose control mode is not REAL  : in principle this is already checked in the wafers statistics
        #  loop, however, if one choses to include lots with no wafers, this filter is still necessary.
        try:
            status_do_mode = df_do_mode.loc[df_do_mode.index < ts_lot_start].iloc[-1].values[0]
        except IndexError:
            # DO status cannot be determined. LOT cannot be validated and is therefore ignored.
            n_could_not_get_do_mode += 1
            df_lots.loc[index,'skip_cause'] = 'no_do_mode'
            continue
        if status_do_mode != 0:
            n_ignored_due_do_mode += 1
            df_lots.loc[index,'skip_cause'] = 'do_mode'
            continue

        # Skip lot if a TM test is being performed. But include the LOT if the TM test is of type TwinRUNR.
        # in principle this is already checked in the wafers statistics loop, however, if one choses to include
        # lots with no wafers, this filter is still necessary.
        if df_test_window is not None:
            current_tm_test = df_test_window.loc[
                (df_test_window.start < ts_lot_start) & (df_test_window.stop > ts_lot_stop)]
            if current_tm_test.size > 0:
                if np.any(current_tm_test.test_name.str.contains('TWINRUNR')):  # Ignore lot if this is not a TwinRUNR.
                    n_twinrunr += 1
                    df_lots.loc[index,'skip_cause'] = 'twin_runr'
                else:
                    n_tm_tests += 1
                    df_lots.loc[index,'skip_cause'] = 'tm_test'
                    # continue
        else:
            pass

        # Calculate die loss for this lot with the 1% ASML spec.
        wafers = df_wafer_stats.loc[
            (df_wafer_stats.wafer_start >= ts_lot_start) & (df_wafer_stats.wafer_stop <= ts_lot_stop)
            ].copy()

        condition_to_include = wafers_index_array.index.isin(wafers.index)
        wafers_index_array.loc[condition_to_include,'included'] = True

        df_lots.loc[index,'n_dies_calc'] = wafers.n_dies.sum()
        df_lots.loc[index,'n_wafers_calc'] = wafers.n_dies.count()

        n_init_dies_nok_asml = np.nansum(wafers['n_init_dies_nok_asml'])
        n_init_dies_nok_asml_15p = np.nansum(wafers['n_init_dies_nok_asml_15p'])
        n_init_dies_nok_sys = np.nansum(wafers['n_init_dies_nok_sys'])
        n_init_dies_unrep = np.nansum(wafers['n_init_dies_unrep'])
        n_repair_dies_ok_sys = np.nansum(wafers['n_repair_dies_ok_sys'])
        n_repair_exposures = np.nansum(wafers['n_repair_exposures'])
        n_dies = np.nansum(wafers['n_dies'])
        n_wafers = len(wafers.loc[wafers['n_dies'] > 0])

        if 'n_after_repair_nok_sys' in wafers.columns:
            n_after_repair_nok_sys = np.nansum(wafers['n_after_repair_nok_sys'])
        else:
            n_after_repair_nok_sys = n_init_dies_nok_sys - n_repair_dies_ok_sys  # this gives sometimes the wrong results, \
            # because in the past there were some cases where the wafer got truncated (probably due to a early repair-stop \
            # (KE-2779 signal). This led to fewer dies ok during repair, which causes this value to be an overestimation.

        if n_dies > 0:
            de_max_reexp_lvl = np.max(wafers['de_max_reexp_lvl'])
            sys_err_lvl = np.max(wafers['sys_err_lvl'])

            L_initial_asml = 100 * n_init_dies_nok_asml / float(n_dies)
            L_initial_asml_15p = 100 * n_init_dies_nok_asml_15p / float(n_dies)
            L_initial_sys = 100 * n_init_dies_nok_sys / float(n_dies)
            L_repair_sys = 100 * n_after_repair_nok_sys / float(n_dies)  # should better be called L_after_repair

            if 'mean_dose_error_initial' in wafers.columns:
                # use the weighted mean using the number of samples (=die exposures)
                mean_dose_error_initial = np.nansum(wafers['n_dies'] * wafers['mean_dose_error_initial']) / np.nansum(
                    wafers['n_dies'])
                # use the pooled standard deviation  :  https://en.wikipedia.org/wiki/Pooled_variance
                std_dose_error_initial = np.sqrt(
                    np.nansum((wafers['n_dies'] - 1) * wafers['std_dose_error_initial'] ** 2 + \
                        wafers['n_dies'] * (wafers['mean_dose_error_initial'] - mean_dose_error_initial) ** 2) / \
                    (np.nansum(wafers['n_dies']) - 1))
                min_dose_error_initial = np.min(np.nanmin(wafers['min_dose_error_initial']))
                max_dose_error_initial = np.max(np.nanmax(wafers['max_dose_error_initial']))
        else:
            sys_err_lvl, de_max_reexp_lvl, L_initial_asml, L_initial_asml_15p, L_initial_sys, \
            L_repair_sys, mean_dose_error_initial, std_dose_error_initial, min_dose_error_initial, \
            max_dose_error_initial \
                = np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan

        if n_repair_exposures > 0:
            Y_repair = 100 * n_repair_dies_ok_sys / float(n_repair_exposures)
        else:
            Y_repair = np.nan

        # Compile statistics
        lot_stats['lot_start'].append(ts_lot_start)
        lot_stats['lot_stop'].append(ts_lot_stop)
        lot_stats['lot_name'].append(lot.lot_name)
        lot_stats['lot_id'].append(lot.lot_id)
        lot_stats['die_loss_init_asml'].append(L_initial_asml)
        lot_stats['die_loss_init_asml_15p'].append(L_initial_asml_15p)
        lot_stats['die_loss_init_sys'].append(L_initial_sys)
        lot_stats['die_loss_repair_sys'].append(L_repair_sys)
        lot_stats['repair_yield'].append(Y_repair)
        lot_stats['sys_err_lvl'].append(sys_err_lvl)
        lot_stats['de_max_reexp_lvl'].append(de_max_reexp_lvl)
        lot_stats['n_init_dies_nok_asml_15p'].append(n_init_dies_nok_asml_15p)
        lot_stats['n_init_dies_nok_asml'].append(n_init_dies_nok_asml)
        lot_stats['n_init_dies_nok_sys'].append(n_init_dies_nok_sys)
        lot_stats['n_init_dies_unrep'].append(n_init_dies_unrep)
        lot_stats['n_repair_dies_ok_sys'].append(n_repair_dies_ok_sys)
        lot_stats['n_after_repair_nok_sys'].append(n_after_repair_nok_sys)
        lot_stats['n_dies'].append(n_dies)
        lot_stats['n_wafers'].append(n_wafers)
        lot_stats['n_repair_exposures'].append(n_repair_exposures)
        lot_stats['mean_dose_error_initial'].append(mean_dose_error_initial)
        lot_stats['std_dose_error_initial'].append(std_dose_error_initial)
        lot_stats['min_dose_error_initial'].append(min_dose_error_initial)
        lot_stats['max_dose_error_initial'].append(max_dose_error_initial)

    df_lot_stats = pd.DataFrame.from_dict(lot_stats)
    df_lot_stats.index = df_lot_stats.lot_start

    # No LOT statistics available
    if df_lot_stats.empty:
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    if verbose:
        # Summary for debugging
        print("calculate_lot_statistics(): ----- LOT FILTER PROCESS SUMMARY  -----")
        print("calculate_lot_statistics(): Processed LOTs                                :{0}".format(df_lots.shape[0]))
        print("calculate_lot_statistics(): Included: TwinRUNR LOTs                       :{0}".format(n_twinrunr))
        print("calculate_lot_statistics(): Excluded: TM-Tests                            :{0}".format(n_tm_tests))
        print("calculate_lot_statistics(): Excluded: DO mode                             :{0}".format(n_ignored_due_do_mode))
        print("calculate_lot_statistics(): Excluded: cannot determine DO mode            :{0}".format(n_could_not_get_do_mode))
        print("calculate_lot_statistics(): % wafers in lot stats               :{0:.1f}".format(
            100 * float(df_lot_stats.n_wafers.sum()) / len(df_wafer_stats)))
        print("calculate_lot_statistics(): % dies in lot stats                 :{0:.1f}".format(
            100 * float(df_lot_stats.n_dies.sum()) / df_wafer_stats.n_dies.sum()))

    return df_lot_stats


if __name__ == '__main__':

    pd.set_option('display.max_rows', 100)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    source_nr = '44481'
    days_back = 3
    to_time_tmp = pd.Timestamp(2020, 3, 20)

    # from_time = pd.to_datetime('2020-03-28 22:00:00').tz_localize('UTC')
    # to_time = pd.to_datetime('2020-03-28 23:27:20').tz_localize('UTC')

    client = clients.UserLANClient()
    machine_list = get_machines(client)

    import matplotlib.pyplot as plt

    # for source_nr in machine_list.source_nr:
    print(source_nr)
    machine = machine_list.loc[machine_list.source_nr == int(source_nr)].iloc[0]
    to_time = to_time_tmp.tz_localize(machine['timezone']).tz_convert('UTC')
    from_time = to_time - pd.Timedelta(days=days_back)
    source_id = 's' + str(source_nr)

    lot_stats = get_lot_statistics(client, source_id, from_time, to_time)

