"""
Script to calculate dose performance
Author: DAAU

Plugin for ETL3 to calculate Lot statistics from extracted scannerlog data.
"""

import pandas as pd
import numpy as np


def import_dose_data(client,source_id,from_time,to_time):
    """
    This function imports data to be used for the dose performance calculation.

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return: dictionary of dataframes
    """


    print('import_dose_data(): Import data')

    #########################################################
    # Import data needed for the wafer and lot identification
    #########################################################

    # use data of 4 hours back to deal with border between days
    df_dose_error = client.get_signals('{0}.ScannerLog.de_err'.format(source_id), from_time - pd.Timedelta('4h'), to_time)
    # use data of 4 hours back to deal with border between days
    df_dose_id = client.get_signals('{0}.ScannerLog.exposure_handle[*]'.format(source_id), from_time - pd.Timedelta('4h'), to_time)

    #########################################################
    # Import data needed for the lot matching
    #########################################################

    # use data of 4 hours back to deal with border between days
    df_lot_name = client.get_signals('{0}.ScannerLog.lot_name[*]'.format(source_id), from_time - pd.Timedelta('4h'), to_time)
    df_lot_id = client.get_signals('{0}.ScannerLog.lot_id'.format(source_id), from_time, to_time)

    #########################################################
    # Import data needed for the wafer statistics
    #########################################################

    df_ke_signal = client.get_signals('{0}.ScannerLog.occurrence[*]'.format(source_id), from_time - pd.Timedelta('4h'), \
        to_time + pd.Timedelta('1d'))  # use data of 4 hours back to deal with border between days

    df_do_mode = client.get_signals('{0}.THCC.THCCGroupDoSignal'.format(source_id), from_time - pd.Timedelta('2d'), to_time)
    if df_do_mode.empty:
        df_do_mode = client.get_last_value_before('{0}.THCC.THCCGroupDoSignal'.format(source_id), from_time)

    df_err_lvl = client.get_signals('{0}.ScannerLog.de_err_lvl'.format(source_id), from_time - pd.Timedelta('2d'), to_time)
    if df_err_lvl.empty:
        df_err_lvl = client.get_last_value_before('{0}.ScannerLog.de_err_lvl'.format(source_id),from_time)

    df_reexp_lvl = client.get_signals('{0}.ScannerLog.de_max_reexp_lvl'.format(source_id), from_time - pd.Timedelta('2d'), to_time)
    if df_reexp_lvl.empty:
        df_reexp_lvl = client.get_last_value_before('{0}.ScannerLog.de_max_reexp_lvl'.format(source_id),from_time)

    df_test_window = client.get_signals('{0}.Filter._TMTestWindows[*]'.format(source_id), from_time - pd.Timedelta('2d'), to_time)
    if df_test_window.empty:
        df_test_window = client.get_last_value_before('{0}.ScannerLog._TMTestWindows[*]'.format(source_id), from_time)


    #########################################################
    # Put all data in a df_dictionary
    #########################################################

    df_dict = {}
    df_dict['df_dose_error'] = df_dose_error
    df_dict['df_dose_id'] = df_dose_id
    df_dict['df_lot_name'] = df_lot_name
    df_dict['df_lot_id'] = df_lot_id
    df_dict['df_ke_signal'] = df_ke_signal
    df_dict['df_do_mode'] = df_do_mode
    df_dict['df_err_lvl'] = df_err_lvl
    df_dict['df_reexp_lvl'] = df_reexp_lvl
    df_dict['df_test_window'] = df_test_window

    #########################################################
    # Convert all data to tz aware data
    #########################################################

    # Force all indices to tz aware
    for key in df_dict.keys():
        try:
            df_dict[key].index = df_dict[key].index.tz_localize('utc')
        except:
            pass

    return df_dict


def import_lot_context(client, source_id, from_time, to_time):
    """
    This function imports lot context data to be used for the lot statistics calculation.

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return: df_lot_context
    """

    print('import_lot_context(): Import data')

    df_lot_context = client.get_signals(['{0}.Dose._LotContext[start]'.format(source_id),
                                         '{0}.Dose._LotContext[stop]'.format(source_id),
                                         '{0}.Dose._LotContext[lot_name]'.format(source_id),
                                         '{0}.Dose._LotContext[lot_id]'.format(source_id)], from_time, to_time)

    try:
        df_lot_context.index = df_lot_context.index.tz_localize('utc')
    except:
        pass

    return df_lot_context


def import_lot_data(client, source_id, from_time, to_time):
    """
    This function imports data to be used for the 4 wk lot aggregation script.

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return: df_lot_stats
    """

    print('import_lot_data(): Import data')

    df_lot_stats = client.get_signals('{0}.Dose._LotStatistics[*]'.format(source_id), from_time, to_time)

    try:
        df_lot_stats.index = df_lot_stats.index.tz_localize('utc')
    except:
        pass

    return df_lot_stats


def import_wafer_data(client, source_id, from_time, to_time):
    """
    This function imports wafer statistics data to be used for the lot statistics calculation.

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return: df_wafer_stats
    """

    print('import_wafer_data(): Import data')

    df_wafer_stats = client.get_signals('{0}.Dose._WaferStatistics[*]'.format(source_id), from_time, to_time)

    try:
        df_wafer_stats.index = df_wafer_stats.index.tz_localize('utc')
    except:
        pass

    return df_wafer_stats
