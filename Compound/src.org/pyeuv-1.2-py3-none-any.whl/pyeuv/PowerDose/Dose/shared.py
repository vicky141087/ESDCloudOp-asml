"""
wafer_lot_aggregation.py
Author: DAAU

Function for dose related calculations
"""

import numpy as np
import pandas as pd

def check_repair_off(df_dose_data_wafer, sys_err_lvl, de_max_reexp_lvl):
    """
    Check if repair is off or on based on system error level and maximum level for die repair

    :param matched_data: all matched dose errros of idea and the scanner
    :return: arrays with true/false indicating whether a dose error has a potential positive value
    """

    repair_off_range = (abs(df_dose_data_wafer['dose_error']) > sys_err_lvl) & \
                                      (abs(df_dose_data_wafer['dose_error']) < de_max_reexp_lvl) & \
                                      (df_dose_data_wafer['error_code'] == 'DW-3425')
    return repair_off_range

def generate_repair_signal(df_ke_signal):
    """
    Generates a 0/1 signal based on repair start and stop signals (KE-7228/7229)

    :param df_ke_signal: dataframe with repair start and stop signals (KE-7228/7229)
    :return: repair on/off signal
    """
    if not df_ke_signal.empty:
        df_ke_signal.loc[df_ke_signal['code'] == 'KE-7228', 'value'] = 1
        df_ke_signal.loc[df_ke_signal['code'] == 'KE-7229', 'value'] = 0
        df_ke_signal.dropna()
        df_ke_signal.rename(columns={'value': 'ke_signal'}, inplace=True)
        df_repair_signal = df_ke_signal[['ke_signal']].copy()
    else:
        df_repair_signal = pd.DataFrame(columns=['ke_signal'], index=pd.to_datetime([], utc=True))
    df_repair_signal.index = pd.DatetimeIndex(df_repair_signal.index)  # .tz_convert(None)

    return df_repair_signal

def cast_for_influxdb(df_data, key=None):
    """
    This function prepares the data to be ingested by InfluxDB. Non-index timestamps are converted to unix timestamps.
    Integer are made np.int64, and floats np.float64.

    :param df_data: data frame with values to be casted
    :param key: Signal name
    :return: data frame with casted values
    """

    if key == 'df_wafer_windows':
        # Convert Timestamp objects to unix timestamps (InfluxDBClient doesn't like timestamps as values)
        df_data['wafer_start'] = (
                    pd.to_numeric(df_data['wafer_start']) / 1e9).astype(np.int64)  # [ns] -> [s]
        df_data['wafer_stop'] = (pd.to_numeric(df_data['wafer_stop']) / 1e9).astype(
            np.int64)
        # Cast dtypes
        df_data['n_dies'] = df_data['n_dies'].astype(np.int64)
        df_data['delta_time_between_wafers'] = df_data[
            'delta_time_between_wafers'].astype(np.float64)

    if key == 'df_wafer_signal':
        df_data = df_data['value'].astype(np.int64)

    if key == 'df_lot_context':
        # Convert Timestamp objects to unix timestamps (InfluxDBClient doesn't like timestamps as values)
        df_data['start'] = (pd.to_numeric(df_data['start']) / 1e9).astype(np.int64)    # [ns] -> [s]
        df_data['stop'] = (pd.to_numeric(df_data['stop']) / 1e9).astype(np.int64)
        # cast lot_id as integer
        df_data['lot_id'] = df_data['lot_id'].astype(np.int64)
        df_data['lot_signal'] = df_data['lot_signal'].astype(np.int64)

    if key == 'df_wafer_stats':
        # Convert Timestamp objects to unix timestamps (InfluxDBClient doesn't like timestamps as values)
        df_data['wafer_start'] = (pd.to_numeric(df_data['wafer_start']) / 1e9).astype(np.int64)
        df_data['wafer_stop'] = (pd.to_numeric(df_data['wafer_stop']) / 1e9).astype(np.int64)

        # Forcefully cast types so Influx always recognises the correct type
        int_keys = [c for c in df_data.columns if c.startswith('n_')]
        for k in int_keys:
            df_data[k] = df_data[k].astype(np.int64)

        float_keys = ['die_loss_init_asml', 'die_loss_init_asml_15p', 'die_loss_init_sys', 'die_loss_repair_sys',
                      'max_dose_error_initial',
                      'mean_dose_error_initial', 'repair_yield', 'std_dose_error_initial', 'sys_err_lvl', 'de_max_reexp_lvl'
                      ]

        for k in float_keys:
            df_data[k] = df_data[k].astype(np.float64)

    if key == 'df_lot_stats':
        # Convert Timestamp objects to unix timestamps (InfluxDBClient doesn't like timestamps as values)
        df_data['lot_start'] = (pd.to_numeric(df_data['lot_start']) / 1e9).astype(np.int64)
        df_data['lot_stop'] = (pd.to_numeric(df_data['lot_stop']) / 1e9).astype(np.int64)

        # Forcefully cast types so Influx always recognises the correct type
        int_keys = [c for c in df_data.columns if c.startswith('n_')]
        for k in int_keys:
            df_data[k] = df_data[k].astype(np.int64)

        float_keys = [
            'die_loss_init_asml',
            'die_loss_init_asml_15p',
            'die_loss_init_sys',
            'die_loss_repair_sys',
            'min_dose_error_initial',
            'max_dose_error_initial',
            'mean_dose_error_initial',
            'std_dose_error_initial',
            'repair_yield',
            'sys_err_lvl',
            'de_max_reexp_lvl'
        ]

        for k in float_keys:
            df_data[k] = df_data[k].astype(np.float64)

    if key == 'df_day_stats':
        # Forcefully cast types so Influx always recognises the correct type
        int_keys = [c for c in df_data.columns if c.startswith('n_')]
        for k in int_keys:
            df_data[k] = df_data[k].astype(np.int64)

        float_keys = ['die_loss_init_asml',
                      'die_loss_init_asml_15p',
                      'die_loss_init_sys',
                      'die_loss_repair_sys',
                      'repair_yield',
                      'mean_dose_error_initial',
                      'std_dose_error_initial',
                      'min_dose_error_initial',
                      'max_dose_error_initial']
        for k in float_keys:
            df_data[k] = df_data[k].astype(np.float64)

    if key == 'df_4wks_stats':
        # Forcefully cast types so Influx always recognises the correct type
        int_keys = [c for c in df_data.columns if (c.startswith('n_') & ('n_wafers' not in c) & ('n_init_dies_unrep' not in c))]
        for k in int_keys:
            df_data[k] = df_data[k].astype(np.int64)

        float_keys = [
            'die_loss_init_asml',
            'die_loss_init_asml_15p',
            'die_loss_init_sys',
            'die_loss_repair_sys',
            'repair_yield',
            'percentage_repairs',
            'n_wafers',
            'n_init_dies_unrep',
            'mean_dose_error_initial',
            'std_dose_error_initial',
            'min_dose_error_initial',
            'max_dose_error_initial'
        ]
        for k in float_keys:
            df_data[k] = df_data[k].astype(np.float64)

    return df_data
