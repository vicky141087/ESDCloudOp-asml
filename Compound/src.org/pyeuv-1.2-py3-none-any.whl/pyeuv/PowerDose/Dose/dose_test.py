"""
Script to test the new lot signal
Author: DAAU

"""

import pandas as pd
import numpy as np

from pyeuv.Shared.wafer_lot_aggregation import add_diff_time
from pyeuv.Shared.filters import aliased_aggr
from pyeuv.EUVDashboard import clients

def check_for_duplicates_lot_stats(df_lot_stats):
    """
    Check for duplicates in new lot stats signal by checking subsequent lots with the same lot name and id.

    :param df_lot_stats: lot stats dataframe
    :return: lot stats dataframe with duplicates removed
    """

    check_duplicates = df_lot_stats.loc[df_lot_stats.lot_name.duplicated(keep=False)].groupby('lot_name').agg(
        {'lot_id': ['max', 'min']})
    check_duplicates.columns = ['_'.join(col) for col in check_duplicates.columns]
    check_duplicates['diff'] = check_duplicates.lot_id_max - check_duplicates.lot_id_min
    print(check_duplicates.loc[check_duplicates['diff'] != 0])

    df_lot_stats.drop_duplicates(subset='lot_name', keep='last', inplace=True)

    return df_lot_stats

def add_lot_context(df_dose_data,df_lot_stats):
    """
    Adding a new and old implementation inclusion tag to the dose data.

    :param df_dose_data: dataframe with dose error data
    :param df_lot_stats: new lot stats dataframe
    :return: dose error dataframe with added lot context
    """

    df_dose_data['lot_new'] = False
    # do loop over lot windows
    for index, lot in df_lot_stats.iterrows():  # Loop trough all LOTs and calculate statistics per LOT
        ts_lot_start = lot.lot_start  # Times are in UTC
        ts_lot_stop = lot.lot_stop
        condition = (df_dose_data.index >= ts_lot_start) & (df_dose_data.index < ts_lot_stop)
        # Calculate die loss for this lot with the 1% ASML spec.
        df_dose_data.loc[condition, 'lot_new'] = True
        df_dose_data.loc[condition, 'lot_id_new'] = lot.lot_id
        df_dose_data.loc[condition, 'lot_name_new'] = lot.lot_name

    return df_dose_data

def create_artificial_lot_stats(df_dose_data, df_lot_stats, df_lot_stats_old):
    """
    Find missing data in by aggregating over the lot data nad compare this to the lot n_dies value.

    :param df_dose_data: dataframe with dose error data
    :param df_lot_stats: new lot stats dataframe
    :return: artificially generated lot stats dataframe
    """

    df_dose_data = add_lot_context(df_dose_data, df_lot_stats, df_lot_stats_old)
    df_dose_data['time'] = df_dose_data.index.copy()
    df_artificial_lot_stats = df_dose_data.groupby('lot_name_old').agg({
        'lot_name_new': 'count',
        'lot_name_old': 'count',
        'time': ['min', 'max']
    })
    df_artificial_lot_stats.columns = ['_'.join(col) for col in df_artificial_lot_stats.columns]
    df_artificial_lot_stats['diff_lot'] = np.nan
    # Calculate the difference in numbers
    df_artificial_lot_stats['diff_lot'] = df_artificial_lot_stats['lot_name_new_count'] - df_artificial_lot_stats[
        'lot_name_old_count']
    print(df_artificial_lot_stats.loc[df_artificial_lot_stats.diff_lot != 0])

    concat_test = pd.concat([df_artificial_lot_stats, df_lot_stats.set_index('lot_name').rename(
                                 columns={'n_dies': 'n_dies_new'}),
                             df_lot_stats_old[['lot_name', 'n_dies']].set_index('lot_name').rename(
                                 columns={'n_dies': 'n_dies_old'})], axis=1, sort=True)
    concat_test['delta'] = concat_test['lot_name_new_count'] - concat_test['n_dies_new']
    print(concat_test.loc[(concat_test['delta'] != 0) & (~concat_test['lot_name_new'].isnull())])

    return concat_test

def create_wafers_and_lots(df_dose_data, min_time_between_wafers):
    """
    Compare the old and new implementation by aggregating all data over the wafers, and subsequently the lots

    :param df_dose_data: dataframe with dose error data
    :param min_time_between_wafers: minimum assumed time between wafers
    :return:
        df_wafer_windows_test: dataframe with wafer windows
        df_lot_windows_test: dataframe with lot windows
    """

    # make wafers
    times_between_wafers_and_lots = df_dose_data.loc[
        df_dose_data['diff_time'] > min_time_between_wafers].copy()
    times_between_wafers_and_lots.loc[:, 'start_wafer_lot'] = np.arange(len(times_between_wafers_and_lots)) + 1
    times_between_wafers_and_lots = times_between_wafers_and_lots[['time', 'start_wafer_lot']].set_index('time')

    # filter the dose error data with the wafer/lot start times
    filtered_data_test = pd.concat([df_dose_data.set_index('time'), times_between_wafers_and_lots], axis=1)
    filtered_data_test['time'] = pd.DatetimeIndex(filtered_data_test.index)
    filtered_data_test['start_wafer_lot'] = filtered_data_test['start_wafer_lot'].fillna(method='ffill')

    # aggregate over the wafers
    df_wafer_windows_test = filtered_data_test.groupby('start_wafer_lot').agg({
        'diff_time': [
            'max', \
            aliased_aggr(lambda x: x.iloc[1:].max(), 'max_after_first'),
            aliased_aggr(lambda x: x.iloc[1:].median(), 'median_after_first'),
            aliased_aggr(lambda x: x.iloc[1:].min(), 'min_after_first')], \
        'start_wafer_lot': ['max', 'count'],
        'lot_name_new': 'max',
        'lot_id_new': 'max',
        'lot_new': 'sum',
        'lot_old': 'sum',
        'time': ['min', 'max', 'count']})
    df_wafer_windows_test.columns = ['_'.join(col) for col in df_wafer_windows_test.columns]
    df_wafer_windows_test.rename(columns={'start_wafer_lot_max': 'wafer_count', \
                                          'time_count': 'n_dies', \
                                          'time_min': 'wafer_start',
                                          'time_max': 'wafer_stop'},
                                 inplace=True)

    # calculate the time between two possible wafers start times
    df_wafer_windows_test['delta_time'] = (
            df_wafer_windows_test.wafer_start - df_wafer_windows_test.wafer_stop.shift(1)).dt.total_seconds()

    df_lot_windows_test = df_wafer_windows_test.groupby('lot_name_new_max').agg({
        'delta_time': [
            aliased_aggr(lambda x: x.iloc[0], 'first'),
            aliased_aggr(lambda x: x.iloc[1:].max(), 'max_after_first'),
            aliased_aggr(lambda x: x.iloc[1:].median(), 'median_after_first'),
            aliased_aggr(lambda x: x.iloc[1:].min(), 'min_after_first')],
        'diff_time_max_after_first': 'max',
        'diff_time_min_after_first': 'min',
        'diff_time_median_after_first': 'median',
    })
    df_lot_windows_test.columns = ['_'.join(col) for col in df_lot_windows_test.columns]

    return df_wafer_windows_test, df_lot_windows_test