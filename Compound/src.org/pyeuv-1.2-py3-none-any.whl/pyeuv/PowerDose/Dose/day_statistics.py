"""
Script to calculate dose performance
Author: DAAU

Plugin for ETL3 to calculate Lot statistics from extracted scannerlog data.
"""

import numpy as np
import pandas as pd
import arrow
import datetime

from pyeuv.PowerDose.Dose.shared import check_repair_off, generate_repair_signal, cast_for_influxdb
from pyeuv.Shared.shared import get_machines
from pyeuv.EUVDashboard import clients
from pyeuv.PowerDose.Dose.dose_io import import_lot_data

pd.set_option('display.max_rows', 100)
pd.set_option('display.max_columns', 500)
pd.set_option('display.width', 1000)


def get_day_statistics(client, source_id, from_time, to_time):
    """
    Makes the following analysis:
    - calculate day statistics

    :param client: client to access the influxdb data
    :param source_id: source id
    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :return:
        df_day_stats: signal with die yield statistics information aggregated over a day
    """

    # get machine info
    machine_list = get_machines(client)
    machine = machine_list.loc[machine_list.source_nr == int(source_id[1:])].iloc[0]

    # expand start time to start of day in the timezone of the machine, to avoid issues for day aggregation (done over
    # the timezone of the machine)
    from_time = from_time.tz_convert(machine['timezone']).floor('d').tz_convert('utc')

    df_dict = dict()
    df_dict['df_lot_stats'] = import_lot_data(client, source_id, from_time, to_time)
    df_dict['machine'] = machine

    day_statistics = calculate_day_statistics(from_time, to_time, df_dict)

    # cast for influxdb
    if not day_statistics.empty:
        day_statistics = cast_for_influxdb(day_statistics, key='df_day_stats')
    else:
        print('cast_for_influxdb(): No day_stats data available.')

    return day_statistics


def calculate_day_statistics(from_time, to_time, df_dict, verbose=False):
    """
    Calculate statistics for each day using the lot statistics signal.
    Calculation details can be found in D000425286-03-EPS_EUV_Dashboard_Die_Yield_Calculation

    :param from_time: start time of calculation
    :param to_time: stop time of calculation
    :param df_lot_stats: signal with die yield statistics information aggregated over a lot
    :return:
        df_day_stats: dataframe with die yield statistics information aggregated over a day
    """

    try:
        df_lot_stats = df_dict['df_lot_stats']
    except:
        print('calculate_day_statistics(): df_lot_stats not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))

    machine = df_dict['machine']

    # check for sufficient data
    if df_lot_stats.empty:
        print('calculate_day_statistics(): df_lot_stats not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))
    if machine.empty:
        print('calculate_day_statistics(): machine info not available')
        return pd.DataFrame(index=pd.to_datetime([]).tz_localize('UTC'))


    # Calculate die yield statistics over the entire day (Localtime)
    day_die_stats = {
        'n_init_dies_nok_asml': [],
        'n_init_dies_nok_asml_15p': [],
        'n_init_dies_nok_sys': [],
        'n_init_dies_unrep': [],
        'n_repair_dies_ok_sys': [],
        'n_after_repair_nok_sys': [],
        'n_dies': [],
        'n_wafers': [],
        'n_lots': [],
        'n_repair_exposures': [],
        'die_loss_init_asml': [],
        'die_loss_init_asml_15p': [],
        'die_loss_init_sys': [],
        'die_loss_repair_sys': [],
        'repair_yield': [],
        'mean_dose_error_initial': [],
        'std_dose_error_initial': [],
        'min_dose_error_initial': [],
        'max_dose_error_initial': [],
    }

    # We've calculated the stats for each lot, now use those results to calculate the day aggregates.
    day_timestamps = []

    day_from_time = from_time.tz_convert(machine['timezone']).ceil('d').tz_convert('utc')
    day_to_time = to_time.tz_convert(machine['timezone']).floor('d').tz_convert('utc')

    # only consider the time range of full days
    for ts in pd.date_range(day_from_time, day_to_time - pd.Timedelta('1d')):

        ts_day_start = ts
        ts_day_stop = ts + pd.Timedelta('1d')

        lots = df_lot_stats.loc[
            (df_lot_stats['lot_start'] >= ts_day_start) &
            (df_lot_stats['lot_stop'] < ts_day_stop)
            ].copy()

        n_init_dies_nok_asml = np.nansum(lots['n_init_dies_nok_asml'])
        n_init_dies_nok_asml_15p = np.nansum(lots['n_init_dies_nok_asml_15p'])
        n_init_dies_nok_sys = np.nansum(lots['n_init_dies_nok_sys'])
        n_init_dies_unrep = np.nansum(lots['n_init_dies_unrep'])
        n_repair_dies_ok_sys = np.nansum(lots['n_repair_dies_ok_sys'])
        n_repair_exposures = np.nansum(lots['n_repair_exposures'])
        n_dies = np.nansum(lots['n_dies'])
        n_wafers = np.nansum(lots['n_wafers'])
        n_lots = len(lots)

        if 'n_after_repair_nok_sys' in lots.columns:
            n_after_repair_nok_sys = np.nansum(lots['n_after_repair_nok_sys'])
        else:
            n_after_repair_nok_sys = n_init_dies_nok_sys - n_repair_dies_ok_sys  # this gives sometimes the wrong results, \
            # because in the past there were some cases where the lot window got either truncated or extended because of \
            # misalignment, leading to either too many initial exposures (from the next lot), or too few repair exposures.

        if n_dies > 0:
            L_initial_asml = 100 * n_init_dies_nok_asml / float(n_dies)
            L_initial_asml_15p = 100 * n_init_dies_nok_asml_15p / float(n_dies)
            L_initial_sys = 100 * n_init_dies_nok_sys / float(n_dies)
            L_repair_sys = 100 * n_after_repair_nok_sys / float(n_dies)

            if 'mean_dose_error_initial' in lots.columns:
                # use the weighted mean ; weights are the number of samples (=die exposures)
                mean_dose_error_initial = np.nansum(lots['n_dies'] * lots['mean_dose_error_initial']) / np.nansum(
                    lots['n_dies'])
                # use the pooled standard deviation  :  https://en.wikipedia.org/wiki/Pooled_variance
                std_dose_error_initial = np.sqrt(np.nansum((lots['n_dies'] - 1) * lots['std_dose_error_initial'] ** 2 + \
                    lots['n_dies'] * (lots['mean_dose_error_initial'] - mean_dose_error_initial) ** 2) / \
                    (np.nansum(lots['n_dies']) - 1))
                min_dose_error_initial = np.min(np.nanmin(lots['min_dose_error_initial']))
                max_dose_error_initial = np.max(np.nanmax(lots['max_dose_error_initial']))
        else:
            L_initial_asml, L_initial_asml_15p, L_initial_sys, \
            L_repair_sys, mean_dose_error_initial, std_dose_error_initial, min_dose_error_initial, \
            max_dose_error_initial \
                = np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan

        if n_repair_exposures > 0:
            Y_repair = 100 * n_repair_dies_ok_sys / float(n_repair_exposures)
        else:
            Y_repair = np.nan

        day_timestamps.append(ts_day_start)
        day_die_stats['die_loss_init_asml'].append(L_initial_asml)
        day_die_stats['die_loss_init_asml_15p'].append(L_initial_asml_15p)
        day_die_stats['die_loss_init_sys'].append(L_initial_sys)
        day_die_stats['die_loss_repair_sys'].append(L_repair_sys)
        day_die_stats['repair_yield'].append(Y_repair)
        day_die_stats['n_dies'].append(n_dies)
        day_die_stats['n_wafers'].append(n_wafers)
        day_die_stats['n_lots'].append(n_lots)
        day_die_stats['n_repair_exposures'].append(n_repair_exposures)
        day_die_stats['n_init_dies_nok_asml'].append(n_init_dies_nok_asml)
        day_die_stats['n_init_dies_nok_asml_15p'].append(n_init_dies_nok_asml_15p)
        day_die_stats['n_init_dies_nok_sys'].append(n_init_dies_nok_sys)
        day_die_stats['n_init_dies_unrep'].append(n_init_dies_unrep)
        day_die_stats['n_repair_dies_ok_sys'].append(n_repair_dies_ok_sys)
        day_die_stats['n_after_repair_nok_sys'].append(n_after_repair_nok_sys)
        day_die_stats['mean_dose_error_initial'].append(mean_dose_error_initial)
        day_die_stats['std_dose_error_initial'].append(std_dose_error_initial)
        day_die_stats['min_dose_error_initial'].append(min_dose_error_initial)
        day_die_stats['max_dose_error_initial'].append(max_dose_error_initial)

    df_day_stats = pd.DataFrame.from_dict(day_die_stats)
    df_day_stats.index = day_timestamps

    if verbose:
        # Summary for debugging
        print("calculate_day_statistics(): ----- DAY AGGREGATE SUMMARY -----")
        print("calculate_day_statistics(): Processed days                   :{0}".format(abs((day_from_time - day_to_time).days)))

    df_dict['df_day_stats'] = df_day_stats

    return df_day_stats


if __name__ == '__main__':

    pd.set_option('display.max_rows', 100)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)

    source_nr = '44481'
    days_back = 3
    to_time_tmp = pd.Timestamp(2020, 3, 20)

    # from_time = pd.to_datetime('2020-03-28 22:00:00').tz_localize('UTC')
    # to_time = pd.to_datetime('2020-03-28 23:27:20').tz_localize('UTC')

    client = clients.UserLANClient()
    machine_list = get_machines(client)

    import matplotlib.pyplot as plt

    # for source_nr in machine_list.source_nr:
    print(source_nr)
    machine = machine_list.loc[machine_list.source_nr == int(source_nr)].iloc[0]
    to_time = to_time_tmp.tz_localize(machine['timezone']).tz_convert('UTC')
    from_time = to_time - pd.Timedelta(days=days_back)
    source_id = 's' + str(source_nr)

    day_stats = get_day_statistics(client, source_id, from_time, to_time)
